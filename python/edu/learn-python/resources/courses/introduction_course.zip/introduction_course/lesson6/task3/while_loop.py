count = 1

while count <= 10:
    print(count)    # This code is executed 10 times
    count += 1      # This code is executed 10 times

print("Finished")  # This code is executed once

count = 0
number = 1

print all squares from 0 to 99
    count = number ** 2
    print(count)
    number += 1