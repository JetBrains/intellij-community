name = "John"
age = 17

print(name == "John" or not age > 17)

print("name" is "Ellis" or not ("name" equal "John" and he is 17 years old))