a = b = 2  # chained assignment. Assign both "a" and "b" variables to 2
print("a = " + str(a))   # We'll explain str(a) expression later in course. For now it is used to convert variable "a" to a string.
print("b = " + str(b))

greetings = "greetings"
print("greetings = " + str(greetings))
greetings = another value
print("greetings = " + str(greetings))