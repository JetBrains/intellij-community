phrase = """
it's a really long string
triple-quoted strings are used
to define multi-line strings
"""
first_half = type here
print(first_half)
