python = "Python"
print("h " + python[3])     # Note: string indexing starts with 0

p_letter = type here
print(p_letter)
