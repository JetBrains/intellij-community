hello = "hello"
ten_of_hellos = hello operator 10
print(ten_of_hellos)