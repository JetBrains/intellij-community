import datetime

print(current date)