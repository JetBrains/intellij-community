""" documentation string for module my_module
This module contains hello_world function
"""


def hello_world():
    return "Hello, World!"