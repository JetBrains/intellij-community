
from calculator import Calculator

calc = Calculator()    # here we can use Calculator class directly without prefix calculator.
calc.add(2)
print(calc.get_current())

import hello_world from my_module

print(hello_world())    # Note: hello_world function used without prefix