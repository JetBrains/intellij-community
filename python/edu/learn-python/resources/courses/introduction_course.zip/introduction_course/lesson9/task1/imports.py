
import calculator

calc = calculator.Calculator()    # create new instance of Calculator class defined in calculator module
calc.add(2)
print(calc.get_current())

here import my_module

call function hello_world from my_module