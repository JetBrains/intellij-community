def foo():
	return 'Foo'