hello = "Hello"
world = 'World'

hello_world = type here
print(hello_world)      # Note: you should print "Hello World"
