monty_python = "Monty Python"
print(monty_python)

print(monty_python.lower())    # print lower-cased version of the string

print(upper cased monty_python)
