long_string = "This is a very long string!"
exclamation = type here
print(exclamation)
