a = b = 2  # This is called a "chained assignment". It assigns the value 2 to variables "a" and "b".
print("a = " + str(a))   # We'll explain the expression str(a) later in the course. For now it is used to convert the  variable "a" to a string.
print("b = " + str(b))

greetings = "greetings"
print("greetings = " + str(greetings))
greetings = another value
print("greetings = " + str(greetings))
