number = 9
print(type(number))   # print type of variable "number"

float_number = 9.0
print(float_number)
print(Convert float_number to integer)
