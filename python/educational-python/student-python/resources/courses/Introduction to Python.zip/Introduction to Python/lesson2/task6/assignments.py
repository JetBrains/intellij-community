number = 9.0
print("number = " + str(number))

number -= 2
print("number = " + str(number))

number operator 5

print("number = " + str(number))
