print("Hello, world! My name is type your name")
