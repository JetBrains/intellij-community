def hello_world():  # function named my_function
    print("Hello, World!")

for i in range(5):
    hello_world()   # call function defined above 5 times

print('I want to be a function')
print('I want to be a function')
print('I want to be a function')


define a function named 'fun' to replace three lines above
    print('I want to be a function')

for i in range(3):
    fun()
