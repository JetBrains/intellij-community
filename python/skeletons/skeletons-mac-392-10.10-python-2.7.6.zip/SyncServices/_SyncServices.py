# encoding: utf-8
# module SyncServices._SyncServices
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/SyncServices/_SyncServices.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
