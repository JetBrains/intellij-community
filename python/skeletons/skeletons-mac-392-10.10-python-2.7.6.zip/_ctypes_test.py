# encoding: utf-8
# module _ctypes_test
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_ctypes_test.so
# by generator 1.136
# no doc
# no imports

# functions

def func(*args, **kwargs): # real signature unknown
    pass

def func_si(*args, **kwargs): # real signature unknown
    pass

# no classes
