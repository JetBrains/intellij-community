# encoding: utf-8
# module _scproxy
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_scproxy.so
# by generator 1.136
# no doc
# no imports

# functions

def _get_proxies(*args, **kwargs): # real signature unknown
    pass

def _get_proxy_settings(*args, **kwargs): # real signature unknown
    pass

# no classes
