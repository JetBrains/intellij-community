# encoding: utf-8
# module WebKit._WebKit
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/WebKit/_WebKit.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
