# encoding: utf-8
# module OSATerminology
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/OSATerminology.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
