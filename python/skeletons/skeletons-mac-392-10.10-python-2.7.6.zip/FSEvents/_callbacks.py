# encoding: utf-8
# module FSEvents._callbacks
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/FSEvents/_callbacks.so
# by generator 1.136
# no doc
# no imports

# functions

def FSEventStreamCreate(allocator, callback, callback_info, pathsToWatch, sinceWhen, latency, flags): # real signature unknown; restored from __doc__
    """
    FSEventStreamCreate(allocator, callback, callback_info, 
    	pathsToWatch, sinceWhen, latency, flags) -> stream
    
    NOTE: the callback info is passed directly, it is not a structure as
    it is in C
    """
    pass

def FSEventStreamCreateRelativeToDevice(*args, **kwargs): # real signature unknown
    """
    FSEventStreamCreate(allocator, callback, callback_info, 
    	deviceToWatch, pathsToWatchRelativeToDevice, sinceWhen, 
    	latency, flags) -> stream
    
    NOTE: the callback info is passed directly, it is not a structure as
    it is in C
    """
    pass

# no classes
