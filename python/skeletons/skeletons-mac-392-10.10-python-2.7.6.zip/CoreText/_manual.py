# encoding: utf-8
# module CoreText._manual
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/CoreText/_manual.so
# by generator 1.136
# no doc
# no imports

# Variables with simple values

sizeof_CGFloat = 8
sizeof_CTLineBreakMode = 1
sizeof_CTTextAlignment = 1
sizeof_CTWritingDirection = 1
sizeof_id = 8

# functions

def CTFontCopyAvailableTables(*args, **kwargs): # real signature unknown
    pass

def CTParagraphStyleCreate(*args, **kwargs): # real signature unknown
    pass

def CTParagraphStyleGetTabStops(style): # real signature unknown; restored from __doc__
    """ CTParagraphStyleGetTabStops(style) -> (stop, ...) """
    pass

# no classes
