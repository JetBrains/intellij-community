# encoding: utf-8
# module matplotlib._tri
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/matplotlib/_tri.so
# by generator 1.136
# no doc
# no imports

# functions

def TrapezoidMapTriFinder(*args, **kwargs): # real signature unknown
    """ Create and return new C++ TrapezoidMapTriFinder object """
    pass

def Triangulation(*args, **kwargs): # real signature unknown
    """ Create and return new C++ Triangulation object """
    pass

def TriContourGenerator(*args, **kwargs): # real signature unknown
    """ Create and return new C++ TriContourGenerator object """
    pass

# no classes
