# encoding: utf-8
# module matplotlib.backends._backend_agg
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/matplotlib/backends/_backend_agg.so
# by generator 1.136
""" The agg rendering backend """
# no imports

# functions

def RendererAgg(width, height, dpi): # real signature unknown; restored from __doc__
    """ RendererAgg(width, height, dpi) """
    pass

# no classes
