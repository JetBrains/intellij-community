# encoding: utf-8
# module matplotlib.backends._tkagg
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/matplotlib/backends/_tkagg.so
# by generator 1.136
# no doc
# no imports

# functions

def tkinit(*args, **kwargs): # real signature unknown
    pass

def _pyobj_addr(*args, **kwargs): # real signature unknown
    pass

# no classes
