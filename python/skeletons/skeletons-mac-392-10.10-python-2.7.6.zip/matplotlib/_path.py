# encoding: utf-8
# module matplotlib._path
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/matplotlib/_path.so
# by generator 1.136
""" Helper functions for paths """
# no imports

# functions

def affine_transform(vertices, transform): # real signature unknown; restored from __doc__
    """ affine_transform(vertices, transform) """
    pass

def cleanup_path(path, trans, remove_nans, clip, snap, simplify, curves, sketch_params): # real signature unknown; restored from __doc__
    """ cleanup_path(path, trans, remove_nans, clip, snap, simplify, curves, sketch_params) """
    pass

def clip_path_to_rect(path, bbox, inside): # real signature unknown; restored from __doc__
    """ clip_path_to_rect(path, bbox, inside) """
    pass

def convert_path_to_polygons(path, trans, width, height): # real signature unknown; restored from __doc__
    """ convert_path_to_polygons(path, trans, width, height) """
    pass

def convert_to_svg(path, trans, clip, simplify, precision): # real signature unknown; restored from __doc__
    """ convert_to_svg(path, trans, clip, simplify, precision) """
    pass

def count_bboxes_overlapping_bbox(bbox, bboxes): # real signature unknown; restored from __doc__
    """ count_bboxes_overlapping_bbox(bbox, bboxes) """
    pass

def get_path_collection_extents(trans, paths, transforms, offsets, offsetTrans): # real signature unknown; restored from __doc__
    """ get_path_collection_extents(trans, paths, transforms, offsets, offsetTrans) """
    pass

def get_path_extents(path, trans): # real signature unknown; restored from __doc__
    """ get_path_extents(path, trans) """
    pass

def path_intersects_path(p1, p2): # real signature unknown; restored from __doc__
    """ path_intersects_path(p1, p2) """
    pass

def path_in_path(a, atrans, b, btrans): # real signature unknown; restored from __doc__
    """ path_in_path(a, atrans, b, btrans) """
    pass

def points_in_path(points, path, trans): # real signature unknown; restored from __doc__
    """ points_in_path(points, path, trans) """
    pass

def point_in_path(x, y, path, trans): # real signature unknown; restored from __doc__
    """ point_in_path(x, y, path, trans) """
    pass

def point_in_path_collection(x, y, r, trans, paths, transforms, offsets, offsetTrans, filled): # real signature unknown; restored from __doc__
    """ point_in_path_collection(x, y, r, trans, paths, transforms, offsets, offsetTrans, filled) """
    pass

def point_on_path(x, y, r, path, trans): # real signature unknown; restored from __doc__
    """ point_on_path(x, y, r, path, trans) """
    pass

def update_path_extents(path, trans, bbox, minpos): # real signature unknown; restored from __doc__
    """ update_path_extents(path, trans, bbox, minpos) """
    pass

# no classes
