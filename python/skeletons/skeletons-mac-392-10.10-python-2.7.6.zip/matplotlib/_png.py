# encoding: utf-8
# module matplotlib._png
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/matplotlib/_png.so
# by generator 1.136
""" Module to write PNG files """
# no imports

# functions

def read_png(fileobj): # real signature unknown; restored from __doc__
    """ read_png(fileobj) """
    pass

def read_png_float(fileobj): # real signature unknown; restored from __doc__
    """ read_png_float(fileobj) """
    pass

def read_png_int(fileobj): # real signature unknown; restored from __doc__
    """ read_png_int(fileobj) """
    pass

def read_png_uint8(fileobj): # real signature unknown; restored from __doc__
    """ read_png_uint8(fileobj) """
    pass

def write_png(buffer, width, height, fileobj, dpi=None): # real signature unknown; restored from __doc__
    """ write_png(buffer, width, height, fileobj, dpi=None) """
    pass

# no classes
