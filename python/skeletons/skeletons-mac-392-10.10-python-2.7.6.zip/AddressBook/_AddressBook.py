# encoding: utf-8
# module AddressBook._AddressBook
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/AddressBook/_AddressBook.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
