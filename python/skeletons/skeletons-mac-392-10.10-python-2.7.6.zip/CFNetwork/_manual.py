# encoding: utf-8
# module CFNetwork._manual
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/CFNetwork/_manual.so
# by generator 1.136
# no doc
# no imports

# functions

def CFHostSetClient(*args, **kwargs): # real signature unknown
    pass

def CFNetworkExecuteProxyAutoConfigurationScript(*args, **kwargs): # real signature unknown
    pass

def CFNetworkExecuteProxyAutoConfigurationURL(*args, **kwargs): # real signature unknown
    pass

# no classes
