# encoding: utf-8
# module gestalt
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/gestalt.so
# by generator 1.136
# no doc
# no imports

# functions

def gestalt(*args, **kwargs): # real signature unknown
    pass

# no classes
