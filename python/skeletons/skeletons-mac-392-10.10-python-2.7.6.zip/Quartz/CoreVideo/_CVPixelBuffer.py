# encoding: utf-8
# module Quartz.CoreVideo._CVPixelBuffer
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/Quartz/CoreVideo/_CVPixelBuffer.so
# by generator 1.136
# no doc
# no imports

# functions

def CVPixelBufferCreateWithBytes(*args, **kwargs): # real signature unknown
    pass

# no classes
