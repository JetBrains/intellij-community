# encoding: utf-8
# module Quartz.CoreGraphics._doubleindirect
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/Quartz/CoreGraphics/_doubleindirect.so
# by generator 1.136
# no doc
# no imports

# functions

def CGReleaseScreenRefreshRects(*args, **kwargs): # real signature unknown
    pass

def CGWaitForScreenRefreshRects(*args, **kwargs): # real signature unknown
    pass

def CGWaitForScreenUpdateRects(*args, **kwargs): # real signature unknown
    pass

# no classes
