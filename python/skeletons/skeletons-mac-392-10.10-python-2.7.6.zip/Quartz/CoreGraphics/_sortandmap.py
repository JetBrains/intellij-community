# encoding: utf-8
# module Quartz.CoreGraphics._sortandmap
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/Quartz/CoreGraphics/_sortandmap.so
# by generator 1.136
# no doc
# no imports

# functions

def CGPathApply(*args, **kwargs): # real signature unknown
    pass

def CGPDFDictionaryApplyFunction(*args, **kwargs): # real signature unknown
    pass

def setCGPathElement(*args, **kwargs): # real signature unknown
    pass

# no classes
