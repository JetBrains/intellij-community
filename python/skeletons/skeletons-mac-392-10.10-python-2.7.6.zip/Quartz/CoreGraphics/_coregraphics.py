# encoding: utf-8
# module Quartz.CoreGraphics._coregraphics
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/Quartz/CoreGraphics/_coregraphics.so
# by generator 1.136
# no doc
# no imports

# functions

def CGBitmapContextCreate(*args, **kwargs): # real signature unknown
    pass

def CGBitmapContextCreateWithData(*args, **kwargs): # real signature unknown
    pass

def CGFontCopyTableTags(*args, **kwargs): # real signature unknown
    pass

def CGWindowListCreate(*args, **kwargs): # real signature unknown
    pass

def CGWindowListCreateDescriptionFromArray(*args, **kwargs): # real signature unknown
    pass

def CGWindowListCreateImageFromArray(*args, **kwargs): # real signature unknown
    pass

# no classes
