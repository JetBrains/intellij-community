# encoding: utf-8
# module numpy.linalg.lapack_lite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/linalg/lapack_lite.so
# by generator 1.136
# no doc
# no imports

# functions

def dgeev(*args, **kwargs): # real signature unknown
    pass

def dgelsd(*args, **kwargs): # real signature unknown
    pass

def dgeqrf(*args, **kwargs): # real signature unknown
    pass

def dgesdd(*args, **kwargs): # real signature unknown
    pass

def dgesv(*args, **kwargs): # real signature unknown
    pass

def dgetrf(*args, **kwargs): # real signature unknown
    pass

def dorgqr(*args, **kwargs): # real signature unknown
    pass

def dpotrf(*args, **kwargs): # real signature unknown
    pass

def dsyevd(*args, **kwargs): # real signature unknown
    pass

def xerbla(*args, **kwargs): # real signature unknown
    pass

def zgeev(*args, **kwargs): # real signature unknown
    pass

def zgelsd(*args, **kwargs): # real signature unknown
    pass

def zgeqrf(*args, **kwargs): # real signature unknown
    pass

def zgesdd(*args, **kwargs): # real signature unknown
    pass

def zgesv(*args, **kwargs): # real signature unknown
    pass

def zgetrf(*args, **kwargs): # real signature unknown
    pass

def zheevd(*args, **kwargs): # real signature unknown
    pass

def zpotrf(*args, **kwargs): # real signature unknown
    pass

def zungqr(*args, **kwargs): # real signature unknown
    pass

# classes

class LapackError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



