# encoding: utf-8
# module numpy.core.scalarmath
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/scalarmath.so
# by generator 1.136
# no doc
# no imports

# functions

def alter_pythonmath(*args, **kwargs): # real signature unknown
    """  """
    pass

def restore_pythonmath(*args, **kwargs): # real signature unknown
    """  """
    pass

def use_pythonmath(*args, **kwargs): # real signature unknown
    """  """
    pass

def use_scalarmath(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
