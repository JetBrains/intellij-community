# encoding: utf-8
# module numpy.core.struct_ufunc_test
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/struct_ufunc_test.so
# by generator 1.136
# no doc
# no imports

# functions

def add_triplet(x1, x2, out=None): # real signature unknown; restored from __doc__
    """
    add_triplet(x1, x2[, out])
    
    add_triplet_docstring
    """
    pass

# no classes
