# encoding: utf-8
# module numpy.core.operand_flag_tests
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/operand_flag_tests.so
# by generator 1.136
# no doc
# no imports

# functions

def inplace_add(x1, x2): # real signature unknown; restored from __doc__
    """
    inplace_add(x1, x2)
    
    inplace_add_docstring
    """
    pass

# no classes
