# encoding: utf-8
# module numpy.core.multiarray_tests
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/multiarray_tests.so
# by generator 1.136
# no doc
# no imports

# functions

def get_buffer_info(*args, **kwargs): # real signature unknown
    pass

def test_inplace_increment(*args, **kwargs): # real signature unknown
    pass

def test_int_subclass(*args, **kwargs): # real signature unknown
    pass

def test_neighborhood_iterator(*args, **kwargs): # real signature unknown
    pass

def test_neighborhood_iterator_oob(*args, **kwargs): # real signature unknown
    pass

def test_pydatamem_seteventhook_end(*args, **kwargs): # real signature unknown
    pass

def test_pydatamem_seteventhook_start(*args, **kwargs): # real signature unknown
    pass

# no classes
