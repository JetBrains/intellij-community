# encoding: utf-8
# module numpy.core._dummy
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/_dummy.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
