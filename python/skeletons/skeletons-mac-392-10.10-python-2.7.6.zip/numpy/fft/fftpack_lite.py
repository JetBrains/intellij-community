# encoding: utf-8
# module numpy.fft.fftpack_lite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/fft/fftpack_lite.so
# by generator 1.136
# no doc
# no imports

# functions

def cfftb(*args, **kwargs): # real signature unknown
    """  """
    pass

def cfftf(*args, **kwargs): # real signature unknown
    """  """
    pass

def cffti(*args, **kwargs): # real signature unknown
    """  """
    pass

def rfftb(*args, **kwargs): # real signature unknown
    """  """
    pass

def rfftf(*args, **kwargs): # real signature unknown
    """  """
    pass

def rffti(*args, **kwargs): # real signature unknown
    """  """
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



