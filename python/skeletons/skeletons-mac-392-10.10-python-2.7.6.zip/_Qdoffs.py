# encoding: utf-8
# module _Qdoffs
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_Qdoffs.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
