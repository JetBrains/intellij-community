# encoding: utf-8
# module CoreFoundation._CoreFoundation
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/CoreFoundation/_CoreFoundation.so
# by generator 1.136
# no doc
# no imports

# functions

def CFBagCreate(*args, **kwargs): # real signature unknown
    pass

def CFBagCreateMutable(*args, **kwargs): # real signature unknown
    pass

def CFBagGetValues(*args, **kwargs): # real signature unknown
    pass

def CFBinaryHeapCreate(*args, **kwargs): # real signature unknown
    pass

def CFBinaryHeapGetValues(*args, **kwargs): # real signature unknown
    pass

def CFBitVectorCreate(*args, **kwargs): # real signature unknown
    pass

def CFBitVectorGetBits(*args, **kwargs): # real signature unknown
    pass

def CFCalendarAddComponents(*args, **kwargs): # real signature unknown
    pass

def CFCalendarComposeAbsoluteTime(*args, **kwargs): # real signature unknown
    pass

def CFCalendarDecomposeAbsoluteTime(*args, **kwargs): # real signature unknown
    pass

def CFCalendarGetComponentDifference(*args, **kwargs): # real signature unknown
    pass

def CFDictionaryGetKeysAndValues(*args, **kwargs): # real signature unknown
    pass

def CFFileDescriptorCreate(*args, **kwargs): # real signature unknown
    pass

def CFFileDescriptorGetContext(*args, **kwargs): # real signature unknown
    pass

def CFMachPortCreate(*args, **kwargs): # real signature unknown
    pass

def CFMachPortCreateWithPort(*args, **kwargs): # real signature unknown
    pass

def CFMachPortGetContext(*args, **kwargs): # real signature unknown
    pass

def CFMachPortGetInvalidationCallBack(*args, **kwargs): # real signature unknown
    pass

def CFMachPortSetInvalidationCallBack(*args, **kwargs): # real signature unknown
    pass

def CFMessagePortCreateLocal(*args, **kwargs): # real signature unknown
    pass

def CFMessagePortGetContext(*args, **kwargs): # real signature unknown
    pass

def CFNumberCreate(*args, **kwargs): # real signature unknown
    pass

def CFNumberGetValue(*args, **kwargs): # real signature unknown
    pass

def CFReadStreamSetClient(*args, **kwargs): # real signature unknown
    pass

def CFRunLoopObserverCreate(*args, **kwargs): # real signature unknown
    pass

def CFRunLoopObserverGetContext(*args, **kwargs): # real signature unknown
    pass

def CFRunLoopSourceCreate(*args, **kwargs): # real signature unknown
    pass

def CFRunLoopSourceGetContext(*args, **kwargs): # real signature unknown
    pass

def CFRunLoopTimerCreate(*args, **kwargs): # real signature unknown
    pass

def CFRunLoopTimerGetContext(*args, **kwargs): # real signature unknown
    pass

def CFSetGetValues(*args, **kwargs): # real signature unknown
    pass

def CFSocketCreate(*args, **kwargs): # real signature unknown
    pass

def CFSocketCreateConnectedToSocketSignature(*args, **kwargs): # real signature unknown
    pass

def CFSocketCreateWithNative(*args, **kwargs): # real signature unknown
    pass

def CFSocketCreateWithSocketSignature(*args, **kwargs): # real signature unknown
    pass

def CFSocketGetContext(*args, **kwargs): # real signature unknown
    pass

def CFTreeCreate(*args, **kwargs): # real signature unknown
    pass

def CFTreeGetChildren(*args, **kwargs): # real signature unknown
    pass

def CFTreeGetContext(*args, **kwargs): # real signature unknown
    pass

def CFTreeSetContext(*args, **kwargs): # real signature unknown
    pass

def CFWriteStreamSetClient(*args, **kwargs): # real signature unknown
    pass

# no classes
