# encoding: utf-8
# module CoreFoundation._inlines
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/CoreFoundation/_inlines.so
# by generator 1.136
# no doc
# no imports

# no functions
# no classes
# variables with complex values

_inline_list_ = None # (!) real value is ''

