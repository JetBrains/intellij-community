# encoding: utf-8
# module scipy.sparse.sparsetools._coo calls itself _coo
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/sparse/sparsetools/_coo.so
# by generator 1.136
# no doc

# imports
from _coo import (SWIG_PyInstanceMethod_New, coo_count_diagonals, coo_matvec, 
    coo_tocsc, coo_tocsr, coo_todense)


# no functions
# no classes
