# encoding: utf-8
# module scipy.sparse.sparsetools._dia calls itself _dia
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/sparse/sparsetools/_dia.so
# by generator 1.136
# no doc

# imports
from _dia import SWIG_PyInstanceMethod_New, dia_matvec


# no functions
# no classes
