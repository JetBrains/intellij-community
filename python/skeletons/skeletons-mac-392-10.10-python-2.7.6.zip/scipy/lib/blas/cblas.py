# encoding: utf-8
# module scipy.lib.blas.cblas
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/lib/blas/cblas.so
# by generator 1.136
"""
This module 'cblas' is auto-generated with f2py (version:2).
Functions:
  empty_module()
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

empty_module = None # (!) real value is ''

