# encoding: utf-8
# module scipy.lib.lapack.clapack
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/lib/lapack/clapack.so
# by generator 1.136
"""
This module 'clapack' is auto-generated with f2py (version:2).
Functions:
  empty_module()
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

empty_module = None # (!) real value is ''

