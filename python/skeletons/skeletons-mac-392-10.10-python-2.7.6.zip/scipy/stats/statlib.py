# encoding: utf-8
# module scipy.stats.statlib
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/stats/statlib.so
# by generator 1.136
"""
This module 'statlib' is auto-generated with f2py (version:2).
Functions:
  a,w,pw,ifault = swilk(x,a,init=0,n1=n)
  astart,a1,ifault = wprob(test,other)
  astart,a1,ifault = gscale(test,other)
  ifault = prho(n,is)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

gscale = None # (!) real value is ''

prho = None # (!) real value is ''

swilk = None # (!) real value is ''

wprob = None # (!) real value is ''

