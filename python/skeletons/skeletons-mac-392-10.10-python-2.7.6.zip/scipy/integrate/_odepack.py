# encoding: utf-8
# module scipy.integrate._odepack
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/integrate/_odepack.so
# by generator 1.136
# no doc
# no imports

# Variables with simple values

__version__ = ' 1.9 '

# functions

def odeint(fun, y0, t, args=(), Dfun=None, col_deriv=0, ml, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    [y,{infodict,}istate] = odeint(fun, y0, t, args=(), Dfun=None, col_deriv=0, ml=, mu=, full_output=0, rtol=, atol=, tcrit=, h0=0.0, hmax=0.0, hmin=0.0, ixpr=0.0, mxstep=0.0, mxhnil=0, mxordn=0, mxords=0)
      yprime = fun(y,t,...)
    """
    pass

# no classes
