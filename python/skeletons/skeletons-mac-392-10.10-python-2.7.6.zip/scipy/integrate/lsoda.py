# encoding: utf-8
# module scipy.integrate.lsoda
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/integrate/lsoda.so
# by generator 1.136
"""
This module 'lsoda' is auto-generated with f2py (version:2).
Functions:
  y,t,istate = lsoda(f,y,t,tout,rtol,atol,itask,istate,rwork,iwork,jac,jt,f_extra_args=(),overwrite_y=0,jac_extra_args=())
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

lsoda = None # (!) real value is ''

