# encoding: utf-8
# module scipy.optimize._lbfgsb
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/optimize/_lbfgsb.so
# by generator 1.136
"""
This module '_lbfgsb' is auto-generated with f2py (version:2).
Functions:
  setulb(m,x,l,u,nbd,f,g,factr,pgtol,wa,iwa,task,iprint,csave,lsave,isave,dsave,n=len(x))
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

setulb = None # (!) real value is ''

