# encoding: utf-8
# module scipy.optimize._nnls
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/optimize/_nnls.so
# by generator 1.136
"""
This module '_nnls' is auto-generated with f2py (version:2).
Functions:
  x,rnorm,mode = nnls(a,m,n,b,w,zz,index_bn,mda=shape(a,0),overwrite_a=0,overwrite_b=0)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

nnls = None # (!) real value is ''

