# encoding: utf-8
# module scipy.optimize._zeros
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/optimize/_zeros.so
# by generator 1.136
# no doc
# no imports

# functions

def _bisect(*args, **kwargs): # real signature unknown
    """ a """
    pass

def _brenth(*args, **kwargs): # real signature unknown
    """ a """
    pass

def _brentq(*args, **kwargs): # real signature unknown
    """ a """
    pass

def _ridder(*args, **kwargs): # real signature unknown
    """ a """
    pass

# no classes
