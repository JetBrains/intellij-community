# encoding: utf-8
# module scipy.optimize.minpack2
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/optimize/minpack2.so
# by generator 1.136
"""
This module 'minpack2' is auto-generated with f2py (version:2).
Functions:
  stp,f,g,task = dcsrch(stp,f,g,ftol,gtol,xtol,task,stpmin,stpmax,isave,dsave)
  stx,fx,dx,sty,fy,dy,stp,brackt = dcstep(stx,fx,dx,sty,fy,dy,stp,fp,dp,brackt,stpmin,stpmax)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

dcsrch = None # (!) real value is ''

dcstep = None # (!) real value is ''

