# encoding: utf-8
# module scipy.optimize._slsqp
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/optimize/_slsqp.so
# by generator 1.136
"""
This module '_slsqp' is auto-generated with f2py (version:2).
Functions:
  slsqp(m,meq,x,xl,xu,f,c,g,a,acc,iter,mode,w,jw,la=len(c),n=len(x),l_w=len(w),l_jw=len(jw))
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

slsqp = None # (!) real value is ''

