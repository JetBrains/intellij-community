# encoding: utf-8
# module scipy.optimize.moduleTNC
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/optimize/moduleTNC.so
# by generator 1.136
# no doc
# no imports

# functions

def minimize(*args, **kwargs): # real signature unknown
    pass

# no classes
