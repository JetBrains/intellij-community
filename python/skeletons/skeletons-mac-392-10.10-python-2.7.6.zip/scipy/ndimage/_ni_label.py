# encoding: utf-8
# module scipy.ndimage._ni_label
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/ndimage/_ni_label.so
# by generator 1.136
# no doc

# imports
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>
import numpy as np # /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/__init__.pyc

# functions

def get_nonzero_line(*args, **kwargs): # real signature unknown
    pass

def get_read_line(*args, **kwargs): # real signature unknown
    pass

def get_write_line(*args, **kwargs): # real signature unknown
    pass

def _label(*args, **kwargs): # real signature unknown
    pass

# classes

class NeedMoreBits(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""


    __qualname__ = 'NeedMoreBits'


# variables with complex values

__test__ = {}

