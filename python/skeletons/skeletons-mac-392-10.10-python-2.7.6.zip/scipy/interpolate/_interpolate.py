# encoding: utf-8
# module scipy.interpolate._interpolate
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/interpolate/_interpolate.so
# by generator 1.136
""" A few interpolation routines. """
# no imports

# functions

def block_average_above_dddd(*args, **kwargs): # real signature unknown
    """  """
    pass

def linear_dddd(*args, **kwargs): # real signature unknown
    """  """
    pass

def loginterp_dddd(*args, **kwargs): # real signature unknown
    """  """
    pass

def window_average_ddddd(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
