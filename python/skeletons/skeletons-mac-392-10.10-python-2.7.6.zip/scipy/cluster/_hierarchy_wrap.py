# encoding: utf-8
# module scipy.cluster._hierarchy_wrap
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/cluster/_hierarchy_wrap.so
# by generator 1.136
# no doc
# no imports

# functions

def calculate_cluster_sizes_wrap(*args, **kwargs): # real signature unknown
    pass

def chopmins(*args, **kwargs): # real signature unknown
    pass

def chopmins_ns_i(*args, **kwargs): # real signature unknown
    pass

def chopmins_ns_ij(*args, **kwargs): # real signature unknown
    pass

def cluster_dist_wrap(*args, **kwargs): # real signature unknown
    pass

def cluster_in_wrap(*args, **kwargs): # real signature unknown
    pass

def cluster_maxclust_dist_wrap(*args, **kwargs): # real signature unknown
    pass

def cluster_maxclust_monocrit_wrap(*args, **kwargs): # real signature unknown
    pass

def cluster_monocrit_wrap(*args, **kwargs): # real signature unknown
    pass

def cophenetic_distances_wrap(*args, **kwargs): # real signature unknown
    pass

def get_max_dist_for_each_cluster_wrap(*args, **kwargs): # real signature unknown
    pass

def get_max_Rfield_for_each_cluster_wrap(*args, **kwargs): # real signature unknown
    pass

def inconsistent_wrap(*args, **kwargs): # real signature unknown
    pass

def leaders_wrap(*args, **kwargs): # real signature unknown
    pass

def linkage_euclid_wrap(*args, **kwargs): # real signature unknown
    pass

def linkage_wrap(*args, **kwargs): # real signature unknown
    pass

def prelist_wrap(*args, **kwargs): # real signature unknown
    pass

# no classes
