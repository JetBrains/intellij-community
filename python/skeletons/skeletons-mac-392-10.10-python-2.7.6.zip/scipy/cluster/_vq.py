# encoding: utf-8
# module scipy.cluster._vq
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/cluster/_vq.so
# by generator 1.136
# no doc
# no imports

# functions

def vq(*args, **kwargs): # real signature unknown
    """ TODO docstring """
    pass

# no classes
