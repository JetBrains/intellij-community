# encoding: utf-8
# module scipy.special._ufuncs_cxx
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/special/_ufuncs_cxx.so
# by generator 1.136
# no doc

# imports
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>

# no functions
# no classes
# variables with complex values

__pyx_capi__ = {
    '_export_faddeeva_dawsn': None, # (!) real value is ''
    '_export_faddeeva_dawsn_complex': None, # (!) real value is ''
    '_export_faddeeva_erf': None, # (!) real value is ''
    '_export_faddeeva_erfc': None, # (!) real value is ''
    '_export_faddeeva_erfcx': None, # (!) real value is ''
    '_export_faddeeva_erfcx_complex': None, # (!) real value is ''
    '_export_faddeeva_erfi': None, # (!) real value is ''
    '_export_faddeeva_erfi_complex': None, # (!) real value is ''
    '_export_faddeeva_w': None, # (!) real value is ''
    '_set_errprint': None, # (!) real value is ''
}

__test__ = {}

