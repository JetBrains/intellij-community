# encoding: utf-8
# module scipy.spatial._distance_wrap
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/scipy/spatial/_distance_wrap.so
# by generator 1.136
# no doc
# no imports

# functions

def cdist_bray_curtis_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_canberra_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_chebyshev_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_city_block_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_cosine_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_dice_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_euclidean_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_hamming_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_hamming_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_jaccard_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_jaccard_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_kulsinski_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_mahalanobis_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_matching_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_minkowski_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_rogerstanimoto_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_russellrao_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_seuclidean_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_sokalmichener_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_sokalsneath_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_weighted_minkowski_wrap(*args, **kwargs): # real signature unknown
    pass

def cdist_yule_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_bray_curtis_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_canberra_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_chebyshev_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_city_block_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_cosine_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_dice_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_euclidean_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_hamming_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_hamming_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_jaccard_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_jaccard_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_kulsinski_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_mahalanobis_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_matching_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_minkowski_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_rogerstanimoto_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_russellrao_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_seuclidean_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_sokalmichener_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_sokalsneath_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_weighted_minkowski_wrap(*args, **kwargs): # real signature unknown
    pass

def pdist_yule_bool_wrap(*args, **kwargs): # real signature unknown
    pass

def to_squareform_from_vector_wrap(*args, **kwargs): # real signature unknown
    pass

def to_vector_from_squareform_wrap(*args, **kwargs): # real signature unknown
    pass

# no classes
