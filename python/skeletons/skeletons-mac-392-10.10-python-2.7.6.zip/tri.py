# encoding: utf-8
# module tri
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/matplotlib/_tri.so
# by generator 1.136
""" Module for unstructured triangular grids """
# no imports

# no functions
# no classes
