# encoding: utf-8
# module _json
# from (built-in) by generator 1.99
""" json speedups """
# no imports

# functions

def encode_basestring_ascii(string): # real signature unknown; restored from __doc__
    """
    encode_basestring_ascii(string) -> string
    
    Return an ASCII-only JSON representation of a Python string
    """
    return ""


def scanstring(string, end, strict=True): # real signature unknown; restored from __doc__
    """
    scanstring(string, end, strict=True) -> (string, end)
    
    Scan the string s for a JSON string. End is the index of the
    character in s after the quote that started the JSON string.
    Unescapes all valid JSON string escape sequences and raises ValueError
    on attempt to decode an invalid string. If strict is False then literal
    control characters are allowed in the string.
    
    Returns a tuple of the decoded string and the index of the character in s
    after the end quote.
    """
    pass


# classes

class make_encoder(object):
    """ _iterencode(obj, _current_indent_level) -> iterable """
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    default = property(lambda self: object()) # default
    encoder = property(lambda self: object()) # default
    indent = property(lambda self: object()) # default
    item_separator = property(lambda self: object()) # default
    key_separator = property(lambda self: object()) # default
    markers = property(lambda self: object()) # default
    skipkeys = property(lambda self: object()) # default
    sort_keys = property(lambda self: object()) # default


class make_scanner(object):
    """ JSON scanner object """
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    object_hook = property(lambda self: object()) # default
    object_pairs_hook = property(lambda self: object()) # default
    parse_constant = property(lambda self: object()) # default
    parse_float = property(lambda self: object()) # default
    parse_int = property(lambda self: object()) # default
    strict = property(lambda self: object()) # default


