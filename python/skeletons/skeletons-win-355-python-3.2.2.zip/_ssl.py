# encoding: utf-8
# module _ssl
# from C:\Python32\DLLs\_ssl.pyd by generator 1.99
"""
Implementation module for SSL socket operations.  See the socket module
for documentation.
"""

# imports
import socket as __socket


# Variables with simple values

CERT_NONE = 0
CERT_OPTIONAL = 1
CERT_REQUIRED = 2

HAS_SNI = True

OPENSSL_VERSION = 'OpenSSL 1.0.0a 1 Jun 2010'

OPENSSL_VERSION_NUMBER = 268435487

OP_ALL = -2147479553

OP_NO_SSLv2 = 16777216
OP_NO_SSLv3 = 33554432
OP_NO_TLSv1 = 67108864

PROTOCOL_SSLv2 = 0
PROTOCOL_SSLv23 = 2
PROTOCOL_SSLv3 = 1
PROTOCOL_TLSv1 = 3

SSL_ERROR_EOF = 8

SSL_ERROR_INVALID_ERROR_CODE = 10

SSL_ERROR_SSL = 1
SSL_ERROR_SYSCALL = 5

SSL_ERROR_WANT_CONNECT = 7
SSL_ERROR_WANT_READ = 2
SSL_ERROR_WANT_WRITE = 3

SSL_ERROR_WANT_X509_LOOKUP = 4

SSL_ERROR_ZERO_RETURN = 6

# functions

def RAND_add(string, entropy): # real signature unknown; restored from __doc__
    """
    RAND_add(string, entropy)
    
    Mix string into the OpenSSL PRNG state.  entropy (a float) is a lower
    bound on the entropy contained in string.  See RFC 1750.
    """
    pass


def RAND_egd(path): # real signature unknown; restored from __doc__
    """
    RAND_egd(path) -> bytes
    
    Queries the entropy gather daemon (EGD) on the socket named by 'path'.
    Returns number of bytes read.  Raises SSLError if connection to EGD
    fails or if it does provide enough data to seed PRNG.
    """
    return b""


def RAND_status(): # real signature unknown; restored from __doc__
    """
    RAND_status() -> 0 or 1
    
    Returns 1 if the OpenSSL PRNG has been seeded with enough data and 0 if not.
    It is necessary to seed the PRNG with RAND_add() on some platforms before
    using the ssl() function.
    """
    pass


def _test_decode_cert(*args, **kwargs): # real signature unknown
    pass


# classes

class SSLError(__socket.error):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class _SSLContext(object):
    # no doc
    def load_cert_chain(self, *args, **kwargs): # real signature unknown
        pass

    def load_verify_locations(self, *args, **kwargs): # real signature unknown
        pass

    def session_stats(self, *args, **kwargs): # real signature unknown
        pass

    def set_ciphers(self, *args, **kwargs): # real signature unknown
        pass

    def set_default_verify_paths(self, *args, **kwargs): # real signature unknown
        pass

    def _wrap_socket(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    options = property(lambda self: object()) # default
    verify_mode = property(lambda self: object()) # default


class _SSLSocket(object):
    # no doc
    def cipher(self, *args, **kwargs): # real signature unknown
        pass

    def do_handshake(self, *args, **kwargs): # real signature unknown
        pass

    def peer_certificate(self, der=False): # real signature unknown; restored from __doc__
        """
        peer_certificate([der=False]) -> certificate
        
        Returns the certificate for the peer.  If no certificate was provided,
        returns None.  If a certificate was provided, but not validated, returns
        an empty dictionary.  Otherwise returns a dict containing information
        about the peer certificate.
        
        If the optional argument is True, returns a DER-encoded copy of the
        peer certificate, or None if no certificate was provided.  This will
        return the certificate even if it wasn't validated.
        """
        pass

    def pending(self): # real signature unknown; restored from __doc__
        """
        pending() -> count
        
        Returns the number of already decrypted bytes available for read,
        pending on the connection.
        """
        pass

    def read(self, len=None): # real signature unknown; restored from __doc__
        """
        read([len]) -> string
        
        Read up to len bytes from the SSL socket.
        """
        return ""

    def shutdown(self, s): # real signature unknown; restored from __doc__
        """
        shutdown(s) -> socket
        
        Does the SSL shutdown handshake with the remote end, and returns
        the underlying socket object.
        """
        pass

    def write(self, s): # real signature unknown; restored from __doc__
        """
        write(s) -> len
        
        Writes the string s into the SSL object.  Returns the number
        of bytes written.
        """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

OPENSSL_VERSION_INFO = (
    1,
    0,
    0,
    1,
    15,
)

_OPENSSL_API_VERSION = (
    1,
    0,
    0,
    1,
    15,
)

