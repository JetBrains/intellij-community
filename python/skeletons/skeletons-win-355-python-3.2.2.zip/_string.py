# encoding: utf-8
# module _string
# from (built-in) by generator 1.99
""" string helper module """
# no imports

# functions

def formatter_field_name_split(*args, **kwargs): # real signature unknown
    """ split the argument as a field name """
    pass


def formatter_parser(*args, **kwargs): # real signature unknown
    """ parse the argument as a format string """
    pass


# no classes
