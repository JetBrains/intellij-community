# encoding: utf-8
# module _md5
# from (built-in) by generator 1.99
# no doc
# no imports

# functions

def md5(*args, **kwargs): # real signature unknown
    """ Return a new MD5 hash object; optionally initialized with a string. """
    pass


# no classes
