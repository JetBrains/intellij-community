# encoding: utf-8
# module _elementtree
# from C:\Python32\DLLs\_elementtree.pyd by generator 1.99
# no doc

# imports
import xml.etree.ElementPath as ElementPath # C:\Python32\lib\xml\etree\ElementPath.py
import xml.etree.ElementTree as __xml_etree_ElementTree


# Variables with simple values

VERSION = '1.0.6'

__version__ = '1.0.6'

# functions

def Comment(*args, **kwargs): # real signature unknown
    pass


def dump(elem): # reliably restored by inspect
    # no doc
    pass


def Element(*args, **kwargs): # real signature unknown
    pass


def fromstring(text): # reliably restored by inspect
    # no doc
    pass


def fromstringlist(sequence, parser=None): # reliably restored by inspect
    # no doc
    pass


def iselement(element): # reliably restored by inspect
    # no doc
    pass


def parse(source, parser=None): # reliably restored by inspect
    # no doc
    pass


def PI(*args, **kwargs): # real signature unknown
    pass


def ProcessingInstruction(*args, **kwargs): # real signature unknown
    pass


def register_namespace(prefix, uri): # reliably restored by inspect
    # no doc
    pass


def SubElement(*args, **kwargs): # real signature unknown
    pass


def tostring(element, encoding=None, method=None): # reliably restored by inspect
    # no doc
    pass


def tostringlist(element, encoding=None, method=None): # reliably restored by inspect
    # no doc
    pass


def TreeBuilder(*args, **kwargs): # real signature unknown
    pass


def XML(text): # reliably restored by inspect
    # no doc
    pass


def XMLID(text): # reliably restored by inspect
    # no doc
    pass


def XMLParser(*args, **kwargs): # real signature unknown
    pass


def XMLTreeBuilder(*args, **kwargs): # real signature unknown
    pass


# classes

class ElementTree(__xml_etree_ElementTree.ElementTree):
    # no doc
    def parse(self, source, parser=None): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, element=None, file=None): # reliably restored by inspect
        # no doc
        pass


class iterparse(object):
    # no doc
    def __init__(self, file, events=None): # reliably restored by inspect
        # no doc
        pass

    def __iter__(self): # reliably restored by inspect
        # no doc
        pass

    def __next__(self): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object()) # default

    root = None
    __dict__ = None # (!) real value is ''


class ParseError(SyntaxError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class QName(object):
    # no doc
    def __eq__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __ge__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __gt__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __hash__(self): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, text_or_uri, tag=None): # reliably restored by inspect
        # no doc
        pass

    def __le__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __lt__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __ne__(self, other): # reliably restored by inspect
        # no doc
        pass

    def __repr__(self): # reliably restored by inspect
        # no doc
        pass

    def __str__(self): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


