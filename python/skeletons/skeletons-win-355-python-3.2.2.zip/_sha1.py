# encoding: utf-8
# module _sha1
# from (built-in) by generator 1.99
# no doc
# no imports

# functions

def sha1(*args, **kwargs): # real signature unknown
    """ Return a new SHA1 hash object; optionally initialized with a string. """
    pass


# no classes
