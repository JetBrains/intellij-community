# encoding: utf-8
# module atexit
# from (built-in) by generator 1.99
"""
allow programmer to define multiple exit functions to be executedupon normal program termination.

Two public functions, register and unregister, are defined.
"""
# no imports

# functions

def register(func, *args, **kwargs): # real signature unknown; restored from __doc__
    """
    register(func, *args, **kwargs) -> func
    
    Register a function to be executed upon normal program termination
    
        func - function to be called at exit
        args - optional arguments to pass to func
        kwargs - optional keyword arguments to pass to func
    
        func is returned to facilitate usage as a decorator.
    """
    pass


def unregister(func): # real signature unknown; restored from __doc__
    """
    unregister(func) -> None
    
    Unregister a exit function which was previously registered using
    atexit.register
    
        func - function to be unregistered
    """
    pass


def _clear(): # real signature unknown; restored from __doc__
    """
    _clear() -> None
    
    Clear the list of previously registered exit functions.
    """
    pass


def _run_exitfuncs(): # real signature unknown; restored from __doc__
    """
    _run_exitfuncs() -> None
    
    Run all registered exit functions.
    """
    pass


# no classes
