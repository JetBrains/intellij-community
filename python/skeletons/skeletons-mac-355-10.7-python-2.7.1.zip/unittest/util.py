# encoding: utf-8
# module unittest.util
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/util.pyo by generator 1.99
""" Various utility functions. """
# no imports

# Variables with simple values

_MAX_LENGTH = 80

__unittest = True

# functions

def safe_repr(obj, short=False): # reliably restored by inspect
    # no doc
    pass


def sorted_list_difference(expected, actual): # reliably restored by inspect
    """
    Finds elements in only one or the other of two, sorted input lists.
    
        Returns a two-element tuple of lists.    The first list contains those
        elements in the "expected" list but not in the "actual" list, and the
        second contains those elements in the "actual" list but not in the
        "expected" list.    Duplicate elements in either input list are ignored.
    """
    pass


def strclass(cls): # reliably restored by inspect
    # no doc
    pass


def unorderable_list_difference(expected, actual, ignore_duplicate=False): # reliably restored by inspect
    """
    Same behavior as sorted_list_difference but
        for lists of unorderable items (like dicts).
    
        As it does a linear search per item (remove) it
        has O(n*n) performance.
    """
    pass


# no classes
