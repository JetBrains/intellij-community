# encoding: utf-8
# module unittest.runner
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/runner.pyo by generator 1.99
""" Running tests """

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest.result as result # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/result.pyc
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so
import unittest.result as __unittest_result


# Variables with simple values

__unittest = True

# functions

def registerResult(result): # reliably restored by inspect
    # no doc
    pass


# classes

class TextTestResult(__unittest_result.TestResult):
    """
    A test result class that can print formatted text results to a stream.
    
        Used by TextTestRunner.
    """
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def getDescription(self, *args, **kwargs): # real signature unknown
        pass

    def printErrorList(self, *args, **kwargs): # real signature unknown
        pass

    def printErrors(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    separator1 = '======================================================================'
    separator2 = '----------------------------------------------------------------------'


class TextTestRunner(object):
    """
    A test runner class that displays results in textual form.
    
        It prints out the names of tests as they are run, errors as they
        occur, and a summary of the results at the end of the test run.
    """
    def resultclass(self, *args, **kwargs): # real signature unknown
        """
        A test result class that can print formatted text results to a stream.
        
            Used by TextTestRunner.
        """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        """ Run the given test case or test suite. """
        pass

    def _makeResult(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class _WritelnDecorator(object):
    """ Used to decorate file-like objects with a handy 'writeln' method """
    def writeln(self, *args, **kwargs): # real signature unknown
        pass

    def __getattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


