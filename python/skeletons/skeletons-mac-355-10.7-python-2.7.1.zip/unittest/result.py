# encoding: utf-8
# module unittest.result
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/result.pyo by generator 1.99
""" Test result object """

# imports
import unittest.util as util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/util.pyc
import traceback as traceback # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/traceback.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

STDERR_LINE = '\nStderr:\n%s'

STDOUT_LINE = '\nStdout:\n%s'

__unittest = True

# functions

def failfast(method): # reliably restored by inspect
    # no doc
    pass


def wraps(wrapped, assigned="('__module__', '__name__', '__doc__')", updated="('__dict__',)"): # reliably restored by inspect
    """
    Decorator factory to apply update_wrapper() to a wrapper function
    
           Returns a decorator that invokes update_wrapper() with the decorated
           function as the wrapper argument and the arguments to wraps() as the
           remaining arguments. Default arguments are as for update_wrapper().
           This is a convenience function to simplify applying partial() to
           update_wrapper().
    """
    pass


# classes

class TestResult(object):
    """
    Holder for test result information.
    
        Test results are automatically managed by the TestCase and TestSuite
        classes, and do not need to be explicitly manipulated by writers of tests.
    
        Each instance holds the total number of tests run, and collections of
        failures and errors that occurred among those test runs. The collections
        contain tuples of (testcase, exceptioninfo), where exceptioninfo is the
        formatted traceback of the error that occurred.
    """
    def addError(self, *args, **kwargs): # real signature unknown
        """
        Called when an error has occurred. 'err' is a tuple of values as
                returned by sys.exc_info().
        """
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        """ Called when an expected failure/error occured. """
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        """
        Called when an error has occurred. 'err' is a tuple of values as
                returned by sys.exc_info().
        """
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        """ Called when a test is skipped. """
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        """ Called when a test has completed successfully """
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        """ Called when a test was expected to fail, but succeed. """
        pass

    def printErrors(self, *args, **kwargs): # real signature unknown
        """ Called by TestRunner after test run """
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        """ Called when the given test is about to be run """
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        """
        Called once before any tests are executed.
        
                See startTest for a method called before each test.
        """
        pass

    def stop(self, *args, **kwargs): # real signature unknown
        """ Indicates that the tests should be aborted """
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        """ Called when the given test has been run """
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        """
        Called once after all tests are executed.
        
                See stopTest for a method called after each test.
        """
        pass

    def wasSuccessful(self, *args, **kwargs): # real signature unknown
        """ Tells whether or not this result was a success """
        pass

    def _count_relevant_tb_levels(self, *args, **kwargs): # real signature unknown
        pass

    def _exc_info_to_string(self, *args, **kwargs): # real signature unknown
        """ Converts a sys.exc_info()-style tuple of values into a string. """
        pass

    def _is_relevant_tb_level(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _moduleSetUpFailed = False
    _previousTestClass = None
    _testRunEntered = False
    __dict__ = None # (!) real value is ''


# variables with complex values

StringIO = None # (!) real value is ''

