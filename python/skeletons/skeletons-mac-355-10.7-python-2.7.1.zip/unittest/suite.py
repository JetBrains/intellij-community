# encoding: utf-8
# module unittest.suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/suite.pyo by generator 1.99
""" TestSuite """

# imports
import unittest.case as case # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/case.pyc
import unittest.util as util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/util.pyc
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

__unittest = True

# functions

def _isnotsuite(test): # reliably restored by inspect
    """ A crude way to tell apart testcases and suites with duck-typing """
    pass


# classes

class BaseTestSuite(object):
    """ A simple test suite that doesn't provide class or module shared fixtures. """
    def addTest(self, *args, **kwargs): # real signature unknown
        pass

    def addTests(self, *args, **kwargs): # real signature unknown
        pass

    def countTestCases(self, *args, **kwargs): # real signature unknown
        pass

    def debug(self, *args, **kwargs): # real signature unknown
        """ Run the tests without collecting errors in a TestResult """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''
    __hash__ = None


class TestSuite(BaseTestSuite):
    """
    A test suite is a composite test consisting of a number of TestCases.
    
        For use, create an instance of TestSuite, then add test case instances.
        When all tests have been added, the suite can be passed to a test
        runner, such as TextTestRunner. It will run the individual test cases
        in the order in which they were added, aggregating the results. When
        subclassing, do not forget to call the base class constructor.
    """
    def debug(self, *args, **kwargs): # real signature unknown
        """ Run the tests without collecting errors in a TestResult """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        pass

    def _addClassOrModuleLevelException(self, *args, **kwargs): # real signature unknown
        pass

    def _get_previous_module(self, *args, **kwargs): # real signature unknown
        pass

    def _handleClassSetUp(self, *args, **kwargs): # real signature unknown
        pass

    def _handleModuleFixture(self, *args, **kwargs): # real signature unknown
        pass

    def _handleModuleTearDown(self, *args, **kwargs): # real signature unknown
        pass

    def _tearDownPreviousClass(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class _DebugResult(object):
    """ Used by the TestSuite to hold previous class when running in debug. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    shouldStop = False
    _moduleSetUpFailed = False
    _previousTestClass = None
    __dict__ = None # (!) real value is ''


class _ErrorHolder(object):
    """
    Placeholder for a TestCase inside a result. As far as a TestResult
        is concerned, this looks exactly like a unit test. Used to insert
        arbitrary errors into a test suite run.
    """
    def countTestCases(self, *args, **kwargs): # real signature unknown
        pass

    def id(self, *args, **kwargs): # real signature unknown
        pass

    def run(self, *args, **kwargs): # real signature unknown
        pass

    def shortDescription(self, *args, **kwargs): # real signature unknown
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    failureException = None
    __dict__ = None # (!) real value is ''


