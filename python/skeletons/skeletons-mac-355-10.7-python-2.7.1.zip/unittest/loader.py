# encoding: utf-8
# module unittest.loader
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/loader.pyo by generator 1.99
""" Loading unittests. """

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import unittest.suite as suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/suite.pyc
import sys as sys # <module 'sys' (built-in)>
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/types.pyc
import unittest.case as case # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/case.pyc
import traceback as traceback # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/traceback.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

__unittest = True

# functions

def findTestCases(module, prefix=None, sortUsing=cmp, suiteClass="<class 'unittest.suite.TestSuite'>"): # reliably restored by inspect
    # no doc
    pass


def fnmatch(name, pat): # reliably restored by inspect
    """
    Test whether FILENAME matches PATTERN.
    
        Patterns are Unix shell style:
    
        *       matches everything
        ?       matches any single character
        [seq]   matches any character in seq
        [!seq]  matches any char not in seq
    
        An initial period in FILENAME is not special.
        Both FILENAME and PATTERN are first case-normalized
        if the operating system requires it.
        If you don't want this, use fnmatchcase(FILENAME, PATTERN).
    """
    pass


def getTestCaseNames(testCaseClass, prefix, sortUsing=cmp): # reliably restored by inspect
    # no doc
    pass


def makeSuite(testCaseClass, prefix=None, sortUsing=cmp, suiteClass="<class 'unittest.suite.TestSuite'>"): # reliably restored by inspect
    # no doc
    pass


def _CmpToKey(mycmp): # reliably restored by inspect
    """ Convert a cmp= function into a key= function """
    pass


def _makeLoader(prefix, sortUsing, suiteClass=None): # reliably restored by inspect
    # no doc
    pass


def _make_failed_import_test(name, suiteClass): # reliably restored by inspect
    # no doc
    pass


def _make_failed_load_tests(name, exception, suiteClass): # reliably restored by inspect
    # no doc
    pass


def _make_failed_test(classname, methodname, exception, suiteClass): # reliably restored by inspect
    # no doc
    pass


# classes

class TestLoader(object):
    """
    This class is responsible for loading tests according to various criteria
        and returning them wrapped in a TestSuite
    """
    def discover(self): # real signature unknown; restored from __doc__
        """
        Find and return all test modules from the specified start
                directory, recursing into subdirectories to find them. Only test files
                that match the pattern will be loaded. (Using shell style pattern
                matching.)
        
                All test modules must be importable from the top level of the project.
                If the start directory is not the top level directory then the top
                level directory must be specified separately.
        
                If a test package name (directory with '__init__.py') matches the
                pattern then the package will be checked for a 'load_tests' function. If
                this exists then it will be called with loader, tests, pattern.
        
                If load_tests exists then discovery does  *not* recurse into the package,
                load_tests is responsible for loading all tests in the package.
        
                The pattern is deliberately not stored as a loader attribute so that
                packages can continue discovery themselves. top_level_dir is stored so
                load_tests does not need to pass this argument in to loader.discover().
        """
        pass

    def getTestCaseNames(self, *args, **kwargs): # real signature unknown
        """ Return a sorted sequence of method names found within testCaseClass """
        pass

    def loadTestsFromModule(self, *args, **kwargs): # real signature unknown
        """ Return a suite of all tests cases contained in the given module """
        pass

    def loadTestsFromName(self, *args, **kwargs): # real signature unknown
        """
        Return a suite of all tests cases given a string specifier.
        
                The name may resolve either to a module, a test case class, a
                test method within a test case class, or a callable object which
                returns a TestCase or TestSuite instance.
        
                The method optionally resolves the names relative to a given module.
        """
        pass

    def loadTestsFromNames(self, *args, **kwargs): # real signature unknown
        """
        Return a suite of all tests cases found using the given sequence
                of string specifiers. See 'loadTestsFromName()'.
        """
        pass

    def loadTestsFromTestCase(self, *args, **kwargs): # real signature unknown
        """ Return a suite of all tests cases contained in testCaseClass """
        pass

    def sortTestMethodsUsing(self, *args, **kwargs): # real signature unknown
        """
        cmp(x, y) -> integer
        
        Return negative if x<y, zero if x==y, positive if x>y.
        """
        pass

    def suiteClass(self, *args, **kwargs): # real signature unknown
        """
        A test suite is a composite test consisting of a number of TestCases.
        
            For use, create an instance of TestSuite, then add test case instances.
            When all tests have been added, the suite can be passed to a test
            runner, such as TextTestRunner. It will run the individual test cases
            in the order in which they were added, aggregating the results. When
            subclassing, do not forget to call the base class constructor.
        """
        pass

    def _find_tests(self, *args, **kwargs): # real signature unknown
        """ Used by discovery. Yields test suites it loads. """
        pass

    def _get_directory_containing_module(self, *args, **kwargs): # real signature unknown
        pass

    def _get_module_from_name(self, *args, **kwargs): # real signature unknown
        pass

    def _get_name_from_path(self, *args, **kwargs): # real signature unknown
        pass

    def _match_path(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    testMethodPrefix = 'test'
    _top_level_dir = None
    __dict__ = None # (!) real value is ''


# variables with complex values

defaultTestLoader = None # (!) real value is ''

VALID_MODULE_NAME = None # (!) real value is ''

