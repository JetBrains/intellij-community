# encoding: utf-8
# module unittest.main
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/main.pyo by generator 1.99
""" Unittest main program """

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest.runner as runner # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/runner.pyc
import unittest.loader as loader # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/loader.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/types.pyc

# Variables with simple values

BUFFEROUTPUT = '  -b, --buffer     Buffer stdout and stderr during test runs\n'

CATCHBREAK = '  -c, --catch      Catch control-C and display results\n'

FAILFAST = '  -f, --failfast   Stop on first failure\n'

USAGE_AS_MAIN = "Usage: %(progName)s [options] [tests]\n\nOptions:\n  -h, --help       Show this message\n  -v, --verbose    Verbose output\n  -q, --quiet      Minimal output\n%(failfast)s%(catchbreak)s%(buffer)s\nExamples:\n  %(progName)s test_module               - run tests from test_module\n  %(progName)s module.TestClass          - run tests from module.TestClass\n  %(progName)s module.Class.test_method  - run specified test method\n\n[tests] can be a list of any number of test modules, classes and test\nmethods.\n\nAlternative Usage: %(progName)s discover [options]\n\nOptions:\n  -v, --verbose    Verbose output\n%(failfast)s%(catchbreak)s%(buffer)s  -s directory     Directory to start discovery ('.' default)\n  -p pattern       Pattern to match test files ('test*.py' default)\n  -t directory     Top level directory of project (default to\n                   start directory)\n\nFor test discovery all test modules must be importable from the top\nlevel directory of the project.\n"

USAGE_FROM_MODULE = "Usage: %(progName)s [options] [test] [...]\n\nOptions:\n  -h, --help       Show this message\n  -v, --verbose    Verbose output\n  -q, --quiet      Minimal output\n%(failfast)s%(catchbreak)s%(buffer)s\nExamples:\n  %(progName)s                               - run default set of tests\n  %(progName)s MyTestSuite                   - run suite 'MyTestSuite'\n  %(progName)s MyTestCase.testSomething      - run MyTestCase.testSomething\n  %(progName)s MyTestCase                    - run all 'test*' test methods\n                                               in MyTestCase\n"

__unittest = True

# functions

def installHandler(): # reliably restored by inspect
    # no doc
    pass


# classes

class TestProgram(object):
    """
    A command-line program that runs a set of tests; this is primarily
           for making test modules conveniently executable.
    """
    def createTests(self, *args, **kwargs): # real signature unknown
        pass

    def parseArgs(self, *args, **kwargs): # real signature unknown
        pass

    def runTests(self, *args, **kwargs): # real signature unknown
        pass

    def usageExit(self, *args, **kwargs): # real signature unknown
        pass

    def _do_discovery(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    buffer = None
    catchbreak = None
    failfast = None
    progName = None
    USAGE = "Usage: %(progName)s [options] [test] [...]\n\nOptions:\n  -h, --help       Show this message\n  -v, --verbose    Verbose output\n  -q, --quiet      Minimal output\n%(failfast)s%(catchbreak)s%(buffer)s\nExamples:\n  %(progName)s                               - run default set of tests\n  %(progName)s MyTestSuite                   - run suite 'MyTestSuite'\n  %(progName)s MyTestCase.testSomething      - run MyTestCase.testSomething\n  %(progName)s MyTestCase                    - run all 'test*' test methods\n                                               in MyTestCase\n"
    __dict__ = None # (!) real value is ''


main = TestProgram


