# encoding: utf-8
# module unittest.test.test_break
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_break.pyo by generator 1.99
# no doc

# imports
import weakref as weakref # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/weakref.pyc
import signal as signal # <module 'signal' (built-in)>
import sys as sys # <module 'sys' (built-in)>
import gc as gc # <module 'gc' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from cStringIO import StringIO

import unittest.case as __unittest_case


# no functions
# classes

class TestBreak(__unittest_case.TestCase):
    # no doc
    def setUp(self, *args, **kwargs): # real signature unknown
        pass

    def tearDown(self, *args, **kwargs): # real signature unknown
        pass

    def testHandlerReplacedButCalled(self, *args, **kwargs): # real signature unknown
        pass

    def testInstallHandler(self, *args, **kwargs): # real signature unknown
        pass

    def testInterruptCaught(self, *args, **kwargs): # real signature unknown
        pass

    def testMainInstallsHandler(self, *args, **kwargs): # real signature unknown
        pass

    def testRegisterResult(self, *args, **kwargs): # real signature unknown
        pass

    def testRemoveHandler(self, *args, **kwargs): # real signature unknown
        pass

    def testRemoveHandlerAsDecorator(self, *args, **kwargs): # real signature unknown
        pass

    def testRemoveResult(self, *args, **kwargs): # real signature unknown
        pass

    def testRunner(self, *args, **kwargs): # real signature unknown
        pass

    def testSecondInterrupt(self, *args, **kwargs): # real signature unknown
        pass

    def testTwoResults(self, *args, **kwargs): # real signature unknown
        pass

    def testWeakReferences(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


