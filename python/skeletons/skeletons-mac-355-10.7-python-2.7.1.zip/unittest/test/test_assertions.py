# encoding: utf-8
# module unittest.test.test_assertions
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_assertions.pyo by generator 1.99
# no doc

# imports
import datetime as datetime # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/datetime.so
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import unittest.case as __unittest_case


# no functions
# classes

class TestLongMessage(__unittest_case.TestCase):
    """
    Test that the individual asserts honour longMessage.
        This actually tests all the message behaviour for
        asserts that use longMessage.
    """
    def assertMessages(self, *args, **kwargs): # real signature unknown
        pass

    def setUp(self, *args, **kwargs): # real signature unknown
        pass

    def testAlmostEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertDictContainsSubset(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertDictEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertFalse(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertGreater(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertGreaterEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIn(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIs(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIsNone(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIsNot(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIsNotNone(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertItemsEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertLess(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertLessEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertMultiLineEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertNotIn(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertSequenceEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertSetEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertTrue(self, *args, **kwargs): # real signature unknown
        pass

    def testDefault(self, *args, **kwargs): # real signature unknown
        pass

    def testNotAlmostEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testNotEqual(self, *args, **kwargs): # real signature unknown
        pass

    def test_baseAssertEqual(self, *args, **kwargs): # real signature unknown
        pass

    def test_formatMessage_unicode_error(self, *args, **kwargs): # real signature unknown
        pass

    def test_formatMsg(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


class Test_Assertions(__unittest_case.TestCase):
    # no doc
    def testAssertNotRegexpMatches(self, *args, **kwargs): # real signature unknown
        pass

    def test_AlmostEqual(self, *args, **kwargs): # real signature unknown
        pass

    def test_AmostEqualWithDelta(self, *args, **kwargs): # real signature unknown
        pass

    def test_assertRaises(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


