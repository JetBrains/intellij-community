# encoding: utf-8
# module unittest.test.test_loader
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_loader.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/types.pyc
import unittest.case as __unittest_case


# no functions
# classes

class Test_TestLoader(__unittest_case.TestCase):
    # no doc
    def test_getTestCaseNames(self, *args, **kwargs): # real signature unknown
        pass

    def test_getTestCaseNames__inheritance(self, *args, **kwargs): # real signature unknown
        pass

    def test_getTestCaseNames__not_a_TestCase(self, *args, **kwargs): # real signature unknown
        pass

    def test_getTestCaseNames__no_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromModule__faulty_load_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromModule__load_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromModule__not_a_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromModule__no_TestCase_instances(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromModule__no_TestCase_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromModule__TestCase_subclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__callable__call_staticmethod(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__callable__TestCase_instance(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__callable__TestSuite(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__callable__wrong_type(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__empty_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__empty_name_list(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__malformed_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__module_not_loaded(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_bad_object(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_empty_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_empty_name_list(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_invalid_testmethod(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_malformed_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_not_a_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_TestCase_subclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_testmethod(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__relative_TestSuite(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__unknown_attr_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__unknown_module_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__unknown_name_relative_1(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromNames__unknown_name_relative_2(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__callable__TestCase_instance(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__callable__TestCase_instance_ProperSuiteClass(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__callable__TestSuite(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__callable__wrong_type(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__empty_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__malformed_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__module_not_loaded(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_bad_object(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_empty_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_invalid_testmethod(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_malformed_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_not_a_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_TestCase_subclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_testmethod(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_testmethod_ProperSuiteClass(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_TestSuite(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__relative_unknown_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__unknown_attr_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromName__unknown_module_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromTestCase(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromTestCase__default_method_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromTestCase__no_matches(self, *args, **kwargs): # real signature unknown
        pass

    def test_loadTestsFromTestCase__TestSuite_subclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__default_value(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__getTestCaseNames(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__loadTestsFromModule(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__loadTestsFromName(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__loadTestsFromNames(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__loadTestsFromTestCase(self, *args, **kwargs): # real signature unknown
        pass

    def test_sortTestMethodsUsing__None(self, *args, **kwargs): # real signature unknown
        pass

    def test_suiteClass__default_value(self, *args, **kwargs): # real signature unknown
        pass

    def test_suiteClass__loadTestsFromModule(self, *args, **kwargs): # real signature unknown
        pass

    def test_suiteClass__loadTestsFromName(self, *args, **kwargs): # real signature unknown
        pass

    def test_suiteClass__loadTestsFromNames(self, *args, **kwargs): # real signature unknown
        pass

    def test_suiteClass__loadTestsFromTestCase(self, *args, **kwargs): # real signature unknown
        pass

    def test_testMethodPrefix__default_value(self, *args, **kwargs): # real signature unknown
        pass

    def test_testMethodPrefix__loadTestsFromModule(self, *args, **kwargs): # real signature unknown
        pass

    def test_testMethodPrefix__loadTestsFromName(self, *args, **kwargs): # real signature unknown
        pass

    def test_testMethodPrefix__loadTestsFromNames(self, *args, **kwargs): # real signature unknown
        pass

    def test_testMethodPrefix__loadTestsFromTestCase(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


