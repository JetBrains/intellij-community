# encoding: utf-8
# module unittest.test.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/__init__.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

here = '/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test'

# functions

def suite(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

loader = unittest.defaultTestLoader

