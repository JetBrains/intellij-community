# encoding: utf-8
# module unittest.test.test_case
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_case.pyo by generator 1.99
# no doc

# imports
import test.test_support as test_support # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/test/test_support.pyc
import pprint as pprint # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/pprint.pyc
import difflib as difflib # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/difflib.pyc
import sys as sys # <module 'sys' (built-in)>
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import unittest.case as __unittest_case
import unittest.result as __unittest_result
import unittest.test.support as __unittest_test_support


# functions

def deepcopy(x, memo=None, _nil='[]'): # reliably restored by inspect
    """
    Deep copy operation on arbitrary Python objects.
    
        See the module's __doc__ string for more info.
    """
    pass


# classes

class LoggingResult(__unittest_result.TestResult):
    # no doc
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class ResultWithNoStartTestRunStopTestRun(object):
    """ An object honouring TestResult before startTestRun/stopTestRun. """
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def wasSuccessful(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Test(object):
    """ Keep these TestCase classes out of the main namespace """
    def Bar(self, *args, **kwargs): # real signature unknown
        pass

    def Foo(self, *args, **kwargs): # real signature unknown
        pass

    def LoggingTestCase(self, *args, **kwargs): # real signature unknown
        """ A test case which logs its calls. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TestEquality(object):
    """ Used as a mixin for TestCase """
    def test_eq(self, *args, **kwargs): # real signature unknown
        pass

    def test_ne(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TestHashing(object):
    """ Used as a mixin for TestCase """
    def test_hash(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Test_TestCase(__unittest_case.TestCase, __unittest_test_support.TestEquality, __unittest_test_support.TestHashing):
    # no doc
    def testAddTypeEqualityFunc(self, *args, **kwargs): # real signature unknown
        pass

    def testAsertEqualSingleLine(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertDictContainsSubset(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertDictEqualTruncates(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIn(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIs(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIsInstance(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIsNone(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertIsNot(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertItemsEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertMultiLineEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertMultiLineEqualTruncates(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertNotIsInstance(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertNotRaisesRegexp(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertRaisesExcValue(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertRaisesRegexp(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertRaisesRegexpMismatch(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertRegexpMatches(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertSequenceEqualMaxDiff(self, *args, **kwargs): # real signature unknown
        pass

    def testAssertSetEqual(self, *args, **kwargs): # real signature unknown
        pass

    def testDeepcopy(self, *args, **kwargs): # real signature unknown
        pass

    def testEquality(self, *args, **kwargs): # real signature unknown
        pass

    def testInequality(self, *args, **kwargs): # real signature unknown
        pass

    def testPendingDeprecationMethodNames(self, *args, **kwargs): # real signature unknown
        """
        Test fail* methods pending deprecation, they will warn in 3.2.
        
                Do not use these methods.  They will go away in 3.3.
        """
        pass

    def testShortDescriptionWithMultiLineDocstring(self, *args, **kwargs): # real signature unknown
        """
        Tests shortDescription() for a method with a longer docstring.
        
                This method ensures that only the first line of a docstring is
                returned used in the short description, no matter how long the
                whole thing is.
        """
        pass

    def testShortDescriptionWithOneLineDocstring(self, *args, **kwargs): # real signature unknown
        """ Tests shortDescription() for a method with a docstring. """
        pass

    def testShortDescriptionWithoutDocstring(self, *args, **kwargs): # real signature unknown
        pass

    def testSynonymAssertMethodNames(self, *args, **kwargs): # real signature unknown
        """
        Test undocumented method name synonyms.
        
                Please do not use these methods names in your own code.
        
                This test confirms their continued existence and functionality
                in order to avoid breaking existing code.
        """
        pass

    def testTruncateMessage(self, *args, **kwargs): # real signature unknown
        pass

    def test_countTestCases(self, *args, **kwargs): # real signature unknown
        pass

    def test_defaultTestResult(self, *args, **kwargs): # real signature unknown
        pass

    def test_failureException__default(self, *args, **kwargs): # real signature unknown
        pass

    def test_failureException__subclassing__explicit_raise(self, *args, **kwargs): # real signature unknown
        pass

    def test_failureException__subclassing__implicit_raise(self, *args, **kwargs): # real signature unknown
        pass

    def test_id(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__no_test_name(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__test_name__invalid(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__test_name__valid(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order_default_result(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__error_in_setUp(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__error_in_setUp_default_result(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__error_in_tearDown(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__error_in_tearDown_default_result(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__error_in_test(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__error_in_test_default_result(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__failure_in_test(self, *args, **kwargs): # real signature unknown
        pass

    def test_run_call_order__failure_in_test_default_result(self, *args, **kwargs): # real signature unknown
        pass

    def test_run__uses_defaultTestResult(self, *args, **kwargs): # real signature unknown
        pass

    def test_setUp(self, *args, **kwargs): # real signature unknown
        pass

    def test_tearDown(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass

    eq_pairs = [
        (
            None, # (!) real value is ''
            '<value is a self-reference, replaced by this string>',
        ),
    ]
    ne_pairs = [
        (
            None, # (!) real value is ''
            None, # (!) real value is ''
        ),
        (
            '<value is a self-reference, replaced by this string>',
            None, # (!) real value is ''
        ),
        (
            '<value is a self-reference, replaced by this string>',
            None, # (!) real value is ''
        ),
    ]


