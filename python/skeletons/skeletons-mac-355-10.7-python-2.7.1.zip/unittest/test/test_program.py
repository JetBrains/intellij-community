# encoding: utf-8
# module unittest.test.test_program
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_program.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from cStringIO import StringIO

import unittest.case as __unittest_case
import unittest.main as __unittest_main


# no functions
# classes

class FakeRunner(object):
    # no doc
    def run(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    initArgs = None
    raiseError = False
    test = None
    __dict__ = None # (!) real value is ''


class InitialisableProgram(__unittest_main.TestProgram):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    defaultTest = None
    exit = False
    progName = 'test'
    result = None
    test = 'test'
    testLoader = unittest.defaultTestLoader
    testRunner = None
    verbosity = 1


class TestCommandLineArgs(__unittest_case.TestCase):
    # no doc
    def setUp(self, *args, **kwargs): # real signature unknown
        pass

    def testBufferCatchFailfast(self, *args, **kwargs): # real signature unknown
        pass

    def testCatchBreakInstallsHandler(self, *args, **kwargs): # real signature unknown
        pass

    def testHelpAndUnknown(self, *args, **kwargs): # real signature unknown
        pass

    def testRunTestsOldRunnerClass(self, *args, **kwargs): # real signature unknown
        pass

    def testRunTestsRunnerClass(self, *args, **kwargs): # real signature unknown
        pass

    def testRunTestsRunnerInstance(self, *args, **kwargs): # real signature unknown
        pass

    def testVerbosity(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


class Test_TestProgram(__unittest_case.TestCase):
    # no doc
    def FooBar(self, *args, **kwargs): # real signature unknown
        pass

    def FooBarLoader(self, *args, **kwargs): # real signature unknown
        """ Test loader that returns a suite containing FooBar. """
        pass

    def testNoExit(self, *args, **kwargs): # real signature unknown
        pass

    def test_discovery_from_dotted_path(self, *args, **kwargs): # real signature unknown
        pass

    def test_Exit(self, *args, **kwargs): # real signature unknown
        pass

    def test_ExitAsDefault(self, *args, **kwargs): # real signature unknown
        pass

    def test_NonExit(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


# variables with complex values

RESULT = None # (!) real value is ''

