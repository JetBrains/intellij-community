# encoding: utf-8
# module unittest.test.test_discovery
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_discovery.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import unittest.case as __unittest_case


# no functions
# classes

class TestDiscovery(__unittest_case.TestCase):
    # no doc
    def test_command_line_handling_do_discovery_calls_loader(self, *args, **kwargs): # real signature unknown
        pass

    def test_command_line_handling_do_discovery_too_many_arguments(self, *args, **kwargs): # real signature unknown
        pass

    def test_command_line_handling_parseArgs(self, *args, **kwargs): # real signature unknown
        pass

    def test_detect_module_clash(self, *args, **kwargs): # real signature unknown
        pass

    def test_discover(self, *args, **kwargs): # real signature unknown
        pass

    def test_discovery_from_dotted_path(self, *args, **kwargs): # real signature unknown
        pass

    def test_discover_with_modules_that_fail_to_import(self, *args, **kwargs): # real signature unknown
        pass

    def test_find_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_find_tests_with_package(self, *args, **kwargs): # real signature unknown
        pass

    def test_get_name_from_path(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


