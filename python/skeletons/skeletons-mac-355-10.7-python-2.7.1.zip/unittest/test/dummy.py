# encoding: utf-8
# module unittest.test.dummy
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/dummy.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
