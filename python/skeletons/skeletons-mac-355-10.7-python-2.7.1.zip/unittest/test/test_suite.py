# encoding: utf-8
# module unittest.test.test_suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_suite.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import unittest.case as __unittest_case
import unittest.result as __unittest_result
import unittest.test.support as __unittest_test_support


# functions

def _mk_TestSuite(*names): # reliably restored by inspect
    # no doc
    pass


# classes

class LoggingResult(__unittest_result.TestResult):
    # no doc
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Test(object):
    # no doc
    def Foo(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TestEquality(object):
    """ Used as a mixin for TestCase """
    def test_eq(self, *args, **kwargs): # real signature unknown
        pass

    def test_ne(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Test_TestSuite(__unittest_case.TestCase, __unittest_test_support.TestEquality):
    # no doc
    def test_addTests(self, *args, **kwargs): # real signature unknown
        pass

    def test_addTests__string(self, *args, **kwargs): # real signature unknown
        pass

    def test_addTest__casesuiteclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_addTest__noncallable(self, *args, **kwargs): # real signature unknown
        pass

    def test_addTest__noniterable(self, *args, **kwargs): # real signature unknown
        pass

    def test_addTest__TestCase(self, *args, **kwargs): # real signature unknown
        pass

    def test_addTest__TestSuite(self, *args, **kwargs): # real signature unknown
        pass

    def test_basetestsuite(self, *args, **kwargs): # real signature unknown
        pass

    def test_countTestCases_nested(self, *args, **kwargs): # real signature unknown
        pass

    def test_countTestCases_simple(self, *args, **kwargs): # real signature unknown
        pass

    def test_countTestCases_zero_nested(self, *args, **kwargs): # real signature unknown
        pass

    def test_countTestCases_zero_simple(self, *args, **kwargs): # real signature unknown
        pass

    def test_function_in_suite(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__empty_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__TestSuite_instances_in_tests(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__tests_from_any_iterable(self, *args, **kwargs): # real signature unknown
        pass

    def test_init__tests_optional(self, *args, **kwargs): # real signature unknown
        pass

    def test_iter(self, *args, **kwargs): # real signature unknown
        pass

    def test_overriding_call(self, *args, **kwargs): # real signature unknown
        pass

    def test_run(self, *args, **kwargs): # real signature unknown
        pass

    def test_run__empty_suite(self, *args, **kwargs): # real signature unknown
        pass

    def test_run__requires_result(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass

    eq_pairs = [
        (
            None, # (!) real value is ''
            '<value is a self-reference, replaced by this string>',
        ),
        '<value is a self-reference, replaced by this string>',
        (
            None, # (!) real value is ''
            '<value is a self-reference, replaced by this string>',
        ),
    ]
    ne_pairs = [
        (
            None, # (!) real value is ''
            None, # (!) real value is ''
        ),
        '<value is a self-reference, replaced by this string>',
        (
            None, # (!) real value is ''
            None, # (!) real value is ''
        ),
        (
            '<value is a self-reference, replaced by this string>',
            None, # (!) real value is ''
        ),
    ]


