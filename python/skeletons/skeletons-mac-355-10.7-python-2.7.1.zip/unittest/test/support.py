# encoding: utf-8
# module unittest.test.support
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/support.pyo by generator 1.99
# no doc

# imports
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import unittest.result as __unittest_result


# no functions
# classes

class LoggingResult(__unittest_result.TestResult):
    # no doc
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class ResultWithNoStartTestRunStopTestRun(object):
    """ An object honouring TestResult before startTestRun/stopTestRun. """
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def wasSuccessful(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TestEquality(object):
    """ Used as a mixin for TestCase """
    def test_eq(self, *args, **kwargs): # real signature unknown
        pass

    def test_ne(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TestHashing(object):
    """ Used as a mixin for TestCase """
    def test_hash(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


