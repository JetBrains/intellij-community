# encoding: utf-8
# module unittest.test.test_skipping
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_skipping.pyo by generator 1.99
# no doc

# imports
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import unittest.case as __unittest_case
import unittest.result as __unittest_result


# no functions
# classes

class LoggingResult(__unittest_result.TestResult):
    # no doc
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Test_TestSkipping(__unittest_case.TestCase):
    # no doc
    def test_decorated_skip(self, *args, **kwargs): # real signature unknown
        pass

    def test_expected_failure(self, *args, **kwargs): # real signature unknown
        pass

    def test_skipping(self, *args, **kwargs): # real signature unknown
        pass

    def test_skipping_decorators(self, *args, **kwargs): # real signature unknown
        pass

    def test_skip_class(self, *args, **kwargs): # real signature unknown
        pass

    def test_skip_doesnt_run_setup(self, *args, **kwargs): # real signature unknown
        pass

    def test_unexpected_success(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


