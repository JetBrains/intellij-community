# encoding: utf-8
# module unittest.test.test_runner
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_runner.pyo by generator 1.99
# no doc

# imports
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import pickle as pickle # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/pickle.pyc
from cStringIO import StringIO

import unittest.case as __unittest_case
import unittest.result as __unittest_result


# no functions
# classes

class LoggingResult(__unittest_result.TestResult):
    # no doc
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addExpectedFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSkip(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def addUnexpectedSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class ResultWithNoStartTestRunStopTestRun(object):
    """ An object honouring TestResult before startTestRun/stopTestRun. """
    def addError(self, *args, **kwargs): # real signature unknown
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def wasSuccessful(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TestCleanUp(__unittest_case.TestCase):
    # no doc
    def testCleanUp(self, *args, **kwargs): # real signature unknown
        pass

    def testCleanupInRun(self, *args, **kwargs): # real signature unknown
        pass

    def testCleanUpWithErrors(self, *args, **kwargs): # real signature unknown
        pass

    def testTestCaseDebugExecutesCleanups(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


class Test_TextTestRunner(__unittest_case.TestCase):
    """ Tests for TextTestRunner. """
    def testBufferAndFailfast(self, *args, **kwargs): # real signature unknown
        pass

    def testRunnerRegistersResult(self, *args, **kwargs): # real signature unknown
        pass

    def test_init(self, *args, **kwargs): # real signature unknown
        pass

    def test_pickle_unpickle(self, *args, **kwargs): # real signature unknown
        pass

    def test_resultclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_startTestRun_stopTestRun_called(self, *args, **kwargs): # real signature unknown
        pass

    def test_works_with_result_without_startTestRun_stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


