# encoding: utf-8
# module unittest.test.test_result
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_result.pyo by generator 1.99
# no doc

# imports
import test.test_support as test_support # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/test/test_support.pyc
import traceback as traceback # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/traceback.pyc
import textwrap as textwrap # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/textwrap.pyc
import sys as sys # <module 'sys' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
import unittest.case as __unittest_case


# Variables with simple values
m = '__init__'

# functions

def restore_traceback(): # reliably restored by inspect
    # no doc
    pass


def __init__(self, stream=None, descriptions=None, verbosity=None): # reliably restored by inspect
    # no doc
    pass


# classes

class MockTraceback(object):
    # no doc
    def format_exception(*_): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class OldResult(object):
    """
    Holder for test result information.
    
        Test results are automatically managed by the TestCase and TestSuite
        classes, and do not need to be explicitly manipulated by writers of tests.
    
        Each instance holds the total number of tests run, and collections of
        failures and errors that occurred among those test runs. The collections
        contain tuples of (testcase, exceptioninfo), where exceptioninfo is the
        formatted traceback of the error that occurred.
    """
    def addError(self, *args, **kwargs): # real signature unknown
        """
        Called when an error has occurred. 'err' is a tuple of values as
                returned by sys.exc_info().
        """
        pass

    def addFailure(self, *args, **kwargs): # real signature unknown
        """
        Called when an error has occurred. 'err' is a tuple of values as
                returned by sys.exc_info().
        """
        pass

    def addSuccess(self, *args, **kwargs): # real signature unknown
        """ Called when a test has completed successfully """
        pass

    def printErrors(self, *args, **kwargs): # real signature unknown
        """ Called by TestRunner after test run """
        pass

    def startTest(self, *args, **kwargs): # real signature unknown
        """ Called when the given test is about to be run """
        pass

    def startTestRun(self, *args, **kwargs): # real signature unknown
        """
        Called once before any tests are executed.
        
                See startTest for a method called before each test.
        """
        pass

    def stop(self, *args, **kwargs): # real signature unknown
        """ Indicates that the tests should be aborted """
        pass

    def stopTest(self, *args, **kwargs): # real signature unknown
        """ Called when the given test has been run """
        pass

    def stopTestRun(self, *args, **kwargs): # real signature unknown
        """
        Called once after all tests are executed.
        
                See stopTest for a method called after each test.
        """
        pass

    def wasSuccessful(self, *args, **kwargs): # real signature unknown
        """ Tells whether or not this result was a success """
        pass

    def _count_relevant_tb_levels(self, *args, **kwargs): # real signature unknown
        pass

    def _exc_info_to_string(self, *args, **kwargs): # real signature unknown
        """ Converts a sys.exc_info()-style tuple of values into a string. """
        pass

    def _is_relevant_tb_level(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _moduleSetUpFailed = False
    _previousTestClass = None
    _testRunEntered = False
    __dict__ = None # (!) real value is ''


class TestOutputBuffering(__unittest_case.TestCase):
    # no doc
    def getStartedResult(self, *args, **kwargs): # real signature unknown
        pass

    def setUp(self, *args, **kwargs): # real signature unknown
        pass

    def tearDown(self, *args, **kwargs): # real signature unknown
        pass

    def testBufferOutputAddErrorOrFailure(self, *args, **kwargs): # real signature unknown
        pass

    def testBufferOutputOff(self, *args, **kwargs): # real signature unknown
        pass

    def testBufferOutputStartTestAddSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


class Test_OldTestResult(__unittest_case.TestCase):
    # no doc
    def assertOldResultWarning(self, *args, **kwargs): # real signature unknown
        pass

    def testOldResultWithRunner(self, *args, **kwargs): # real signature unknown
        pass

    def testOldTestResult(self, *args, **kwargs): # real signature unknown
        pass

    def testOldTestResultClass(self, *args, **kwargs): # real signature unknown
        pass

    def testOldTestTesultSetup(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


class Test_TestResult(__unittest_case.TestCase):
    # no doc
    def testFailFast(self, *args, **kwargs): # real signature unknown
        pass

    def testFailFastSetByRunner(self, *args, **kwargs): # real signature unknown
        pass

    def testGetDescriptionWithMultiLineDocstring(self, *args, **kwargs): # real signature unknown
        """
        Tests getDescription() for a method with a longer docstring.
                The second line of the docstring.
        """
        pass

    def testGetDescriptionWithOneLineDocstring(self, *args, **kwargs): # real signature unknown
        """ Tests getDescription() for a method with a docstring. """
        pass

    def testGetDescriptionWithoutDocstring(self, *args, **kwargs): # real signature unknown
        pass

    def testStackFrameTrimming(self, *args, **kwargs): # real signature unknown
        pass

    def test_addError(self, *args, **kwargs): # real signature unknown
        pass

    def test_addFailure(self, *args, **kwargs): # real signature unknown
        pass

    def test_addSuccess(self, *args, **kwargs): # real signature unknown
        pass

    def test_init(self, *args, **kwargs): # real signature unknown
        pass

    def test_startTest(self, *args, **kwargs): # real signature unknown
        pass

    def test_startTestRun_stopTestRun(self, *args, **kwargs): # real signature unknown
        pass

    def test_stop(self, *args, **kwargs): # real signature unknown
        pass

    def test_stopTest(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


# variables with complex values

classDict = {
    '__dict__': None, # (!) real value is ''
    '__doc__': 'Holder for test result information.\n\n    Test results are automatically managed by the TestCase and TestSuite\n    classes, and do not need to be explicitly manipulated by writers of tests.\n\n    Each instance holds the total number of tests run, and collections of\n    failures and errors that occurred among those test runs. The collections\n    contain tuples of (testcase, exceptioninfo), where exceptioninfo is the\n    formatted traceback of the error that occurred.\n    ',
    '__init__': __init__,
    '__module__': 'unittest.result',
    '__repr__': None, # (!) real value is ''
    '__weakref__': None, # (!) real value is ''
    '_count_relevant_tb_levels': None, # (!) real value is ''
    '_exc_info_to_string': None, # (!) real value is ''
    '_is_relevant_tb_level': None, # (!) real value is ''
    '_moduleSetUpFailed': False,
    '_previousTestClass': None,
    '_testRunEntered': False,
    'addError': None, # (!) real value is ''
    'addFailure': None, # (!) real value is ''
    'addSuccess': None, # (!) real value is ''
    'printErrors': None, # (!) real value is ''
    'startTest': None, # (!) real value is ''
    'startTestRun': None, # (!) real value is ''
    'stop': None, # (!) real value is ''
    'stopTest': None, # (!) real value is ''
    'stopTestRun': None, # (!) real value is ''
    'wasSuccessful': None, # (!) real value is ''
}

StringIO = None # (!) real value is ''

