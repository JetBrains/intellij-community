# encoding: utf-8
# module unittest.test.test_setups
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/test/test_setups.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import unittest as unittest # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/__init__.pyc
from cStringIO import StringIO

import unittest.case as __unittest_case


# functions

def resultFactory(*_): # reliably restored by inspect
    # no doc
    pass


# classes

class TestSetups(__unittest_case.TestCase):
    # no doc
    def getRunner(self, *args, **kwargs): # real signature unknown
        pass

    def runTests(self, *args, **kwargs): # real signature unknown
        pass

    def test_class_not_setup_or_torndown_when_skipped(self, *args, **kwargs): # real signature unknown
        pass

    def test_class_not_torndown_when_setup_fails(self, *args, **kwargs): # real signature unknown
        pass

    def test_error_in_setupclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_error_in_setup_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_error_in_teardown_class(self, *args, **kwargs): # real signature unknown
        pass

    def test_error_in_teardown_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_setup_class(self, *args, **kwargs): # real signature unknown
        pass

    def test_setup_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_setup_teardown_order_with_pathological_suite(self, *args, **kwargs): # real signature unknown
        pass

    def test_skiptest_in_setupclass(self, *args, **kwargs): # real signature unknown
        pass

    def test_skiptest_in_setupmodule(self, *args, **kwargs): # real signature unknown
        pass

    def test_suite_debug_executes_setups_and_teardowns(self, *args, **kwargs): # real signature unknown
        pass

    def test_suite_debug_propagates_exceptions(self, *args, **kwargs): # real signature unknown
        pass

    def test_teardown_class(self, *args, **kwargs): # real signature unknown
        pass

    def test_teardown_class_two_classes(self, *args, **kwargs): # real signature unknown
        pass

    def test_teardown_module(self, *args, **kwargs): # real signature unknown
        pass

    def test_testcase_with_missing_module(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Create an instance of the class that will use the named test
                   method when executed. Raises a ValueError if the instance does
                   not have a method with the specified name.
        """
        pass


