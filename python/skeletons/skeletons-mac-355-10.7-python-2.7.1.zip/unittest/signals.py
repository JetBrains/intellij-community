# encoding: utf-8
# module unittest.signals
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/unittest/signals.pyo by generator 1.99
# no doc

# imports
import weakref as weakref # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/weakref.pyc
import signal as signal # <module 'signal' (built-in)>

# Variables with simple values

_interrupt_handler = None

__unittest = True

# functions

def installHandler(): # reliably restored by inspect
    # no doc
    pass


def registerResult(result): # reliably restored by inspect
    # no doc
    pass


def removeHandler(method=None): # reliably restored by inspect
    # no doc
    pass


def removeResult(result): # reliably restored by inspect
    # no doc
    pass


def wraps(wrapped, assigned="('__module__', '__name__', '__doc__')", updated="('__dict__',)"): # reliably restored by inspect
    """
    Decorator factory to apply update_wrapper() to a wrapper function
    
           Returns a decorator that invokes update_wrapper() with the decorated
           function as the wrapper argument and the arguments to wraps() as the
           remaining arguments. Default arguments are as for update_wrapper().
           This is a convenience function to simplify applying partial() to
           update_wrapper().
    """
    pass


# classes

class _InterruptHandler(object):
    # no doc
    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

_results = None # (!) real value is ''

