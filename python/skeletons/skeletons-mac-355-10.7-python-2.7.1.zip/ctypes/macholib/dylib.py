# encoding: utf-8
# module ctypes.macholib.dylib
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ctypes/macholib/dylib.pyo by generator 1.99
""" Generic dylib path manipulation """

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc

# functions

def dylib_info(filename): # reliably restored by inspect
    """
    A dylib name can take one of the following four forms:
            Location/Name.SomeVersion_Suffix.dylib
            Location/Name.SomeVersion.dylib
            Location/Name_Suffix.dylib
            Location/Name.dylib
    
        returns None if not found or a mapping equivalent to:
            dict(
                location='Location',
                name='Name.SomeVersion_Suffix.dylib',
                shortname='Name',
                version='SomeVersion',
                suffix='Suffix',
            )
    
        Note that SomeVersion and Suffix are optional and may be None
        if not present.
    """
    pass


def test_dylib_info(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

DYLIB_RE = None # (!) real value is ''

__all__ = [
    'dylib_info',
]

