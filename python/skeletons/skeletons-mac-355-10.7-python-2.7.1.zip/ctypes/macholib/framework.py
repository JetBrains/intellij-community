# encoding: utf-8
# module ctypes.macholib.framework
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ctypes/macholib/framework.pyo by generator 1.99
""" Generic framework path manipulation """

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc

# functions

def framework_info(filename): # reliably restored by inspect
    """
    A framework name can take one of the following four forms:
            Location/Name.framework/Versions/SomeVersion/Name_Suffix
            Location/Name.framework/Versions/SomeVersion/Name
            Location/Name.framework/Name_Suffix
            Location/Name.framework/Name
    
        returns None if not found, or a mapping equivalent to:
            dict(
                location='Location',
                name='Name.framework/Versions/SomeVersion/Name_Suffix',
                shortname='Name',
                version='SomeVersion',
                suffix='Suffix',
            )
    
        Note that SomeVersion and Suffix are optional and may be None
        if not present
    """
    pass


def test_framework_info(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

STRICT_FRAMEWORK_RE = None # (!) real value is ''

__all__ = [
    'framework_info',
]

