# encoding: utf-8
# module ctypes.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ctypes/__init__.pyo by generator 1.99
""" create and manipulate C data types in Python """

# imports
import sys as _sys # <module 'sys' (built-in)>
import os as _os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from _ctypes import (Array, LittleEndianStructure, POINTER, Structure, Union, 
    _CFuncPtr, _Pointer, _SimpleCData, _dlopen, addressof, alignment, byref, 
    get_errno, pointer, resize, set_conversion_mode, set_errno, sizeof)

from _struct import _calcsize

import _ctypes as ___ctypes


# Variables with simple values

DEFAULT_MODE = 4

RTLD_GLOBAL = 8
RTLD_LOCAL = 4

_cast_addr = 4428808081

_ctypes_version = '1.1.0'

_FUNCFLAG_CDECL = 1
_FUNCFLAG_PYTHONAPI = 4

_FUNCFLAG_USE_ERRNO = 8
_FUNCFLAG_USE_LASTERROR = 16

_memmove_addr = 140735471838796

_memset_addr = 140735471814112

_string_at_addr = 4428793090

_wstring_at_addr = 4428810428

__version__ = '1.1.0'

# functions

def ARRAY(typ, len): # reliably restored by inspect
    # no doc
    pass


def cast(obj, typ): # reliably restored by inspect
    # no doc
    pass


def CFUNCTYPE(restype, *argtypes, **kw): # reliably restored by inspect
    """
    CFUNCTYPE(restype, *argtypes,
                     use_errno=False, use_last_error=False) -> function prototype.
    
        restype: the result type
        argtypes: a sequence specifying the argument types
    
        The function prototype can be called in different ways to create a
        callable object:
    
        prototype(integer address) -> foreign function
        prototype(callable) -> create and return a C callable function from callable
        prototype(integer index, method name[, paramflags]) -> foreign function calling a COM method
        prototype((ordinal number, dll object)[, paramflags]) -> foreign function exported by ordinal
        prototype((function name, dll object)[, paramflags]) -> foreign function exported by name
    """
    pass


def create_string_buffer(init, size=None): # reliably restored by inspect
    """
    create_string_buffer(aString) -> character array
        create_string_buffer(anInteger) -> character array
        create_string_buffer(aString, anInteger) -> character array
    """
    pass


def create_unicode_buffer(init, size=None): # reliably restored by inspect
    """
    create_unicode_buffer(aString) -> character array
            create_unicode_buffer(anInteger) -> character array
            create_unicode_buffer(aString, anInteger) -> character array
    """
    pass


def c_buffer(init, size=None): # reliably restored by inspect
    # no doc
    pass


def memmove(*args, **kwargs): # real signature unknown
    pass


def memset(*args, **kwargs): # real signature unknown
    pass


def PYFUNCTYPE(restype, *argtypes): # reliably restored by inspect
    # no doc
    pass


def SetPointerType(pointer, cls): # reliably restored by inspect
    # no doc
    pass


def string_at(ptr, size=-1): # reliably restored by inspect
    """
    string_at(addr[, size]) -> string
    
        Return the string at addr.
    """
    pass


def wstring_at(ptr, size=-1): # reliably restored by inspect
    """
    wstring_at(addr[, size]) -> string
    
            Return the string at addr.
    """
    pass


def _cast(*args, **kwargs): # real signature unknown
    pass


def _check_size(typ, typecode=None): # reliably restored by inspect
    # no doc
    pass


def _string_at(*args, **kwargs): # real signature unknown
    pass


def _wstring_at(*args, **kwargs): # real signature unknown
    pass


# classes

class ArgumentError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class BigEndianStructure(___ctypes.Structure):
    """ Structure with big endian byte order """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _swappedbytes_ = None
    __dict__ = None # (!) real value is ''


class CDLL(object):
    """
    An instance of this class represents a loaded dll/shared
        library, exporting functions using the standard C calling
        convention (named 'cdecl' on Windows).
    
        The exported functions can be accessed as attributes, or by
        indexing with the function name.  Examples:
    
        <obj>.qsort -> callable object
        <obj>['qsort'] -> callable object
    
        Calling the functions releases the Python GIL during the call and
        reacquires it afterwards.
    """
    def _func_restype_(self, *args, **kwargs): # real signature unknown
        pass

    def __getattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _func_flags_ = 1
    __dict__ = None # (!) real value is ''


class c_bool(___ctypes._SimpleCData):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = '?'
    __dict__ = None # (!) real value is ''


class c_int8(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'b'
    __dict__ = None # (!) real value is ''


c_byte = c_int8


class c_char(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'c'
    __dict__ = None # (!) real value is ''


class c_char_p(___ctypes._SimpleCData):
    # no doc
    @classmethod
    def from_param(cls, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'z'
    __dict__ = None # (!) real value is ''


class c_double(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'd'
    __dict__ = None # (!) real value is ''


class c_float(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'f'
    __dict__ = None # (!) real value is ''


class c_int32(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'i'
    __dict__ = None # (!) real value is ''


c_int = c_int32


class c_short(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'h'
    __dict__ = None # (!) real value is ''


c_int16 = c_short


class c_ssize_t(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'l'
    __dict__ = None # (!) real value is ''


c_longlong = c_ssize_t


c_long = c_ssize_t


c_int64 = c_ssize_t


class c_longdouble(___ctypes._SimpleCData):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'g'
    __dict__ = None # (!) real value is ''


class c_ulonglong(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'L'
    __dict__ = None # (!) real value is ''


c_ulong = c_ulonglong


c_uint64 = c_ulonglong


c_size_t = c_ulonglong


class c_uint8(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'B'
    __dict__ = None # (!) real value is ''


c_ubyte = c_uint8


class c_uint32(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'I'
    __dict__ = None # (!) real value is ''


c_uint = c_uint32


class c_ushort(___ctypes._SimpleCData):
    # no doc
    def __ctype_be__(self, *args, **kwargs): # real signature unknown
        pass

    def __ctype_le__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'H'
    __dict__ = None # (!) real value is ''


c_uint16 = c_ushort


class c_void_p(___ctypes._SimpleCData):
    # no doc
    @classmethod
    def from_param(cls, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'P'
    __dict__ = None # (!) real value is ''


c_voidp = c_void_p


class c_wchar(___ctypes._SimpleCData):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'u'
    __dict__ = None # (!) real value is ''


class c_wchar_p(___ctypes._SimpleCData):
    # no doc
    @classmethod
    def from_param(cls, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'Z'
    __dict__ = None # (!) real value is ''


class LibraryLoader(object):
    # no doc
    def LoadLibrary(self, *args, **kwargs): # real signature unknown
        pass

    def __getattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class PyDLL(CDLL):
    """
    This class represents the Python library itself.  It allows to
        access Python API functions.  The GIL is not released, and
        Python exceptions are handled correctly.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _func_flags_ = 5


class py_object(___ctypes._SimpleCData):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _type_ = 'O'
    __dict__ = None # (!) real value is ''


# variables with complex values

cdll = None # (!) real value is ''

pydll = None # (!) real value is ''

pythonapi = None # (!) real value is ''

_c_functype_cache = {
    (
        c_int,
        (),
        1,
    ): 
        None # (!) real value is ''
    ,
    (
        c_voidp,
        (
            '<value is a self-reference, replaced by this string>',
            '<value is a self-reference, replaced by this string>',
            c_ulong,
        ),
        1,
    ): 
        None # (!) real value is ''
    ,
    (
        '<value is a self-reference, replaced by this string>',
        (
            '<value is a self-reference, replaced by this string>',
            '<value is a self-reference, replaced by this string>',
            '<value is a self-reference, replaced by this string>',
        ),
        1,
    ): 
        None # (!) real value is ''
    ,
}

_pointer_type_cache = {
    None: c_voidp,
    None:  # (!) real value is ''
        None # (!) real value is ''
    ,
    None:  # (!) real value is ''
        None # (!) real value is ''
    ,
    c_char: 
        None # (!) real value is ''
    ,
    c_wchar: 
        None # (!) real value is ''
    ,
}

