# encoding: utf-8
# module twisted.python._initgroups
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/twisted/python/_initgroups.so by generator 1.99
# no doc
# no imports

# functions

def initgroups(*args, **kwargs): # real signature unknown
    pass


# no classes
