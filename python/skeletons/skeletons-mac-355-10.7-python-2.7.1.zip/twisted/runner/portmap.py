# encoding: utf-8
# module twisted.runner.portmap
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/twisted/runner/portmap.so by generator 1.99
# no doc
# no imports

# functions

def set(*args, **kwargs): # real signature unknown
    """ Set an entry in the portmapper. """
    pass


def unset(*args, **kwargs): # real signature unknown
    """ Unset an entry in the portmapper. """
    pass


# no classes
