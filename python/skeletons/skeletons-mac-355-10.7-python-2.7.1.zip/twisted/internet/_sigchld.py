# encoding: utf-8
# module twisted.internet._sigchld
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/twisted/internet/_sigchld.so by generator 1.99
""" This module contains an API for receiving SIGCHLD via a file descriptor. """
# no imports

# functions

def installHandler(*args, **kwargs): # real signature unknown
    """
    install_sigchld_handler(fd)
    
    Installs a SIGCHLD handler which will write a byte to the given fd
    whenever a SIGCHLD occurs. This is done in C code because the python
    signal handling system is not reliable, and additionally cannot
    specify SA_RESTART.
    
    Please ensure fd is in non-blocking mode.
    """
    pass


def isDefaultHandler(*args, **kwargs): # real signature unknown
    """ Return 1 if the SIGCHLD handler is SIG_DFL, 0 otherwise. """
    pass


# no classes
