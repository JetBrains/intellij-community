# encoding: utf-8
# module _builtinSuites.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/_builtinSuites/__init__.pyo by generator 1.99
"""
Manually generated suite used as base class for StdSuites Required and Standard
suites. This is needed because the events and enums in this suite belong
in the Required suite according to the Apple docs, but they often seem to be
in the Standard suite.
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import _builtinSuites.builtin_Suite as builtin_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/_builtinSuites/builtin_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# functions

def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

builtin_Suite_Events = builtin_Suite.builtin_Suite_Events

_builtinSuites = None # (!) real value is ''

_code_to_fullname = {
    'core': (
        '_builtinSuites.builtin_Suite',
        'builtin_Suite',
    ),
    'reqd': '<value is a self-reference, replaced by this string>',
}

_code_to_module = {
    'core': None, # (!) forward: builtin_Suite, real value is ''
    'reqd': '<value is a self-reference, replaced by this string>',
}

