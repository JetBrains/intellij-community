# encoding: utf-8
# module pydoc_data.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/pydoc_data/__init__.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
