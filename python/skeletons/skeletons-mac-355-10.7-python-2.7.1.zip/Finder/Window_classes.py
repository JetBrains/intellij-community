# encoding: utf-8
# module Finder.Window_classes
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Window_classes.pyo by generator 1.99
"""
Suite Window classes: Classes representing windows
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'fndr'

# no functions
# no classes
# variables with complex values

clipping_window = None # (!) forward: clipping_windows, real value is ''

clipping_windows = None # (!) real value is ''

Finder_window = None # (!) real value is ''

Finder_windows = Finder_window

information_window = None # (!) real value is ''

preferences_window = None # (!) real value is ''

window = None # (!) real value is ''

windows = window

Window_classes_Events = None # (!) real value is ''

_classdeclarations = {
    'brow': Finder_window,
    'cwin': window,
    'iwnd': information_window,
    'lwnd': clipping_windows,
    'pwnd': preferences_window,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'ID  ': None, # (!) forward: _Prop_id, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'cobj': None, # (!) forward: _Prop_item, real value is ''
    'fvtg': None, # (!) forward: _Prop_target, real value is ''
    'hclb': None, # (!) forward: _Prop_closeable, real value is ''
    'icop': None, # (!) forward: _Prop_icon_view_options, real value is ''
    'isfl': None, # (!) forward: _Prop_floating, real value is ''
    'iszm': None, # (!) forward: _Prop_zoomable, real value is ''
    'lvop': None, # (!) forward: _Prop_list_view_options, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
    'panl': None, # (!) forward: _Prop_current_panel, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pmod': None, # (!) forward: _Prop_modal, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'posn': None, # (!) forward: _Prop_position, real value is ''
    'prsz': None, # (!) forward: _Prop_resizable, real value is ''
    'ptit': None, # (!) forward: _Prop_titled, real value is ''
    'pvew': None, # (!) forward: _Prop_current_view, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'pzum': None, # (!) forward: _Prop_zoomed, real value is ''
    'wshd': None, # (!) forward: _Prop_collapsed, real value is ''
    'zumf': None, # (!) forward: _Prop_zoomed_full_size, real value is ''
}

_Prop_bounds = None # (!) real value is ''

_Prop_closeable = None # (!) real value is ''

_Prop_collapsed = None # (!) real value is ''

_Prop_current_panel = None # (!) real value is ''

_Prop_current_view = None # (!) real value is ''

_Prop_floating = None # (!) real value is ''

_Prop_icon_view_options = None # (!) real value is ''

_Prop_id = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_item = None # (!) real value is ''

_Prop_list_view_options = None # (!) real value is ''

_Prop_modal = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_position = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop_resizable = None # (!) real value is ''

_Prop_target = None # (!) real value is ''

_Prop_titled = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_zoomable = None # (!) real value is ''

_Prop_zoomed = None # (!) real value is ''

_Prop_zoomed_full_size = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

