# encoding: utf-8
# module Finder.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/__init__.pyo by generator 1.99
""" Package generated from /System/Library/CoreServices/Finder.app """

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import StdSuites as StdSuites # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/__init__.pyc
import Finder.Files as Files # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Files.pyc
import Finder.Enumerations as Enumerations # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Enumerations.pyc
import Finder.Finder_items as Finder_items # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_items.pyc
import Finder.Type_Definitions as Type_Definitions # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Type_Definitions.pyc
import Finder.Window_classes as Window_classes # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Window_classes.pyc
import Finder.Finder_Basics as Finder_Basics # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_Basics.pyc
import Finder.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import Finder.Legacy_suite as Legacy_suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Legacy_suite.pyc
import Finder.Containers_and_folders as Containers_and_folders # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Containers_and_folders.pyc

# Variables with simple values

Error = 'aetools.Error'

# functions

def getbaseclasses(v): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

alias = StdSuites.aliases

aliases = StdSuites.aliases

alias_file = Files.alias_files

alias_files = Files.alias_files

alias_list = Type_Definitions.alias_list

application = Finder_Basics.application

applications = StdSuites.application

application_dictionary = StdSuites.application_dictionary

application_file = Files.application_files

application_files = Files.application_files

application_process = Legacy_suite.application_process

application_processes = Legacy_suite.application_process

bounding_rectangle = StdSuites.bounding_rectangle

builtin_Suite_Events = StdSuites.builtin_Suite_Events

clipboard = Finder_Basics.clipboard

clipping = Files.clipping

clippings = Files.clipping

clipping_window = Window_classes.clipping_windows

clipping_windows = Window_classes.clipping_windows

color_table = StdSuites.color_table

column = Type_Definitions.columns

columns = Type_Definitions.columns

container = Containers_and_folders.container

containers = Containers_and_folders.container

Containers_and_folders_Events = Containers_and_folders.Containers_and_folders_Events

contains = StdSuites.contains

dash_style = StdSuites.dash_style

desktop = Finder_Basics.desktop

desktop_2d_object = Containers_and_folders.desktop_2d_object

desktop_picture = Legacy_suite.desktop_picture

desk_accessory_process = Legacy_suite.desk_accessory_process

desk_accessory_processes = Legacy_suite.desk_accessory_process

disk = Containers_and_folders.disk

disks = Containers_and_folders.disk

document = StdSuites.document

documents = StdSuites.document

document_file = Files.document_file

document_files = Files.document_file

double_integer = StdSuites.double_integer

ends_with = StdSuites.ends_with

Enumerations_Events = Enumerations.Enumerations_Events

extended_real = StdSuites.extended_real

file = Files.file

files = Files.file

Files_Events = Files.Files_Events

Finder = None # (!) real value is ''

Finder_Basics_Events = Finder_Basics.Finder_Basics_Events

Finder_items_Events = Finder_items.Finder_items_Events

Finder_preferences = Finder_Basics.Finder_preferences

Finder_window = Window_classes.Finder_window

Finder_windows = Window_classes.Finder_window

fixed = StdSuites.fixed

fixed_point = StdSuites.fixed_point

fixed_rectangle = StdSuites.fixed_rectangle

folder = Containers_and_folders.folder

folders = Containers_and_folders.folder

frontmost = Finder_Basics.frontmost

home = Finder_Basics.home

icon_family = Type_Definitions.icon_family

icon_view_options = Type_Definitions.icon_view_options

information_window = Window_classes.information_window

insertion_location = Finder_Basics.insertion_location

insertion_point = StdSuites.insertion_points

insertion_points = StdSuites.insertion_points

internet_location_file = Files.internet_location_files

internet_location_files = Files.internet_location_files

item = Finder_items.items

items = Finder_items.items

label = Type_Definitions.label

Legacy_suite_Events = Legacy_suite.Legacy_suite_Events

list_view_options = Type_Definitions.list_view_options

location_reference = StdSuites.location_reference

long_fixed = StdSuites.long_fixed

long_fixed_point = StdSuites.long_fixed_point

long_fixed_rectangle = StdSuites.long_fixed_rectangle

long_point = StdSuites.long_point

long_rectangle = StdSuites.long_rectangle

machine_location = StdSuites.machine_location

menu = StdSuites.menu

menu_item = StdSuites.menu_item

name = Finder_Basics.name

null = StdSuites.null

package = Files.packages

packages = Files.packages

pixel_map_record = StdSuites.pixel_map_record

plain_text = StdSuites.string

point = StdSuites.point

PostScript_picture = StdSuites.PostScript_picture

preferences = Type_Definitions.preferences

preferences_window = Window_classes.preferences_window

process = Legacy_suite.process

processes = Legacy_suite.process

product_version = Finder_Basics.product_version

RGB16_color = StdSuites.RGB16_color

RGB96_color = StdSuites.RGB96_color

rotation = StdSuites.rotation

scrap_styles = StdSuites.scrap_styles

selection = Finder_Basics.selection

selection_2d_object = StdSuites.selection_2d_object

small_integer = StdSuites.small_integer

small_real = StdSuites.small_real

Standard_Suite_Events = Standard_Suite.Standard_Suite_Events

starts_with = StdSuites.starts_with

startup_disk = Finder_Basics.startup_disk

string = StdSuites.string

system_dictionary = StdSuites.system_dictionary

target_id = StdSuites.target_id

TIFF_picture = StdSuites.TIFF_picture

trash = Finder_Basics.trash

trash_2d_object = Containers_and_folders.trash_2d_object

type_class_info = StdSuites.type_class_info

Type_Definitions_Events = Type_Definitions.Type_Definitions_Events

type_element_info = StdSuites.type_element_info

type_event_info = StdSuites.type_event_info

Type_Names_Suite_Events = StdSuites.Type_Names_Suite_Events

type_parameter_info = StdSuites.type_parameter_info

type_property_info = StdSuites.type_property_info

type_suite_info = StdSuites.type_suite_info

unsigned_integer = StdSuites.unsigned_integer

version = StdSuites.version

visible = Finder_Basics.visible

window = Window_classes.window

windows = Window_classes.window

Window_classes_Events = Window_classes.Window_classes_Events

_classdeclarations = {
    'EPS ': StdSuites.PostScript_picture,
    'QDpt': StdSuites.point,
    'TEXT': StdSuites.string,
    'TIFF': StdSuites.TIFF_picture,
    'aete': StdSuites.application_dictionary,
    'aeut': StdSuites.system_dictionary,
    'alia': Files.alias_files,
    'alst': Type_Definitions.alias_list,
    'appf': Files.application_files,
    'brow': Window_classes.Finder_window,
    'capp': Finder_Basics.application,
    'cdis': Containers_and_folders.disk,
    'cdsk': Containers_and_folders.desktop_2d_object,
    'cfol': Containers_and_folders.folder,
    'clbl': Type_Definitions.label,
    'clpf': Files.clipping,
    'clrt': StdSuites.color_table,
    'cmen': StdSuites.menu_item,
    'cmnu': StdSuites.menu,
    'cobj': Finder_items.items,
    'comp': StdSuites.double_integer,
    'cprf': Type_Definitions.preferences,
    'ctnr': Containers_and_folders.container,
    'ctrs': Containers_and_folders.trash_2d_object,
    'cwin': Window_classes.window,
    'docf': Files.document_file,
    'elin': StdSuites.type_element_info,
    'evin': StdSuites.type_event_info,
    'exte': StdSuites.extended_real,
    'file': Files.file,
    'fixd': StdSuites.fixed,
    'fpnt': StdSuites.fixed_point,
    'frct': StdSuites.fixed_rectangle,
    'gcli': StdSuites.type_class_info,
    'icop': Type_Definitions.icon_view_options,
    'ifam': Type_Definitions.icon_family,
    'inlf': Files.internet_location_files,
    'insl': StdSuites.location_reference,
    'iwnd': Window_classes.information_window,
    'lfpt': StdSuites.long_fixed_point,
    'lfrc': StdSuites.long_fixed_rectangle,
    'lfxd': StdSuites.long_fixed,
    'lpnt': StdSuites.long_point,
    'lrct': StdSuites.long_rectangle,
    'lvcl': Type_Definitions.columns,
    'lvop': Type_Definitions.list_view_options,
    'lwnd': Window_classes.clipping_windows,
    'mLoc': StdSuites.machine_location,
    'magn': StdSuites.unsigned_integer,
    'null': StdSuites.null,
    'pack': Files.packages,
    'pcap': Legacy_suite.application_process,
    'pcda': Legacy_suite.desk_accessory_process,
    'pinf': StdSuites.type_property_info,
    'pmin': StdSuites.type_parameter_info,
    'prcs': Legacy_suite.process,
    'pwnd': Window_classes.preferences_window,
    'qdrt': StdSuites.bounding_rectangle,
    'shor': StdSuites.small_integer,
    'sing': StdSuites.small_real,
    'styl': StdSuites.scrap_styles,
    'suin': StdSuites.type_suite_info,
    'targ': StdSuites.target_id,
    'tdas': StdSuites.dash_style,
    'tpmm': StdSuites.pixel_map_record,
    'tr16': StdSuites.RGB16_color,
    'tr96': StdSuites.RGB96_color,
    'trot': StdSuites.rotation,
    'vers': StdSuites.version,
}

_code_to_fullname = {
    'CoRe': (
        'Finder.Standard_Suite',
        'Standard_Suite',
    ),
    'fleg': (
        'Finder.Legacy_suite',
        'Legacy_suite',
    ),
    'fndr': (
        'Finder.Window_classes',
        'Window_classes',
    ),
    'tpdf': (
        'Finder.Type_Definitions',
        'Type_Definitions',
    ),
    'tpnm': (
        'Finder.Enumerations',
        'Enumerations',
    ),
}

_code_to_module = {
    'CoRe': None, # (!) forward: Standard_Suite, real value is ''
    'fleg': None, # (!) forward: Legacy_suite, real value is ''
    'fndr': Finder_Basics.Window_classes,
    'tpdf': None, # (!) forward: Type_Definitions, real value is ''
    'tpnm': None, # (!) forward: Enumerations, real value is ''
}

