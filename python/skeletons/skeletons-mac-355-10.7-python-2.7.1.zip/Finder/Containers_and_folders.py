# encoding: utf-8
# module Finder.Containers_and_folders
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Containers_and_folders.pyo by generator 1.99
"""
Suite Containers and folders: Classes that can contain other file system items
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import Finder.Files as Files # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Files.pyc
import Finder.Finder_items as Finder_items # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_items.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'fndr'

# no functions
# no classes
# variables with complex values

container = None # (!) real value is ''

containers = container

Containers_and_folders_Events = None # (!) real value is ''

desktop_2d_object = None # (!) real value is ''

disk = None # (!) real value is ''

disks = disk

folder = None # (!) real value is ''

folders = folder

trash_2d_object = None # (!) real value is ''

_classdeclarations = {
    'cdis': disk,
    'cdsk': desktop_2d_object,
    'cfol': folder,
    'ctnr': container,
    'ctrs': trash_2d_object,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'capa': None, # (!) forward: _Prop_capacity, real value is ''
    'cwnd': None, # (!) forward: _Prop_container_window, real value is ''
    'dfmt': None, # (!) forward: _Prop_format, real value is ''
    'ects': None, # (!) forward: _Prop_entire_contents, real value is ''
    'frsp': None, # (!) forward: _Prop_free_space, real value is ''
    'igpr': None, # (!) forward: _Prop_ignore_privileges, real value is ''
    'isej': None, # (!) forward: _Prop_ejectable, real value is ''
    'isrv': None, # (!) forward: _Prop_local_volume, real value is ''
    'istd': None, # (!) forward: _Prop_startup, real value is ''
    'pexa': None, # (!) forward: _Prop_expandable, real value is ''
    'pexc': None, # (!) forward: _Prop_completely_expanded, real value is ''
    'pexp': None, # (!) forward: _Prop_expanded, real value is ''
    'warn': None, # (!) forward: _Prop_warns_before_emptying, real value is ''
}

_Prop_capacity = None # (!) real value is ''

_Prop_completely_expanded = None # (!) real value is ''

_Prop_container_window = None # (!) real value is ''

_Prop_ejectable = None # (!) real value is ''

_Prop_entire_contents = None # (!) real value is ''

_Prop_expandable = None # (!) real value is ''

_Prop_expanded = None # (!) real value is ''

_Prop_format = None # (!) real value is ''

_Prop_free_space = None # (!) real value is ''

_Prop_ignore_privileges = None # (!) real value is ''

_Prop_local_volume = None # (!) real value is ''

_Prop_startup = None # (!) real value is ''

_Prop_warns_before_emptying = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

