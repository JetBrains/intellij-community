# encoding: utf-8
# module Finder.Finder_items
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_items.pyo by generator 1.99
"""
Suite Finder items: Commands used with file system items, and basic item definition
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'fndr'

# no functions
# no classes
# variables with complex values

Finder_items_Events = None # (!) real value is ''

item = None # (!) forward: items, real value is ''

items = None # (!) real value is ''

_classdeclarations = {
    'cobj': items,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'ascd': None, # (!) forward: _Prop_creation_date, real value is ''
    'aslk': None, # (!) forward: _Prop_locked, real value is ''
    'asmo': None, # (!) forward: _Prop_modification_date, real value is ''
    'cdis': None, # (!) forward: _Prop_disk, real value is ''
    'comt': None, # (!) forward: _Prop_comment, real value is ''
    'ctnr': None, # (!) forward: _Prop_container, real value is ''
    'dnam': None, # (!) forward: _Prop_displayed_name, real value is ''
    'dscr': None, # (!) forward: _Prop_description, real value is ''
    'gppr': None, # (!) forward: _Prop_group_privileges, real value is ''
    'gstp': None, # (!) forward: _Prop_everyones_privileges, real value is ''
    'hidx': None, # (!) forward: _Prop_extension_hidden, real value is ''
    'iimg': None, # (!) forward: _Prop_icon, real value is ''
    'iwnd': None, # (!) forward: _Prop_information_window, real value is ''
    'kind': None, # (!) forward: _Prop_kind, real value is ''
    'labi': None, # (!) forward: _Prop_label_index, real value is ''
    'nmxt': None, # (!) forward: _Prop_name_extension, real value is ''
    'ownr': None, # (!) forward: _Prop_owner_privileges, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
    'pURL': None, # (!) forward: _Prop_url, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'phys': None, # (!) forward: _Prop_physical_size, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'posn': None, # (!) forward: _Prop_position, real value is ''
    'ptsz': None, # (!) forward: _Prop_size, real value is ''
    'sgrp': None, # (!) forward: _Prop_group, real value is ''
    'sown': None, # (!) forward: _Prop_owner, real value is ''
}

_Prop_bounds = None # (!) real value is ''

_Prop_comment = None # (!) real value is ''

_Prop_container = None # (!) real value is ''

_Prop_creation_date = None # (!) real value is ''

_Prop_description = None # (!) real value is ''

_Prop_disk = None # (!) real value is ''

_Prop_displayed_name = None # (!) real value is ''

_Prop_everyones_privileges = None # (!) real value is ''

_Prop_extension_hidden = None # (!) real value is ''

_Prop_group = None # (!) real value is ''

_Prop_group_privileges = None # (!) real value is ''

_Prop_icon = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_information_window = None # (!) real value is ''

_Prop_kind = None # (!) real value is ''

_Prop_label_index = None # (!) real value is ''

_Prop_locked = None # (!) real value is ''

_Prop_modification_date = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_name_extension = None # (!) real value is ''

_Prop_owner = None # (!) real value is ''

_Prop_owner_privileges = None # (!) real value is ''

_Prop_physical_size = None # (!) real value is ''

_Prop_position = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop_size = None # (!) real value is ''

_Prop_url = None # (!) real value is ''

