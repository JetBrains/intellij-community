# encoding: utf-8
# module Finder.Legacy_suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Legacy_suite.pyo by generator 1.99
"""
Suite Legacy suite: Operations formerly handled by the Finder, but now automatically delegated to other applications
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'fleg'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

application_process = None # (!) real value is ''

application_processes = application_process

desktop_picture = None # (!) real value is ''

desk_accessory_process = None # (!) real value is ''

desk_accessory_processes = desk_accessory_process

Legacy_suite_Events = None # (!) real value is ''

process = None # (!) real value is ''

processes = process

_classdeclarations = {
    'capp': application,
    'pcap': application_process,
    'pcda': desk_accessory_process,
    'prcs': process,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'appf': None, # (!) forward: _Prop_application_file, real value is ''
    'appt': None, # (!) forward: _Prop_total_partition_size, real value is ''
    'asty': None, # (!) forward: _Prop_file_type, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'dafi': None, # (!) forward: _Prop_desk_accessory_file, real value is ''
    'dpic': None, # (!) forward: _Prop_desktop_picture, real value is ''
    'fcrt': None, # (!) forward: _Prop_creator_type, real value is ''
    'file': None, # (!) forward: _Prop_file, real value is ''
    'hscr': None, # (!) forward: _Prop_has_scripting_terminology, real value is ''
    'isab': None, # (!) forward: _Prop_accepts_high_level_events, real value is ''
    'pisf': None, # (!) forward: _Prop_frontmost, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'pusd': None, # (!) forward: _Prop_partition_space_used, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'revt': None, # (!) forward: _Prop_accepts_remote_events, real value is ''
}

_Prop_accepts_high_level_events = None # (!) real value is ''

_Prop_accepts_remote_events = None # (!) real value is ''

_Prop_application_file = None # (!) real value is ''

_Prop_creator_type = None # (!) real value is ''

_Prop_desktop_picture = None # (!) real value is ''

_Prop_desk_accessory_file = None # (!) real value is ''

_Prop_file = None # (!) real value is ''

_Prop_file_type = None # (!) real value is ''

_Prop_frontmost = None # (!) real value is ''

_Prop_has_scripting_terminology = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_partition_space_used = None # (!) real value is ''

_Prop_total_partition_size = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

