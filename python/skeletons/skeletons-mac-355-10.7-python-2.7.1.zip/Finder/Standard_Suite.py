# encoding: utf-8
# module Finder.Standard_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Standard_Suite.pyo by generator 1.99
"""
Suite Standard Suite: Common terms that most applications should support
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'CoRe'

_Enum_bool = None
_Enum_list = None

# no functions
# no classes
# variables with complex values

alias = None # (!) forward: aliases, real value is ''

aliases = None # (!) real value is ''

application = None # (!) real value is ''

applications = application

builtin_Suite_Events = None # (!) real value is ''

clipboard = None # (!) real value is ''

contains = None # (!) real value is ''

document = None # (!) forward: documents, real value is ''

documents = None # (!) real value is ''

ends_with = None # (!) real value is ''

file = None # (!) real value is ''

files = file

frontmost = None # (!) real value is ''

insertion_point = None # (!) forward: insertion_points, real value is ''

insertion_points = None # (!) real value is ''

name = None # (!) real value is ''

selection = None # (!) real value is ''

selection_2d_object = None # (!) real value is ''

Standard_Suite_Events = None # (!) real value is ''

starts_with = None # (!) real value is ''

version = None # (!) real value is ''

window = None # (!) real value is ''

windows = window

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {}

