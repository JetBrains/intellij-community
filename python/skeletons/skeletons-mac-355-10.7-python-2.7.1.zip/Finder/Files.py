# encoding: utf-8
# module Finder.Files
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Files.pyo by generator 1.99
"""
Suite Files: Classes representing files
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import Finder.Finder_items as Finder_items # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_items.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'fndr'

# no functions
# no classes
# variables with complex values

alias_file = None # (!) forward: alias_files, real value is ''

alias_files = None # (!) real value is ''

application_file = None # (!) forward: application_files, real value is ''

application_files = None # (!) real value is ''

clipping = None # (!) real value is ''

clippings = clipping

document_file = None # (!) real value is ''

document_files = document_file

file = None # (!) real value is ''

files = file

Files_Events = None # (!) real value is ''

internet_location_file = None # (!) forward: internet_location_files, real value is ''

internet_location_files = None # (!) real value is ''

package = None # (!) forward: packages, real value is ''

packages = None # (!) real value is ''

_classdeclarations = {
    'alia': alias_files,
    'appf': application_files,
    'clpf': clipping,
    'docf': document_file,
    'file': file,
    'inlf': internet_location_files,
    'pack': packages,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'Clsc': None, # (!) forward: _Prop_opens_in_Classic, real value is ''
    'appt': None, # (!) forward: _Prop_preferred_size, real value is ''
    'asty': None, # (!) forward: _Prop_file_type, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'fcrt': None, # (!) forward: _Prop_creator_type, real value is ''
    'hscr': None, # (!) forward: _Prop_has_scripting_terminology, real value is ''
    'iloc': None, # (!) forward: _Prop_location, real value is ''
    'isab': None, # (!) forward: _Prop_accepts_high_level_events, real value is ''
    'lwnd': None, # (!) forward: _Prop_clipping_window, real value is ''
    'mprt': None, # (!) forward: _Prop_minimum_size, real value is ''
    'orig': None, # (!) forward: _Prop_original_item, real value is ''
    'pspd': None, # (!) forward: _Prop_stationery, real value is ''
    'sprt': None, # (!) forward: _Prop_suggested_size, real value is ''
    'ver2': None, # (!) forward: _Prop_product_version, real value is ''
    'vers': None, # (!) forward: _Prop_version, real value is ''
}

_Prop_accepts_high_level_events = None # (!) real value is ''

_Prop_clipping_window = None # (!) real value is ''

_Prop_creator_type = None # (!) real value is ''

_Prop_file_type = None # (!) real value is ''

_Prop_has_scripting_terminology = None # (!) real value is ''

_Prop_location = None # (!) real value is ''

_Prop_minimum_size = None # (!) real value is ''

_Prop_opens_in_Classic = None # (!) real value is ''

_Prop_original_item = None # (!) real value is ''

_Prop_preferred_size = None # (!) real value is ''

_Prop_product_version = None # (!) real value is ''

_Prop_stationery = None # (!) real value is ''

_Prop_suggested_size = None # (!) real value is ''

_Prop_version = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

