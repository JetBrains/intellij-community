# encoding: utf-8
# module Finder.Enumerations
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Enumerations.pyo by generator 1.99
"""
Suite Enumerations: Enumerations for the Finder
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'tpnm'

# no functions
# no classes
# variables with complex values

application_dictionary = None # (!) real value is ''

bounding_rectangle = None # (!) real value is ''

color_table = None # (!) real value is ''

dash_style = None # (!) real value is ''

double_integer = None # (!) real value is ''

Enumerations_Events = None # (!) real value is ''

extended_real = None # (!) real value is ''

fixed = None # (!) real value is ''

fixed_point = None # (!) real value is ''

fixed_rectangle = None # (!) real value is ''

location_reference = None # (!) real value is ''

long_fixed = None # (!) real value is ''

long_fixed_point = None # (!) real value is ''

long_fixed_rectangle = None # (!) real value is ''

long_point = None # (!) real value is ''

long_rectangle = None # (!) real value is ''

machine_location = None # (!) real value is ''

menu = None # (!) real value is ''

menu_item = None # (!) real value is ''

null = None # (!) real value is ''

pixel_map_record = None # (!) real value is ''

plain_text = None # (!) forward: string, real value is ''

point = None # (!) real value is ''

PostScript_picture = None # (!) real value is ''

RGB16_color = None # (!) real value is ''

RGB96_color = None # (!) real value is ''

rotation = None # (!) real value is ''

scrap_styles = None # (!) real value is ''

small_integer = None # (!) real value is ''

small_real = None # (!) real value is ''

string = None # (!) real value is ''

system_dictionary = None # (!) real value is ''

target_id = None # (!) real value is ''

TIFF_picture = None # (!) real value is ''

type_class_info = None # (!) real value is ''

type_element_info = None # (!) real value is ''

type_event_info = None # (!) real value is ''

Type_Names_Suite_Events = None # (!) real value is ''

type_parameter_info = None # (!) real value is ''

type_property_info = None # (!) real value is ''

type_suite_info = None # (!) real value is ''

unsigned_integer = None # (!) real value is ''

version = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {
    'earr': {
        'arranged_by_creation_date': 'cdta',
        'arranged_by_kind': 'kina',
        'arranged_by_label': 'laba',
        'arranged_by_modification_date': 'mdta',
        'arranged_by_name': 'nama',
        'arranged_by_size': 'siza',
        'not_arranged': 'narr',
        'snap_to_grid': 'grda',
    },
    'ecvw': {
        'column_view': 'clvw',
        'icon_view': 'icnv',
        'list_view': 'lsvw',
    },
    'edfm': {
        'AppleShare_format': 'dfas',
        'Apple_Photo_format': 'dfph',
        'FTP_format': 'dfft',
        'High_Sierra_format': 'dfhs',
        'ISO_9660_format': 'df96',
        'MS_2d_DOS_format': 'dfms',
        'Mac_OS_Extended_format': 'dfh+',
        'Mac_OS_format': 'dfhf',
        'NFS_format': 'dfnf',
        'Packet_2d_written_UDF_format': 'dfpu',
        'ProDOS_format': 'dfpr',
        'QuickTake_format': 'dfqt',
        'UDF_format': 'dfud',
        'UFS_format': 'dfuf',
        'WebDAV_format': 'dfwd',
        'audio_format': 'dfau',
        'unknown_format': 'df??',
    },
    'elsv': {
        'comment_column': 'elsC',
        'creation_date_column': 'elsc',
        'kind_column': 'elsk',
        'label_column': 'elsl',
        'modification_date_column': 'elsm',
        'name_column': 'elsn',
        'size_column': 'elss',
        'version_column': 'elsv',
    },
    'ipnl': {
        'Application_panel': 'apnl',
        'Comments_panel': 'cpnl',
        'Content_Index_panel': 'cinl',
        'General_Information_panel': 'gpnl',
        'Languages_panel': 'pklg',
        'Memory_panel': 'mpnl',
        'Name__26__Extension_panel': 'npnl',
        'Plugins_panel': 'pkpg',
        'Preview_panel': 'vpnl',
        'Sharing_panel': 'spnl',
    },
    'isiz': {
        'large': 'lgic',
        'mini': 'miic',
        'small': 'smic',
    },
    'lvic': {
        'large_icon': 'lgic',
        'small_icon': 'smic',
    },
    'priv': {
        'none': 'none',
        'read_only': 'read',
        'read_write': 'rdwr',
        'write_only': 'writ',
    },
    'sodr': {
        'normal': 'snrm',
        'reversed': 'srvs',
    },
    'vwby': {
        'all': 'kyal',
        'comment': 'comt',
        'conflicts': 'cflc',
        'creation_date': 'ascd',
        'existing_items': 'exsi',
        'grid': 'grid',
        'icon': 'iimg',
        'kind': 'kind',
        'label': 'labi',
        'large_button': 'lgbu',
        'modification_date': 'asmo',
        'name': 'pnam',
        'size': 'ptsz',
        'small_button': 'smbu',
        'small_icon': 'smic',
        'version': 'vers',
    },
}

_Enum_earr = {
    'arranged_by_creation_date': 'cdta',
    'arranged_by_kind': 'kina',
    'arranged_by_label': 'laba',
    'arranged_by_modification_date': 'mdta',
    'arranged_by_name': 'nama',
    'arranged_by_size': 'siza',
    'not_arranged': 'narr',
    'snap_to_grid': 'grda',
}

_Enum_ecvw = {
    'column_view': 'clvw',
    'icon_view': 'icnv',
    'list_view': 'lsvw',
}

_Enum_edfm = {
    'AppleShare_format': 'dfas',
    'Apple_Photo_format': 'dfph',
    'FTP_format': 'dfft',
    'High_Sierra_format': 'dfhs',
    'ISO_9660_format': 'df96',
    'MS_2d_DOS_format': 'dfms',
    'Mac_OS_Extended_format': 'dfh+',
    'Mac_OS_format': 'dfhf',
    'NFS_format': 'dfnf',
    'Packet_2d_written_UDF_format': 'dfpu',
    'ProDOS_format': 'dfpr',
    'QuickTake_format': 'dfqt',
    'UDF_format': 'dfud',
    'UFS_format': 'dfuf',
    'WebDAV_format': 'dfwd',
    'audio_format': 'dfau',
    'unknown_format': 'df??',
}

_Enum_elsv = {
    'comment_column': 'elsC',
    'creation_date_column': 'elsc',
    'kind_column': 'elsk',
    'label_column': 'elsl',
    'modification_date_column': 'elsm',
    'name_column': 'elsn',
    'size_column': 'elss',
    'version_column': 'elsv',
}

_Enum_ipnl = {
    'Application_panel': 'apnl',
    'Comments_panel': 'cpnl',
    'Content_Index_panel': 'cinl',
    'General_Information_panel': 'gpnl',
    'Languages_panel': 'pklg',
    'Memory_panel': 'mpnl',
    'Name__26__Extension_panel': 'npnl',
    'Plugins_panel': 'pkpg',
    'Preview_panel': 'vpnl',
    'Sharing_panel': 'spnl',
}

_Enum_isiz = {
    'large': 'lgic',
    'mini': 'miic',
    'small': 'smic',
}

_Enum_lvic = {
    'large_icon': 'lgic',
    'small_icon': 'smic',
}

_Enum_priv = {
    'none': 'none',
    'read_only': 'read',
    'read_write': 'rdwr',
    'write_only': 'writ',
}

_Enum_sodr = {
    'normal': 'snrm',
    'reversed': 'srvs',
}

_Enum_vwby = {
    'all': 'kyal',
    'comment': 'comt',
    'conflicts': 'cflc',
    'creation_date': 'ascd',
    'existing_items': 'exsi',
    'grid': 'grid',
    'icon': 'iimg',
    'kind': 'kind',
    'label': 'labi',
    'large_button': 'lgbu',
    'modification_date': 'asmo',
    'name': 'pnam',
    'size': 'ptsz',
    'small_button': 'smbu',
    'small_icon': 'smic',
    'version': 'vers',
}

_propdeclarations = {}

