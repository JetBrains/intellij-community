# encoding: utf-8
# module Finder.Type_Definitions
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Type_Definitions.pyo by generator 1.99
"""
Suite Type Definitions: Definitions of records used in scripting the Finder
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'tpdf'

# no functions
# no classes
# variables with complex values

alias_list = None # (!) real value is ''

column = None # (!) forward: columns, real value is ''

columns = None # (!) real value is ''

icon_family = None # (!) real value is ''

icon_view_options = None # (!) real value is ''

label = None # (!) real value is ''

list_view_options = None # (!) real value is ''

preferences = None # (!) real value is ''

Type_Definitions_Events = None # (!) real value is ''

_classdeclarations = {
    'alst': alias_list,
    'clbl': label,
    'cprf': preferences,
    'icop': icon_view_options,
    'ifam': icon_family,
    'lvcl': columns,
    'lvop': list_view_options,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'ICN#': None, # (!) forward: _Prop_large_monochrome_icon_and_mask, real value is ''
    'barr': None, # (!) forward: _Prop_button_view_arrangement, real value is ''
    'bisz': None, # (!) forward: _Prop_button_view_icon_size, real value is ''
    'clwd': None, # (!) forward: _Prop_width, real value is ''
    'colr': None, # (!) forward: _Prop_color, real value is ''
    'cwin': None, # (!) forward: _Prop_window, real value is ''
    'dela': None, # (!) forward: _Prop_delay_before_springing, real value is ''
    'iarr': None, # (!) forward: _Prop_spatial_view_arrangement, real value is ''
    'icl4': None, # (!) forward: _Prop_large_4_bit_icon, real value is ''
    'icl8': None, # (!) forward: _Prop_large_8_bit_icon, real value is ''
    'ics#': None, # (!) forward: _Prop_small_monochrome_icon_and_mask, real value is ''
    'ics4': None, # (!) forward: _Prop_small_4_bit_icon, real value is ''
    'ics8': None, # (!) forward: _Prop_small_8_bit_icon, real value is ''
    'iisz': None, # (!) forward: _Prop_spatial_view_icon_size, real value is ''
    'il32': None, # (!) forward: _Prop_large_32_bit_icon, real value is ''
    'is32': None, # (!) forward: _Prop_small_32_bit_icon, real value is ''
    'l8mk': None, # (!) forward: _Prop_large_8_bit_mask, real value is ''
    'lisz': None, # (!) forward: _Prop_list_view_icon_size, real value is ''
    'lvis': None, # (!) forward: _Prop_icon_size, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'scda': None, # (!) forward: _Prop_shows_creation_date, real value is ''
    'scom': None, # (!) forward: _Prop_shows_comments, real value is ''
    'sdat': None, # (!) forward: _Prop_shows_modification_date, real value is ''
    'sfsz': None, # (!) forward: _Prop_calculates_folder_sizes, real value is ''
    'sknd': None, # (!) forward: _Prop_shows_kind, real value is ''
    'slbl': None, # (!) forward: _Prop_shows_label, real value is ''
    'sord': None, # (!) forward: _Prop_sort_direction, real value is ''
    'sprg': None, # (!) forward: _Prop_spring_open_folders, real value is ''
    'srtc': None, # (!) forward: _Prop_sort_column, real value is ''
    'ssiz': None, # (!) forward: _Prop_shows_size, real value is ''
    'svrs': None, # (!) forward: _Prop_shows_version, real value is ''
    'urdt': None, # (!) forward: _Prop_uses_relative_dates, real value is ''
    'usme': None, # (!) forward: _Prop_uses_simple_menus, real value is ''
    'uswg': None, # (!) forward: _Prop_uses_wide_grid, real value is ''
    'vfnt': None, # (!) forward: _Prop_view_font, real value is ''
    'vfsz': None, # (!) forward: _Prop_view_font_size, real value is ''
}

_Prop_arrangement = None # (!) forward: _Prop_spatial_view_arrangement, real value is ''

_Prop_button_view_arrangement = None # (!) real value is ''

_Prop_button_view_icon_size = None # (!) real value is ''

_Prop_calculates_folder_sizes = None # (!) real value is ''

_Prop_color = None # (!) real value is ''

_Prop_delay_before_springing = None # (!) real value is ''

_Prop_icon_size = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_large_32_bit_icon = None # (!) real value is ''

_Prop_large_4_bit_icon = None # (!) real value is ''

_Prop_large_8_bit_icon = None # (!) real value is ''

_Prop_large_8_bit_mask = None # (!) real value is ''

_Prop_large_monochrome_icon_and_mask = None # (!) real value is ''

_Prop_list_view_icon_size = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_shows_comments = None # (!) real value is ''

_Prop_shows_creation_date = None # (!) real value is ''

_Prop_shows_kind = None # (!) real value is ''

_Prop_shows_label = None # (!) real value is ''

_Prop_shows_modification_date = None # (!) real value is ''

_Prop_shows_size = None # (!) real value is ''

_Prop_shows_version = None # (!) real value is ''

_Prop_small_32_bit_icon = None # (!) real value is ''

_Prop_small_4_bit_icon = None # (!) real value is ''

_Prop_small_8_bit_icon = None # (!) real value is ''

_Prop_small_8_bit_mask = _Prop_small_8_bit_icon

_Prop_small_monochrome_icon_and_mask = None # (!) real value is ''

_Prop_sort_column = None # (!) real value is ''

_Prop_sort_direction = None # (!) real value is ''

_Prop_spatial_view_arrangement = None # (!) real value is ''

_Prop_spatial_view_icon_size = None # (!) real value is ''

_Prop_spring_open_folders = None # (!) real value is ''

_Prop_uses_relative_dates = None # (!) real value is ''

_Prop_uses_simple_menus = None # (!) real value is ''

_Prop_uses_wide_grid = None # (!) real value is ''

_Prop_view_font = None # (!) real value is ''

_Prop_view_font_size = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_width = None # (!) real value is ''

_Prop_window = None # (!) real value is ''

