# encoding: utf-8
# module Finder.Finder_Basics
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_Basics.pyo by generator 1.99
"""
Suite Finder Basics: Commonly-used Finder commands and object classes
Level 1, version 1

Generated from /System/Library/CoreServices/Finder.app
AETE/AEUT resource version 0/144, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import Finder.Finder_items as Finder_items # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Finder_items.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import Finder.Files as Files # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Files.pyc
import Finder.Containers_and_folders as Containers_and_folders # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Containers_and_folders.pyc
import Finder.Window_classes as Window_classes # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Finder/Window_classes.pyc

# Variables with simple values

_code = 'fndr'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

clipboard = None # (!) real value is ''

desktop = None # (!) real value is ''

Finder_Basics_Events = None # (!) real value is ''

Finder_preferences = None # (!) real value is ''

frontmost = None # (!) real value is ''

home = None # (!) real value is ''

insertion_location = None # (!) real value is ''

name = None # (!) real value is ''

product_version = None # (!) real value is ''

selection = None # (!) real value is ''

startup_disk = None # (!) real value is ''

trash = None # (!) real value is ''

version = None # (!) real value is ''

visible = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'desk': None, # (!) forward: _Prop_desktop, real value is ''
    'home': None, # (!) forward: _Prop_home, real value is ''
    'pcli': None, # (!) forward: _Prop_clipboard, real value is ''
    'pfrp': None, # (!) forward: _Prop_Finder_preferences, real value is ''
    'pins': None, # (!) forward: _Prop_insertion_location, real value is ''
    'pisf': None, # (!) forward: _Prop_frontmost, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'sdsk': None, # (!) forward: _Prop_startup_disk, real value is ''
    'sele': None, # (!) forward: _Prop_selection, real value is ''
    'trsh': None, # (!) forward: _Prop_trash, real value is ''
    'ver2': None, # (!) forward: _Prop_product_version, real value is ''
    'vers': None, # (!) forward: _Prop_version, real value is ''
}

_Prop_clipboard = None # (!) real value is ''

_Prop_desktop = None # (!) real value is ''

_Prop_Finder_preferences = None # (!) real value is ''

_Prop_frontmost = None # (!) real value is ''

_Prop_home = None # (!) real value is ''

_Prop_insertion_location = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_product_version = None # (!) real value is ''

_Prop_selection = None # (!) real value is ''

_Prop_startup_disk = None # (!) real value is ''

_Prop_trash = None # (!) real value is ''

_Prop_version = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

