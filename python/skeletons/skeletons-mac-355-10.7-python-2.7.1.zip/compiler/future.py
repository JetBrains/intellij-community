# encoding: utf-8
# module compiler.future
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/future.pyo by generator 1.99
""" Parser for future statements """

# imports
import compiler.ast as ast # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/ast.pyc

# functions

def find_futures(node): # reliably restored by inspect
    # no doc
    pass


def is_future(stmt): # reliably restored by inspect
    """ Return true if statement is a well-formed future statement """
    pass


def walk(tree, visitor, walker=None, verbose=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

BadFutureParser = None # (!) real value is ''

FutureParser = None # (!) real value is ''

