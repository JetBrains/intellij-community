# encoding: utf-8
# module compiler.consts
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/consts.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

CO_FUTURE_ABSIMPORT = 16384
CO_FUTURE_DIVISION = 8192

CO_FUTURE_PRINT_FUNCTION = 65536

CO_FUTURE_WITH_STATEMENT = 32768

CO_GENERATOR = 32

CO_GENERATOR_ALLOWED = 0

CO_NESTED = 16
CO_NEWLOCALS = 2
CO_OPTIMIZED = 1
CO_VARARGS = 4
CO_VARKEYWORDS = 8

OP_APPLY = 'OP_APPLY'
OP_ASSIGN = 'OP_ASSIGN'
OP_DELETE = 'OP_DELETE'

SC_CELL = 5
SC_FREE = 4

SC_GLOBAL_EXPLICT = 3
SC_GLOBAL_IMPLICIT = 2

SC_LOCAL = 1
SC_UNKNOWN = 6

# no functions
# no classes
