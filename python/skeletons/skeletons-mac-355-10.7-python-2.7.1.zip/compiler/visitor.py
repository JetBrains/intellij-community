# encoding: utf-8
# module compiler.visitor
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/visitor.pyo by generator 1.99
# no doc

# imports
import compiler.ast as ast # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/ast.pyc

# functions

def dumpNode(node): # reliably restored by inspect
    # no doc
    pass


def walk(tree, visitor, walker=None, verbose=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

ASTVisitor = None # (!) forward: _walker, real value is ''

ExampleASTVisitor = None # (!) real value is ''

_walker = None # (!) real value is ''

