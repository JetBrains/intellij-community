# encoding: utf-8
# module compiler.syntax
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/syntax.pyo by generator 1.99
"""
Check for errs in the AST.

The Python parser does not catch all syntax errors.  Others, like
assignments with invalid targets, are caught in the code generation
phase.

The compiler package catches some errors in the transformer module.
But it seems clearer to write checkers that use the AST to detect
errors.
"""

# imports
import compiler.ast as ast # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/compiler/ast.pyc

# functions

def check(tree, multi=None): # reliably restored by inspect
    # no doc
    pass


def walk(tree, visitor, walker=None, verbose=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

SyntaxErrorChecker = None # (!) real value is ''

