# encoding: utf-8
# module StdSuites.Table_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Table_Suite.pyo by generator 1.99
"""
Suite Table Suite: Classes for manipulating tables
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'tbls'

# no functions
# no classes
# variables with complex values

cell = None # (!) real value is ''

cells = cell

column = None # (!) forward: columns, real value is ''

columns = None # (!) real value is ''

row = None # (!) real value is ''

rows = row

table = None # (!) real value is ''

tables = table

Table_Suite_Events = None # (!) real value is ''

_classdeclarations = {
    'ccel': cell,
    'ccol': columns,
    'crow': row,
    'ctbl': table,
}

_compdeclarations = {}

_enumdeclarations = {
    'prtn': {
        'formulas_protected': 'fpro',
        'read_2f_write': 'modf',
        'read_only': 'nmod',
    },
}

_Enum_prtn = {
    'formulas_protected': 'fpro',
    'read_2f_write': 'modf',
    'read_only': 'nmod',
}

_propdeclarations = {
    'pfor': None, # (!) forward: _Prop_formula, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'ppro': None, # (!) forward: _Prop_protection, real value is ''
}

_Prop_formula = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_protection = None # (!) real value is ''

