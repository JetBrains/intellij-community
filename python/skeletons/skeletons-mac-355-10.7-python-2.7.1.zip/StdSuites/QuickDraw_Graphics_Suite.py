# encoding: utf-8
# module StdSuites.QuickDraw_Graphics_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/QuickDraw_Graphics_Suite.pyo by generator 1.99
"""
Suite QuickDraw Graphics Suite: A set of basic classes for graphics
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'qdrw'

# no functions
# no classes
# variables with complex values

arc = None # (!) real value is ''

arcs = arc

drawing_area = None # (!) forward: drawing_areas, real value is ''

drawing_areas = None # (!) real value is ''

graphic_group = None # (!) real value is ''

graphic_groups = graphic_group

graphic_line = None # (!) real value is ''

graphic_lines = graphic_line

graphic_object = None # (!) forward: graphic_objects, real value is ''

graphic_objects = None # (!) real value is ''

graphic_shape = None # (!) forward: graphic_shapes, real value is ''

graphic_shapes = None # (!) real value is ''

graphic_text = None # (!) real value is ''

oval = None # (!) real value is ''

ovals = oval

pixel = None # (!) forward: pixels, real value is ''

pixels = None # (!) real value is ''

pixel_map = None # (!) real value is ''

pixel_maps = pixel_map

polygon = None # (!) forward: polygons, real value is ''

polygons = None # (!) real value is ''

QuickDraw_Graphics_Suite_Events = None # (!) real value is ''

rectangle = None # (!) forward: rectangles, real value is ''

rectangles = None # (!) real value is ''

rounded_rectangle = None # (!) real value is ''

rounded_rectangles = rounded_rectangle

_classdeclarations = {
    'carc': arc,
    'cdrw': drawing_areas,
    'cgob': graphic_objects,
    'cgsh': graphic_shapes,
    'cgtx': graphic_text,
    'covl': oval,
    'cpgn': polygons,
    'cpic': graphic_group,
    'cpix': pixel_map,
    'cpxl': pixels,
    'crec': rectangles,
    'crrc': rounded_rectangle,
    'glin': graphic_line,
}

_compdeclarations = {}

_enumdeclarations = {
    'arro': {
        'arrow_at_both_ends': 'arbo',
        'arrow_at_end': 'aren',
        'arrow_at_start': 'arst',
        'no_arrow': 'arno',
    },
    'tran': {
        'ad_max_pixels': 'admx',
        'ad_min_pixels': 'admn',
        'add_over_pixels': 'addo',
        'add_pin_pixels': 'addp',
        'bic_pixels': 'bic ',
        'blend_pixels': 'blnd',
        'copy_pixels': 'cpy ',
        'not_bic_pixels': 'nbic',
        'not_copy_pixels': 'ncpy',
        'not_or_pixels': 'ntor',
        'not_xor_pixels': 'nxor',
        'or_pixels': 'or  ',
        'sub_over_pixels': 'subo',
        'sub_pin_pixels': 'subp',
        'xor_pixels': 'xor ',
    },
}

_Enum_arro = {
    'arrow_at_both_ends': 'arbo',
    'arrow_at_end': 'aren',
    'arrow_at_start': 'arst',
    'no_arrow': 'arno',
}

_Enum_tran = {
    'ad_max_pixels': 'admx',
    'ad_min_pixels': 'admn',
    'add_over_pixels': 'addo',
    'add_pin_pixels': 'addp',
    'bic_pixels': 'bic ',
    'blend_pixels': 'blnd',
    'copy_pixels': 'cpy ',
    'not_bic_pixels': 'nbic',
    'not_copy_pixels': 'ncpy',
    'not_or_pixels': 'ntor',
    'not_xor_pixels': 'nxor',
    'or_pixels': 'or  ',
    'sub_over_pixels': 'subo',
    'sub_pin_pixels': 'subp',
    'xor_pixels': 'xor ',
}

_propdeclarations = {
    'arro': None, # (!) forward: _Prop_arrow_style, real value is ''
    'cltb': None, # (!) forward: _Prop_color_table, real value is ''
    'colr': None, # (!) forward: _Prop_color, real value is ''
    'flcl': None, # (!) forward: _Prop_fill_color, real value is ''
    'flpt': None, # (!) forward: _Prop_fill_pattern, real value is ''
    'font': None, # (!) forward: _Prop_font, real value is ''
    'gobs': None, # (!) forward: _Prop_ordering, real value is ''
    'pang': None, # (!) forward: _Prop_start_angle, real value is ''
    'parc': None, # (!) forward: _Prop_arc_angle, real value is ''
    'pbcl': None, # (!) forward: _Prop_background_color, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'pbpt': None, # (!) forward: _Prop_background_pattern, real value is ''
    'pchd': None, # (!) forward: _Prop_corner_curve_height, real value is ''
    'pcwd': None, # (!) forward: _Prop_corner_curve_width, real value is ''
    'pdpt': None, # (!) forward: _Prop_pixel_depth, real value is ''
    'pdrt': None, # (!) forward: _Prop_definition_rect, real value is ''
    'pdst': None, # (!) forward: _Prop_dash_style, real value is ''
    'pend': None, # (!) forward: _Prop_end_point, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'pnel': None, # (!) forward: _Prop_default_location, real value is ''
    'ppcl': None, # (!) forward: _Prop_pen_color, real value is ''
    'pppa': None, # (!) forward: _Prop_pen_pattern, real value is ''
    'pptm': None, # (!) forward: _Prop_transfer_mode, real value is ''
    'ppwd': None, # (!) forward: _Prop_pen_width, real value is ''
    'psct': None, # (!) forward: _Prop_writing_code, real value is ''
    'pstp': None, # (!) forward: _Prop_start_point, real value is ''
    'ptlt': None, # (!) forward: _Prop_point_list, real value is ''
    'ptps': None, # (!) forward: _Prop_default_size, real value is ''
    'ptsz': None, # (!) forward: _Prop_size, real value is ''
    'ptxc': None, # (!) forward: _Prop_text_color, real value is ''
    'ptxf': None, # (!) forward: _Prop_default_font, real value is ''
    'pupd': None, # (!) forward: _Prop_update_on_change, real value is ''
    'txst': None, # (!) forward: _Prop_style, real value is ''
    'ustl': None, # (!) forward: _Prop_uniform_styles, real value is ''
}

_Prop_arc_angle = None # (!) real value is ''

_Prop_arrow_style = None # (!) real value is ''

_Prop_background_color = None # (!) real value is ''

_Prop_background_pattern = None # (!) real value is ''

_Prop_bounds = None # (!) real value is ''

_Prop_color = None # (!) real value is ''

_Prop_color_table = None # (!) real value is ''

_Prop_corner_curve_height = None # (!) real value is ''

_Prop_corner_curve_width = None # (!) real value is ''

_Prop_dash_style = None # (!) real value is ''

_Prop_default_font = None # (!) real value is ''

_Prop_default_location = None # (!) real value is ''

_Prop_default_size = None # (!) real value is ''

_Prop_definition_rect = None # (!) real value is ''

_Prop_end_point = None # (!) real value is ''

_Prop_fill_color = None # (!) real value is ''

_Prop_fill_pattern = None # (!) real value is ''

_Prop_font = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_ordering = None # (!) real value is ''

_Prop_pen_color = None # (!) real value is ''

_Prop_pen_pattern = None # (!) real value is ''

_Prop_pen_width = None # (!) real value is ''

_Prop_pixel_depth = None # (!) real value is ''

_Prop_point_list = None # (!) real value is ''

_Prop_size = None # (!) real value is ''

_Prop_start_angle = None # (!) real value is ''

_Prop_start_point = None # (!) real value is ''

_Prop_style = None # (!) real value is ''

_Prop_text_color = None # (!) real value is ''

_Prop_transfer_mode = None # (!) real value is ''

_Prop_uniform_styles = None # (!) real value is ''

_Prop_update_on_change = None # (!) real value is ''

_Prop_writing_code = None # (!) real value is ''

