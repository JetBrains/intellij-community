# encoding: utf-8
# module StdSuites.AppleScript_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/AppleScript_Suite.pyo by generator 1.99
"""
Suite AppleScript Suite: Standard terms for AppleScript
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'ascr'

# no functions
# no classes
# variables with complex values

alias = None # (!) forward: aliases, real value is ''

aliases = None # (!) real value is ''

alias_or_string = None # (!) real value is ''

anything = None # (!) real value is ''

app = None # (!) forward: applications, real value is ''

AppleScript = None # (!) real value is ''

AppleScript_Suite_Events = None # (!) real value is ''

application = None # (!) forward: applications, real value is ''

applications = None # (!) real value is ''

April = None # (!) real value is ''

August = None # (!) real value is ''

boolean = None # (!) forward: booleans, real value is ''

booleans = None # (!) real value is ''

centimeters = None # (!) real value is ''

centimetres = centimeters

character = None # (!) real value is ''

characters = character

classes = None # (!) forward: class_, real value is ''

class_ = None # (!) real value is ''

constant = None # (!) real value is ''

constants = constant

cubic_centimeters = None # (!) forward: cubic_centimetres, real value is ''

cubic_centimetres = None # (!) real value is ''

cubic_feet = None # (!) real value is ''

cubic_inches = None # (!) real value is ''

cubic_meters = None # (!) real value is ''

cubic_metres = cubic_meters

cubic_yards = None # (!) real value is ''

C_string = None # (!) forward: C_strings, real value is ''

C_strings = None # (!) real value is ''

data = None # (!) real value is ''

date = None # (!) forward: dates, real value is ''

dates = None # (!) real value is ''

days = None # (!) real value is ''

December = None # (!) real value is ''

degrees_Celsius = None # (!) real value is ''

degrees_Fahrenheit = None # (!) real value is ''

degrees_Kelvin = None # (!) real value is ''

empty_ae_name_ = None # (!) real value is ''

encoded_string = None # (!) forward: encoded_strings, real value is ''

encoded_strings = None # (!) real value is ''

event = None # (!) real value is ''

events = event

February = None # (!) real value is ''

feet = None # (!) real value is ''

file_specification = None # (!) real value is ''

file_specifications = file_specification

Friday = None # (!) real value is ''

gallons = None # (!) real value is ''

grams = None # (!) real value is ''

handler = None # (!) real value is ''

handlers = handler

hours = None # (!) real value is ''

inches = None # (!) real value is ''

integer = None # (!) real value is ''

integers = integer

international_text = None # (!) real value is ''

item = None # (!) real value is ''

items = item

January = None # (!) real value is ''

July = None # (!) real value is ''

June = None # (!) real value is ''

keystroke = None # (!) forward: keystrokes, real value is ''

keystrokes = None # (!) real value is ''

kilograms = None # (!) real value is ''

kilometers = None # (!) forward: kilometres, real value is ''

kilometres = None # (!) real value is ''

linked_list = None # (!) real value is ''

linked_lists = linked_list

list = None # (!) real value is ''

lists = list

list_2c__record_or_text = None # (!) real value is ''

list_or_record = None # (!) real value is ''

list_or_string = None # (!) real value is ''

liters = None # (!) real value is ''

litres = liters

machine = None # (!) forward: machines, real value is ''

machines = None # (!) real value is ''

March = None # (!) real value is ''

May = None # (!) real value is ''

meters = None # (!) forward: metres, real value is ''

metres = None # (!) real value is ''

miles = None # (!) real value is ''

minutes = None # (!) real value is ''

missing_value = None # (!) forward: missing_values, real value is ''

missing_values = None # (!) real value is ''

Monday = None # (!) real value is ''

month = None # (!) real value is ''

months = month

November = None # (!) real value is ''

number = None # (!) real value is ''

numbers = number

number_2c__date_or_text = None # (!) real value is ''

number_or_date = None # (!) real value is ''

number_or_string = None # (!) real value is ''

October = None # (!) real value is ''

ounces = None # (!) real value is ''

Pascal_string = None # (!) real value is ''

Pascal_strings = Pascal_string

pi = None # (!) real value is ''

picture = None # (!) forward: pictures, real value is ''

pictures = None # (!) real value is ''

pounds = None # (!) real value is ''

preposition = None # (!) forward: prepositions, real value is ''

prepositions = None # (!) real value is ''

print_depth = None # (!) real value is ''

print_length = None # (!) real value is ''

properties = None # (!) real value is ''

property = properties

quarts = None # (!) real value is ''

real = None # (!) real value is ''

reals = real

record = None # (!) forward: records, real value is ''

records = None # (!) real value is ''

reference = None # (!) real value is ''

references = reference

reference_form = None # (!) real value is ''

reference_forms = reference_form

result = None # (!) real value is ''

return_ = None # (!) real value is ''

RGB_color = None # (!) forward: RGB_colors, real value is ''

RGB_colors = None # (!) real value is ''

Saturday = None # (!) real value is ''

script = None # (!) forward: scripts, real value is ''

scripts = None # (!) real value is ''

seconds = None # (!) real value is ''

September = None # (!) real value is ''

sound = None # (!) forward: sounds, real value is ''

sounds = None # (!) real value is ''

space = None # (!) real value is ''

square_feet = None # (!) real value is ''

square_kilometers = None # (!) forward: square_kilometres, real value is ''

square_kilometres = None # (!) real value is ''

square_meters = None # (!) forward: square_metres, real value is ''

square_metres = None # (!) real value is ''

square_miles = None # (!) real value is ''

square_yards = None # (!) real value is ''

string = None # (!) real value is ''

strings = string

styled_Clipboard_text = None # (!) real value is ''

styled_text = None # (!) real value is ''

styled_Unicode_text = None # (!) real value is ''

Sunday = None # (!) real value is ''

tab = None # (!) real value is ''

text = None # (!) real value is ''

text_item = None # (!) forward: text_items, real value is ''

text_items = None # (!) real value is ''

text_item_delimiters = None # (!) real value is ''

Thursday = None # (!) real value is ''

Tuesday = None # (!) real value is ''

type_class = None # (!) real value is ''

Unicode_text = None # (!) real value is ''

upper_case = None # (!) real value is ''

vector = None # (!) forward: vectors, real value is ''

vectors = None # (!) real value is ''

version = None # (!) real value is ''

Wednesday = None # (!) real value is ''

weekday = None # (!) forward: weekdays, real value is ''

weekdays = None # (!) real value is ''

weeks = None # (!) real value is ''

writing_code = None # (!) real value is ''

writing_code_info = None # (!) forward: writing_code_infos, real value is ''

writing_code_infos = None # (!) real value is ''

yards = None # (!) real value is ''

zone = None # (!) forward: zones, real value is ''

zones = None # (!) real value is ''

_classdeclarations = {
    '****': anything,
    'PICT': pictures,
    'STXT': styled_text,
    'TEXT': string,
    'alis': aliases,
    'apr ': April,
    'aug ': August,
    'bool': booleans,
    'cRGB': RGB_colors,
    'capp': applications,
    'case': upper_case,
    'ccmt': cubic_centimetres,
    'cfet': cubic_feet,
    'cha ': character,
    'citl': writing_code_infos,
    'citm': text_items,
    'cmet': cubic_meters,
    'cmtr': centimeters,
    'cobj': item,
    'cstr': C_strings,
    'ctxt': text,
    'cuin': cubic_inches,
    'cyrd': cubic_yards,
    'dec ': December,
    'degc': degrees_Celsius,
    'degf': degrees_Fahrenheit,
    'degk': degrees_Kelvin,
    'doub': real,
    'encs': encoded_strings,
    'enum': constant,
    'evnt': event,
    'feb ': February,
    'feet': feet,
    'fri ': Friday,
    'fss ': file_specification,
    'galn': gallons,
    'gram': grams,
    'hand': handler,
    'inch': inches,
    'itxt': international_text,
    'jan ': January,
    'jul ': July,
    'jun ': June,
    'kfrm': reference_form,
    'kgrm': kilograms,
    'kmtr': kilometres,
    'kprs': keystrokes,
    'lbs ': pounds,
    'ldt ': dates,
    'list': list,
    'litr': liters,
    'llst': linked_list,
    'long': integer,
    'lr  ': list_or_record,
    'lrs ': list_2c__record_or_text,
    'ls  ': list_or_string,
    'mach': machines,
    'mar ': March,
    'may ': May,
    'metr': metres,
    'mile': miles,
    'mnth': month,
    'mon ': Monday,
    'msng': missing_values,
    'nd  ': number_or_date,
    'nds ': number_2c__date_or_text,
    'nmbr': number,
    'nov ': November,
    'ns  ': number_or_string,
    'obj ': reference,
    'oct ': October,
    'ozs ': ounces,
    'pcls': class_,
    'prep': prepositions,
    'prop': properties,
    'psct': writing_code,
    'pstr': Pascal_string,
    'qrts': quarts,
    'rdat': data,
    'reco': records,
    'sat ': Saturday,
    'scnd': seconds,
    'scpt': scripts,
    'sep ': September,
    'sf  ': alias_or_string,
    'snd ': sounds,
    'sqft': square_feet,
    'sqkm': square_kilometres,
    'sqmi': square_miles,
    'sqrm': square_metres,
    'sqyd': square_yards,
    'styl': styled_Clipboard_text,
    'sun ': Sunday,
    'sutx': styled_Unicode_text,
    'thu ': Thursday,
    'tue ': Tuesday,
    'type': type_class,
    'undf': empty_ae_name_,
    'utxt': Unicode_text,
    'vect': vectors,
    'vers': version,
    'wed ': Wednesday,
    'wkdy': weekdays,
    'yard': yards,
    'zone': zones,
}

_compdeclarations = {}

_enumdeclarations = {
    'boov': {
        'false': 'fals',
        'true': 'true',
    },
    'cons': {
        'application_responses': 'rmte',
        'case': 'case',
        'diacriticals': 'diac',
        'expansion': 'expa',
        'hyphens': 'hyph',
        'punctuation': 'punc',
        'white_space': 'whit',
    },
    'eMds': {
        'caps_lock_down': 'Kclk',
        'command_down': 'Kcmd',
        'control_down': 'Kctl',
        'option_down': 'Kopt',
        'shift_down': 'Ksft',
    },
    'ekst': {
        'F10_key': 'ksm\x00',
        'F11_key': 'ksg\x00',
        'F12_key': 'kso\x00',
        'F13_key': 'ksi\x00',
        'F14_key': 'ksk\x00',
        'F15_key': 'ksq\x00',
        'F1_key': 'ksz\x00',
        'F2_key': 'ksx\x00',
        'F3_key': 'ksc\x00',
        'F4_key': 'ksv\x00',
        'F5_key': 'ks`\x00',
        'F6_key': 'ksa\x00',
        'F7_key': 'ksb\x00',
        'F8_key': 'ksd\x00',
        'F9_key': 'kse\x00',
        'clear_key': 'ksG\x00',
        'delete_key': 'ks3\x00',
        'down_arrow_key': 'ks}\x00',
        'end_key': 'ksw\x00',
        'enter_key': 'ksL\x00',
        'escape_key': 'ks5\x00',
        'forward_del_key': 'ksu\x00',
        'help_key': 'ksr\x00',
        'home_key': 'kss\x00',
        'left_arrow_key': 'ks{\x00',
        'page_down_key': 'ksy\x00',
        'page_up_key': 'kst\x00',
        'return_key': 'ks$\x00',
        'right_arrow_key': 'ks|\x00',
        'tab_key': 'ks0\x00',
        'up_arrow_key': 'ks~\x00',
    },
    'misc': {
        'current_application': 'cura',
    },
}

_Enum_boov = {
    'false': 'fals',
    'true': 'true',
}

_Enum_cons = {
    'application_responses': 'rmte',
    'case': 'case',
    'diacriticals': 'diac',
    'expansion': 'expa',
    'hyphens': 'hyph',
    'punctuation': 'punc',
    'white_space': 'whit',
}

_Enum_ekst = {
    'F10_key': 'ksm\x00',
    'F11_key': 'ksg\x00',
    'F12_key': 'kso\x00',
    'F13_key': 'ksi\x00',
    'F14_key': 'ksk\x00',
    'F15_key': 'ksq\x00',
    'F1_key': 'ksz\x00',
    'F2_key': 'ksx\x00',
    'F3_key': 'ksc\x00',
    'F4_key': 'ksv\x00',
    'F5_key': 'ks`\x00',
    'F6_key': 'ksa\x00',
    'F7_key': 'ksb\x00',
    'F8_key': 'ksd\x00',
    'F9_key': 'kse\x00',
    'clear_key': 'ksG\x00',
    'delete_key': 'ks3\x00',
    'down_arrow_key': 'ks}\x00',
    'end_key': 'ksw\x00',
    'enter_key': 'ksL\x00',
    'escape_key': 'ks5\x00',
    'forward_del_key': 'ksu\x00',
    'help_key': 'ksr\x00',
    'home_key': 'kss\x00',
    'left_arrow_key': 'ks{\x00',
    'page_down_key': 'ksy\x00',
    'page_up_key': 'kst\x00',
    'return_key': 'ks$\x00',
    'right_arrow_key': 'ks|\x00',
    'tab_key': 'ks0\x00',
    'up_arrow_key': 'ks~\x00',
}

_Enum_eMds = {
    'caps_lock_down': 'Kclk',
    'command_down': 'Kcmd',
    'control_down': 'Kctl',
    'option_down': 'Kopt',
    'shift_down': 'Ksft',
}

_Enum_misc = {
    'current_application': 'cura',
}

_propdeclarations = {
    'ID  ': None, # (!) forward: _Prop_id, real value is ''
    'ascr': None, # (!) forward: _Prop_AppleScript, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'day ': None, # (!) forward: _Prop_day, real value is ''
    'days': None, # (!) forward: _Prop_days, real value is ''
    'dstr': None, # (!) forward: _Prop_date_string, real value is ''
    'hour': None, # (!) forward: _Prop_hours, real value is ''
    'kMod': None, # (!) forward: _Prop_modifiers, real value is ''
    'kMsg': None, # (!) forward: _Prop_key, real value is ''
    'kknd': None, # (!) forward: _Prop_key_kind, real value is ''
    'leng': None, # (!) forward: _Prop_length, real value is ''
    'min ': None, # (!) forward: _Prop_minutes, real value is ''
    'mnth': None, # (!) forward: _Prop_month, real value is ''
    'pare': None, # (!) forward: _Prop_parent, real value is ''
    'pi  ': None, # (!) forward: _Prop_pi, real value is ''
    'plcd': None, # (!) forward: _Prop_language_code, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'prdp': None, # (!) forward: _Prop_print_depth, real value is ''
    'prln': None, # (!) forward: _Prop_print_length, real value is ''
    'pscd': None, # (!) forward: _Prop_script_code, real value is ''
    'psxp': None, # (!) forward: _Prop_POSIX_path, real value is ''
    'rest': None, # (!) forward: _Prop_rest, real value is ''
    'ret ': None, # (!) forward: _Prop_return_, real value is ''
    'rslt': None, # (!) forward: _Prop_result, real value is ''
    'rvse': None, # (!) forward: _Prop_reverse, real value is ''
    'spac': None, # (!) forward: _Prop_space, real value is ''
    'tab ': None, # (!) forward: _Prop_tab, real value is ''
    'time': None, # (!) forward: _Prop_time, real value is ''
    'tstr': None, # (!) forward: _Prop_time_string, real value is ''
    'txdl': None, # (!) forward: _Prop_text_item_delimiters, real value is ''
    'week': None, # (!) forward: _Prop_weeks, real value is ''
    'wkdy': None, # (!) forward: _Prop_weekday, real value is ''
    'year': None, # (!) forward: _Prop_year, real value is ''
}

_Prop_AppleScript = None # (!) real value is ''

_Prop_date_string = None # (!) real value is ''

_Prop_day = None # (!) real value is ''

_Prop_days = None # (!) real value is ''

_Prop_hours = None # (!) real value is ''

_Prop_id = None # (!) real value is ''

_Prop_key = None # (!) real value is ''

_Prop_key_kind = None # (!) real value is ''

_Prop_language_code = None # (!) real value is ''

_Prop_length = None # (!) real value is ''

_Prop_minutes = None # (!) real value is ''

_Prop_modifiers = None # (!) real value is ''

_Prop_month = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_parent = None # (!) real value is ''

_Prop_pi = None # (!) real value is ''

_Prop_POSIX_path = None # (!) real value is ''

_Prop_print_depth = None # (!) real value is ''

_Prop_print_length = None # (!) real value is ''

_Prop_rest = None # (!) real value is ''

_Prop_result = None # (!) real value is ''

_Prop_return_ = None # (!) real value is ''

_Prop_reverse = None # (!) real value is ''

_Prop_script_code = None # (!) real value is ''

_Prop_space = None # (!) real value is ''

_Prop_tab = None # (!) real value is ''

_Prop_text_item_delimiters = None # (!) real value is ''

_Prop_time = None # (!) real value is ''

_Prop_time_string = None # (!) real value is ''

_Prop_weekday = None # (!) real value is ''

_Prop_weeks = None # (!) real value is ''

_Prop_year = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

