# encoding: utf-8
# module StdSuites.Required_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Required_Suite.pyo by generator 1.99
"""
Suite Required Suite: Every application supports open, print, run, and quit
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'reqd'

# no functions
# no classes
# variables with complex values

builtin_Suite_Events = None # (!) real value is ''

Required_Suite_Events = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {}

