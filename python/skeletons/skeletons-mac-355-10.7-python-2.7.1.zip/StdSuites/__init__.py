# encoding: utf-8
# module StdSuites.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/__init__.pyo by generator 1.99
"""
Package generated from /Volumes/Sap/System Folder/Extensions/AppleScript
Resource aeut resid 0 Standard Event Suites for English
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import StdSuites.Table_Suite as Table_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Table_Suite.pyc
import StdSuites.AppleScript_Suite as AppleScript_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/AppleScript_Suite.pyc
import StdSuites.QuickDraw_Graphics_Suite as QuickDraw_Graphics_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/QuickDraw_Graphics_Suite.pyc
import StdSuites.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import StdSuites.Macintosh_Connectivity_Clas as Macintosh_Connectivity_Clas # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Macintosh_Connectivity_Clas.pyc
import StdSuites.Text_Suite as Text_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Text_Suite.pyc
import StdSuites.Required_Suite as Required_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Required_Suite.pyc
import StdSuites.QuickDraw_Graphics_Suppleme as QuickDraw_Graphics_Suppleme # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/QuickDraw_Graphics_Suppleme.pyc
import StdSuites.Type_Names_Suite as Type_Names_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Type_Names_Suite.pyc

# Variables with simple values

Error = 'aetools.Error'

# functions

def getbaseclasses(v): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

ADB_address = Macintosh_Connectivity_Clas.ADB_address

ADB_addresses = Macintosh_Connectivity_Clas.ADB_address

address_specification = Macintosh_Connectivity_Clas.address_specification

address_specifications = Macintosh_Connectivity_Clas.address_specification

alias = Standard_Suite.aliases

aliases = Standard_Suite.aliases

alias_or_string = AppleScript_Suite.alias_or_string

anything = AppleScript_Suite.anything

app = AppleScript_Suite.applications

AppleScript = AppleScript_Suite.AppleScript

AppleScript_Suite_Events = AppleScript_Suite.AppleScript_Suite_Events

AppleTalk_address = Macintosh_Connectivity_Clas.AppleTalk_addresses

AppleTalk_addresses = Macintosh_Connectivity_Clas.AppleTalk_addresses

application = Standard_Suite.application

applications = Standard_Suite.application

application_dictionary = Type_Names_Suite.application_dictionary

April = AppleScript_Suite.April

arc = QuickDraw_Graphics_Suite.arc

arcs = QuickDraw_Graphics_Suite.arc

August = AppleScript_Suite.August

boolean = AppleScript_Suite.booleans

booleans = AppleScript_Suite.booleans

bounding_rectangle = Type_Names_Suite.bounding_rectangle

builtin_Suite_Events = Required_Suite.builtin_Suite_Events

bus_slot = Macintosh_Connectivity_Clas.bus_slots

bus_slots = Macintosh_Connectivity_Clas.bus_slots

cell = Table_Suite.cell

cells = Table_Suite.cell

centimeters = AppleScript_Suite.centimeters

centimetres = AppleScript_Suite.centimeters

character = AppleScript_Suite.character

characters = AppleScript_Suite.character

classes = AppleScript_Suite.class_

class_ = AppleScript_Suite.class_

clipboard = Standard_Suite.clipboard

color_table = Type_Names_Suite.color_table

column = Table_Suite.columns

columns = Table_Suite.columns

constant = AppleScript_Suite.constant

constants = AppleScript_Suite.constant

contains = Standard_Suite.contains

cubic_centimeters = AppleScript_Suite.cubic_centimetres

cubic_centimetres = AppleScript_Suite.cubic_centimetres

cubic_feet = AppleScript_Suite.cubic_feet

cubic_inches = AppleScript_Suite.cubic_inches

cubic_meters = AppleScript_Suite.cubic_meters

cubic_metres = AppleScript_Suite.cubic_meters

cubic_yards = AppleScript_Suite.cubic_yards

C_string = AppleScript_Suite.C_strings

C_strings = AppleScript_Suite.C_strings

dash_style = Type_Names_Suite.dash_style

data = AppleScript_Suite.data

date = AppleScript_Suite.dates

dates = AppleScript_Suite.dates

days = AppleScript_Suite.days

December = AppleScript_Suite.December

degrees_Celsius = AppleScript_Suite.degrees_Celsius

degrees_Fahrenheit = AppleScript_Suite.degrees_Fahrenheit

degrees_Kelvin = AppleScript_Suite.degrees_Kelvin

device_specification = Macintosh_Connectivity_Clas.device_specifications

device_specifications = Macintosh_Connectivity_Clas.device_specifications

document = Standard_Suite.documents

documents = Standard_Suite.documents

double_integer = Type_Names_Suite.double_integer

drawing_area = QuickDraw_Graphics_Suppleme.drawing_areas

drawing_areas = QuickDraw_Graphics_Suppleme.drawing_areas

empty_ae_name_ = AppleScript_Suite.empty_ae_name_

encoded_string = AppleScript_Suite.encoded_strings

encoded_strings = AppleScript_Suite.encoded_strings

ends_with = Standard_Suite.ends_with

Ethernet_address = Macintosh_Connectivity_Clas.Ethernet_address

Ethernet_addresses = Macintosh_Connectivity_Clas.Ethernet_address

event = AppleScript_Suite.event

events = AppleScript_Suite.event

extended_real = Type_Names_Suite.extended_real

February = AppleScript_Suite.February

feet = AppleScript_Suite.feet

file = Standard_Suite.file

files = Standard_Suite.file

file_specification = AppleScript_Suite.file_specification

file_specifications = AppleScript_Suite.file_specification

FireWire_address = Macintosh_Connectivity_Clas.FireWire_address

FireWire_addresses = Macintosh_Connectivity_Clas.FireWire_address

fixed = Type_Names_Suite.fixed

fixed_point = Type_Names_Suite.fixed_point

fixed_rectangle = Type_Names_Suite.fixed_rectangle

Friday = AppleScript_Suite.Friday

frontmost = Standard_Suite.frontmost

gallons = AppleScript_Suite.gallons

grams = AppleScript_Suite.grams

graphic_group = QuickDraw_Graphics_Suppleme.graphic_group

graphic_groups = QuickDraw_Graphics_Suppleme.graphic_group

graphic_line = QuickDraw_Graphics_Suite.graphic_line

graphic_lines = QuickDraw_Graphics_Suite.graphic_line

graphic_object = QuickDraw_Graphics_Suite.graphic_objects

graphic_objects = QuickDraw_Graphics_Suite.graphic_objects

graphic_shape = QuickDraw_Graphics_Suite.graphic_shapes

graphic_shapes = QuickDraw_Graphics_Suite.graphic_shapes

graphic_text = QuickDraw_Graphics_Suite.graphic_text

handler = AppleScript_Suite.handler

handlers = AppleScript_Suite.handler

hours = AppleScript_Suite.hours

inches = AppleScript_Suite.inches

insertion_point = Standard_Suite.insertion_points

insertion_points = Standard_Suite.insertion_points

integer = AppleScript_Suite.integer

integers = AppleScript_Suite.integer

international_text = AppleScript_Suite.international_text

IP_address = Macintosh_Connectivity_Clas.IP_addresses

IP_addresses = Macintosh_Connectivity_Clas.IP_addresses

item = AppleScript_Suite.item

items = AppleScript_Suite.item

January = AppleScript_Suite.January

July = AppleScript_Suite.July

June = AppleScript_Suite.June

keystroke = AppleScript_Suite.keystrokes

keystrokes = AppleScript_Suite.keystrokes

kilograms = AppleScript_Suite.kilograms

kilometers = AppleScript_Suite.kilometres

kilometres = AppleScript_Suite.kilometres

line = Text_Suite.line

lines = Text_Suite.line

linked_list = AppleScript_Suite.linked_list

linked_lists = AppleScript_Suite.linked_list

list = AppleScript_Suite.list

lists = AppleScript_Suite.list

list_2c__record_or_text = AppleScript_Suite.list_2c__record_or_text

list_or_record = AppleScript_Suite.list_or_record

list_or_string = AppleScript_Suite.list_or_string

liters = AppleScript_Suite.liters

litres = AppleScript_Suite.liters

LocalTalk_address = Macintosh_Connectivity_Clas.LocalTalk_address

LocalTalk_addresses = Macintosh_Connectivity_Clas.LocalTalk_address

location_reference = Type_Names_Suite.location_reference

long_fixed = Type_Names_Suite.long_fixed

long_fixed_point = Type_Names_Suite.long_fixed_point

long_fixed_rectangle = Type_Names_Suite.long_fixed_rectangle

long_point = Type_Names_Suite.long_point

long_rectangle = Type_Names_Suite.long_rectangle

machine = AppleScript_Suite.machines

machines = AppleScript_Suite.machines

machine_location = Type_Names_Suite.machine_location

Macintosh_Connectivity_Clas_Events = Macintosh_Connectivity_Clas.Macintosh_Connectivity_Clas_Events

March = AppleScript_Suite.March

May = AppleScript_Suite.May

menu = Type_Names_Suite.menu

menu_item = Type_Names_Suite.menu_item

meters = AppleScript_Suite.metres

metres = AppleScript_Suite.metres

miles = AppleScript_Suite.miles

minutes = AppleScript_Suite.minutes

missing_value = AppleScript_Suite.missing_values

missing_values = AppleScript_Suite.missing_values

Monday = AppleScript_Suite.Monday

month = AppleScript_Suite.month

months = AppleScript_Suite.month

name = Standard_Suite.name

November = AppleScript_Suite.November

null = Type_Names_Suite.null

number = AppleScript_Suite.number

numbers = AppleScript_Suite.number

number_2c__date_or_text = AppleScript_Suite.number_2c__date_or_text

number_or_date = AppleScript_Suite.number_or_date

number_or_string = AppleScript_Suite.number_or_string

October = AppleScript_Suite.October

ounces = AppleScript_Suite.ounces

oval = QuickDraw_Graphics_Suite.oval

ovals = QuickDraw_Graphics_Suite.oval

paragraph = Text_Suite.paragraphs

paragraphs = Text_Suite.paragraphs

Pascal_string = AppleScript_Suite.Pascal_string

Pascal_strings = AppleScript_Suite.Pascal_string

pi = AppleScript_Suite.pi

picture = AppleScript_Suite.pictures

pictures = AppleScript_Suite.pictures

pixel = QuickDraw_Graphics_Suite.pixels

pixels = QuickDraw_Graphics_Suite.pixels

pixel_map = QuickDraw_Graphics_Suite.pixel_map

pixel_maps = QuickDraw_Graphics_Suite.pixel_map

pixel_map_record = Type_Names_Suite.pixel_map_record

plain_text = Type_Names_Suite.string

point = Type_Names_Suite.point

polygon = QuickDraw_Graphics_Suite.polygons

polygons = QuickDraw_Graphics_Suite.polygons

PostScript_picture = Type_Names_Suite.PostScript_picture

pounds = AppleScript_Suite.pounds

preposition = AppleScript_Suite.prepositions

prepositions = AppleScript_Suite.prepositions

print_depth = AppleScript_Suite.print_depth

print_length = AppleScript_Suite.print_length

properties = AppleScript_Suite.properties

property = AppleScript_Suite.properties

quarts = AppleScript_Suite.quarts

QuickDraw_Graphics_Suite_Events = QuickDraw_Graphics_Suite.QuickDraw_Graphics_Suite_Events

QuickDraw_Graphics_Suppleme_Events = QuickDraw_Graphics_Suppleme.QuickDraw_Graphics_Suppleme_Events

real = AppleScript_Suite.real

reals = AppleScript_Suite.real

record = AppleScript_Suite.records

records = AppleScript_Suite.records

rectangle = QuickDraw_Graphics_Suite.rectangles

rectangles = QuickDraw_Graphics_Suite.rectangles

reference = AppleScript_Suite.reference

references = AppleScript_Suite.reference

reference_form = AppleScript_Suite.reference_form

reference_forms = AppleScript_Suite.reference_form

Required_Suite_Events = Required_Suite.Required_Suite_Events

result = AppleScript_Suite.result

return_ = AppleScript_Suite.return_

RGB16_color = Type_Names_Suite.RGB16_color

RGB96_color = Type_Names_Suite.RGB96_color

RGB_color = AppleScript_Suite.RGB_colors

RGB_colors = AppleScript_Suite.RGB_colors

rotation = Type_Names_Suite.rotation

rounded_rectangle = QuickDraw_Graphics_Suite.rounded_rectangle

rounded_rectangles = QuickDraw_Graphics_Suite.rounded_rectangle

row = Table_Suite.row

rows = Table_Suite.row

Saturday = AppleScript_Suite.Saturday

scrap_styles = Type_Names_Suite.scrap_styles

script = AppleScript_Suite.scripts

scripts = AppleScript_Suite.scripts

SCSI_address = Macintosh_Connectivity_Clas.SCSI_addresses

SCSI_addresses = Macintosh_Connectivity_Clas.SCSI_addresses

seconds = AppleScript_Suite.seconds

selection = Standard_Suite.selection

selection_2d_object = Standard_Suite.selection_2d_object

September = AppleScript_Suite.September

small_integer = Type_Names_Suite.small_integer

small_real = Type_Names_Suite.small_real

sound = AppleScript_Suite.sounds

sounds = AppleScript_Suite.sounds

space = AppleScript_Suite.space

square_feet = AppleScript_Suite.square_feet

square_kilometers = AppleScript_Suite.square_kilometres

square_kilometres = AppleScript_Suite.square_kilometres

square_meters = AppleScript_Suite.square_metres

square_metres = AppleScript_Suite.square_metres

square_miles = AppleScript_Suite.square_miles

square_yards = AppleScript_Suite.square_yards

Standard_Suite_Events = Standard_Suite.Standard_Suite_Events

starts_with = Standard_Suite.starts_with

StdSuites = None # (!) real value is ''

string = Type_Names_Suite.string

strings = AppleScript_Suite.string

styled_Clipboard_text = AppleScript_Suite.styled_Clipboard_text

styled_text = AppleScript_Suite.styled_text

styled_Unicode_text = AppleScript_Suite.styled_Unicode_text

Sunday = AppleScript_Suite.Sunday

system_dictionary = Type_Names_Suite.system_dictionary

tab = AppleScript_Suite.tab

table = Table_Suite.table

tables = Table_Suite.table

Table_Suite_Events = Table_Suite.Table_Suite_Events

target_id = Type_Names_Suite.target_id

text = AppleScript_Suite.text

text_flow = Text_Suite.text_flows

text_flows = Text_Suite.text_flows

text_item = AppleScript_Suite.text_items

text_items = AppleScript_Suite.text_items

text_item_delimiters = AppleScript_Suite.text_item_delimiters

text_style_info = Text_Suite.text_style_info

text_style_infos = Text_Suite.text_style_info

Text_Suite_Events = Text_Suite.Text_Suite_Events

Thursday = AppleScript_Suite.Thursday

TIFF_picture = Type_Names_Suite.TIFF_picture

Token_Ring_address = Macintosh_Connectivity_Clas.Token_Ring_address

Token_Ring_addresses = Macintosh_Connectivity_Clas.Token_Ring_address

Tuesday = AppleScript_Suite.Tuesday

type_class = AppleScript_Suite.type_class

type_class_info = Type_Names_Suite.type_class_info

type_element_info = Type_Names_Suite.type_element_info

type_event_info = Type_Names_Suite.type_event_info

Type_Names_Suite_Events = Type_Names_Suite.Type_Names_Suite_Events

type_parameter_info = Type_Names_Suite.type_parameter_info

type_property_info = Type_Names_Suite.type_property_info

type_suite_info = Type_Names_Suite.type_suite_info

Unicode_text = AppleScript_Suite.Unicode_text

unsigned_integer = Type_Names_Suite.unsigned_integer

upper_case = AppleScript_Suite.upper_case

USB_address = Macintosh_Connectivity_Clas.USB_address

USB_Addresses = Macintosh_Connectivity_Clas.USB_address

vector = AppleScript_Suite.vectors

vectors = AppleScript_Suite.vectors

version = Type_Names_Suite.version

Wednesday = AppleScript_Suite.Wednesday

weekday = AppleScript_Suite.weekdays

weekdays = AppleScript_Suite.weekdays

weeks = AppleScript_Suite.weeks

window = Standard_Suite.window

windows = Standard_Suite.window

word = Text_Suite.words

words = Text_Suite.words

writing_code = AppleScript_Suite.writing_code

writing_code_info = AppleScript_Suite.writing_code_infos

writing_code_infos = AppleScript_Suite.writing_code_infos

yards = AppleScript_Suite.yards

zone = AppleScript_Suite.zones

zones = AppleScript_Suite.zones

_classdeclarations = {
    '****': AppleScript_Suite.anything,
    'EPS ': Type_Names_Suite.PostScript_picture,
    'PICT': AppleScript_Suite.pictures,
    'QDpt': Type_Names_Suite.point,
    'STXT': AppleScript_Suite.styled_text,
    'TEXT': Type_Names_Suite.string,
    'TIFF': Type_Names_Suite.TIFF_picture,
    'aete': Type_Names_Suite.application_dictionary,
    'aeut': Type_Names_Suite.system_dictionary,
    'alis': Standard_Suite.aliases,
    'apr ': AppleScript_Suite.April,
    'aug ': AppleScript_Suite.August,
    'bool': AppleScript_Suite.booleans,
    'cRGB': AppleScript_Suite.RGB_colors,
    'cadb': Macintosh_Connectivity_Clas.ADB_address,
    'cadr': Macintosh_Connectivity_Clas.address_specification,
    'capp': AppleScript_Suite.applications,
    'carc': QuickDraw_Graphics_Suite.arc,
    'case': AppleScript_Suite.upper_case,
    'cat ': Macintosh_Connectivity_Clas.AppleTalk_addresses,
    'cbus': Macintosh_Connectivity_Clas.bus_slots,
    'ccel': Table_Suite.cell,
    'ccmt': AppleScript_Suite.cubic_centimetres,
    'ccol': Table_Suite.columns,
    'cdev': Macintosh_Connectivity_Clas.device_specifications,
    'cdrw': QuickDraw_Graphics_Suppleme.drawing_areas,
    'cen ': Macintosh_Connectivity_Clas.Ethernet_address,
    'cfet': AppleScript_Suite.cubic_feet,
    'cflo': Text_Suite.text_flows,
    'cfw ': Macintosh_Connectivity_Clas.FireWire_address,
    'cgob': QuickDraw_Graphics_Suite.graphic_objects,
    'cgsh': QuickDraw_Graphics_Suite.graphic_shapes,
    'cgtx': QuickDraw_Graphics_Suite.graphic_text,
    'cha ': AppleScript_Suite.character,
    'cins': Standard_Suite.insertion_points,
    'cip ': Macintosh_Connectivity_Clas.IP_addresses,
    'citl': AppleScript_Suite.writing_code_infos,
    'citm': AppleScript_Suite.text_items,
    'clin': Text_Suite.line,
    'clrt': Type_Names_Suite.color_table,
    'clt ': Macintosh_Connectivity_Clas.LocalTalk_address,
    'cmen': Type_Names_Suite.menu_item,
    'cmet': AppleScript_Suite.cubic_meters,
    'cmnu': Type_Names_Suite.menu,
    'cmtr': AppleScript_Suite.centimeters,
    'cobj': AppleScript_Suite.item,
    'comp': Type_Names_Suite.double_integer,
    'covl': QuickDraw_Graphics_Suite.oval,
    'cpar': Text_Suite.paragraphs,
    'cpgn': QuickDraw_Graphics_Suite.polygons,
    'cpic': QuickDraw_Graphics_Suppleme.graphic_group,
    'cpix': QuickDraw_Graphics_Suite.pixel_map,
    'cpxl': QuickDraw_Graphics_Suite.pixels,
    'crec': QuickDraw_Graphics_Suite.rectangles,
    'crow': Table_Suite.row,
    'crrc': QuickDraw_Graphics_Suite.rounded_rectangle,
    'cscs': Macintosh_Connectivity_Clas.SCSI_addresses,
    'csel': Standard_Suite.selection_2d_object,
    'cstr': AppleScript_Suite.C_strings,
    'ctbl': Table_Suite.table,
    'ctok': Macintosh_Connectivity_Clas.Token_Ring_address,
    'ctxt': AppleScript_Suite.text,
    'cuin': AppleScript_Suite.cubic_inches,
    'cusb': Macintosh_Connectivity_Clas.USB_address,
    'cwin': Standard_Suite.window,
    'cwor': Text_Suite.words,
    'cyrd': AppleScript_Suite.cubic_yards,
    'dec ': AppleScript_Suite.December,
    'degc': AppleScript_Suite.degrees_Celsius,
    'degf': AppleScript_Suite.degrees_Fahrenheit,
    'degk': AppleScript_Suite.degrees_Kelvin,
    'docu': Standard_Suite.documents,
    'doub': AppleScript_Suite.real,
    'elin': Type_Names_Suite.type_element_info,
    'encs': AppleScript_Suite.encoded_strings,
    'enum': AppleScript_Suite.constant,
    'evin': Type_Names_Suite.type_event_info,
    'evnt': AppleScript_Suite.event,
    'exte': Type_Names_Suite.extended_real,
    'feb ': AppleScript_Suite.February,
    'feet': AppleScript_Suite.feet,
    'file': Standard_Suite.file,
    'fixd': Type_Names_Suite.fixed,
    'fpnt': Type_Names_Suite.fixed_point,
    'frct': Type_Names_Suite.fixed_rectangle,
    'fri ': AppleScript_Suite.Friday,
    'fss ': AppleScript_Suite.file_specification,
    'galn': AppleScript_Suite.gallons,
    'gcli': Type_Names_Suite.type_class_info,
    'glin': QuickDraw_Graphics_Suite.graphic_line,
    'gram': AppleScript_Suite.grams,
    'hand': AppleScript_Suite.handler,
    'inch': AppleScript_Suite.inches,
    'insl': Type_Names_Suite.location_reference,
    'itxt': AppleScript_Suite.international_text,
    'jan ': AppleScript_Suite.January,
    'jul ': AppleScript_Suite.July,
    'jun ': AppleScript_Suite.June,
    'kfrm': AppleScript_Suite.reference_form,
    'kgrm': AppleScript_Suite.kilograms,
    'kmtr': AppleScript_Suite.kilometres,
    'kprs': AppleScript_Suite.keystrokes,
    'lbs ': AppleScript_Suite.pounds,
    'ldt ': AppleScript_Suite.dates,
    'lfpt': Type_Names_Suite.long_fixed_point,
    'lfrc': Type_Names_Suite.long_fixed_rectangle,
    'lfxd': Type_Names_Suite.long_fixed,
    'list': AppleScript_Suite.list,
    'litr': AppleScript_Suite.liters,
    'llst': AppleScript_Suite.linked_list,
    'long': AppleScript_Suite.integer,
    'lpnt': Type_Names_Suite.long_point,
    'lr  ': AppleScript_Suite.list_or_record,
    'lrct': Type_Names_Suite.long_rectangle,
    'lrs ': AppleScript_Suite.list_2c__record_or_text,
    'ls  ': AppleScript_Suite.list_or_string,
    'mLoc': Type_Names_Suite.machine_location,
    'mach': AppleScript_Suite.machines,
    'magn': Type_Names_Suite.unsigned_integer,
    'mar ': AppleScript_Suite.March,
    'may ': AppleScript_Suite.May,
    'metr': AppleScript_Suite.metres,
    'mile': AppleScript_Suite.miles,
    'mnth': AppleScript_Suite.month,
    'mon ': AppleScript_Suite.Monday,
    'msng': AppleScript_Suite.missing_values,
    'nd  ': AppleScript_Suite.number_or_date,
    'nds ': AppleScript_Suite.number_2c__date_or_text,
    'nmbr': AppleScript_Suite.number,
    'nov ': AppleScript_Suite.November,
    'ns  ': AppleScript_Suite.number_or_string,
    'null': Type_Names_Suite.null,
    'obj ': AppleScript_Suite.reference,
    'oct ': AppleScript_Suite.October,
    'ozs ': AppleScript_Suite.ounces,
    'pcls': AppleScript_Suite.class_,
    'pinf': Type_Names_Suite.type_property_info,
    'pmin': Type_Names_Suite.type_parameter_info,
    'prep': AppleScript_Suite.prepositions,
    'prop': AppleScript_Suite.properties,
    'psct': AppleScript_Suite.writing_code,
    'pstr': AppleScript_Suite.Pascal_string,
    'qdrt': Type_Names_Suite.bounding_rectangle,
    'qrts': AppleScript_Suite.quarts,
    'rdat': AppleScript_Suite.data,
    'reco': AppleScript_Suite.records,
    'sat ': AppleScript_Suite.Saturday,
    'scnd': AppleScript_Suite.seconds,
    'scpt': AppleScript_Suite.scripts,
    'sep ': AppleScript_Suite.September,
    'sf  ': AppleScript_Suite.alias_or_string,
    'shor': Type_Names_Suite.small_integer,
    'sing': Type_Names_Suite.small_real,
    'snd ': AppleScript_Suite.sounds,
    'sqft': AppleScript_Suite.square_feet,
    'sqkm': AppleScript_Suite.square_kilometres,
    'sqmi': AppleScript_Suite.square_miles,
    'sqrm': AppleScript_Suite.square_metres,
    'sqyd': AppleScript_Suite.square_yards,
    'styl': AppleScript_Suite.styled_Clipboard_text,
    'suin': Type_Names_Suite.type_suite_info,
    'sun ': AppleScript_Suite.Sunday,
    'sutx': AppleScript_Suite.styled_Unicode_text,
    'targ': Type_Names_Suite.target_id,
    'tdas': Type_Names_Suite.dash_style,
    'thu ': AppleScript_Suite.Thursday,
    'tpmm': Type_Names_Suite.pixel_map_record,
    'tr16': Type_Names_Suite.RGB16_color,
    'tr96': Type_Names_Suite.RGB96_color,
    'trot': Type_Names_Suite.rotation,
    'tsty': Text_Suite.text_style_info,
    'tue ': AppleScript_Suite.Tuesday,
    'type': AppleScript_Suite.type_class,
    'undf': AppleScript_Suite.empty_ae_name_,
    'utxt': AppleScript_Suite.Unicode_text,
    'vect': AppleScript_Suite.vectors,
    'vers': Type_Names_Suite.version,
    'wed ': AppleScript_Suite.Wednesday,
    'wkdy': AppleScript_Suite.weekdays,
    'yard': AppleScript_Suite.yards,
    'zone': AppleScript_Suite.zones,
}

_code_to_fullname = {
    'TEXT': (
        'StdSuites.Text_Suite',
        'Text_Suite',
    ),
    'ascr': (
        'StdSuites.AppleScript_Suite',
        'AppleScript_Suite',
    ),
    'core': (
        'StdSuites.Standard_Suite',
        'Standard_Suite',
    ),
    'macc': (
        'StdSuites.Macintosh_Connectivity_Clas',
        'Macintosh_Connectivity_Clas',
    ),
    'qdrw': (
        'StdSuites.QuickDraw_Graphics_Suite',
        'QuickDraw_Graphics_Suite',
    ),
    'qdsp': (
        'StdSuites.QuickDraw_Graphics_Suppleme',
        'QuickDraw_Graphics_Suppleme',
    ),
    'reqd': (
        'StdSuites.Required_Suite',
        'Required_Suite',
    ),
    'tbls': (
        'StdSuites.Table_Suite',
        'Table_Suite',
    ),
    'tpnm': (
        'StdSuites.Type_Names_Suite',
        'Type_Names_Suite',
    ),
}

_code_to_module = {
    'TEXT': None, # (!) forward: Text_Suite, real value is ''
    'ascr': None, # (!) forward: AppleScript_Suite, real value is ''
    'core': None, # (!) forward: Standard_Suite, real value is ''
    'macc': None, # (!) forward: Macintosh_Connectivity_Clas, real value is ''
    'qdrw': None, # (!) forward: QuickDraw_Graphics_Suite, real value is ''
    'qdsp': None, # (!) forward: QuickDraw_Graphics_Suppleme, real value is ''
    'reqd': None, # (!) forward: Required_Suite, real value is ''
    'tbls': None, # (!) forward: Table_Suite, real value is ''
    'tpnm': None, # (!) forward: Type_Names_Suite, real value is ''
}

