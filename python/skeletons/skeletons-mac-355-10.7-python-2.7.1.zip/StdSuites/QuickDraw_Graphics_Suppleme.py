# encoding: utf-8
# module StdSuites.QuickDraw_Graphics_Suppleme
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/QuickDraw_Graphics_Suppleme.pyo by generator 1.99
"""
Suite QuickDraw Graphics Supplemental Suite: Defines transformations of graphic objects
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'qdsp'

# no functions
# no classes
# variables with complex values

drawing_area = None # (!) forward: drawing_areas, real value is ''

drawing_areas = None # (!) real value is ''

graphic_group = None # (!) real value is ''

graphic_groups = graphic_group

QuickDraw_Graphics_Suppleme_Events = None # (!) real value is ''

_classdeclarations = {
    'cdrw': drawing_areas,
    'cpic': graphic_group,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'prot': None, # (!) forward: _Prop_rotation, real value is ''
    'pscl': None, # (!) forward: _Prop_scale, real value is ''
    'ptrs': None, # (!) forward: _Prop_translation, real value is ''
}

_Prop_rotation = None # (!) real value is ''

_Prop_scale = None # (!) real value is ''

_Prop_translation = None # (!) real value is ''

