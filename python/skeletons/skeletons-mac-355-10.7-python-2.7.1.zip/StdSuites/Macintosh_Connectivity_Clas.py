# encoding: utf-8
# module StdSuites.Macintosh_Connectivity_Clas
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Macintosh_Connectivity_Clas.pyo by generator 1.99
"""
Suite Macintosh Connectivity Classes: Classes relating to Apple Macintosh personal computer connectivity
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'macc'

# no functions
# no classes
# variables with complex values

ADB_address = None # (!) real value is ''

ADB_addresses = ADB_address

address_specification = None # (!) real value is ''

address_specifications = address_specification

AppleTalk_address = None # (!) forward: AppleTalk_addresses, real value is ''

AppleTalk_addresses = None # (!) real value is ''

bus_slot = None # (!) forward: bus_slots, real value is ''

bus_slots = None # (!) real value is ''

device_specification = None # (!) forward: device_specifications, real value is ''

device_specifications = None # (!) real value is ''

Ethernet_address = None # (!) real value is ''

Ethernet_addresses = Ethernet_address

FireWire_address = None # (!) real value is ''

FireWire_addresses = FireWire_address

IP_address = None # (!) forward: IP_addresses, real value is ''

IP_addresses = None # (!) real value is ''

LocalTalk_address = None # (!) real value is ''

LocalTalk_addresses = LocalTalk_address

Macintosh_Connectivity_Clas_Events = None # (!) real value is ''

SCSI_address = None # (!) forward: SCSI_addresses, real value is ''

SCSI_addresses = None # (!) real value is ''

Token_Ring_address = None # (!) real value is ''

Token_Ring_addresses = Token_Ring_address

USB_address = None # (!) real value is ''

USB_Addresses = USB_address

_classdeclarations = {
    'cadb': ADB_address,
    'cadr': address_specification,
    'cat ': AppleTalk_addresses,
    'cbus': bus_slots,
    'cdev': device_specifications,
    'cen ': Ethernet_address,
    'cfw ': FireWire_address,
    'cip ': IP_addresses,
    'clt ': LocalTalk_address,
    'cscs': SCSI_addresses,
    'ctok': Token_Ring_address,
    'cusb': USB_address,
}

_compdeclarations = {}

_enumdeclarations = {
    'econ': {
        'ADB': 'eadb',
        'Comm_slot': 'eccm',
        'Ethernet': 'ecen',
        'FireWire': 'ecfw',
        'LocalTalk': 'eclt',
        'NuBus': 'enub',
        'PCI_bus': 'ecpi',
        'PC_card': 'ecpc',
        'PDS_slot': 'ecpd',
        'SCSI': 'ecsc',
        'Token_Ring': 'etok',
        'USB': 'ecus',
        'audio_line_in': 'ecai',
        'audio_line_out': 'ecal',
        'audio_out': 'ecao',
        'infrared': 'ecir',
        'microphone': 'ecmi',
        'modem_port': 'ecmp',
        'modem_printer_port': 'empp',
        'monitor_out': 'ecmn',
        'printer_port': 'ecpp',
        'video_in': 'ecvi',
        'video_out': 'ecvo',
    },
    'edvt': {
        'CD_ROM_drive': 'ecd ',
        'DVD_drive': 'edvd',
        'LCD_display': 'edlc',
        'NuBus_card': 'ednb',
        'PCI_card': 'edpi',
        'PC_card': 'ecpc',
        'display': 'edds',
        'floppy_disk_drive': 'efd ',
        'hard_disk_drive': 'ehd ',
        'keyboard': 'ekbd',
        'microphone': 'ecmi',
        'modem': 'edmm',
        'mouse': 'emou',
        'pointing_device': 'edpd',
        'printer': 'edpr',
        'speakers': 'edsp',
        'storage_device': 'edst',
        'trackball': 'etrk',
        'trackpad': 'edtp',
        'video_monitor': 'edvm',
    },
    'epro': {
        'ADB': 'eadb',
        'AppleTalk': 'epat',
        'FireWire': 'ecfw',
        'IP': 'epip',
        'IRTalk': 'epit',
        'IrDA': 'epir',
        'Macintosh_video': 'epmv',
        'NuBus': 'enub',
        'PCI_bus': 'ecpi',
        'PC_card': 'ecpc',
        'PostScript': 'epps',
        'SCSI': 'ecsc',
        'SVGA': 'epsg',
        'S_video': 'epsv',
        'USB': 'ecus',
        'analog_audio': 'epau',
        'bus': 'ebus',
        'digital_audio': 'epda',
        'serial': 'epsr',
    },
}

_Enum_econ = {
    'ADB': 'eadb',
    'Comm_slot': 'eccm',
    'Ethernet': 'ecen',
    'FireWire': 'ecfw',
    'LocalTalk': 'eclt',
    'NuBus': 'enub',
    'PCI_bus': 'ecpi',
    'PC_card': 'ecpc',
    'PDS_slot': 'ecpd',
    'SCSI': 'ecsc',
    'Token_Ring': 'etok',
    'USB': 'ecus',
    'audio_line_in': 'ecai',
    'audio_line_out': 'ecal',
    'audio_out': 'ecao',
    'infrared': 'ecir',
    'microphone': 'ecmi',
    'modem_port': 'ecmp',
    'modem_printer_port': 'empp',
    'monitor_out': 'ecmn',
    'printer_port': 'ecpp',
    'video_in': 'ecvi',
    'video_out': 'ecvo',
}

_Enum_edvt = {
    'CD_ROM_drive': 'ecd ',
    'DVD_drive': 'edvd',
    'LCD_display': 'edlc',
    'NuBus_card': 'ednb',
    'PCI_card': 'edpi',
    'PC_card': 'ecpc',
    'display': 'edds',
    'floppy_disk_drive': 'efd ',
    'hard_disk_drive': 'ehd ',
    'keyboard': 'ekbd',
    'microphone': 'ecmi',
    'modem': 'edmm',
    'mouse': 'emou',
    'pointing_device': 'edpd',
    'printer': 'edpr',
    'speakers': 'edsp',
    'storage_device': 'edst',
    'trackball': 'etrk',
    'trackpad': 'edtp',
    'video_monitor': 'edvm',
}

_Enum_epro = {
    'ADB': 'eadb',
    'AppleTalk': 'epat',
    'FireWire': 'ecfw',
    'IP': 'epip',
    'IRTalk': 'epit',
    'IrDA': 'epir',
    'Macintosh_video': 'epmv',
    'NuBus': 'enub',
    'PCI_bus': 'ecpi',
    'PC_card': 'ecpc',
    'PostScript': 'epps',
    'SCSI': 'ecsc',
    'SVGA': 'epsg',
    'S_video': 'epsv',
    'USB': 'ecus',
    'analog_audio': 'epau',
    'bus': 'ebus',
    'digital_audio': 'epda',
    'serial': 'epsr',
}

_propdeclarations = {
    'ID  ': None, # (!) forward: _Prop_ID, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_inheritance_3e_, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
    'patm': None, # (!) forward: _Prop_AppleTalk_machine, real value is ''
    'patt': None, # (!) forward: _Prop_AppleTalk_type, real value is ''
    'patz': None, # (!) forward: _Prop_AppleTalk_zone, real value is ''
    'pcon': None, # (!) forward: _Prop_conduit, real value is ''
    'pdns': None, # (!) forward: _Prop_DNS_form, real value is ''
    'pdva': None, # (!) forward: _Prop_device_address, real value is ''
    'pdvt': None, # (!) forward: _Prop_device_type, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'pnet': None, # (!) forward: _Prop_network, real value is ''
    'pnod': None, # (!) forward: _Prop_node, real value is ''
    'ppor': None, # (!) forward: _Prop_port, real value is ''
    'pprt': None, # (!) forward: _Prop_protocol, real value is ''
    'pscb': None, # (!) forward: _Prop_SCSI_bus, real value is ''
    'pslu': None, # (!) forward: _Prop_LUN, real value is ''
    'psoc': None, # (!) forward: _Prop_socket, real value is ''
}

_Prop_AppleTalk_machine = None # (!) real value is ''

_Prop_AppleTalk_type = None # (!) real value is ''

_Prop_AppleTalk_zone = None # (!) real value is ''

_Prop_conduit = None # (!) real value is ''

_Prop_device_address = None # (!) real value is ''

_Prop_device_type = None # (!) real value is ''

_Prop_DNS_form = None # (!) real value is ''

_Prop_ID = None # (!) real value is ''

_Prop_LUN = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_network = None # (!) real value is ''

_Prop_node = None # (!) real value is ''

_Prop_port = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop_protocol = None # (!) real value is ''

_Prop_SCSI_bus = None # (!) real value is ''

_Prop_socket = None # (!) real value is ''

_Prop__3c_inheritance_3e_ = None # (!) real value is ''

