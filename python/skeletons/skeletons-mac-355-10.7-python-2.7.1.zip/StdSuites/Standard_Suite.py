# encoding: utf-8
# module StdSuites.Standard_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Standard_Suite.pyo by generator 1.99
"""
Suite Standard Suite: Common terms for most applications
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'core'

# no functions
# no classes
# variables with complex values

alias = None # (!) forward: aliases, real value is ''

aliases = None # (!) real value is ''

application = None # (!) real value is ''

applications = application

builtin_Suite_Events = None # (!) real value is ''

clipboard = None # (!) real value is ''

contains = None # (!) real value is ''

document = None # (!) forward: documents, real value is ''

documents = None # (!) real value is ''

ends_with = None # (!) real value is ''

file = None # (!) real value is ''

files = file

frontmost = None # (!) real value is ''

insertion_point = None # (!) forward: insertion_points, real value is ''

insertion_points = None # (!) real value is ''

name = None # (!) real value is ''

selection = None # (!) real value is ''

selection_2d_object = None # (!) real value is ''

Standard_Suite_Events = None # (!) real value is ''

starts_with = None # (!) real value is ''

version = None # (!) real value is ''

window = None # (!) real value is ''

windows = window

_3c_ = None # (!) real value is ''

_3d_ = None # (!) real value is ''

_3e_ = None # (!) real value is ''

_b2_ = None # (!) real value is ''

_b3_ = None # (!) real value is ''

_classdeclarations = {
    'alis': aliases,
    'capp': application,
    'cins': insertion_points,
    'csel': selection_2d_object,
    'cwin': window,
    'docu': documents,
    'file': file,
}

_compdeclarations = {
    '<   ': _3c_,
    '<=  ': _b2_,
    '=   ': _3d_,
    '>   ': _3e_,
    '>=  ': _b3_,
    'bgwt': starts_with,
    'cont': contains,
    'ends': ends_with,
}

_enumdeclarations = {
    'kfrm': {
        'id': 'ID  ',
        'index': 'indx',
        'named': 'name',
    },
    'savo': {
        'ask': 'ask ',
        'no': 'no  ',
        'yes': 'yes ',
    },
    'styl': {
        'all_caps': 'alcp',
        'all_lowercase': 'lowc',
        'bold': 'bold',
        'condensed': 'cond',
        'expanded': 'pexp',
        'hidden': 'hidn',
        'italic': 'ital',
        'outline': 'outl',
        'plain': 'plan',
        'shadow': 'shad',
        'small_caps': 'smcp',
        'strikethrough': 'strk',
        'subscript': 'sbsc',
        'superscript': 'spsc',
        'underline': 'undl',
    },
}

_Enum_kfrm = {
    'id': 'ID  ',
    'index': 'indx',
    'named': 'name',
}

_Enum_savo = {
    'ask': 'ask ',
    'no': 'no  ',
    'yes': 'yes ',
}

_Enum_styl = {
    'all_caps': 'alcp',
    'all_lowercase': 'lowc',
    'bold': 'bold',
    'condensed': 'cond',
    'expanded': 'pexp',
    'hidden': 'hidn',
    'italic': 'ital',
    'outline': 'outl',
    'plain': 'plan',
    'shadow': 'shad',
    'small_caps': 'smcp',
    'strikethrough': 'strk',
    'subscript': 'sbsc',
    'superscript': 'spsc',
    'underline': 'undl',
}

_propdeclarations = {
    'hclb': None, # (!) forward: _Prop_closeable, real value is ''
    'imod': None, # (!) forward: _Prop_modified, real value is ''
    'isfl': None, # (!) forward: _Prop_floating, real value is ''
    'iszm': None, # (!) forward: _Prop_zoomable, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'pcli': None, # (!) forward: _Prop_clipboard, real value is ''
    'pcnt': None, # (!) forward: _Prop_contents, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pisf': None, # (!) forward: _Prop_frontmost, real value is ''
    'pmod': None, # (!) forward: _Prop_modal, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'prsz': None, # (!) forward: _Prop_resizable, real value is ''
    'psxp': None, # (!) forward: _Prop_POSIX_path, real value is ''
    'ptit': None, # (!) forward: _Prop_titled, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'pzum': None, # (!) forward: _Prop_zoomed, real value is ''
    'sele': None, # (!) forward: _Prop_selection, real value is ''
    'vers': None, # (!) forward: _Prop_version, real value is ''
}

_Prop_bounds = None # (!) real value is ''

_Prop_clipboard = None # (!) real value is ''

_Prop_closeable = None # (!) real value is ''

_Prop_contents = None # (!) real value is ''

_Prop_floating = None # (!) real value is ''

_Prop_frontmost = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_modal = None # (!) real value is ''

_Prop_modified = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_POSIX_path = None # (!) real value is ''

_Prop_resizable = None # (!) real value is ''

_Prop_selection = None # (!) real value is ''

_Prop_titled = None # (!) real value is ''

_Prop_version = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_zoomable = None # (!) real value is ''

_Prop_zoomed = None # (!) real value is ''

