# encoding: utf-8
# module StdSuites.Text_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/Text_Suite.pyo by generator 1.99
"""
Suite Text Suite: A set of basic classes for text processing
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'TEXT'

# no functions
# no classes
# variables with complex values

character = None # (!) real value is ''

line = None # (!) real value is ''

lines = line

paragraph = None # (!) forward: paragraphs, real value is ''

paragraphs = None # (!) real value is ''

text = None # (!) real value is ''

text_flow = None # (!) forward: text_flows, real value is ''

text_flows = None # (!) real value is ''

text_style_info = None # (!) real value is ''

text_style_infos = text_style_info

Text_Suite_Events = None # (!) real value is ''

word = None # (!) forward: words, real value is ''

words = None # (!) real value is ''

_classdeclarations = {
    'cflo': text_flows,
    'cha ': character,
    'clin': line,
    'cpar': paragraphs,
    'ctxt': text,
    'cwor': words,
    'tsty': text_style_info,
}

_compdeclarations = {}

_enumdeclarations = {
    'just': {
        'center': 'cent',
        'full': 'full',
        'left': 'left',
        'right': 'rght',
    },
    'styl': {
        'all_caps': 'alcp',
        'all_lowercase': 'lowc',
        'bold': 'bold',
        'condensed': 'cond',
        'expanded': 'pexp',
        'hidden': 'hidn',
        'italic': 'ital',
        'outline': 'outl',
        'plain': 'plan',
        'shadow': 'shad',
        'small_caps': 'smcp',
        'strikethrough': 'strk',
        'subscript': 'sbsc',
        'superscript': 'spsc',
        'underline': 'undl',
    },
}

_Enum_just = {
    'center': 'cent',
    'full': 'full',
    'left': 'left',
    'right': 'rght',
}

_Enum_styl = {
    'all_caps': 'alcp',
    'all_lowercase': 'lowc',
    'bold': 'bold',
    'condensed': 'cond',
    'expanded': 'pexp',
    'hidden': 'hidn',
    'italic': 'ital',
    'outline': 'outl',
    'plain': 'plan',
    'shadow': 'shad',
    'small_caps': 'smcp',
    'strikethrough': 'strk',
    'subscript': 'sbsc',
    'superscript': 'spsc',
    'underline': 'undl',
}

_propdeclarations = {
    'c@#^': None, # (!) forward: _Prop__3c_inheritance_3e_, real value is ''
    'colr': None, # (!) forward: _Prop_color, real value is ''
    'font': None, # (!) forward: _Prop_font, real value is ''
    'ofst': None, # (!) forward: _Prop_off_styles, real value is ''
    'onst': None, # (!) forward: _Prop_on_styles, real value is ''
    'pjst': None, # (!) forward: _Prop_justification, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'psct': None, # (!) forward: _Prop_writing_code, real value is ''
    'ptsz': None, # (!) forward: _Prop_size, real value is ''
    'strq': None, # (!) forward: _Prop_quoted_form, real value is ''
    'txst': None, # (!) forward: _Prop_style, real value is ''
    'ustl': None, # (!) forward: _Prop_uniform_styles, real value is ''
}

_Prop_color = None # (!) real value is ''

_Prop_font = None # (!) real value is ''

_Prop_justification = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_off_styles = None # (!) real value is ''

_Prop_on_styles = None # (!) real value is ''

_Prop_quoted_form = None # (!) real value is ''

_Prop_size = None # (!) real value is ''

_Prop_style = None # (!) real value is ''

_Prop_uniform_styles = None # (!) real value is ''

_Prop_writing_code = None # (!) real value is ''

_Prop__3c_inheritance_3e_ = None # (!) real value is ''

