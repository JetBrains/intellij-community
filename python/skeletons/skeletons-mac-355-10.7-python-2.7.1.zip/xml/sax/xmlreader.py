# encoding: utf-8
# module xml.sax.xmlreader
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/sax/xmlreader.pyo by generator 1.99
"""
An XML Reader is the SAX 2 name for an XML parser. XML Parsers
should be based on this code.
"""

# imports
import xml.sax.handler as handler # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/sax/handler.pyc
import xml.sax._exceptions as __xml_sax__exceptions


# functions

def _test(): # reliably restored by inspect
    # no doc
    pass


# classes

class SAXNotRecognizedException(__xml_sax__exceptions.SAXException):
    """
    Exception class for an unrecognized identifier.
    
        An XMLReader will raise this exception when it is confronted with an
        unrecognized feature or property. SAX applications and extensions may
        use this class for similar purposes.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an exception. The message is required, but the exception
                is optional.
        """
        pass


class SAXNotSupportedException(__xml_sax__exceptions.SAXException):
    """
    Exception class for an unsupported operation.
    
        An XMLReader will raise this exception when a service it cannot
        perform is requested (specifically setting a state or value). SAX
        applications and extensions may use this class for similar
        purposes.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an exception. The message is required, but the exception
                is optional.
        """
        pass


# variables with complex values

AttributesImpl = None # (!) real value is ''

AttributesNSImpl = None # (!) real value is ''

IncrementalParser = None # (!) real value is ''

InputSource = None # (!) real value is ''

Locator = None # (!) real value is ''

XMLReader = None # (!) real value is ''

