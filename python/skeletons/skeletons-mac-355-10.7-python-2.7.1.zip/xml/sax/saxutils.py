# encoding: utf-8
# module xml.sax.saxutils
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/sax/saxutils.pyo by generator 1.99
"""
A library of useful helper classes to the SAX classes, for the
convenience of application and driver writers.
"""

# imports
import urllib as urllib # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/urllib.py
import urlparse as urlparse # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/urlparse.pyc
import xml.sax.handler as handler # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/sax/handler.pyc
import xml.sax.xmlreader as xmlreader # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/sax/xmlreader.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/types.pyc

# Variables with simple values

_error_handling = 'xmlcharrefreplace'

# functions

def escape(data, entities='{}'): # reliably restored by inspect
    """
    Escape &, <, and > in a string of data.
    
        You can escape other strings of data by passing a dictionary as
        the optional entities parameter.  The keys and values must all be
        strings; each key will be replaced with its corresponding value.
    """
    pass


def prepare_input_source(source, base=None): # reliably restored by inspect
    """
    This function takes an InputSource and an optional base URL and
        returns a fully resolved InputSource object ready for reading.
    """
    pass


def quoteattr(data, entities='{}'): # reliably restored by inspect
    """
    Escape and quote an attribute value.
    
        Escape &, <, and > in a string of data, then quote it for use as
        an attribute value.  The " character will be escaped as well, if
        necessary.
    
        You can escape other strings of data by passing a dictionary as
        the optional entities parameter.  The keys and values must all be
        strings; each key will be replaced with its corresponding value.
    """
    pass


def unescape(data, entities='{}'): # reliably restored by inspect
    """
    Unescape &amp;, &lt;, and &gt; in a string of data.
    
        You can unescape other strings of data by passing a dictionary as
        the optional entities parameter.  The keys and values must all be
        strings; each key will be replaced with its corresponding value.
    """
    pass


def __dict_replace(s, d): # reliably restored by inspect
    """ Replace substrings of a string using a dictionary. """
    pass


# no classes
# variables with complex values

XMLFilterBase = None # (!) real value is ''

XMLGenerator = None # (!) real value is ''

_StringTypes = [
    bytes,
    unicode,
]

