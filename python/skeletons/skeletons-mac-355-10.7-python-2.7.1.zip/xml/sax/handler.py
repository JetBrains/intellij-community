# encoding: utf-8
# module xml.sax.handler
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/sax/handler.pyo by generator 1.99
"""
This module contains the core classes of version 2.0 of SAX for Python.
This file provides only default classes with absolutely minimum
functionality, from which drivers and applications can be subclassed.

Many of these classes are empty and are included only as documentation
of the interfaces.

$Id: handler.py 35816 2004-05-06 03:47:48Z fdrake $
"""
# no imports

# Variables with simple values

feature_external_ges = 'http://xml.org/sax/features/external-general-entities'
feature_external_pes = 'http://xml.org/sax/features/external-parameter-entities'

feature_namespaces = 'http://xml.org/sax/features/namespaces'

feature_namespace_prefixes = 'http://xml.org/sax/features/namespace-prefixes'

feature_string_interning = 'http://xml.org/sax/features/string-interning'

feature_validation = 'http://xml.org/sax/features/validation'

property_declaration_handler = 'http://xml.org/sax/properties/declaration-handler'

property_dom_node = 'http://xml.org/sax/properties/dom-node'

property_encoding = 'http://www.python.org/sax/properties/encoding'

property_interning_dict = 'http://www.python.org/sax/properties/interning-dict'

property_lexical_handler = 'http://xml.org/sax/properties/lexical-handler'

property_xml_string = 'http://xml.org/sax/properties/xml-string'

version = '2.0beta'

# no functions
# no classes
# variables with complex values

all_features = [
    'http://xml.org/sax/features/namespaces',
    'http://xml.org/sax/features/namespace-prefixes',
    'http://xml.org/sax/features/string-interning',
    'http://xml.org/sax/features/validation',
    'http://xml.org/sax/features/external-general-entities',
    'http://xml.org/sax/features/external-parameter-entities',
]

all_properties = [
    'http://xml.org/sax/properties/lexical-handler',
    'http://xml.org/sax/properties/dom-node',
    'http://xml.org/sax/properties/declaration-handler',
    'http://xml.org/sax/properties/xml-string',
    'http://www.python.org/sax/properties/encoding',
    'http://www.python.org/sax/properties/interning-dict',
]

ContentHandler = None # (!) real value is ''

DTDHandler = None # (!) real value is ''

EntityResolver = None # (!) real value is ''

ErrorHandler = None # (!) real value is ''

