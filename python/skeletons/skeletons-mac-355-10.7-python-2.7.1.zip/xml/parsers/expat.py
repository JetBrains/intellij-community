# encoding: utf-8
# module xml.parsers.expat
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/parsers/expat.pyo by generator 1.99
""" Interface to the Expat non-validating XML parser. """

# imports
import pyexpat.errors as errors # <module 'pyexpat.errors' (built-in)>
import pyexpat.model as model # <module 'pyexpat.model' (built-in)>
from pyexpat import ErrorString, ParserCreate, XMLParserType


# Variables with simple values

EXPAT_VERSION = 'expat_2.0.1'

native_encoding = 'UTF-8'

XML_PARAM_ENTITY_PARSING_ALWAYS = 2
XML_PARAM_ENTITY_PARSING_NEVER = 0

XML_PARAM_ENTITY_PARSING_UNLESS_STANDALONE = 1

__version__ = '$Revision: 17640 $'

# no functions
# classes

class ExpatError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


error = ExpatError


# variables with complex values

expat_CAPI = None # (!) real value is ''

features = [
    (
        'sizeof(XML_Char)',
        1,
    ),
    (
        'sizeof(XML_LChar)',
        1,
    ),
    (
        'XML_DTD',
        0,
    ),
    (
        'XML_CONTEXT_BYTES',
        1024,
    ),
    (
        'XML_NS',
        0,
    ),
]

version_info = (
    2,
    0,
    1,
)

