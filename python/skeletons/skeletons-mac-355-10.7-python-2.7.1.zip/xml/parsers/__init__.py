# encoding: utf-8
# module xml.parsers.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/parsers/__init__.pyo by generator 1.99
"""
Python interfaces to XML parsers.

This package contains one module:

expat -- Python wrapper for James Clark's Expat parser, with namespace
         support.
"""
# no imports

# no functions
# no classes
