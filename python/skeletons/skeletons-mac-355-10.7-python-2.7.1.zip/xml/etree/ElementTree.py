# encoding: utf-8
# module xml.etree.ElementTree
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/etree/ElementTree.pyo by generator 1.99
# no doc

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import xml.etree.ElementPath as ElementPath # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/etree/ElementPath.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/warnings.pyc
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

VERSION = '1.3.0'

# functions

def Comment(text=None): # reliably restored by inspect
    # no doc
    pass


def dump(elem): # reliably restored by inspect
    # no doc
    pass


def fromstring(text, parser=None): # reliably restored by inspect
    # no doc
    pass


def fromstringlist(sequence, parser=None): # reliably restored by inspect
    # no doc
    pass


def iselement(element): # reliably restored by inspect
    # no doc
    pass


def iterparse(source, events=None, parser=None): # reliably restored by inspect
    # no doc
    pass


def parse(source, parser=None): # reliably restored by inspect
    # no doc
    pass


def PI(target, text=None): # reliably restored by inspect
    # no doc
    pass


def ProcessingInstruction(target, text=None): # reliably restored by inspect
    # no doc
    pass


def register_namespace(prefix, uri): # reliably restored by inspect
    # no doc
    pass


def SubElement(parent, tag, attrib='{}', **extra): # reliably restored by inspect
    # no doc
    pass


def tostring(element, encoding=None, method=None): # reliably restored by inspect
    # no doc
    pass


def tostringlist(element, encoding=None, method=None): # reliably restored by inspect
    # no doc
    pass


def XML(text, parser=None): # reliably restored by inspect
    # no doc
    pass


def XMLID(text, parser=None): # reliably restored by inspect
    # no doc
    pass


def _encode(text, encoding): # reliably restored by inspect
    # no doc
    pass


def _escape_attrib(text, encoding): # reliably restored by inspect
    # no doc
    pass


def _escape_attrib_html(text, encoding): # reliably restored by inspect
    # no doc
    pass


def _escape_cdata(text, encoding): # reliably restored by inspect
    # no doc
    pass


def _namespaces(elem, encoding, default_namespace=None): # reliably restored by inspect
    # no doc
    pass


def _raise_serialization_error(text): # reliably restored by inspect
    # no doc
    pass


def _serialize_html(write, elem, encoding, qnames, namespaces): # reliably restored by inspect
    # no doc
    pass


def _serialize_text(write, elem, encoding): # reliably restored by inspect
    # no doc
    pass


def _serialize_xml(write, elem, encoding, qnames, namespaces): # reliably restored by inspect
    # no doc
    pass


# classes

class _ElementInterface(object):
    # no doc
    def append(self, *args, **kwargs): # real signature unknown
        pass

    def clear(self, *args, **kwargs): # real signature unknown
        pass

    def copy(self, *args, **kwargs): # real signature unknown
        pass

    def extend(self, *args, **kwargs): # real signature unknown
        pass

    def find(self, *args, **kwargs): # real signature unknown
        pass

    def findall(self, *args, **kwargs): # real signature unknown
        pass

    def findtext(self, *args, **kwargs): # real signature unknown
        pass

    def get(self, *args, **kwargs): # real signature unknown
        pass

    def getchildren(self, *args, **kwargs): # real signature unknown
        pass

    def getiterator(self, *args, **kwargs): # real signature unknown
        pass

    def insert(self, *args, **kwargs): # real signature unknown
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def iter(self, *args, **kwargs): # real signature unknown
        pass

    def iterfind(self, *args, **kwargs): # real signature unknown
        pass

    def itertext(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def makeelement(self, *args, **kwargs): # real signature unknown
        pass

    def remove(self, *args, **kwargs): # real signature unknown
        pass

    def set(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __nonzero__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    attrib = None
    tag = None
    tail = None
    text = None
    __dict__ = None # (!) real value is ''


_Element = _ElementInterface


Element = _ElementInterface


class ElementTree(object):
    # no doc
    def find(self, *args, **kwargs): # real signature unknown
        pass

    def findall(self, *args, **kwargs): # real signature unknown
        pass

    def findtext(self, *args, **kwargs): # real signature unknown
        pass

    def getiterator(self, *args, **kwargs): # real signature unknown
        pass

    def getroot(self, *args, **kwargs): # real signature unknown
        pass

    def iter(self, *args, **kwargs): # real signature unknown
        pass

    def iterfind(self, *args, **kwargs): # real signature unknown
        pass

    def parse(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def write_c14n(self, *args, **kwargs): # real signature unknown
        pass

    def _setroot(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class ParseError(SyntaxError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class QName(object):
    # no doc
    def __cmp__(self, *args, **kwargs): # real signature unknown
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TreeBuilder(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def data(self, *args, **kwargs): # real signature unknown
        pass

    def end(self, *args, **kwargs): # real signature unknown
        pass

    def start(self, *args, **kwargs): # real signature unknown
        pass

    def _flush(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class XMLTreeBuilder(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def doctype(self, *args, **kwargs): # real signature unknown
        """ This method of XMLParser is deprecated. """
        pass

    def feed(self, *args, **kwargs): # real signature unknown
        pass

    def _comment(self, *args, **kwargs): # real signature unknown
        pass

    def _data(self, *args, **kwargs): # real signature unknown
        pass

    def _default(self, *args, **kwargs): # real signature unknown
        pass

    def _end(self, *args, **kwargs): # real signature unknown
        pass

    def _fixname(self, *args, **kwargs): # real signature unknown
        pass

    def _fixtext(self, *args, **kwargs): # real signature unknown
        pass

    def _pi(self, *args, **kwargs): # real signature unknown
        pass

    def _raiseerror(self, *args, **kwargs): # real signature unknown
        pass

    def _start(self, *args, **kwargs): # real signature unknown
        pass

    def _start_list(self, *args, **kwargs): # real signature unknown
        pass

    def _XMLParser__doctype(self, *args, **kwargs): # real signature unknown
        """ This method of XMLParser is deprecated. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


XMLParser = XMLTreeBuilder


class _IterParseIterator(object):
    # no doc
    def next(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class _SimpleElementPath(object):
    # no doc
    def find(self, *args, **kwargs): # real signature unknown
        pass

    def findall(self, *args, **kwargs): # real signature unknown
        pass

    def findtext(self, *args, **kwargs): # real signature unknown
        pass

    def iterfind(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

HTML_EMPTY = None # (!) real value is ''

_namespace_map = {
    'http://purl.org/dc/elements/1.1/': 'dc',
    'http://schemas.xmlsoap.org/wsdl/': 'wsdl',
    'http://www.w3.org/1999/02/22-rdf-syntax-ns#': 'rdf',
    'http://www.w3.org/1999/xhtml': 'html',
    'http://www.w3.org/2001/XMLSchema': 'xs',
    'http://www.w3.org/2001/XMLSchema-instance': 'xsi',
    'http://www.w3.org/XML/1998/namespace': 'xml',
}

_serialize = {
    'html': _serialize_html,
    'text': _serialize_text,
    'xml': _serialize_xml,
}

__all__ = [
    'Comment',
    'dump',
    'Element',
    'ElementTree',
    'fromstring',
    'fromstringlist',
    'iselement',
    'iterparse',
    'parse',
    'ParseError',
    'PI',
    'ProcessingInstruction',
    'QName',
    'SubElement',
    'tostring',
    'tostringlist',
    'TreeBuilder',
    'VERSION',
    'XML',
    'XMLParser',
    'XMLTreeBuilder',
]

