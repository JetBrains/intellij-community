# encoding: utf-8
# module xml.etree.ElementInclude
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/etree/ElementInclude.pyo by generator 1.99
# no doc

# imports
import xml.etree.ElementTree as ElementTree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/etree/ElementTree.pyc
import copy as copy # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/copy.pyc

# Variables with simple values

XINCLUDE = '{http://www.w3.org/2001/XInclude}'

XINCLUDE_FALLBACK = '{http://www.w3.org/2001/XInclude}fallback'
XINCLUDE_INCLUDE = '{http://www.w3.org/2001/XInclude}include'

# functions

def default_loader(href, parse, encoding=None): # reliably restored by inspect
    # no doc
    pass


def include(elem, loader=None): # reliably restored by inspect
    # no doc
    pass


# classes

class FatalIncludeError(SyntaxError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


