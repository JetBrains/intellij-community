# encoding: utf-8
# module xml.etree.ElementPath
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/etree/ElementPath.pyo by generator 1.99
# no doc

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc

# functions

def find(elem, path, namespaces=None): # reliably restored by inspect
    # no doc
    pass


def findall(elem, path, namespaces=None): # reliably restored by inspect
    # no doc
    pass


def findtext(elem, path, default=None, namespaces=None): # reliably restored by inspect
    # no doc
    pass


def get_parent_map(context): # reliably restored by inspect
    # no doc
    pass


def iterfind(elem, path, namespaces=None): # reliably restored by inspect
    # no doc
    pass


def prepare_child(next, token): # reliably restored by inspect
    # no doc
    pass


def prepare_descendant(next, token): # reliably restored by inspect
    # no doc
    pass


def prepare_parent(next, token): # reliably restored by inspect
    # no doc
    pass


def prepare_predicate(next, token): # reliably restored by inspect
    # no doc
    pass


def prepare_self(next, token): # reliably restored by inspect
    # no doc
    pass


def prepare_star(next, token): # reliably restored by inspect
    # no doc
    pass


def xpath_tokenizer(pattern, namespaces=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

ops = {
    '': prepare_child,
    '*': prepare_star,
    '.': prepare_self,
    '..': prepare_parent,
    '//': prepare_descendant,
    '[': prepare_predicate,
}

xpath_tokenizer_re = None # (!) real value is ''

_cache = {}

_SelectorContext = None # (!) real value is ''

