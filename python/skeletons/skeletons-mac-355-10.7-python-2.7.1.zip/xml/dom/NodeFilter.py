# encoding: utf-8
# module xml.dom.NodeFilter
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/NodeFilter.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
# variables with complex values

NodeFilter = None # (!) real value is ''

