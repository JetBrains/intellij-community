# encoding: utf-8
# module xml.dom.expatbuilder
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/expatbuilder.pyo by generator 1.99
"""
Facility to use the Expat parser to load a minidom instance
from a string or file.

This avoids all the overhead of SAX and pulldom to gain performance.
"""

# imports
import xml.parsers.expat as expat # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/parsers/expat.pyc
import xml.dom.xmlbuilder as xmlbuilder # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/xmlbuilder.pyc
import xml.dom.minidom as minidom # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/minidom.pyc

# Variables with simple values

CDATA_SECTION_NODE = 4

DOCUMENT_NODE = 9

EMPTY_NAMESPACE = None
EMPTY_PREFIX = None

FILTER_ACCEPT = 1
FILTER_INTERRUPT = 4
FILTER_REJECT = 2
FILTER_SKIP = 3

TEXT_NODE = 3

XMLNS_NAMESPACE = 'http://www.w3.org/2000/xmlns/'

_FRAGMENT_BUILDER_INTERNAL_SYSTEM_ID = 'http://xml.python.org/entities/fragment-builder/internal'

_FRAGMENT_BUILDER_TEMPLATE = '<!DOCTYPE wrapper\n  %s [\n  <!ENTITY fragment-builder-internal\n    SYSTEM "http://xml.python.org/entities/fragment-builder/internal">\n%s\n]>\n<wrapper %s\n>&fragment-builder-internal;</wrapper>'

# functions

def defproperty(klass, name, doc): # reliably restored by inspect
    # no doc
    pass


def makeBuilder(options): # reliably restored by inspect
    """ Create a builder based on an Options object. """
    pass


def parse(file, namespaces=True): # reliably restored by inspect
    """
    Parse a document, returning the resulting Document node.
    
        'file' may be either a file name or an open file object.
    """
    pass


def parseFragment(file, context, namespaces=True): # reliably restored by inspect
    """
    Parse a fragment of a document, given the context from which it
        was originally extracted.  context should be the parent of the
        node(s) which are in the fragment.
    
        'file' may be either a file name or an open file object.
    """
    pass


def parseFragmentString(string, context, namespaces=True): # reliably restored by inspect
    """
    Parse a fragment of a document from a string, given the context
        from which it was originally extracted.  context should be the
        parent of the node(s) which are in the fragment.
    """
    pass


def parseString(string, namespaces=True): # reliably restored by inspect
    """
    Parse a document from a string, returning the resulting
        Document node.
    """
    pass


def _append_child(self, node): # reliably restored by inspect
    # no doc
    pass


def _intern(builder, s): # reliably restored by inspect
    # no doc
    pass


def _parse_ns_name(builder, name): # reliably restored by inspect
    # no doc
    pass


def _set_attribute_node(element, attr): # reliably restored by inspect
    # no doc
    pass


# classes

class ElementInfo(object):
    # no doc
    def getAttributeType(self, *args, **kwargs): # real signature unknown
        pass

    def getAttributeTypeNS(self, *args, **kwargs): # real signature unknown
        pass

    def isElementContent(self, *args, **kwargs): # real signature unknown
        pass

    def isEmpty(self, *args, **kwargs): # real signature unknown
        pass

    def isId(self, *args, **kwargs): # real signature unknown
        pass

    def isIdNS(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    tagName = property(lambda self: object()) # default
    _attr_info = property(lambda self: object()) # default
    _model = property(lambda self: object()) # default

    __slots__ = (
        '_attr_info',
        '_model',
        'tagName',
    )


class EmptyNodeList(tuple):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __radd__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


class FilterCrutch(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _builder = property(lambda self: object()) # default
    _level = property(lambda self: object()) # default
    _old_end = property(lambda self: object()) # default
    _old_start = property(lambda self: object()) # default

    __slots__ = (
        '_builder',
        '_level',
        '_old_start',
        '_old_end',
    )


class FilterVisibilityController(object):
    """
    Wrapper around a DOMBuilderFilter which implements the checks
        to make the whatToShow filter attribute work.
    """
    def acceptNode(self, *args, **kwargs): # real signature unknown
        pass

    def startContainer(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    filter = property(lambda self: object()) # default

    _nodetype_mask = {
        1: 1,
        2: 2,
        3: 4,
        4: 8,
        5: 16,
        6: 32,
        7: 64,
        8: 128,
        9: 256,
        10: 512,
        11: 1024,
        12: 2048,
    }
    __slots__ = (
        'filter',
    )


class NodeList(list):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


class ParseEscape(Exception):
    """ Exception raised to short-circuit parsing in InternalSubsetExtractor. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class Rejecter(FilterCrutch):
    # no doc
    def end_element_handler(self, *args, **kwargs): # real signature unknown
        pass

    def start_element_handler(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __slots__ = ()


class Skipper(FilterCrutch):
    # no doc
    def end_element_handler(self, *args, **kwargs): # real signature unknown
        pass

    def start_element_handler(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __slots__ = ()


# variables with complex values

ExpatBuilder = None # (!) real value is ''

ExpatBuilderNS = None # (!) real value is ''

FragmentBuilder = None # (!) real value is ''

FragmentBuilderNS = None # (!) real value is ''

InternalSubsetExtractor = None # (!) real value is ''

Namespaces = None # (!) real value is ''

Node = None # (!) real value is ''

NodeFilter = None # (!) real value is ''

StringTypes = minidom.StringTypes

theDOMImplementation = None # (!) real value is ''

_ALLOWED_FILTER_RETURNS = (
    1,
    2,
    3,
)

_typeinfo_map = {
    'CDATA': None, # (!) real value is ''
    'ENTITIES': None, # (!) real value is ''
    'ENTITY': None, # (!) real value is ''
    'ENUM': None, # (!) real value is ''
    'ID': None, # (!) real value is ''
    'IDREF': None, # (!) real value is ''
    'IDREFS': None, # (!) real value is ''
    'NMTOKEN': None, # (!) real value is ''
    'NMTOKENS': None, # (!) real value is ''
}

