# encoding: utf-8
# module xml.dom.pulldom
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/pulldom.pyo by generator 1.99
# no doc

# imports
import xml as xml # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/__init__.pyc
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/types.pyc

# Variables with simple values

CHARACTERS = 'CHARACTERS'

COMMENT = 'COMMENT'

default_bufsize = 16364

END_DOCUMENT = 'END_DOCUMENT'
END_ELEMENT = 'END_ELEMENT'

IGNORABLE_WHITESPACE = 'IGNORABLE_WHITESPACE'

PROCESSING_INSTRUCTION = 'PROCESSING_INSTRUCTION'

START_DOCUMENT = 'START_DOCUMENT'
START_ELEMENT = 'START_ELEMENT'

# functions

def parse(stream_or_string, parser=None, bufsize=None): # reliably restored by inspect
    # no doc
    pass


def parseString(string, parser=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

DOMEventStream = None # (!) real value is ''

ErrorHandler = None # (!) real value is ''

PullDOM = None # (!) real value is ''

SAX2DOM = None # (!) real value is ''

_StringTypes = [
    bytes,
    unicode,
]

