# encoding: utf-8
# module xml.dom.minicompat
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/minicompat.pyo by generator 1.99
""" Python version compatibility support for minidom. """

# imports
import xml as xml # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/__init__.pyc

# functions

def defproperty(klass, name, doc): # reliably restored by inspect
    # no doc
    pass


# classes

class EmptyNodeList(tuple):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __radd__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


class NodeList(list):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


# variables with complex values

StringTypes = (
    bytes,
    unicode,
)

__all__ = [
    'NodeList',
    'EmptyNodeList',
    'StringTypes',
    'defproperty',
]

