# encoding: utf-8
# module xml.dom.minidom
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/minidom.pyo by generator 1.99
"""
minidom.py -- a lightweight DOM implementation.

parse("foo.xml")

parseString("<foo><bar/></foo>")

Todo:
=====
 * convenience methods for getting elements and text.
 * more testing
 * bring some of the writer and linearizer code into conformance with this
        interface
 * SAX 2 namespaces
"""

# imports
import xml as xml # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/__init__.pyc
import xml.dom.domreg as domreg # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/domreg.pyc

# Variables with simple values

EMPTY_NAMESPACE = None
EMPTY_PREFIX = None

XMLNS_NAMESPACE = 'http://www.w3.org/2000/xmlns/'

# functions

def defproperty(klass, name, doc): # reliably restored by inspect
    # no doc
    pass


def getDOMImplementation(features=None): # reliably restored by inspect
    # no doc
    pass


def parse(file, parser=None, bufsize=None): # reliably restored by inspect
    """ Parse a file into a DOM by filename or file object. """
    pass


def parseString(string, parser=None): # reliably restored by inspect
    """ Parse a file into a DOM from a string. """
    pass


def _append_child(self, node): # reliably restored by inspect
    # no doc
    pass


def _clear_id_cache(node): # reliably restored by inspect
    # no doc
    pass


def _clone_node(node, deep, newOwnerDocument): # reliably restored by inspect
    """
    Clone a node and give it the new owner document.
        Called by Node.cloneNode and Document.importNode
    """
    pass


def _do_pulldom_parse(func, args, kwargs): # reliably restored by inspect
    # no doc
    pass


def _get_containing_element(node): # reliably restored by inspect
    # no doc
    pass


def _get_containing_entref(node): # reliably restored by inspect
    # no doc
    pass


def _get_elements_by_tagName_helper(parent, name, rc): # reliably restored by inspect
    # no doc
    pass


def _get_elements_by_tagName_ns_helper(parent, nsURI, localName, rc): # reliably restored by inspect
    # no doc
    pass


def _get_StringIO(): # reliably restored by inspect
    # no doc
    pass


def _in_document(node): # reliably restored by inspect
    # no doc
    pass


def _nssplit(qualifiedName): # reliably restored by inspect
    # no doc
    pass


def _set_attribute_node(element, attr): # reliably restored by inspect
    # no doc
    pass


def _write_data(writer, data): # reliably restored by inspect
    """ Writes datachars to writer. """
    pass


# classes

class NamedNodeMap(object):
    """
    The attribute list is a transient interface to the underlying
        dictionaries.  Mutations here will change the underlying element's
        dictionary.
    
        Ordering is imposed artificially and does not reflect the order of
        attributes as found in an input document.
    """
    def get(self, *args, **kwargs): # real signature unknown
        pass

    def getNamedItem(self, *args, **kwargs): # real signature unknown
        pass

    def getNamedItemNS(self, *args, **kwargs): # real signature unknown
        pass

    def has_key(self, *args, **kwargs): # real signature unknown
        pass

    def item(self, *args, **kwargs): # real signature unknown
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def itemsNS(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def keysNS(self, *args, **kwargs): # real signature unknown
        pass

    def removeNamedItem(self, *args, **kwargs): # real signature unknown
        pass

    def removeNamedItemNS(self, *args, **kwargs): # real signature unknown
        pass

    def setNamedItem(self, *args, **kwargs): # real signature unknown
        pass

    def setNamedItemNS(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def __cmp__(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default
    _attrs = property(lambda self: object()) # default
    _attrsNS = property(lambda self: object()) # default
    _ownerElement = property(lambda self: object()) # default

    __hash__ = None
    __slots__ = (
        '_attrs',
        '_attrsNS',
        '_ownerElement',
    )


AttributeList = NamedNodeMap


class ElementInfo(object):
    """
    Object that represents content-model information for an element.
    
        This implementation is not expected to be used in practice; DOM
        builders should provide implementations which do the right thing
        using information available to it.
    """
    def getAttributeType(self, *args, **kwargs): # real signature unknown
        pass

    def getAttributeTypeNS(self, *args, **kwargs): # real signature unknown
        pass

    def isElementContent(self, *args, **kwargs): # real signature unknown
        pass

    def isEmpty(self, *args, **kwargs): # real signature unknown
        """
        Returns true iff this element is declared to have an EMPTY
                content model.
        """
        pass

    def isId(self, *args, **kwargs): # real signature unknown
        """ Returns true iff the named attribte is a DTD-style ID. """
        pass

    def isIdNS(self, *args, **kwargs): # real signature unknown
        """ Returns true iff the identified attribute is a DTD-style ID. """
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    tagName = property(lambda self: object()) # default

    __slots__ = (
        'tagName',
    )


class EmptyNodeList(tuple):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __radd__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


class NodeList(list):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


class ReadOnlySequentialNamedNodeMap(object):
    # no doc
    def getNamedItem(self, *args, **kwargs): # real signature unknown
        pass

    def getNamedItemNS(self, *args, **kwargs): # real signature unknown
        pass

    def item(self, *args, **kwargs): # real signature unknown
        pass

    def removeNamedItem(self, *args, **kwargs): # real signature unknown
        pass

    def removeNamedItemNS(self, *args, **kwargs): # real signature unknown
        pass

    def setNamedItem(self, *args, **kwargs): # real signature unknown
        pass

    def setNamedItemNS(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default
    _seq = property(lambda self: object()) # default

    __slots__ = (
        '_seq',
    )


class TypeInfo(object):
    # no doc
    def _get_name(self, *args, **kwargs): # real signature unknown
        pass

    def _get_namespace(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    name = property(lambda self: object()) # default
    namespace = property(lambda self: object()) # default

    __slots__ = (
        'namespace',
        'name',
    )


# variables with complex values

Attr = None # (!) real value is ''

CDATASection = None # (!) real value is ''

CharacterData = None # (!) real value is ''

Childless = None # (!) real value is ''

Comment = None # (!) real value is ''

Document = None # (!) real value is ''

DocumentFragment = None # (!) real value is ''

DocumentLS = None # (!) real value is ''

DocumentType = None # (!) real value is ''

DOMImplementation = None # (!) real value is ''

DOMImplementationLS = None # (!) real value is ''

Element = None # (!) real value is ''

Entity = None # (!) real value is ''

Identified = None # (!) real value is ''

Node = None # (!) real value is ''

Notation = None # (!) real value is ''

ProcessingInstruction = None # (!) real value is ''

StringTypes = domreg.StringTypes

Text = None # (!) real value is ''

_nodeTypes_with_children = (
    1,
    5,
)

_no_type = None # (!) real value is ''

