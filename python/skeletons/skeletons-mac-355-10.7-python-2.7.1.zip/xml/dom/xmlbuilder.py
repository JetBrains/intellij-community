# encoding: utf-8
# module xml.dom.xmlbuilder
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/xmlbuilder.pyo by generator 1.99
""" Implementation of the DOM Level 3 'LS-Load' feature. """

# imports
import xml as xml # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/__init__.pyc
import copy as copy # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/copy.pyc

# functions

def _name_xform(name): # reliably restored by inspect
    # no doc
    pass


# classes

class DOMEntityResolver(object):
    # no doc
    def resolveEntity(self, *args, **kwargs): # real signature unknown
        pass

    def _create_opener(self, *args, **kwargs): # real signature unknown
        pass

    def _get_opener(self, *args, **kwargs): # real signature unknown
        pass

    def _guess_media_encoding(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _opener = property(lambda self: object()) # default

    __slots__ = (
        '_opener',
    )


class DOMInputSource(object):
    # no doc
    def _get_baseURI(self, *args, **kwargs): # real signature unknown
        pass

    def _get_byteStream(self, *args, **kwargs): # real signature unknown
        pass

    def _get_characterStream(self, *args, **kwargs): # real signature unknown
        pass

    def _get_encoding(self, *args, **kwargs): # real signature unknown
        pass

    def _get_publicId(self, *args, **kwargs): # real signature unknown
        pass

    def _get_stringData(self, *args, **kwargs): # real signature unknown
        pass

    def _get_systemId(self, *args, **kwargs): # real signature unknown
        pass

    def _set_baseURI(self, *args, **kwargs): # real signature unknown
        pass

    def _set_byteStream(self, *args, **kwargs): # real signature unknown
        pass

    def _set_characterStream(self, *args, **kwargs): # real signature unknown
        pass

    def _set_encoding(self, *args, **kwargs): # real signature unknown
        pass

    def _set_publicId(self, *args, **kwargs): # real signature unknown
        pass

    def _set_stringData(self, *args, **kwargs): # real signature unknown
        pass

    def _set_systemId(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    baseURI = property(lambda self: object()) # default
    byteStream = property(lambda self: object()) # default
    characterStream = property(lambda self: object()) # default
    encoding = property(lambda self: object()) # default
    publicId = property(lambda self: object()) # default
    stringData = property(lambda self: object()) # default
    systemId = property(lambda self: object()) # default

    __slots__ = (
        'byteStream',
        'characterStream',
        'stringData',
        'encoding',
        'publicId',
        'systemId',
        'baseURI',
    )


# variables with complex values

DocumentLS = None # (!) real value is ''

DOMBuilder = None # (!) real value is ''

DOMBuilderFilter = None # (!) real value is ''

DOMImplementationLS = None # (!) real value is ''

Options = None # (!) real value is ''

__all__ = [
    'DOMBuilder',
    'DOMEntityResolver',
    'DOMInputSource',
]

