# encoding: utf-8
# module xml.dom.domreg
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/xml/dom/domreg.pyo by generator 1.99
"""
Registration facilities for DOM. This module should not be used
directly. Instead, the functions getDOMImplementation and
registerDOMImplementation should be imported from xml.dom.
"""
# no imports

# functions

def defproperty(klass, name, doc): # reliably restored by inspect
    # no doc
    pass


def getDOMImplementation(name=None, features='()'): # reliably restored by inspect
    """
    getDOMImplementation(name = None, features = ()) -> DOM implementation.
    
        Return a suitable DOM implementation. The name is either
        well-known, the module name of a DOM implementation, or None. If
        it is not None, imports the corresponding module and returns
        DOMImplementation object if the import succeeds.
    
        If name is not given, consider the available implementations to
        find one with the required feature set. If no implementation can
        be found, raise an ImportError. The features list must be a sequence
        of (feature, version) pairs which are passed to hasFeature.
    """
    pass


def registerDOMImplementation(name, factory): # reliably restored by inspect
    """
    registerDOMImplementation(name, factory)
    
        Register the factory function with the name. The factory function
        should return an object which implements the DOMImplementation
        interface. The factory function can either return the same object,
        or a new one (e.g. if that implementation supports some
        customization).
    """
    pass


def _good_enough(dom, features): # reliably restored by inspect
    """ _good_enough(dom, features) -> Return 1 if the dom offers the features """
    pass


def _parse_feature_string(s): # reliably restored by inspect
    # no doc
    pass


# classes

class EmptyNodeList(tuple):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __radd__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


class NodeList(list):
    # no doc
    def item(self, *args, **kwargs): # real signature unknown
        pass

    def _get_length(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    length = property(lambda self: object()) # default

    __slots__ = ()


# variables with complex values

registered = {}

StringTypes = (
    bytes,
    unicode,
)

well_known_implementations = {
    '4DOM': 'xml.dom.DOMImplementation',
    'minidom': 'xml.dom.minidom',
}

