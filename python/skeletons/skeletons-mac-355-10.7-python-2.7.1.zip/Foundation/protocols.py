# encoding: utf-8
# module Foundation.protocols
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/SystemConfiguration/_manual.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
# variables with complex values

CAAction = None # (!) real value is ''

CAMediaTiming = None # (!) real value is ''

CAPropertyInfo = None # (!) real value is ''

CIFilterConstructor = None # (!) real value is ''

DDTypeCheckerDelegate = None # (!) real value is ''

FINode = None # (!) real value is ''

IMKClientProtocol = None # (!) real value is ''

IMKInkInput = None # (!) real value is ''

IMKServerProxy = None # (!) real value is ''

IMKTextInput = None # (!) real value is ''

IMKUnicodeTextInput = None # (!) real value is ''

IMTSMSupport = None # (!) real value is ''

KeychainProxyProtocol = None # (!) real value is ''

NSArchiverCallback = None # (!) real value is ''

NSCacheDelegate = None # (!) real value is ''

NSClassDescriptionPrimitives = None # (!) real value is ''

NSCoderMethods = None # (!) real value is ''

NSCoding = None # (!) real value is ''

NSComparisonMethods = None # (!) real value is ''

NSConnectionDelegateMethods = None # (!) real value is ''

NSConnectionVersionedProtocol = None # (!) real value is ''

NSCopying = None # (!) real value is ''

NSCopyLinkMoveHandler = None # (!) real value is ''

NSDecimalNumberBehaviors = None # (!) real value is ''

NSDelayedPerforming = None # (!) real value is ''

NSDeprecatedKeyValueCoding = None # (!) real value is ''

NSDeprecatedKeyValueObservingCustomization = None # (!) real value is ''

NSDeprecatedMethods = None # (!) real value is ''

NSDeserializerStream = None # (!) real value is ''

NSDiscardableContent = None # (!) real value is ''

NSDistantObjectRequestMethods = None # (!) real value is ''

NSDistributedObjects = None # (!) real value is ''

NSErrorRecoveryAttempting = None # (!) real value is ''

NSFastEnumeration = None # (!) real value is ''

NSFileAccessArbiter = None # (!) real value is ''

NSFileManagerFileOperationAdditions = None # (!) real value is ''

NSFilePresenter = None # (!) real value is ''

NSKeyedArchiverDelegate = None # (!) real value is ''

NSKeyedArchiverObjectSubstitution = None # (!) real value is ''

NSKeyedUnarchiverDelegate = None # (!) real value is ''

NSKeyedUnarchiverObjectSubstitution = None # (!) real value is ''

NSKeyValueCoding = None # (!) real value is ''

NSKeyValueObserverNotification = None # (!) real value is ''

NSKeyValueObserverRegistration = None # (!) real value is ''

NSKeyValueObserving = None # (!) real value is ''

NSKeyValueObservingCustomization = None # (!) real value is ''

NSKeyValueProxyCaching = None # (!) real value is ''

NSLocking = None # (!) real value is ''

NSMachPortDelegateMethods = None # (!) real value is ''

NSMetadataQueryDelegate = None # (!) real value is ''

NSMutableCopying = None # (!) real value is ''

NSNetServiceBrowserDelegateMethods = None # (!) real value is ''

NSNetServiceDelegateMethods = None # (!) real value is ''

NSObject = None # (!) real value is ''

NSPortDelegateMethods = None # (!) real value is ''

NSScriptClassDescription = None # (!) real value is ''

NSScripting = None # (!) real value is ''

NSScriptingComparisonMethods = None # (!) real value is ''

NSScriptKeyValueCoding = None # (!) real value is ''

NSScriptObjectSpecifiers = None # (!) real value is ''

NSSerializerStream = None # (!) real value is ''

NSSpellServerDelegate = None # (!) real value is ''

NSSpellServerPrivateNewDO = None # (!) real value is ''

NSStreamDelegateEventExtensions = None # (!) real value is ''

NSThreadPerformAdditions = None # (!) real value is ''

NSURLAuthenticationChallengeSender = None # (!) real value is ''

NSURLClient = None # (!) real value is ''

NSURLConnectionDelegate = None # (!) real value is ''

NSURLDataDecoder = None # (!) real value is ''

NSURLDownloadDecoder = None # (!) real value is ''

NSURLDownloadDelegate = None # (!) real value is ''

NSURLHandleClient = None # (!) real value is ''

NSURLProtocolCFRunloopScheduling = None # (!) real value is ''

NSURLProtocolClient = None # (!) real value is ''

NSXMLParserDelegate = None # (!) real value is ''

NSXMLParserDelegateEventAdditions = None # (!) real value is ''

NSXPCObject = None # (!) real value is ''

ODQueryDelegate = None # (!) real value is ''

