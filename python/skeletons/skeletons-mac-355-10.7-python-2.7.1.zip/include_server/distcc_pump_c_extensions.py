# encoding: utf-8
# module include_server.distcc_pump_c_extensions
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/include_server/distcc_pump_c_extensions.so by generator 1.99
""" Various utilities for distcc-pump. """
# no imports

# Variables with simple values

__author__ = 'Nils Klarlund'

__version__ = '.01'

# functions

def CompressLzo1xAlloc(*args, **kwargs): # real signature unknown
    """
    CompressFileLZO1Z__(in_buf):
    Compress file according to distcc lzo protocol.
    
       Arguments:
         in_buf: a string
       Raises:
         distcc_pump_c_extensions.Error
       Returns:
     a string, compressed according to distcc protocol
    .
    """
    pass


def OsPathExists(filepath): # real signature unknown; restored from __doc__
    """
    OsPathExists(filepath):
      Libc version of os.path.exists.
    
      Arguments:
        filepath: a string
      Returns:
        True or False
    """
    pass


def OsPathIsFile(filename): # real signature unknown; restored from __doc__
    """
    OsPathIsFile(filename):
      Libc version of os.path.isfile.
    
      Arguments:
        filename: a string
      Returns:
        True or False
    """
    pass


def RArgv(*args, **kwargs): # real signature unknown
    """
    Rargv(ifd):
       Read argv values.
    
       Arguments:
         ifd: an integer file descriptor
       Raises:
         distcc_pump_c_extensions.Error
    """
    pass


def RCwd(*args, **kwargs): # real signature unknown
    """
    Rcwd_doc__(ifd):
       Read value of current directory.
    
       Arguments:
         ifd: an integer file descriptor
       Raises:
         distcc_pump_c_extensions.Error
    """
    pass


def Realpath(filename): # real signature unknown; restored from __doc__
    """
    Realpath(filename)
      Libc version of os.path.realpath.
    
      Arguments:
        filename: a string
      Returns:
        the realpath (or filename if it does not exist)
      The semantics of this function is probably not quite the same as that
      of os.path.realpath for paths that do not correspond to existing files.
      This is why we do not call it OsPathRealpath.
    """
    pass


def RTokenString(ifd, expect_token): # real signature unknown; restored from __doc__
    """
    RTokenString(ifd, expect_token):
       Read value of expected token.
    
       Arguments:
         ifd: an integer file descriptor
         expect_token: a four-character string
       Raises:
         distcc_pump_c_extensions.Error
    """
    pass


def XArgv(ifd, argv): # real signature unknown; restored from __doc__
    """
    XArgv(ifd, argv)
      Transmit list argv.
    
      Arguments:
        ifd: integer file descriptor
        argv: a list of strings
    """
    pass


# classes

class Error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


