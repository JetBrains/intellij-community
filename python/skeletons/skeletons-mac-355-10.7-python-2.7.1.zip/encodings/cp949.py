# encoding: utf-8
# module encodings.cp949
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/encodings/cp949.pyo by generator 1.99
# no doc

# imports
import _codecs_kr as _codecs_kr # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_codecs_kr.so
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/codecs.pyc
import _multibytecodec as mbc # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_multibytecodec.so
import codecs as __codecs


# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(MultibyteIncrementalDecoder, __codecs.IncrementalDecoder):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


class IncrementalEncoder(MultibyteIncrementalEncoder, __codecs.IncrementalEncoder):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


class StreamReader(Codec, MultibyteStreamReader, __codecs.StreamReader):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


class StreamWriter(Codec, MultibyteStreamWriter, __codecs.StreamWriter):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


# variables with complex values

Codec = None # (!) real value is ''

codec = None # (!) real value is ''

