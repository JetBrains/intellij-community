# encoding: utf-8
# module encodings.hex_codec
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/encodings/hex_codec.pyo by generator 1.99
"""
Python 'hex_codec' Codec - 2-digit hex content transfer encoding

    Unlike most of the other codecs which target Unicode, this codec
    will return Python string objects for both encode and decode.

    Written by Marc-Andre Lemburg (mal@lemburg.com).
"""

# imports
import binascii as binascii # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/binascii.so
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/codecs.pyc
import codecs as __codecs


# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


def hex_decode(input, errors=None): # reliably restored by inspect
    """
    Decodes the object input and returns a tuple (output
            object, length consumed).
    
            input must be an object which provides the bf_getreadbuf
            buffer slot. Python strings, buffer objects and memory
            mapped files are examples of objects providing this slot.
    
            errors defines the error handling to apply. It defaults to
            'strict' handling which is the only currently supported
            error handling for this codec.
    """
    pass


def hex_encode(input, errors=None): # reliably restored by inspect
    """
    Encodes the object input and returns a tuple (output
            object, length consumed).
    
            errors defines the error handling to apply. It defaults to
            'strict' handling which is the only currently supported
            error handling for this codec.
    """
    pass


# classes

class IncrementalDecoder(__codecs.IncrementalDecoder):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates a IncrementalDecoder instance.
        
                The IncrementalDecoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

Codec = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

