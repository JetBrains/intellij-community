# encoding: utf-8
# module encodings.quopri_codec
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/encodings/quopri_codec.pyo by generator 1.99
"""
Codec for quoted-printable encoding.

Like base64 and rot13, this returns Python strings, not Unicode.
"""

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/codecs.pyc
import quopri as quopri # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/quopri.pyc
from cStringIO import StringIO

import codecs as __codecs


# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


def quopri_decode(input, errors=None): # reliably restored by inspect
    """
    Decode the input, returning a tuple (output object, length consumed).
    
        errors defines the error handling to apply. It defaults to
        'strict' handling which is the only currently supported
        error handling for this codec.
    """
    pass


def quopri_encode(input, errors=None): # reliably restored by inspect
    """
    Encode the input, returning a tuple (output object, length consumed).
    
        errors defines the error handling to apply. It defaults to
        'strict' handling which is the only currently supported
        error handling for this codec.
    """
    pass


# classes

class IncrementalDecoder(__codecs.IncrementalDecoder):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates a IncrementalDecoder instance.
        
                The IncrementalDecoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

Codec = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

