# encoding: utf-8
# module encodings.cp500
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/encodings/cp500.pyo by generator 1.99
""" Python Character Mapping Codec cp500 generated from 'MAPPINGS/VENDORS/MICSFT/EBCDIC/CP500.TXT' with gencodec.py. """

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/codecs.pyc
import codecs as __codecs


# Variables with simple values

decoding_table = u'\x00\x01\x02\x03\x9c\t\x86\x7f\x97\x8d\x8e\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x9d\x85\x08\x87\x18\x19\x92\x8f\x1c\x1d\x1e\x1f\x80\x81\x82\x83\x84\n\x17\x1b\x88\x89\x8a\x8b\x8c\x05\x06\x07\x90\x91\x16\x93\x94\x95\x96\x04\x98\x99\x9a\x9b\x14\x15\x9e\x1a \xa0\xe2\xe4\xe0\xe1\xe3\xe5\xe7\xf1[.<(+!&\xe9\xea\xeb\xe8\xed\xee\xef\xec\xdf]$*);^-/\xc2\xc4\xc0\xc1\xc3\xc5\xc7\xd1\xa6,%_>?\xf8\xc9\xca\xcb\xc8\xcd\xce\xcf\xcc`:#@\'="\xd8abcdefghi\xab\xbb\xf0\xfd\xfe\xb1\xb0jklmnopqr\xaa\xba\xe6\xb8\xc6\xa4\xb5~stuvwxyz\xa1\xbf\xd0\xdd\xde\xae\xa2\xa3\xa5\xb7\xa9\xa7\xb6\xbc\xbd\xbe\xac|\xaf\xa8\xb4\xd7{ABCDEFGHI\xad\xf4\xf6\xf2\xf3\xf5}JKLMNOPQR\xb9\xfb\xfc\xf9\xfa\xff\\\xf7STUVWXYZ\xb2\xd4\xd6\xd2\xd3\xd50123456789\xb3\xdb\xdc\xd9\xda\x9f'

# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(__codecs.IncrementalDecoder):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates a IncrementalDecoder instance.
        
                The IncrementalDecoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

Codec = None # (!) real value is ''

encoding_table = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

