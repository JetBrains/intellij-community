# encoding: utf-8
# module xattr._xattr
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/xattr/_xattr.so by generator 1.99
# no doc
# no imports

# functions

def fgetxattr(fd, name, size=0, position=0, options=0): # real signature unknown; restored from __doc__
    """
    fgetxattr(fd, name, size=0, position=0, options=0) -> str
    
    ...
    """
    return ""


def flistxattr(fd, options=0): # real signature unknown; restored from __doc__
    """
    flistxattr(fd, options=0) -> str
    
    ...
    """
    return ""


def fremovexattr(fd, name, options=0): # real signature unknown; restored from __doc__
    """
    fremovexattr(fd, name, options=0) -> None
    
    ...
    """
    pass


def fsetxattr(fd, name, value, position=0, options=0): # real signature unknown; restored from __doc__
    """
    fsetxattr(fd, name, value, position=0, options=0) -> None
    
    ...
    """
    pass


def getxattr(path, name, size=0, position=0, options=0): # real signature unknown; restored from __doc__
    """
    getxattr(path, name, size=0, position=0, options=0) -> str
    
    ...
    """
    return ""


def listxattr(path, options=0): # real signature unknown; restored from __doc__
    """
    listxattr(path, options=0) -> str
    
    ...
    """
    return ""


def removexattr(path, name, options=0): # real signature unknown; restored from __doc__
    """
    removexattr(path, name, options=0) -> None
    
    ...
    """
    pass


def setxattr(path, name, value, position=0, options=0): # real signature unknown; restored from __doc__
    """
    setxattr(path, name, value, position=0, options=0) -> None
    
    ...
    """
    pass


# no classes
