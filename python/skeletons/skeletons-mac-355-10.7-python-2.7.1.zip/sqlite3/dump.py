# encoding: utf-8
# module sqlite3.dump
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/sqlite3/dump.pyo by generator 1.99
# no doc
# no imports

# functions

def _iterdump(connection): # reliably restored by inspect
    """
    Returns an iterator to the dump of the database in an SQL text format.
    
        Used to produce an SQL dump of the database.  Useful to save an in-memory
        database for later restoration.  This function should not be called
        directly but instead called from the Connection method, iterdump().
    """
    pass


# no classes
