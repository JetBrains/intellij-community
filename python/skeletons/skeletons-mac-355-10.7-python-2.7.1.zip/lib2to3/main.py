# encoding: utf-8
# module lib2to3.main
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/main.pyo by generator 1.99
""" Main program for 2to3. """

# imports
import logging as logging # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/logging/__init__.pyc
import difflib as difflib # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/difflib.pyc
import lib2to3.refactor as refactor # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/refactor.pyc
import sys as sys # <module 'sys' (built-in)>
import optparse as optparse # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/optparse.pyc
import shutil as shutil # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/shutil.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import lib2to3.refactor as __lib2to3_refactor


# functions

def diff_texts(a, b, filename): # reliably restored by inspect
    """ Return a unified diff of two strings. """
    pass


def main(fixer_pkg, args=None): # reliably restored by inspect
    """
    Main program.
    
        Args:
            fixer_pkg: the name of a package where the fixers are located.
            args: optional; a list of command line arguments. If omitted,
                  sys.argv[1:] is used.
    
        Returns a suggested exit status (0, 1, 2).
    """
    pass


def warn(msg): # reliably restored by inspect
    # no doc
    pass


# classes

class StdoutRefactoringTool(__lib2to3_refactor.MultiprocessRefactoringTool):
    """ Prints output to stdout. """
    def log_error(self, *args, **kwargs): # real signature unknown
        pass

    def print_output(self, *args, **kwargs): # real signature unknown
        pass

    def write_file(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

with_statement = refactor.with_statement

