# encoding: utf-8
# module lib2to3.patcomp
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/patcomp.pyo by generator 1.99
"""
Pattern compiler.

The grammer is taken from PatternGrammar.txt.

The compiler compiles a pattern to a pytree.*Pattern instance.
"""

# imports
import lib2to3.pgen2.parse as parse # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/parse.pyc
import lib2to3.pgen2.literals as literals # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/literals.pyc
import lib2to3.pgen2.tokenize as tokenize # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/tokenize.pyc
import lib2to3.pytree as pytree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pytree.pyc
import lib2to3.pgen2.driver as driver # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/driver.pyc
import lib2to3.pygram as pygram # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pygram.pyc
import lib2to3.pgen2.grammar as grammar # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/grammar.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

_PATTERN_GRAMMAR_FILE = '/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/PatternGrammar.txt'

__author__ = 'Guido van Rossum <guido@python.org>'

# functions

def compile_pattern(pattern): # reliably restored by inspect
    # no doc
    pass


def pattern_convert(grammar, raw_node_info): # reliably restored by inspect
    """ Converts raw node information to a Node or Leaf instance. """
    pass


def tokenize_wrapper(input): # reliably restored by inspect
    """ Tokenizes a string suppressing significant whitespace. """
    pass


def _type_of_literal(value): # reliably restored by inspect
    # no doc
    pass


# classes

class PatternCompiler(object):
    # no doc
    def compile_basic(self, *args, **kwargs): # real signature unknown
        pass

    def compile_node(self, *args, **kwargs): # real signature unknown
        """
        Compiles a node, recursively.
        
                This is one big switch on the node type.
        """
        pass

    def compile_pattern(self, *args, **kwargs): # real signature unknown
        """ Compiles a pattern string to a nested pytree.*Pattern object. """
        pass

    def get_int(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.
        
                Takes an optional alternative filename for the pattern grammar.
        """
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class PatternSyntaxError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

TOKEN_MAP = {
    'NAME': 1,
    'NUMBER': 2,
    'STRING': 3,
    'TOKEN': None,
}

