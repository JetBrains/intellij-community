# encoding: utf-8
# module lib2to3.pygram
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pygram.pyo by generator 1.99
""" Export the Python grammar and symbols. """

# imports
import lib2to3.pytree as pytree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pytree.pyc
import lib2to3.pgen2.driver as driver # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/driver.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

_GRAMMAR_FILE = '/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/Grammar.txt'

_PATTERN_GRAMMAR_FILE = '/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/PatternGrammar.txt'

# no functions
# classes

class Symbols(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.
        
                Creates an attribute for each grammar symbol (nonterminal),
                whose value is the symbol's type (an int >= 256).
        """
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

pattern_grammar = None # (!) real value is ''

pattern_symbols = None # (!) real value is ''

python_grammar = None # (!) real value is ''

python_grammar_no_print_statement = None # (!) real value is ''

python_symbols = None # (!) real value is ''

