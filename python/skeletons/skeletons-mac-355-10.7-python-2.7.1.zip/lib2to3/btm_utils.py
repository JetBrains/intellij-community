# encoding: utf-8
# module lib2to3.btm_utils
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/btm_utils.pyo by generator 1.99
""" Utility functions used by the btm_matcher module """

# imports
import lib2to3.pgen2.token as token_labels # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import lib2to3.pgen2.grammar as grammar # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/grammar.pyc
import lib2to3.pytree as pytree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pytree.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc

# Variables with simple values

TYPE_ALTERNATIVES = -2
TYPE_ANY = -1
TYPE_GROUP = -3

# functions

def get_characteristic_subpattern(subpatterns): # reliably restored by inspect
    """
    Picks the most characteristic from a list of linear patterns
        Current order used is:
        names > common_names > common_chars
    """
    pass


def rec_test(sequence, test_func): # reliably restored by inspect
    """
    Tests test_func on all items of sequence and items of included
        sub-iterables
    """
    pass


def reduce_tree(node, parent=None): # reliably restored by inspect
    """
    Internal function. Reduces a compiled pattern tree to an
        intermediate representation suitable for feeding the
        automaton. This also trims off any optional pattern elements(like
        [a], a*).
    """
    pass


# classes

class MinNode(object):
    """
    This class serves as an intermediate representation of the
        pattern tree during the conversion to sets of leaf-to-root
        subpatterns
    """
    def get_linear_subpattern(self, *args, **kwargs): # real signature unknown
        """
        Drives the leaf_to_root method. The reason that
                leaf_to_root must be run multiple times is because we need to
                reject 'group' matches; for example the alternative form
                (a | b c) creates a group [b c] that needs to be matched. Since
                matching multiple linear patterns overcomes the automaton's
                capabilities, leaf_to_root merges each group into a single
                choice based on 'characteristic'ity,
        
                i.e. (a|b c) -> (a|b) if b more characteristic than c
        
                Returns: The most 'characteristic'(as defined by
                  get_characteristic_subpattern) path for the compiled pattern
                  tree.
        """
        pass

    def leaf_to_root(self, *args, **kwargs): # real signature unknown
        """
        Internal method. Returns a characteristic path of the
                pattern tree. This method must be run for all leaves until the
                linear subpatterns are merged into a single
        """
        pass

    def leaves(self, *args, **kwargs): # real signature unknown
        """ Generator that returns the leaves of the tree """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

pattern_symbols = None # (!) forward: syms, real value is ''

pysyms = None # (!) forward: python_symbols, real value is ''

python_symbols = None # (!) real value is ''

syms = None # (!) real value is ''

tokens = grammar.opmap

