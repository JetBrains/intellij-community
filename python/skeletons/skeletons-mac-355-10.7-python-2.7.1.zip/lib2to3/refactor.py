# encoding: utf-8
# module lib2to3.refactor
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/refactor.pyo by generator 1.99
"""
Refactoring framework.

Used as a main program, this can refactor any number of files and/or
recursively descend down directories.  Imported as a module, this
provides infrastructure to write your own refactoring tool.
"""

# imports
import operator as operator # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/operator.so
import collections as collections # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/collections.pyc
import lib2to3.pgen2.tokenize as tokenize # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/tokenize.pyc
import lib2to3.btm_matcher as bm # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/btm_matcher.pyc
import lib2to3.pytree as pytree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pytree.pyc
import lib2to3.pgen2.driver as driver # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/driver.pyc
import sys as sys # <module 'sys' (built-in)>
import lib2to3.btm_utils as bu # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/btm_utils.pyc
import lib2to3.pygram as pygram # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pygram.pyc
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/codecs.pyc
import logging as logging # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/logging/__init__.pyc
import StringIO as StringIO # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/StringIO.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from itertools import chain


# Variables with simple values

__author__ = 'Guido van Rossum <guido@python.org>'

# functions

def find_root(node): # reliably restored by inspect
    """ Find the top level namespace. """
    pass


def get_all_fix_names(fixer_pkg, remove_prefix=True): # reliably restored by inspect
    """ Return a sorted list of all available fix names in the given package. """
    pass


def get_fixers_from_package(pkg_name): # reliably restored by inspect
    """ Return the fully qualified names for fixers in the package pkg_name. """
    pass


def _detect_future_features(source): # reliably restored by inspect
    # no doc
    pass


def _from_system_newlines(input): # reliably restored by inspect
    # no doc
    pass


def _get_headnode_dict(fixer_list): # reliably restored by inspect
    """
    Accepts a list of fixers and returns a dictionary
            of head node type --> fixer list.
    """
    pass


def _get_head_types(pat): # reliably restored by inspect
    """
    Accepts a pytree Pattern Node and returns a set
            of the pattern types which will match first.
    """
    pass


def _identity(obj): # reliably restored by inspect
    # no doc
    pass


def _open_with_encoding(filename, mode=None, encoding=None, errors=None, buffering=1): # reliably restored by inspect
    """
    Open an encoded file using the given mode and return
            a wrapped version providing transparent encoding/decoding.
    
            Note: The wrapped version will only accept the object format
            defined by the codecs, i.e. Unicode objects for most builtin
            codecs. Output is also codec dependent and will usually be
            Unicode as well.
    
            Files are always opened in binary mode, even if no binary mode
            was specified. This is done to avoid data loss due to encodings
            using 8-bit values. The default file mode is 'rb' meaning to
            open the file in binary read mode.
    
            encoding specifies the encoding which is to be used for the
            file.
    
            errors may be given to define the error handling. It defaults
            to 'strict' which causes ValueErrors to be raised in case an
            encoding error occurs.
    
            buffering has the same meaning as for the builtin open() API.
            It defaults to line buffered.
    
            The returned wrapped file object provides an extra attribute
            .encoding which allows querying the used encoding. This
            attribute is only available if an encoding was specified as
            parameter.
    """
    pass


def _to_system_newlines(input): # reliably restored by inspect
    # no doc
    pass


# classes

class FixerError(Exception):
    """ A fixer could not be loaded. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class MultiprocessingUnsupported(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class RefactoringTool(object):
    # no doc
    def gen_lines(self, *args, **kwargs): # real signature unknown
        """
        Generates lines as expected by tokenize from a list of lines.
        
                This strips the first len(indent + self.PS1) characters off each line.
        """
        pass

    def get_fixers(self, *args, **kwargs): # real signature unknown
        """
        Inspects the options to load the requested patterns and handlers.
        
                Returns:
                  (pre_order, post_order), where pre_order is the list of fixers that
                  want a pre-order AST traversal, and post_order is the list that want
                  post-order traversal.
        """
        pass

    def log_debug(self, *args, **kwargs): # real signature unknown
        pass

    def log_error(self, *args, **kwargs): # real signature unknown
        """ Called when an error occurs. """
        pass

    def log_message(self, *args, **kwargs): # real signature unknown
        """ Hook to log a message. """
        pass

    def parse_block(self, *args, **kwargs): # real signature unknown
        """
        Parses a block into a tree.
        
                This is necessary to get correct line number / offset information
                in the parser diagnostics and embedded into the parse tree.
        """
        pass

    def print_output(self, *args, **kwargs): # real signature unknown
        """
        Called with the old version, new version, and filename of a
                refactored file.
        """
        pass

    def processed_file(self, *args, **kwargs): # real signature unknown
        """ Called when a file has been refactored, and there are changes. """
        pass

    def refactor(self, *args, **kwargs): # real signature unknown
        """ Refactor a list of files and directories. """
        pass

    def refactor_dir(self, *args, **kwargs): # real signature unknown
        """
        Descends down a directory and refactor every Python file found.
        
                Python files are assumed to have a .py extension.
        
                Files and subdirectories starting with '.' are skipped.
        """
        pass

    def refactor_docstring(self, *args, **kwargs): # real signature unknown
        """
        Refactors a docstring, looking for doctests.
        
                This returns a modified version of the input string.  It looks
                for doctests, which start with a ">>>" prompt, and may be
                continued with "..." prompts, as long as the "..." is indented
                the same as the ">>>".
        
                (Unfortunately we can't use the doctest module's parser,
                since, like most parsers, it is not geared towards preserving
                the original source.)
        """
        pass

    def refactor_doctest(self, *args, **kwargs): # real signature unknown
        """
        Refactors one doctest.
        
                A doctest is given as a block of lines, the first of which starts
                with ">>>" (possibly indented), while the remaining lines start
                with "..." (identically indented).
        """
        pass

    def refactor_file(self, *args, **kwargs): # real signature unknown
        """ Refactors a file. """
        pass

    def refactor_stdin(self, *args, **kwargs): # real signature unknown
        pass

    def refactor_string(self, *args, **kwargs): # real signature unknown
        """
        Refactor a given input string.
        
                Args:
                    data: a string holding the code to be refactored.
                    name: a human-readable name for use in error/log messages.
        
                Returns:
                    An AST corresponding to the refactored input stream; None if
                    there were errors during the parse.
        """
        pass

    def refactor_tree(self, *args, **kwargs): # real signature unknown
        """
        Refactors a parse tree (modifying the tree in place).
        
                For compatible patterns the bottom matcher module is
                used. Otherwise the tree is traversed node-to-node for
                matches.
        
                Args:
                    tree: a pytree.Node instance representing the root of the tree
                          to be refactored.
                    name: a human-readable name for this tree.
        
                Returns:
                    True if the tree was modified, False otherwise.
        """
        pass

    def summarize(self, *args, **kwargs): # real signature unknown
        pass

    def traverse_by(self, *args, **kwargs): # real signature unknown
        """
        Traverse an AST, applying a set of fixers to each node.
        
                This is a helper method for refactor_tree().
        
                Args:
                    fixers: a list of fixer instances.
                    traversal: a generator that yields AST nodes.
        
                Returns:
                    None
        """
        pass

    def wrap_toks(self, *args, **kwargs): # real signature unknown
        """ Wraps a tokenize stream to systematically modify start/end. """
        pass

    def write_file(self, *args, **kwargs): # real signature unknown
        """
        Writes a string to a file.
        
                It first shows a unified diff between the old text and the new text, and
                then rewrites the file; the latter is only done if the write option is
                set.
        """
        pass

    def _read_python_source(self, *args, **kwargs): # real signature unknown
        """ Do our best to decode a Python source file correctly. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.
        
                Args:
                    fixer_names: a list of fixers to import
                    options: an dict with configuration.
                    explicit: a list of fixers to run even if they are explicit.
        """
        pass

    __weakref__ = property(lambda self: object()) # default

    CLASS_PREFIX = 'Fix'
    FILE_PREFIX = 'fix_'
    PS1 = '>>> '
    PS2 = '... '
    _default_options = {
        'print_function': False,
    }
    __dict__ = None # (!) real value is ''


class MultiprocessRefactoringTool(RefactoringTool):
    # no doc
    def refactor(self, *args, **kwargs): # real signature unknown
        pass

    def refactor_file(self, *args, **kwargs): # real signature unknown
        pass

    def _child(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class _EveryNode(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

with_statement = None # (!) real value is ''

