# encoding: utf-8
# module lib2to3.fixer_util
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_util.pyo by generator 1.99
""" Utility functions, node construction macros, etc. """

# imports
import lib2to3.patcomp as patcomp # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/patcomp.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
from itertools import islice

import lib2to3.pytree as __lib2to3_pytree


# Variables with simple values

p0 = "for_stmt< 'for' any 'in' node=any ':' any* >\n        | comp_for< 'for' any 'in' node=any any* >\n     "

p1 = "\npower<\n    ( 'iter' | 'list' | 'tuple' | 'sorted' | 'set' | 'sum' |\n      'any' | 'all' | (any* trailer< '.' 'join' >) )\n    trailer< '(' node=any ')' >\n    any*\n>\n"

p2 = "\npower<\n    'sorted'\n    trailer< '(' arglist<node=any any*> ')' >\n    any*\n>\n"

pats_built = False

# functions

def ArgList(args, lparen="Leaf(7, u'(')", rparen="Leaf(8, u')')"): # reliably restored by inspect
    """ A parenthesised argument list, used by Call() """
    pass


def Assign(target, source): # reliably restored by inspect
    """ Build an assignment statement """
    pass


def Attr(obj, attr): # reliably restored by inspect
    """ A node tuple for obj.attr """
    pass


def attr_chain(obj, attr): # reliably restored by inspect
    """
    Follow an attribute chain.
    
        If you have a chain of objects where a.foo -> b, b.foo-> c, etc,
        use this to iterate over all objects in the chain. Iteration is
        terminated by getattr(x, attr) is None.
    
        Args:
            obj: the starting object
            attr: the name of the chaining attribute
    
        Yields:
            Each successive object in the chain.
    """
    pass


def BlankLine(): # reliably restored by inspect
    """ A blank line """
    pass


def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def Comma(): # reliably restored by inspect
    """ A comma leaf """
    pass


def does_tree_import(package, name, node): # reliably restored by inspect
    """
    Returns true if name is imported from package at the
            top level of the tree which node belongs to.
            To cover the case of an import like 'import foo', use
            None for the package and 'foo' for the name.
    """
    pass


def Dot(): # reliably restored by inspect
    """ A period (.) leaf """
    pass


def find_binding(name, node, package=None): # reliably restored by inspect
    """
    Returns the node which binds variable name, otherwise None.
            If optional argument package is supplied, only imports will
            be returned.
            See test cases for examples.
    """
    pass


def find_indentation(node): # reliably restored by inspect
    """ Find the indentation of *node*. """
    pass


def find_root(node): # reliably restored by inspect
    """ Find the top level namespace. """
    pass


def FromImport(package_name, name_leafs): # reliably restored by inspect
    """
    Return an import statement in the form:
            from package import name_leafs
    """
    pass


def in_special_context(node): # reliably restored by inspect
    """
    Returns true if node is in an environment where all that is required
            of it is being itterable (ie, it doesn't matter if it returns a list
            or an itterator).
            See test_map_nochange in test_fixers.py for some examples and tests.
    """
    pass


def is_import(node): # reliably restored by inspect
    """ Returns true if the node is an import statement. """
    pass


def is_list(node): # reliably restored by inspect
    """ Does the node represent a list literal? """
    pass


def is_probably_builtin(node): # reliably restored by inspect
    """ Check that something isn't an attribute or function name etc. """
    pass


def is_tuple(node): # reliably restored by inspect
    """ Does the node represent a tuple literal? """
    pass


def KeywordArg(keyword, value): # reliably restored by inspect
    # no doc
    pass


def ListComp(xp, fp, it, test=None): # reliably restored by inspect
    """
    A list comprehension of the form [xp for fp in it if test].
    
        If test is None, the "if test" part is omitted.
    """
    pass


def LParen(): # reliably restored by inspect
    # no doc
    pass


def make_suite(node): # reliably restored by inspect
    # no doc
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


def Newline(): # reliably restored by inspect
    """ A newline literal """
    pass


def Number(n, prefix=None): # reliably restored by inspect
    # no doc
    pass


def parenthesize(node): # reliably restored by inspect
    # no doc
    pass


def RParen(): # reliably restored by inspect
    # no doc
    pass


def String(string, prefix=None): # reliably restored by inspect
    """ A string leaf """
    pass


def Subscript(index_node): # reliably restored by inspect
    """ A numeric or string subscript """
    pass


def touch_import(package, name, node): # reliably restored by inspect
    """
    Works like `does_tree_import` but adds an import statement
            if it was not imported.
    """
    pass


def _find(name, node): # reliably restored by inspect
    # no doc
    pass


def _is_import_binding(node, name, package=None): # reliably restored by inspect
    """
    Will reuturn node if node will import name, or node
            will import * from package.  None is returned otherwise.
            See test cases for examples.
    """
    pass


# classes

class Leaf(__lib2to3_pytree.Base):
    """ Concrete implementation for leaf nodes. """
    def clone(self, *args, **kwargs): # real signature unknown
        """ Return a cloned (deep) copy of self. """
        pass

    def leaves(self, *args, **kwargs): # real signature unknown
        pass

    def post_order(self, *args, **kwargs): # real signature unknown
        """ Return a post-order iterator for the tree. """
        pass

    def pre_order(self, *args, **kwargs): # real signature unknown
        """ Return a pre-order iterator for the tree. """
        pass

    def _eq(self, *args, **kwargs): # real signature unknown
        """ Compare two nodes for equality. """
        pass

    def _prefix_getter(self, *args, **kwargs): # real signature unknown
        """ The whitespace and comments preceding this token in the input. """
        pass

    def _prefix_setter(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.
        
                Takes a type constant (a token number < 256), a string value, and an
                optional context keyword argument.
        """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return a canonical string representation. """
        pass

    def __unicode__(self, *args, **kwargs): # real signature unknown
        """
        Return a pretty string representation.
        
                This reproduces the input source exactly.
        """
        pass

    prefix = property(lambda self: object()) # default

    column = 0
    lineno = 0
    _prefix = ''


class Node(__lib2to3_pytree.Base):
    """ Concrete implementation for interior nodes. """
    def append_child(self, *args, **kwargs): # real signature unknown
        """
        Equivalent to 'node.children.append(child)'. This method also sets the
                child's parent attribute appropriately.
        """
        pass

    def clone(self, *args, **kwargs): # real signature unknown
        """ Return a cloned (deep) copy of self. """
        pass

    def insert_child(self, *args, **kwargs): # real signature unknown
        """
        Equivalent to 'node.children.insert(i, child)'. This method also sets
                the child's parent attribute appropriately.
        """
        pass

    def post_order(self, *args, **kwargs): # real signature unknown
        """ Return a post-order iterator for the tree. """
        pass

    def pre_order(self, *args, **kwargs): # real signature unknown
        """ Return a pre-order iterator for the tree. """
        pass

    def set_child(self, *args, **kwargs): # real signature unknown
        """
        Equivalent to 'node.children[i] = child'. This method also sets the
                child's parent attribute appropriately.
        """
        pass

    def _eq(self, *args, **kwargs): # real signature unknown
        """ Compare two nodes for equality. """
        pass

    def _prefix_getter(self, *args, **kwargs): # real signature unknown
        """ The whitespace and comments preceding this node in the input. """
        pass

    def _prefix_setter(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.
        
                Takes a type constant (a symbol number >= 256), a sequence of
                child nodes, and an optional context keyword argument.
        
                As a side effect, the parent pointers of the children are updated.
        """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return a canonical string representation. """
        pass

    def __unicode__(self, *args, **kwargs): # real signature unknown
        """
        Return a pretty string representation.
        
                This reproduces the input source exactly.
        """
        pass

    prefix = property(lambda self: object()) # default


# variables with complex values

consuming_calls = None # (!) real value is ''

syms = None # (!) real value is ''

_block_syms = None # (!) real value is ''

_def_syms = None # (!) real value is ''

