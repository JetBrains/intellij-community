# encoding: utf-8
# module lib2to3.pgen2.driver
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/driver.pyo by generator 1.99
"""
Parser driver.

This provides a high-level interface to parse a file into a syntax tree.
"""

# imports
import lib2to3.pgen2.parse as parse # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/parse.pyc
import logging as logging # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/logging/__init__.pyc
import lib2to3.pgen2.tokenize as tokenize # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/tokenize.pyc
import sys as sys # <module 'sys' (built-in)>
import lib2to3.pgen2.grammar as grammar # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/grammar.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import lib2to3.pgen2.pgen as pgen # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/pgen.pyc
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/codecs.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

__author__ = 'Guido van Rossum <guido@python.org>'

# functions

def generate_lines(text): # reliably restored by inspect
    """ Generator that behaves like readline without using StringIO. """
    pass


def load_grammar(gt=None, gp=None, save=True, force=False, logger=None): # reliably restored by inspect
    """ Load the grammar (maybe from a pickle). """
    pass


def _newer(a, b): # reliably restored by inspect
    """ Inquire whether file a was written since file b. """
    pass


# classes

class Driver(object):
    # no doc
    def parse_file(self, *args, **kwargs): # real signature unknown
        """ Parse a file and return the syntax tree. """
        pass

    def parse_stream(self, *args, **kwargs): # real signature unknown
        """ Parse a stream and return the syntax tree. """
        pass

    def parse_stream_raw(self, *args, **kwargs): # real signature unknown
        """ Parse a stream and return the syntax tree. """
        pass

    def parse_string(self, *args, **kwargs): # real signature unknown
        """ Parse a string and return the syntax tree. """
        pass

    def parse_tokens(self, *args, **kwargs): # real signature unknown
        """ Parse a series of tokens and return the syntax tree. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

__all__ = [
    'Driver',
    'load_grammar',
]

