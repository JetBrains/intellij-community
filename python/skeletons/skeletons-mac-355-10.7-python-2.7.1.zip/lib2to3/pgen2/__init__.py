# encoding: utf-8
# module lib2to3.pgen2.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/__init__.pyo by generator 1.99
""" The pgen2 package. """
# no imports

# no functions
# no classes
