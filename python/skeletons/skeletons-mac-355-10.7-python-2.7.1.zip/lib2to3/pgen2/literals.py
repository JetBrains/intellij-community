# encoding: utf-8
# module lib2to3.pgen2.literals
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/literals.pyo by generator 1.99
""" Safely evaluate Python string literals without using eval(). """

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc

# functions

def escape(m): # reliably restored by inspect
    # no doc
    pass


def evalString(s): # reliably restored by inspect
    # no doc
    pass


def test(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

simple_escapes = {
    '"': '"',
    "'": "'",
    '\\': '\\',
    'a': '\x07',
    'b': '\x08',
    'f': '\x0c',
    'n': '\n',
    'r': '\r',
    't': '\t',
    'v': '\x0b',
}

