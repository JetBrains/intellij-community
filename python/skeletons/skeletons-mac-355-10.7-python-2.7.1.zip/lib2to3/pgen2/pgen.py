# encoding: utf-8
# module lib2to3.pgen2.pgen
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/pgen.pyo by generator 1.99
# no doc

# imports
import lib2to3.pgen2.grammar as grammar # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/grammar.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import lib2to3.pgen2.tokenize as tokenize # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/tokenize.pyc
import lib2to3.pgen2.grammar as __lib2to3_pgen2_grammar


# functions

def generate_grammar(filename=None): # reliably restored by inspect
    # no doc
    pass


# classes

class DFAState(object):
    # no doc
    def addarc(self, *args, **kwargs): # real signature unknown
        pass

    def unifystate(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''
    __hash__ = None


class NFAState(object):
    # no doc
    def addarc(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class ParserGenerator(object):
    # no doc
    def addfirstsets(self, *args, **kwargs): # real signature unknown
        pass

    def calcfirst(self, *args, **kwargs): # real signature unknown
        pass

    def dump_dfa(self, *args, **kwargs): # real signature unknown
        pass

    def dump_nfa(self, *args, **kwargs): # real signature unknown
        pass

    def expect(self, *args, **kwargs): # real signature unknown
        pass

    def gettoken(self, *args, **kwargs): # real signature unknown
        pass

    def make_dfa(self, *args, **kwargs): # real signature unknown
        pass

    def make_first(self, *args, **kwargs): # real signature unknown
        pass

    def make_grammar(self, *args, **kwargs): # real signature unknown
        pass

    def make_label(self, *args, **kwargs): # real signature unknown
        pass

    def parse(self, *args, **kwargs): # real signature unknown
        pass

    def parse_alt(self, *args, **kwargs): # real signature unknown
        pass

    def parse_atom(self, *args, **kwargs): # real signature unknown
        pass

    def parse_item(self, *args, **kwargs): # real signature unknown
        pass

    def parse_rhs(self, *args, **kwargs): # real signature unknown
        pass

    def raise_error(self, *args, **kwargs): # real signature unknown
        pass

    def simplify_dfa(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class PgenGrammar(__lib2to3_pgen2_grammar.Grammar):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


