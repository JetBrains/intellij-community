# encoding: utf-8
# module lib2to3.pgen2.token
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyo by generator 1.99
""" Token constants (from "token.h"). """
# no imports

# Variables with simple values

AMPER = 19
AMPEREQUAL = 42

AT = 50

BACKQUOTE = 25

CIRCUMFLEX = 33
CIRCUMFLEXEQUAL = 44

COLON = 11
COMMA = 12
COMMENT = 52

DEDENT = 6

DOT = 23
DOUBLESLASH = 48
DOUBLESLASHEQUAL = 49
DOUBLESTAR = 36
DOUBLESTAREQUAL = 47

ENDMARKER = 0

EQEQUAL = 28
EQUAL = 22

ERRORTOKEN = 55

GREATER = 21
GREATEREQUAL = 31

INDENT = 5

LBRACE = 26

LEFTSHIFT = 34
LEFTSHIFTEQUAL = 45
LESS = 20
LESSEQUAL = 30

LPAR = 7

LSQB = 9

MINEQUAL = 38
MINUS = 15

NAME = 1

NEWLINE = 4

NL = 53

NOTEQUAL = 29

NT_OFFSET = 256

NUMBER = 2

N_TOKENS = 56

OP = 51

PERCENT = 24
PERCENTEQUAL = 41

PLUS = 14
PLUSEQUAL = 37

RARROW = 54

RBRACE = 27

RIGHTSHIFT = 35
RIGHTSHIFTEQUAL = 46

RPAR = 8

RSQB = 10

SEMI = 13

SLASH = 17
SLASHEQUAL = 40

STAR = 16
STAREQUAL = 39
STRING = 3

TILDE = 32

VBAR = 18
VBAREQUAL = 43

_name = 'OP'

_value = 51

# functions

def ISEOF(x): # reliably restored by inspect
    # no doc
    pass


def ISNONTERMINAL(x): # reliably restored by inspect
    # no doc
    pass


def ISTERMINAL(x): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

tok_name = {
    0: 'ENDMARKER',
    1: 'NAME',
    2: 'NUMBER',
    3: 'STRING',
    4: 'NEWLINE',
    5: 'INDENT',
    6: 'DEDENT',
    7: 'LPAR',
    8: 'RPAR',
    9: 'LSQB',
    10: 'RSQB',
    11: 'COLON',
    12: 'COMMA',
    13: 'SEMI',
    14: 'PLUS',
    15: 'MINUS',
    16: 'STAR',
    17: 'SLASH',
    18: 'VBAR',
    19: 'AMPER',
    20: 'LESS',
    21: 'GREATER',
    22: 'EQUAL',
    23: 'DOT',
    24: 'PERCENT',
    25: 'BACKQUOTE',
    26: 'LBRACE',
    27: 'RBRACE',
    28: 'EQEQUAL',
    29: 'NOTEQUAL',
    30: 'LESSEQUAL',
    31: 'GREATEREQUAL',
    32: 'TILDE',
    33: 'CIRCUMFLEX',
    34: 'LEFTSHIFT',
    35: 'RIGHTSHIFT',
    36: 'DOUBLESTAR',
    37: 'PLUSEQUAL',
    38: 'MINEQUAL',
    39: 'STAREQUAL',
    40: 'SLASHEQUAL',
    41: 'PERCENTEQUAL',
    42: 'AMPEREQUAL',
    43: 'VBAREQUAL',
    44: 'CIRCUMFLEXEQUAL',
    45: 'LEFTSHIFTEQUAL',
    46: 'RIGHTSHIFTEQUAL',
    47: 'DOUBLESTAREQUAL',
    48: 'DOUBLESLASH',
    49: 'DOUBLESLASHEQUAL',
    50: 'AT',
    51: 'OP',
    52: 'COMMENT',
    53: 'NL',
    54: 'RARROW',
    55: 'ERRORTOKEN',
    56: 'N_TOKENS',
    256: 'NT_OFFSET',
}

