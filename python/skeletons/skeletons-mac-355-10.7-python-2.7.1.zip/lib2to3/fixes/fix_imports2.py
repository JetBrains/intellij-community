# encoding: utf-8
# module lib2to3.fixes.fix_imports2
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_imports2.pyo by generator 1.99
"""
Fix incompatible imports and module references that must be fixed after
fix_imports.
"""

# imports
import lib2to3.fixes.fix_imports as fix_imports # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_imports.pyc
import lib2to3.fixes.fix_imports as __lib2to3_fixes_fix_imports


# no functions
# classes

class FixImports2(__lib2to3_fixes_fix_imports.FixImports):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    mapping = {
        'anydbm': 'dbm',
        'whichdb': 'dbm',
    }
    run_order = 7


# variables with complex values

MAPPING = {
    'anydbm': 'dbm',
    'whichdb': 'dbm',
}

