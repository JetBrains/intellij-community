# encoding: utf-8
# module lib2to3.fixes.fix_callable
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_callable.pyo by generator 1.99
"""
Fixer for callable().

This converts callable(obj) into isinstance(obj, collections.Callable), adding a
collections import if needed.
"""

# imports
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def Attr(obj, attr): # reliably restored by inspect
    """ A node tuple for obj.attr """
    pass


def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


def String(string, prefix=None): # reliably restored by inspect
    """ A string leaf """
    pass


def touch_import(package, name, node): # reliably restored by inspect
    """
    Works like `does_tree_import` but adds an import statement
            if it was not imported.
    """
    pass


# classes

class FixCallable(__lib2to3_fixer_base.BaseFix):
    # no doc
    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    order = 'pre'
    PATTERN = "\n    power< 'callable'\n           trailer< lpar='('\n                    ( not(arglist | argument<any '=' any>) func=any\n                      | func=arglist<(not argument<any '=' any>) any ','> )\n                    rpar=')' >\n           after=any*\n    >\n    "


