# encoding: utf-8
# module lib2to3.fixes.fix_next
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_next.pyo by generator 1.99
""" Fixer for it.next() -> next(it), per PEP 3114. """

# imports
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# Variables with simple values

bind_warning = 'Calls to builtin next() possibly shadowed by global binding'

# functions

def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def find_assign(node): # reliably restored by inspect
    # no doc
    pass


def find_binding(name, node, package=None): # reliably restored by inspect
    """
    Returns the node which binds variable name, otherwise None.
            If optional argument package is supplied, only imports will
            be returned.
            See test cases for examples.
    """
    pass


def is_assign_target(node): # reliably restored by inspect
    # no doc
    pass


def is_subtree(root, node): # reliably restored by inspect
    # no doc
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


# classes

class FixNext(__lib2to3_fixer_base.BaseFix):
    # no doc
    def start_tree(self, *args, **kwargs): # real signature unknown
        pass

    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    order = 'pre'
    PATTERN = "\n    power< base=any+ trailer< '.' attr='next' > trailer< '(' ')' > >\n    |\n    power< head=any+ trailer< '.' attr='next' > not trailer< '(' ')' > >\n    |\n    classdef< 'class' any+ ':'\n              suite< any*\n                     funcdef< 'def'\n                              name='next'\n                              parameters< '(' NAME ')' > any+ >\n                     any* > >\n    |\n    global=global_stmt< 'global' any* 'next' any* >\n    "


# variables with complex values

syms = None # (!) real value is ''

