# encoding: utf-8
# module lib2to3.fixes.fix_imports
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_imports.pyo by generator 1.99
""" Fix incompatible imports and module references. """

# imports
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def alternates(members): # reliably restored by inspect
    # no doc
    pass


def attr_chain(obj, attr): # reliably restored by inspect
    """
    Follow an attribute chain.
    
        If you have a chain of objects where a.foo -> b, b.foo-> c, etc,
        use this to iterate over all objects in the chain. Iteration is
        terminated by getattr(x, attr) is None.
    
        Args:
            obj: the starting object
            attr: the name of the chaining attribute
    
        Yields:
            Each successive object in the chain.
    """
    pass


def build_pattern(mapping="{'dbm': 'dbm.ndbm', 'tkFileDialog': 'tkinter.filedialog', '__builtin__': 'builtins', 'ttk': 'tkinter.ttk', 'dummy_thread': '_dummy_thread', 'tkSimpleDialog': 'tkinter.simpledialog', 'FileDialog': 'tkinter.filedialog', 'Tix': 'tkinter.tix', 'gdbm': 'dbm.gnu', 'robotparser': 'urllib.robotparser', 'CGIHTTPServer': 'http.server', 'Cookie': 'http.cookies', 'cPickle': 'pickle', 'SocketServer': 'socketserver', 'repr': 'reprlib', 'Dialog': 'tkinter.dialog', 'ScrolledText': 'tkinter.scrolledtext', 'cookielib': 'http.cookiejar', 'ConfigParser': 'configparser', 'httplib': 'http.client', 'markupbase': '_markupbase', 'tkMessageBox': 'tkinter.messagebox', '_winreg': 'winreg', 'DocXMLRPCServer': 'xmlrpc.server', 'cStringIO': 'io', 'copy_reg': 'copyreg', 'Tkdnd': 'tkinter.dnd', 'SimpleHTTPServer': 'http.server', 'SimpleDialog': 'tkinter.simpledialog', 'HTMLParser': 'html.parser', 'BaseHTTPServer': 'http.server', 'tkCommonDialog': 'tkinter.commondialog', 'dumbdbm': 'dbm.dumb', 'UserList': 'collections', 'UserString': 'collections', 'Tkinter': 'tkinter', 'tkFont': 'tkinter.font', 'htmlentitydefs': 'html.entities', 'SimpleXMLRPCServer': 'xmlrpc.server', 'Queue': 'queue', 'tkColorChooser': 'tkinter.colorchooser', 'commands': 'subprocess', 'thread': '_thread', 'StringIO': 'io', 'xmlrpclib': 'xmlrpc.client', 'Tkconstants': 'tkinter.constants', 'urlparse': 'urllib.parse', 'dbhash': 'dbm.bsd'}"): # reliably restored by inspect
    # no doc
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


# classes

class FixImports(__lib2to3_fixer_base.BaseFix):
    # no doc
    def build_pattern(self, *args, **kwargs): # real signature unknown
        pass

    def compile_pattern(self, *args, **kwargs): # real signature unknown
        pass

    def match(self, *args, **kwargs): # real signature unknown
        pass

    def start_tree(self, *args, **kwargs): # real signature unknown
        pass

    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    keep_line_order = True
    mapping = {
        'BaseHTTPServer': 'http.server',
        'CGIHTTPServer': 'http.server',
        'ConfigParser': 'configparser',
        'Cookie': 'http.cookies',
        'Dialog': 'tkinter.dialog',
        'DocXMLRPCServer': 'xmlrpc.server',
        'FileDialog': 'tkinter.filedialog',
        'HTMLParser': 'html.parser',
        'Queue': 'queue',
        'ScrolledText': 'tkinter.scrolledtext',
        'SimpleDialog': 'tkinter.simpledialog',
        'SimpleHTTPServer': 'http.server',
        'SimpleXMLRPCServer': 'xmlrpc.server',
        'SocketServer': 'socketserver',
        'StringIO': 'io',
        'Tix': 'tkinter.tix',
        'Tkconstants': 'tkinter.constants',
        'Tkdnd': 'tkinter.dnd',
        'Tkinter': 'tkinter',
        'UserList': 'collections',
        'UserString': 'collections',
        '__builtin__': 'builtins',
        '_winreg': 'winreg',
        'cPickle': 'pickle',
        'cStringIO': 'io',
        'commands': 'subprocess',
        'cookielib': 'http.cookiejar',
        'copy_reg': 'copyreg',
        'dbhash': 'dbm.bsd',
        'dbm': 'dbm.ndbm',
        'dumbdbm': 'dbm.dumb',
        'dummy_thread': '_dummy_thread',
        'gdbm': 'dbm.gnu',
        'htmlentitydefs': 'html.entities',
        'httplib': 'http.client',
        'markupbase': '_markupbase',
        'repr': 'reprlib',
        'robotparser': 'urllib.robotparser',
        'thread': '_thread',
        'tkColorChooser': 'tkinter.colorchooser',
        'tkCommonDialog': 'tkinter.commondialog',
        'tkFileDialog': 'tkinter.filedialog',
        'tkFont': 'tkinter.font',
        'tkMessageBox': 'tkinter.messagebox',
        'tkSimpleDialog': 'tkinter.simpledialog',
        'ttk': 'tkinter.ttk',
        'urlparse': 'urllib.parse',
        'xmlrpclib': 'xmlrpc.client',
    }
    run_order = 6


# variables with complex values

MAPPING = {
    'BaseHTTPServer': 'http.server',
    'CGIHTTPServer': 'http.server',
    'ConfigParser': 'configparser',
    'Cookie': 'http.cookies',
    'Dialog': 'tkinter.dialog',
    'DocXMLRPCServer': 'xmlrpc.server',
    'FileDialog': 'tkinter.filedialog',
    'HTMLParser': 'html.parser',
    'Queue': 'queue',
    'ScrolledText': 'tkinter.scrolledtext',
    'SimpleDialog': 'tkinter.simpledialog',
    'SimpleHTTPServer': 'http.server',
    'SimpleXMLRPCServer': 'xmlrpc.server',
    'SocketServer': 'socketserver',
    'StringIO': 'io',
    'Tix': 'tkinter.tix',
    'Tkconstants': 'tkinter.constants',
    'Tkdnd': 'tkinter.dnd',
    'Tkinter': 'tkinter',
    'UserList': 'collections',
    'UserString': 'collections',
    '__builtin__': 'builtins',
    '_winreg': 'winreg',
    'cPickle': 'pickle',
    'cStringIO': 'io',
    'commands': 'subprocess',
    'cookielib': 'http.cookiejar',
    'copy_reg': 'copyreg',
    'dbhash': 'dbm.bsd',
    'dbm': 'dbm.ndbm',
    'dumbdbm': 'dbm.dumb',
    'dummy_thread': '_dummy_thread',
    'gdbm': 'dbm.gnu',
    'htmlentitydefs': 'html.entities',
    'httplib': 'http.client',
    'markupbase': '_markupbase',
    'repr': 'reprlib',
    'robotparser': 'urllib.robotparser',
    'thread': '_thread',
    'tkColorChooser': 'tkinter.colorchooser',
    'tkCommonDialog': 'tkinter.commondialog',
    'tkFileDialog': 'tkinter.filedialog',
    'tkFont': 'tkinter.font',
    'tkMessageBox': 'tkinter.messagebox',
    'tkSimpleDialog': 'tkinter.simpledialog',
    'ttk': 'tkinter.ttk',
    'urlparse': 'urllib.parse',
    'xmlrpclib': 'xmlrpc.client',
}

