# encoding: utf-8
# module lib2to3.fixes.fix_xrange
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_xrange.pyo by generator 1.99
""" Fixer that changes xrange(...) into range(...). """

# imports
import lib2to3.patcomp as patcomp # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/patcomp.pyc
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


# classes

class FixXrange(__lib2to3_fixer_base.BaseFix):
    # no doc
    def finish_tree(self, *args, **kwargs): # real signature unknown
        pass

    def in_special_context(self, *args, **kwargs): # real signature unknown
        pass

    def start_tree(self, *args, **kwargs): # real signature unknown
        pass

    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def transform_range(self, *args, **kwargs): # real signature unknown
        pass

    def transform_xrange(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    P1 = "power< func=NAME trailer< '(' node=any ')' > any* >"
    p1 = None # (!) real value is ''
    P2 = "for_stmt< 'for' any 'in' node=any ':' any* >\n            | comp_for< 'for' any 'in' node=any any* >\n            | comparison< any 'in' node=any any*>\n         "
    p2 = None # (!) real value is ''
    PATTERN = "\n              power<\n                 (name='range'|name='xrange') trailer< '(' args=any ')' >\n              rest=any* >\n              "


# variables with complex values

consuming_calls = None # (!) real value is ''

