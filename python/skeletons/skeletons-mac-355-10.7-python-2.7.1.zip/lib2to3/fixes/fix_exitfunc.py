# encoding: utf-8
# module lib2to3.fixes.fix_exitfunc
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_exitfunc.pyo by generator 1.99
""" Convert use of sys.exitfunc to use the atexit module. """

# imports
import lib2to3.pytree as pytree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pytree.pyc
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def Attr(obj, attr): # reliably restored by inspect
    """ A node tuple for obj.attr """
    pass


def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def Comma(): # reliably restored by inspect
    """ A comma leaf """
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


def Newline(): # reliably restored by inspect
    """ A newline literal """
    pass


# classes

class FixExitfunc(__lib2to3_fixer_base.BaseFix):
    # no doc
    def start_tree(self, *args, **kwargs): # real signature unknown
        pass

    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    BM_compatible = True
    keep_line_order = True
    PATTERN = "\n              (\n                  sys_import=import_name<'import'\n                      ('sys'\n                      |\n                      dotted_as_names< (any ',')* 'sys' (',' any)* >\n                      )\n                  >\n              |\n                  expr_stmt<\n                      power< 'sys' trailer< '.' 'exitfunc' > >\n                  '=' func=any >\n              )\n              "


# variables with complex values

syms = None # (!) real value is ''

