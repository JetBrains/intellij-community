# encoding: utf-8
# module lib2to3.fixes.fix_sys_exc
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_sys_exc.pyo by generator 1.99
"""
Fixer for sys.exc_{type, value, traceback}

sys.exc_type -> sys.exc_info()[0]
sys.exc_value -> sys.exc_info()[1]
sys.exc_traceback -> sys.exc_info()[2]
"""

# imports
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base
import lib2to3.pytree as __lib2to3_pytree


# functions

def Attr(obj, attr): # reliably restored by inspect
    """ A node tuple for obj.attr """
    pass


def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


def Number(n, prefix=None): # reliably restored by inspect
    # no doc
    pass


def Subscript(index_node): # reliably restored by inspect
    """ A numeric or string subscript """
    pass


# classes

class FixSysExc(__lib2to3_fixer_base.BaseFix):
    # no doc
    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    exc_info = [
        u'exc_type',
        u'exc_value',
        u'exc_traceback',
    ]
    PATTERN = u"\n              power< 'sys' trailer< dot='.' attribute=('exc_type'|'exc_value'|'exc_traceback') > >\n              "


class Node(__lib2to3_pytree.Base):
    """ Concrete implementation for interior nodes. """
    def append_child(self, *args, **kwargs): # real signature unknown
        """
        Equivalent to 'node.children.append(child)'. This method also sets the
                child's parent attribute appropriately.
        """
        pass

    def clone(self, *args, **kwargs): # real signature unknown
        """ Return a cloned (deep) copy of self. """
        pass

    def insert_child(self, *args, **kwargs): # real signature unknown
        """
        Equivalent to 'node.children.insert(i, child)'. This method also sets
                the child's parent attribute appropriately.
        """
        pass

    def post_order(self, *args, **kwargs): # real signature unknown
        """ Return a post-order iterator for the tree. """
        pass

    def pre_order(self, *args, **kwargs): # real signature unknown
        """ Return a pre-order iterator for the tree. """
        pass

    def set_child(self, *args, **kwargs): # real signature unknown
        """
        Equivalent to 'node.children[i] = child'. This method also sets the
                child's parent attribute appropriately.
        """
        pass

    def _eq(self, *args, **kwargs): # real signature unknown
        """ Compare two nodes for equality. """
        pass

    def _prefix_getter(self, *args, **kwargs): # real signature unknown
        """ The whitespace and comments preceding this node in the input. """
        pass

    def _prefix_setter(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.
        
                Takes a type constant (a symbol number >= 256), a sequence of
                child nodes, and an optional context keyword argument.
        
                As a side effect, the parent pointers of the children are updated.
        """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        """ Return a canonical string representation. """
        pass

    def __unicode__(self, *args, **kwargs): # real signature unknown
        """
        Return a pretty string representation.
        
                This reproduces the input source exactly.
        """
        pass

    prefix = property(lambda self: object()) # default


# variables with complex values

syms = None # (!) real value is ''

