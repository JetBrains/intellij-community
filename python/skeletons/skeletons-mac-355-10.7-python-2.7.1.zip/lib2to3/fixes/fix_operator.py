# encoding: utf-8
# module lib2to3.fixes.fix_operator
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_operator.pyo by generator 1.99
"""
Fixer for operator functions.

operator.isCallable(obj)       -> hasattr(obj, '__call__')
operator.sequenceIncludes(obj) -> operator.contains(obj)
operator.isSequenceType(obj)   -> isinstance(obj, collections.Sequence)
operator.isMappingType(obj)    -> isinstance(obj, collections.Mapping)
operator.isNumberType(obj)     -> isinstance(obj, numbers.Number)
operator.repeat(obj, n)        -> operator.mul(obj, n)
operator.irepeat(obj, n)       -> operator.imul(obj, n)
"""

# imports
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def Call(func_name, args=None, prefix=None): # reliably restored by inspect
    """ A function call """
    pass


def invocation(s): # reliably restored by inspect
    # no doc
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


def String(string, prefix=None): # reliably restored by inspect
    """ A string leaf """
    pass


def touch_import(package, name, node): # reliably restored by inspect
    """
    Works like `does_tree_import` but adds an import statement
            if it was not imported.
    """
    pass


# classes

class FixOperator(__lib2to3_fixer_base.BaseFix):
    # no doc
    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def _check_method(self, *args, **kwargs): # real signature unknown
        pass

    def _handle_rename(self, *args, **kwargs): # real signature unknown
        pass

    def _handle_type2abc(self, *args, **kwargs): # real signature unknown
        pass

    def _irepeat(self, *args, **kwargs): # real signature unknown
        pass

    def _isCallable(self, *args, **kwargs): # real signature unknown
        pass

    def _isMappingType(self, *args, **kwargs): # real signature unknown
        pass

    def _isNumberType(self, *args, **kwargs): # real signature unknown
        pass

    def _isSequenceType(self, *args, **kwargs): # real signature unknown
        pass

    def _repeat(self, *args, **kwargs): # real signature unknown
        pass

    def _sequenceIncludes(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    methods = "\n              method=('isCallable'|'sequenceIncludes'\n                     |'isSequenceType'|'isMappingType'|'isNumberType'\n                     |'repeat'|'irepeat')\n              "
    obj = "'(' obj=any ')'"
    order = 'pre'
    PATTERN = "\n              power< module='operator'\n                trailer< '.' \n              method=('isCallable'|'sequenceIncludes'\n                     |'isSequenceType'|'isMappingType'|'isNumberType'\n                     |'repeat'|'irepeat')\n               > trailer< '(' obj=any ')' > >\n              |\n              power< \n              method=('isCallable'|'sequenceIncludes'\n                     |'isSequenceType'|'isMappingType'|'isNumberType'\n                     |'repeat'|'irepeat')\n               trailer< '(' obj=any ')' > >\n              "


