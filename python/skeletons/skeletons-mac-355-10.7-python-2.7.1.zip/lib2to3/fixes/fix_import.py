# encoding: utf-8
# module lib2to3.fixes.fix_import
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_import.pyo by generator 1.99
"""
Fixer for import statements.
If spam is being imported from the local directory, this import:
    from spam import eggs
Becomes:
    from .spam import eggs

And this import:
    import spam
Becomes:
    from . import spam
"""

# imports
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# Variables with simple values

sep = '/'

# functions

def dirname(p): # reliably restored by inspect
    """ Returns the directory component of a pathname """
    pass


def exists(path): # reliably restored by inspect
    """ Test whether a path exists.  Returns False for broken symbolic links """
    pass


def FromImport(package_name, name_leafs): # reliably restored by inspect
    """
    Return an import statement in the form:
            from package import name_leafs
    """
    pass


def join(a, *p): # reliably restored by inspect
    """
    Join two or more pathname components, inserting '/' as needed.
        If any component is an absolute path, all previous path components
        will be discarded.
    """
    pass


def traverse_imports(names): # reliably restored by inspect
    """ Walks over all the names imported in a dotted_as_names node. """
    pass


# classes

class FixImport(__lib2to3_fixer_base.BaseFix):
    # no doc
    def probably_a_local_import(self, *args, **kwargs): # real signature unknown
        pass

    def start_tree(self, *args, **kwargs): # real signature unknown
        pass

    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    PATTERN = "\n    import_from< 'from' imp=any 'import' ['('] any [')'] >\n    |\n    import_name< 'import' imp=any >\n    "


# variables with complex values

syms = None # (!) real value is ''

