# encoding: utf-8
# module lib2to3.fixes.fix_tuple_params
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_tuple_params.pyo by generator 1.99
"""
Fixer for function definitions with tuple parameters.

def func(((a, b), c), d):
    ...

    ->

def func(x, d):
    ((a, b), c) = x
    ...

It will also support lambdas:

    lambda (x, y): x + y -> lambda t: t[0] + t[1]

    # The parens are a syntax error in Python 3
    lambda (x): x + y -> lambda x: x + y
"""

# imports
import lib2to3.pytree as pytree # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pytree.pyc
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.pgen2.token as token # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/pgen2/token.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def Assign(target, source): # reliably restored by inspect
    """ Build an assignment statement """
    pass


def find_params(node): # reliably restored by inspect
    # no doc
    pass


def is_docstring(stmt): # reliably restored by inspect
    # no doc
    pass


def map_to_index(param_list, prefix='[]', d=None): # reliably restored by inspect
    # no doc
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


def Newline(): # reliably restored by inspect
    """ A newline literal """
    pass


def Number(n, prefix=None): # reliably restored by inspect
    # no doc
    pass


def simplify_args(node): # reliably restored by inspect
    # no doc
    pass


def Subscript(index_node): # reliably restored by inspect
    """ A numeric or string subscript """
    pass


def tuple_name(param_list): # reliably restored by inspect
    # no doc
    pass


# classes

class FixTupleParams(__lib2to3_fixer_base.BaseFix):
    # no doc
    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def transform_lambda(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    PATTERN = "\n              funcdef< 'def' any parameters< '(' args=any ')' >\n                       ['->' any] ':' suite=any+ >\n              |\n              lambda=\n              lambdef< 'lambda' args=vfpdef< '(' inner=any ')' >\n                       ':' body=any\n              >\n              "
    run_order = 4


# variables with complex values

syms = None # (!) real value is ''

