# encoding: utf-8
# module lib2to3.fixes.fix_renames
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixes/fix_renames.pyo by generator 1.99
"""
Fix incompatible renames

Fixes:
  * sys.maxint -> sys.maxsize
"""

# imports
import lib2to3.fixer_base as fixer_base # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib2to3/fixer_base.pyc
import lib2to3.fixer_base as __lib2to3_fixer_base


# functions

def alternates(members): # reliably restored by inspect
    # no doc
    pass


def attr_chain(obj, attr): # reliably restored by inspect
    """
    Follow an attribute chain.
    
        If you have a chain of objects where a.foo -> b, b.foo-> c, etc,
        use this to iterate over all objects in the chain. Iteration is
        terminated by getattr(x, attr) is None.
    
        Args:
            obj: the starting object
            attr: the name of the chaining attribute
    
        Yields:
            Each successive object in the chain.
    """
    pass


def build_pattern(): # reliably restored by inspect
    # no doc
    pass


def Name(name, prefix=None): # reliably restored by inspect
    """ Return a NAME leaf """
    pass


# classes

class FixRenames(__lib2to3_fixer_base.BaseFix):
    # no doc
    def match(self, *args, **kwargs): # real signature unknown
        pass

    def transform(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Initializer.  Subclass may override.
        
                Args:
                    options: an dict containing the options passed to RefactoringTool
                    that could be used to customize the fixer through the command line.
                    log: a list to append warnings and other messages to.
        """
        pass

    BM_compatible = True
    order = 'pre'
    PATTERN = "\n                  import_from< 'from' module_name='sys' 'import'\n                      ( attr_name='maxint' | import_as_name< attr_name='maxint' 'as' any >) >\n                  |\n                  power< module_name='sys' trailer< '.' attr_name='maxint' > any* >\n                  "


# variables with complex values

LOOKUP = {
    (
        'sys',
        'maxint',
    ): 
        'maxsize'
    ,
}

MAPPING = {
    'sys': {
        'maxint': 'maxsize',
    },
}

