# encoding: utf-8
# module multiprocessing.managers
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/managers.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import array as array # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/array.so
import multiprocessing.util as util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/util.pyc
import Queue as Queue # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/Queue.pyc
import weakref as weakref # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/weakref.pyc
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/threading.pyc
import multiprocessing.connection as connection # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/connection.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from cPickle import PicklingError

from posix import exit


# Variables with simple values

name = 'values'

# functions

def active_children(): # reliably restored by inspect
    """ Return list of process objects corresponding to live child processes """
    pass


def all_methods(obj): # reliably restored by inspect
    """ Return a list of names of methods of `obj` """
    pass


def Array(typecode, sequence, lock=True): # reliably restored by inspect
    # no doc
    pass


def assert_spawning(self): # reliably restored by inspect
    # no doc
    pass


def AutoProxy(token, serializer, manager=None, authkey=None, exposed=None, incref=True): # reliably restored by inspect
    """ Return an auto-proxy for `token` """
    pass


def convert_to_error(kind, result): # reliably restored by inspect
    # no doc
    pass


def current_process(): # reliably restored by inspect
    """ Return process object representing the current process """
    pass


def dispatch(c, id, methodname, args='()', kwds='{}'): # reliably restored by inspect
    """ Send a message to manager using connection `c` and return response """
    pass


def format_exc(limit=None): # reliably restored by inspect
    """ Like print_exc() but return a string. """
    pass


def info(msg, *args): # reliably restored by inspect
    # no doc
    pass


def MakeProxyType(name, exposed, _cache="{('ArrayProxy', ('__len__', '__getitem__', '__setitem__', '__getslice__', '__setslice__')): <class 'multiprocessing.managers.ArrayProxy'>, ('DictProxy', ('__contains__', '__delitem__', '__getitem__', '__len__', '__setitem__', 'clear', 'copy', 'get', 'has_key', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values')): <class 'multiprocessing.managers.DictProxy'>, ('BaseListProxy', ('__add__', '__contains__', '__delitem__', '__delslice__', '__getitem__', '__getslice__', '__len__', '__mul__', '__reversed__', '__rmul__', '__setitem__', '__setslice__', 'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort', '__imul__')): <class 'multiprocessing.managers.BaseListProxy'>, ('PoolProxy', ('apply', 'apply_async', 'close', 'imap', 'imap_unordered', 'join', 'map', 'map_async', 'terminate')): <class 'multiprocessing.managers.PoolProxy'>}"): # reliably restored by inspect
    """ Return an proxy type whose methods are given by `exposed` """
    pass


def Pool(processes=None, initializer=None, initargs='()', maxtasksperchild=None): # reliably restored by inspect
    """ Returns a process pool object """
    pass


def public_methods(obj): # reliably restored by inspect
    """ Return a list of names of methods of `obj` which do not start with '_' """
    pass


def RebuildProxy(func, token, serializer, kwds): # reliably restored by inspect
    """
    Function used for unpickling proxy objects.
    
        If possible the shared object is returned, or otherwise a proxy for it.
    """
    pass


def reduce_array(a): # reliably restored by inspect
    # no doc
    pass


# classes

class BaseProxy(object):
    """ A base for proxies of shared objects """
    def _after_fork(self, *args, **kwargs): # real signature unknown
        pass

    def _callmethod(self, *args, **kwargs): # real signature unknown
        """ Try to call a method of the referrent and return a copy of the result """
        pass

    def _connect(self, *args, **kwargs): # real signature unknown
        pass

    def _decref(token, authkey, state, tls, idset, _Client): # reliably restored by inspect
        # no doc
        pass

    def _getvalue(self, *args, **kwargs): # real signature unknown
        """ Get a copy of the value of the referent """
        pass

    def _incref(self, *args, **kwargs): # real signature unknown
        pass

    def __deepcopy__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        """ Return representation of the referent (or a fall-back if that fails) """
        pass

    __weakref__ = property(lambda self: object()) # default

    _address_to_local = {}
    _mutex = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class AcquirerProxy(BaseProxy):
    # no doc
    def acquire(self, *args, **kwargs): # real signature unknown
        pass

    def release(self, *args, **kwargs): # real signature unknown
        pass

    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        'acquire',
        'release',
    )


class ArrayProxy(BaseProxy):
    # no doc
    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getslice__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __setslice__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        '__len__',
        '__getitem__',
        '__setitem__',
        '__getslice__',
        '__setslice__',
    )
    __builtins__ = Queue.__builtins__


class AuthenticationString(str):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is ''


class BaseListProxy(BaseProxy):
    # no doc
    def append(self, *args, **kwargs): # real signature unknown
        pass

    def count(self, *args, **kwargs): # real signature unknown
        pass

    def extend(self, *args, **kwargs): # real signature unknown
        pass

    def index(self, *args, **kwargs): # real signature unknown
        pass

    def insert(self, *args, **kwargs): # real signature unknown
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        pass

    def remove(self, *args, **kwargs): # real signature unknown
        pass

    def reverse(self, *args, **kwargs): # real signature unknown
        pass

    def sort(self, *args, **kwargs): # real signature unknown
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __delslice__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getslice__(self, *args, **kwargs): # real signature unknown
        pass

    def __imul__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        pass

    def __reversed__(self, *args, **kwargs): # real signature unknown
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __setslice__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        '__add__',
        '__contains__',
        '__delitem__',
        '__delslice__',
        '__getitem__',
        '__getslice__',
        '__len__',
        '__mul__',
        '__reversed__',
        '__rmul__',
        '__setitem__',
        '__setslice__',
        'append',
        'count',
        'extend',
        'index',
        'insert',
        'pop',
        'remove',
        'reverse',
        'sort',
        '__imul__',
    )
    __builtins__ = Queue.__builtins__


class BaseManager(object):
    """ Base class for managers """
    def connect(self, *args, **kwargs): # real signature unknown
        """ Connect manager object to the server process """
        pass

    def get_server(self, *args, **kwargs): # real signature unknown
        """ Return server object with serve_forever() method and address attribute """
        pass

    def join(self, *args, **kwargs): # real signature unknown
        """ Join the manager process (if it has been spawned) """
        pass

    @classmethod
    def register(cls, *args, **kwargs): # real signature unknown
        """ Register a typeid with the manager type """
        pass

    def start(self, *args, **kwargs): # real signature unknown
        """ Spawn a server process for this manager object """
        pass

    def _create(self, *args, **kwargs): # real signature unknown
        """ Create a new shared object; return the token and exposed tuple """
        pass

    def _debug_info(self, *args, **kwargs): # real signature unknown
        """ Return some info about the servers shared objects and connections """
        pass

    def _finalize_manager(process, address, authkey, state, _Client): # reliably restored by inspect
        """ Shutdown the manager process; will be registered as a finalizer """
        pass

    def _number_of_objects(self, *args, **kwargs): # real signature unknown
        """ Return the number of shared objects """
        pass

    @classmethod
    def _run_server(cls, *args, **kwargs): # real signature unknown
        """ Create a server, report its address and run it """
        pass

    def _Server(self, *args, **kwargs): # real signature unknown
        """ Server class which runs in a process controlled by a manager object """
        pass

    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    address = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    _registry = {}
    __dict__ = None # (!) real value is ''


class ConditionProxy(AcquirerProxy):
    # no doc
    def notify(self, *args, **kwargs): # real signature unknown
        pass

    def notify_all(self, *args, **kwargs): # real signature unknown
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        'acquire',
        'release',
        'wait',
        'notify',
        'notify_all',
    )


class DictProxy(BaseProxy):
    # no doc
    def clear(self, *args, **kwargs): # real signature unknown
        pass

    def copy(self, *args, **kwargs): # real signature unknown
        pass

    def get(self, *args, **kwargs): # real signature unknown
        pass

    def has_key(self, *args, **kwargs): # real signature unknown
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        pass

    def popitem(self, *args, **kwargs): # real signature unknown
        pass

    def setdefault(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        '__contains__',
        '__delitem__',
        '__getitem__',
        '__len__',
        '__setitem__',
        'clear',
        'copy',
        'get',
        'has_key',
        'items',
        'keys',
        'pop',
        'popitem',
        'setdefault',
        'update',
        'values',
    )
    __builtins__ = Queue.__builtins__


class EventProxy(BaseProxy):
    # no doc
    def clear(self, *args, **kwargs): # real signature unknown
        pass

    def is_set(self, *args, **kwargs): # real signature unknown
        pass

    def set(self, *args, **kwargs): # real signature unknown
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        'is_set',
        'set',
        'clear',
        'wait',
    )


class Finalize(object):
    """ Class which supports object finalization using weakrefs """
    def cancel(self, *args, **kwargs): # real signature unknown
        """ Cancel finalization of the object """
        pass

    def still_active(self, *args, **kwargs): # real signature unknown
        """ Return whether this finalizer is still waiting to invoke callback """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Run the callback unless it has already been called or cancelled """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class IteratorProxy(BaseProxy):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def next(self, *args, **kwargs): # real signature unknown
        pass

    def send(self, *args, **kwargs): # real signature unknown
        pass

    def throw(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        '__next__',
        'next',
        'send',
        'throw',
        'close',
    )


class ListProxy(BaseListProxy):
    # no doc
    def __iadd__(self, *args, **kwargs): # real signature unknown
        pass

    def __imul__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Namespace(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class NamespaceProxy(BaseProxy):
    # no doc
    def __delattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __getattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setattr__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        '__getattribute__',
        '__setattr__',
        '__delattr__',
    )


class PoolProxy(BaseProxy):
    # no doc
    def apply(self, *args, **kwargs): # real signature unknown
        pass

    def apply_async(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def imap(self, *args, **kwargs): # real signature unknown
        pass

    def imap_unordered(self, *args, **kwargs): # real signature unknown
        pass

    def join(self, *args, **kwargs): # real signature unknown
        pass

    def map(self, *args, **kwargs): # real signature unknown
        pass

    def map_async(self, *args, **kwargs): # real signature unknown
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _exposed_ = (
        'apply',
        'apply_async',
        'close',
        'imap',
        'imap_unordered',
        'join',
        'map',
        'map_async',
        'terminate',
    )
    _method_to_typeid_ = {
        'apply_async': 'AsyncResult',
        'imap': 'Iterator',
        'imap_unordered': 'Iterator',
        'map_async': 'AsyncResult',
    }
    __builtins__ = Queue.__builtins__


class Popen(object):
    # no doc
    def poll(self, *args, **kwargs): # real signature unknown
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        pass

    def thread_is_spawning(): # reliably restored by inspect
        # no doc
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Process(object):
    """
    Process objects represent activity that is run in a separate process
    
        The class is analagous to `threading.Thread`
    """
    def is_alive(self, *args, **kwargs): # real signature unknown
        """ Return whether process is alive """
        pass

    def join(self, *args, **kwargs): # real signature unknown
        """ Wait until child process terminates """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        """ Method to be run in sub-process; can be overridden in sub-class """
        pass

    def start(self, *args, **kwargs): # real signature unknown
        """ Start child process """
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        """ Terminate process; sends SIGTERM signal or uses TerminateProcess() """
        pass

    def _bootstrap(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    authkey = property(lambda self: object()) # default
    daemon = property(lambda self: object()) # default
    exitcode = property(lambda self: object()) # default
    ident = property(lambda self: object()) # default
    name = property(lambda self: object()) # default
    pid = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    _Popen = None
    __dict__ = None # (!) real value is ''


class ProcessLocalSet(set):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is ''


class RemoteError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class Server(object):
    """ Server class which runs in a process controlled by a manager object """
    def accept_connection(self, *args, **kwargs): # real signature unknown
        """ Spawn a new thread to serve this connection """
        pass

    def create(self, *args, **kwargs): # real signature unknown
        """ Create a new shared object and return its id """
        pass

    def debug_info(self, *args, **kwargs): # real signature unknown
        """ Return some info --- useful to spot problems with refcounting """
        pass

    def decref(self, *args, **kwargs): # real signature unknown
        pass

    def dummy(self, *args, **kwargs): # real signature unknown
        pass

    def fallback_getvalue(self, *args, **kwargs): # real signature unknown
        pass

    def fallback_repr(self, *args, **kwargs): # real signature unknown
        pass

    def fallback_str(self, *args, **kwargs): # real signature unknown
        pass

    def get_methods(self, *args, **kwargs): # real signature unknown
        """ Return the methods of the shared object indicated by token """
        pass

    def handle_request(self, *args, **kwargs): # real signature unknown
        """ Handle a new connection """
        pass

    def incref(self, *args, **kwargs): # real signature unknown
        pass

    def number_of_objects(self, *args, **kwargs): # real signature unknown
        """ Number of shared objects """
        pass

    def serve_client(self, *args, **kwargs): # real signature unknown
        """ Handle requests from the proxies in a particular process/thread """
        pass

    def serve_forever(self, *args, **kwargs): # real signature unknown
        """ Run the server forever """
        pass

    def shutdown(self, *args, **kwargs): # real signature unknown
        """ Shutdown this process """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    fallback_mapping = {
        '#GETVALUE': None, # (!) real value is ''
        '__repr__': None, # (!) real value is ''
        '__str__': None, # (!) real value is ''
    }
    public = [
        'shutdown',
        'create',
        'accept_connection',
        'get_methods',
        'debug_info',
        'number_of_objects',
        'dummy',
        'incref',
        'decref',
    ]
    __dict__ = None # (!) real value is ''


class State(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    value = property(lambda self: object()) # default

    INITIAL = 0
    SHUTDOWN = 2
    STARTED = 1
    __slots__ = [
        'value',
    ]


class SyncManager(BaseManager):
    """
    Subclass of `BaseManager` which supports a number of shared object types.
    
        The types registered are those intended for the synchronization
        of threads, plus `dict`, `list` and `Namespace`.
    
        The `multiprocessing.Manager()` function creates started instances of
        this class.
    """
    def Array(self, *args, **kwargs): # real signature unknown
        pass

    def BoundedSemaphore(self, *args, **kwargs): # real signature unknown
        pass

    def Condition(self, *args, **kwargs): # real signature unknown
        pass

    def dict(self, *args, **kwargs): # real signature unknown
        pass

    def Event(self, *args, **kwargs): # real signature unknown
        pass

    def JoinableQueue(self, *args, **kwargs): # real signature unknown
        pass

    def list(self, *args, **kwargs): # real signature unknown
        pass

    def Lock(self, *args, **kwargs): # real signature unknown
        pass

    def Namespace(self, *args, **kwargs): # real signature unknown
        pass

    def Pool(self, *args, **kwargs): # real signature unknown
        pass

    def Queue(self, *args, **kwargs): # real signature unknown
        pass

    def RLock(self, *args, **kwargs): # real signature unknown
        pass

    def Semaphore(self, *args, **kwargs): # real signature unknown
        pass

    def Value(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _registry = {
        'Array': (
            Array,
            (
                '__len__',
                '__getitem__',
                '__setitem__',
                '__getslice__',
                '__setslice__',
            ),
            None,
            ArrayProxy,
        ),
        'AsyncResult': (
            None,
            None,
            None,
            AutoProxy,
        ),
        'BoundedSemaphore': (
            threading.BoundedSemaphore,
            (
                'acquire',
                'release',
            ),
            None,
            AcquirerProxy,
        ),
        'Condition': (
            threading.Condition,
            (
                'acquire',
                'release',
                'wait',
                'notify',
                'notify_all',
            ),
            None,
            ConditionProxy,
        ),
        'Event': (
            threading.Event,
            (
                'is_set',
                'set',
                'clear',
                'wait',
            ),
            None,
            EventProxy,
        ),
        'Iterator': (
            None,
            (
                '__next__',
                'next',
                'send',
                'throw',
                'close',
            ),
            None,
            IteratorProxy,
        ),
        'JoinableQueue': (
            Queue.Queue,
            None,
            None,
            '<value is a self-reference, replaced by this string>',
        ),
        'Lock': (
            threading.Lock,
            '<value is a self-reference, replaced by this string>',
            None,
            '<value is a self-reference, replaced by this string>',
        ),
        'Namespace': (
            Namespace,
            (
                '__getattribute__',
                '__setattr__',
                '__delattr__',
            ),
            None,
            NamespaceProxy,
        ),
        'Pool': (
            Pool,
            (
                'apply',
                'apply_async',
                'close',
                'imap',
                'imap_unordered',
                'join',
                'map',
                'map_async',
                'terminate',
            ),
            {
                'apply_async': 'AsyncResult',
                'imap': 'Iterator',
                'imap_unordered': 'Iterator',
                'map_async': 'AsyncResult',
            },
            PoolProxy,
        ),
        'Queue': '<value is a self-reference, replaced by this string>',
        'RLock': (
            threading.RLock,
            '<value is a self-reference, replaced by this string>',
            None,
            '<value is a self-reference, replaced by this string>',
        ),
        'Semaphore': (
            threading.Semaphore,
            '<value is a self-reference, replaced by this string>',
            None,
            '<value is a self-reference, replaced by this string>',
        ),
        'Value': (
            None, # (!) forward: Value, real value is ''
            (
                'get',
                'set',
            ),
            None,
            None, # (!) forward: ValueProxy, real value is ''
        ),
        'dict': (
            dict,
            (
                '__contains__',
                '__delitem__',
                '__getitem__',
                '__len__',
                '__setitem__',
                'clear',
                'copy',
                'get',
                'has_key',
                'items',
                'keys',
                'pop',
                'popitem',
                'setdefault',
                'update',
                'values',
            ),
            None,
            DictProxy,
        ),
        'list': (
            list,
            (
                '__add__',
                '__contains__',
                '__delitem__',
                '__delslice__',
                '__getitem__',
                '__getslice__',
                '__len__',
                '__mul__',
                '__reversed__',
                '__rmul__',
                '__setitem__',
                '__setslice__',
                'append',
                'count',
                'extend',
                'index',
                'insert',
                'pop',
                'remove',
                'reverse',
                'sort',
                '__imul__',
            ),
            None,
            ListProxy,
        ),
    }


class Token(object):
    """ Type to uniquely indentify a shared object """
    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    address = property(lambda self: object()) # default
    id = property(lambda self: object()) # default
    typeid = property(lambda self: object()) # default

    __slots__ = (
        'typeid',
        'address',
        'id',
    )


class Value(object):
    # no doc
    def get(self, *args, **kwargs): # real signature unknown
        pass

    def set(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    value = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class ValueProxy(BaseProxy):
    # no doc
    def get(self, *args, **kwargs): # real signature unknown
        pass

    def set(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    value = property(lambda self: object()) # default

    _exposed_ = (
        'get',
        'set',
    )


# variables with complex values

ForkingPickler = None # (!) real value is ''

listener_client = {
    'pickle': (
        connection.Listener,
        connection.Client,
    ),
    'xmlrpclib': (
        connection.XmlListener,
        connection.XmlClient,
    ),
}

view_types = [
    list,
    '<value is a self-reference, replaced by this string>',
    '<value is a self-reference, replaced by this string>',
]

__all__ = [
    'BaseManager',
    'SyncManager',
    'BaseProxy',
    'Token',
]

