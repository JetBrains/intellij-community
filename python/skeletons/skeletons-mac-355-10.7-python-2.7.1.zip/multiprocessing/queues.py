# encoding: utf-8
# module multiprocessing.queues
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/queues.pyo by generator 1.99
# no doc

# imports
import atexit as atexit # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/atexit.pyc
import _multiprocessing as _multiprocessing # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_multiprocessing.so
import collections as collections # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/collections.pyc
import sys as sys # <module 'sys' (built-in)>
import weakref as weakref # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/weakref.pyc
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/threading.pyc
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import multiprocessing.synchronize as __multiprocessing_synchronize


# functions

def assert_spawning(self): # reliably restored by inspect
    # no doc
    pass


def debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def info(msg, *args): # reliably restored by inspect
    # no doc
    pass


def Pipe(duplex=True): # reliably restored by inspect
    """ Returns two connection object connected by a pipe """
    pass


def register_after_fork(obj, func): # reliably restored by inspect
    # no doc
    pass


# classes

class Semaphore(__multiprocessing_synchronize.SemLock):
    # no doc
    def get_value(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass


class BoundedSemaphore(__multiprocessing_synchronize.Semaphore):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass


class Condition(object):
    # no doc
    def notify(self, *args, **kwargs): # real signature unknown
        pass

    def notify_all(self, *args, **kwargs): # real signature unknown
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def _make_methods(self, *args, **kwargs): # real signature unknown
        pass

    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Empty(Exception):
    """ Exception raised by Queue.get(block=0)/get_nowait(). """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class Finalize(object):
    """ Class which supports object finalization using weakrefs """
    def cancel(self, *args, **kwargs): # real signature unknown
        """ Cancel finalization of the object """
        pass

    def still_active(self, *args, **kwargs): # real signature unknown
        """ Return whether this finalizer is still waiting to invoke callback """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Run the callback unless it has already been called or cancelled """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Full(Exception):
    """ Exception raised by Queue.put(block=0)/put_nowait(). """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class Queue(object):
    # no doc
    def cancel_join_thread(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def empty(self, *args, **kwargs): # real signature unknown
        pass

    def full(self, *args, **kwargs): # real signature unknown
        pass

    def get(self, *args, **kwargs): # real signature unknown
        pass

    def get_nowait(self, *args, **kwargs): # real signature unknown
        pass

    def join_thread(self, *args, **kwargs): # real signature unknown
        pass

    def put(self, *args, **kwargs): # real signature unknown
        pass

    def put_nowait(self, *args, **kwargs): # real signature unknown
        pass

    def qsize(self, *args, **kwargs): # real signature unknown
        pass

    def _after_fork(self, *args, **kwargs): # real signature unknown
        pass

    def _feed(buffer, notempty, send, writelock, close): # reliably restored by inspect
        # no doc
        pass

    def _finalize_close(buffer, notempty): # reliably restored by inspect
        # no doc
        pass

    def _finalize_join(twr): # reliably restored by inspect
        # no doc
        pass

    def _start_thread(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class JoinableQueue(Queue):
    # no doc
    def join(self, *args, **kwargs): # real signature unknown
        pass

    def put(self, *args, **kwargs): # real signature unknown
        pass

    def task_done(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass


class Lock(__multiprocessing_synchronize.SemLock):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass


class SimpleQueue(object):
    # no doc
    def empty(self, *args, **kwargs): # real signature unknown
        pass

    def _make_methods(self, *args, **kwargs): # real signature unknown
        pass

    def __getstate__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

_sentinel = None # (!) real value is ''

__all__ = [
    'Queue',
    'SimpleQueue',
    'JoinableQueue',
]

