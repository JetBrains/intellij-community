# encoding: utf-8
# module multiprocessing.util
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/util.pyo by generator 1.99
# no doc

# imports
import atexit as atexit # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/atexit.pyc
import weakref as weakref # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/weakref.pyc
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/threading.pyc
import itertools as itertools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/itertools.so
import thread as __thread


# Variables with simple values

DEBUG = 10

DEFAULT_LOGGING_FORMAT = '[%(levelname)s/%(processName)s] %(message)s'

INFO = 20

LOGGER_NAME = 'multiprocessing'

NOTSET = 0

SUBDEBUG = 5
SUBWARNING = 25

_exiting = False

_logger = None

_log_to_stderr = False

# functions

def active_children(): # reliably restored by inspect
    """ Return list of process objects corresponding to live child processes """
    pass


def current_process(): # reliably restored by inspect
    """ Return process object representing the current process """
    pass


def debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def get_logger(): # reliably restored by inspect
    """ Returns logger used by multiprocessing """
    pass


def get_temp_dir(): # reliably restored by inspect
    # no doc
    pass


def info(msg, *args): # reliably restored by inspect
    # no doc
    pass


def is_exiting(): # reliably restored by inspect
    """ Returns true if the process is shutting down """
    pass


def log_to_stderr(level=None): # reliably restored by inspect
    """ Turn on logging and add a handler which prints to stderr """
    pass


def register_after_fork(obj, func): # reliably restored by inspect
    # no doc
    pass


def sub_debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def sub_warning(msg, *args): # reliably restored by inspect
    # no doc
    pass


def _exit_function(): # reliably restored by inspect
    # no doc
    pass


def _run_after_forkers(): # reliably restored by inspect
    # no doc
    pass


def _run_finalizers(minpriority=None): # reliably restored by inspect
    """
    Run all finalizers whose exit priority is not None and at least minpriority
    
        Finalizers with highest priority are called first; finalizers with
        the same priority will be called in reverse order of creation.
    """
    pass


# classes

class Finalize(object):
    """ Class which supports object finalization using weakrefs """
    def cancel(self, *args, **kwargs): # real signature unknown
        """ Cancel finalization of the object """
        pass

    def still_active(self, *args, **kwargs): # real signature unknown
        """ Return whether this finalizer is still waiting to invoke callback """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Run the callback unless it has already been called or cancelled """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class ForkAwareLocal(__thread._local):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is ''


class ForkAwareThreadLock(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

_afterfork_counter = None # (!) real value is ''

_afterfork_registry = None # (!) real value is ''

_finalizer_counter = None # (!) real value is ''

_finalizer_registry = {}

__all__ = [
    'sub_debug',
    'debug',
    'info',
    'sub_warning',
    'get_logger',
    'log_to_stderr',
    'get_temp_dir',
    'register_after_fork',
    'is_exiting',
    'Finalize',
    'ForkAwareThreadLock',
    'ForkAwareLocal',
    'SUBDEBUG',
    'SUBWARNING',
]

