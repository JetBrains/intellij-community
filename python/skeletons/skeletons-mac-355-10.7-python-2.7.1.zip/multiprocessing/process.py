# encoding: utf-8
# module multiprocessing.process
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/process.pyo by generator 1.99
# no doc

# imports
import signal as signal # <module 'signal' (built-in)>
import sys as sys # <module 'sys' (built-in)>
import itertools as itertools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/itertools.so
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from signal import signum


# Variables with simple values

name = 'alarm'

ORIGINAL_DIR = '/System/Library/Frameworks/Python.framework/Versions/2.7/bin'

# functions

def active_children(): # reliably restored by inspect
    """ Return list of process objects corresponding to live child processes """
    pass


def current_process(): # reliably restored by inspect
    """ Return process object representing the current process """
    pass


def _cleanup(): # reliably restored by inspect
    # no doc
    pass


# classes

class AuthenticationString(str):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    __dict__ = None # (!) real value is ''


class Process(object):
    """
    Process objects represent activity that is run in a separate process
    
        The class is analagous to `threading.Thread`
    """
    def is_alive(self, *args, **kwargs): # real signature unknown
        """ Return whether process is alive """
        pass

    def join(self, *args, **kwargs): # real signature unknown
        """ Wait until child process terminates """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        """ Method to be run in sub-process; can be overridden in sub-class """
        pass

    def start(self, *args, **kwargs): # real signature unknown
        """ Start child process """
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        """ Terminate process; sends SIGTERM signal or uses TerminateProcess() """
        pass

    def _bootstrap(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    authkey = property(lambda self: object()) # default
    daemon = property(lambda self: object()) # default
    exitcode = property(lambda self: object()) # default
    ident = property(lambda self: object()) # default
    name = property(lambda self: object()) # default
    pid = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    _Popen = None
    __dict__ = None # (!) real value is ''


# variables with complex values

_current_process = None # (!) real value is ''

_exitcode_to_name = {
    -31: 'SIGUSR2',
    -30: 'SIGUSR1',
    -29: 'SIGINFO',
    -28: 'SIGWINCH',
    -27: 'SIGPROF',
    -26: 'SIGVTALRM',
    -25: 'SIGXFSZ',
    -24: 'SIGXCPU',
    -23: 'SIGIO',
    -22: 'SIGTTOU',
    -21: 'SIGTTIN',
    -20: 'SIGCHLD',
    -19: 'SIGCONT',
    -18: 'SIGTSTP',
    -17: 'SIGSTOP',
    -16: 'SIGURG',
    -15: 'SIGTERM',
    -14: 'SIGALRM',
    -13: 'SIGPIPE',
    -12: 'SIGSYS',
    -11: 'SIGSEGV',
    -10: 'SIGBUS',
    -9: 'SIGKILL',
    -8: 'SIGFPE',
    -7: 'SIGEMT',
    -6: 'SIGABRT',
    -5: 'SIGTRAP',
    -4: 'SIGILL',
    -3: 'SIGQUIT',
    -2: 'SIGINT',
    -1: 'SIGHUP',
}

__all__ = [
    'Process',
    'current_process',
    'active_children',
]

