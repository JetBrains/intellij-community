# encoding: utf-8
# module multiprocessing.forking
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/forking.pyo by generator 1.99
# no doc

# imports
import multiprocessing.process as process # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/process.pyc
import multiprocessing.util as util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/util.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import signal as signal # <module 'signal' (built-in)>
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so
from posix import close, duplicate, exit


# functions

def assert_spawning(self): # reliably restored by inspect
    # no doc
    pass


def prepare(data): # reliably restored by inspect
    """ Try to get current process ready to unpickle process object """
    pass


def _rebuild_partial(func, args, keywords): # reliably restored by inspect
    # no doc
    pass


def _reduce_method(m): # reliably restored by inspect
    # no doc
    pass


def _reduce_method_descriptor(m): # reliably restored by inspect
    # no doc
    pass


def _reduce_partial(p): # reliably restored by inspect
    # no doc
    pass


# classes

class partial(object):
    """
    partial(func, *args, **keywords) - new function with partial application
        of the given arguments and keywords.
    """
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, func, *args, **keywords): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    def __setstate__(self, *args, **kwargs): # real signature unknown
        pass

    args = property(lambda self: object()) # default
    func = property(lambda self: object()) # default
    keywords = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Popen(object):
    # no doc
    def poll(self, *args, **kwargs): # real signature unknown
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        pass

    def thread_is_spawning(): # reliably restored by inspect
        # no doc
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

ForkingPickler = None # (!) real value is ''

old_main_modules = []

Pickler = None # (!) real value is ''

__all__ = [
    'Popen',
    'assert_spawning',
    'exit',
    'duplicate',
    'close',
    'ForkingPickler',
]

