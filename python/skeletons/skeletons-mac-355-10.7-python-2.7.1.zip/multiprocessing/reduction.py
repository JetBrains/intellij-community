# encoding: utf-8
# module multiprocessing.reduction
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/reduction.pyo by generator 1.99
# no doc

# imports
import _multiprocessing as _multiprocessing # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_multiprocessing.so
import sys as sys # <module 'sys' (built-in)>
import socket as socket # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/socket.pyc
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/threading.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from posix import close, duplicate


# Variables with simple values

_listener = None

# functions

def Client(address, family=None, authkey=None): # reliably restored by inspect
    """ Returns a connection to the address of a `Listener` """
    pass


def current_process(): # reliably restored by inspect
    """ Return process object representing the current process """
    pass


def debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def fromfd(fd, family, type_, proto=0): # reliably restored by inspect
    # no doc
    pass


def rebuild_connection(reduced_handle, readable, writable): # reliably restored by inspect
    # no doc
    pass


def rebuild_handle(pickled_data): # reliably restored by inspect
    # no doc
    pass


def rebuild_socket(reduced_handle, family, type_, proto): # reliably restored by inspect
    # no doc
    pass


def recv_handle(conn): # reliably restored by inspect
    # no doc
    pass


def reduce_connection(conn): # reliably restored by inspect
    # no doc
    pass


def reduce_handle(handle): # reliably restored by inspect
    # no doc
    pass


def reduce_socket(s): # reliably restored by inspect
    # no doc
    pass


def register_after_fork(obj, func): # reliably restored by inspect
    # no doc
    pass


def send_handle(conn, handle, destination_pid): # reliably restored by inspect
    # no doc
    pass


def sub_debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def _get_listener(): # reliably restored by inspect
    # no doc
    pass


def _reset(obj): # reliably restored by inspect
    # no doc
    pass


def _serve(): # reliably restored by inspect
    # no doc
    pass


# classes

class Listener(object):
    """
    Returns a listener object.
    
        This is a wrapper for a bound socket which is 'listening' for
        connections, or for a Windows named pipe.
    """
    def accept(self, *args, **kwargs): # real signature unknown
        """
        Accept a connection on the bound socket or named pipe of `self`.
        
                Returns a `Connection` object.
        """
        pass

    def close(self, *args, **kwargs): # real signature unknown
        """ Close the bound socket or named pipe of `self`. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    address = property(lambda self: object()) # default
    last_accepted = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Popen(object):
    # no doc
    def poll(self, *args, **kwargs): # real signature unknown
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        pass

    def thread_is_spawning(): # reliably restored by inspect
        # no doc
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

ForkingPickler = None # (!) real value is ''

_cache = None # (!) real value is ''

_lock = None # (!) real value is ''

__all__ = []

