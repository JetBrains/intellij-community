# encoding: utf-8
# module multiprocessing.heap
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/heap.pyo by generator 1.99
# no doc

# imports
import tempfile as tempfile # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/tempfile.pyc
import mmap as mmap # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/mmap.so
import _multiprocessing as _multiprocessing # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_multiprocessing.so
import sys as sys # <module 'sys' (built-in)>
import bisect as bisect # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/bisect.pyc
import itertools as itertools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/itertools.so
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/threading.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# functions

def assert_spawning(self): # reliably restored by inspect
    # no doc
    pass


def info(msg, *args): # reliably restored by inspect
    # no doc
    pass


# classes

class Arena(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class BufferWrapper(object):
    # no doc
    def get_address(self, *args, **kwargs): # real signature unknown
        pass

    def get_size(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _heap = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class Finalize(object):
    """ Class which supports object finalization using weakrefs """
    def cancel(self, *args, **kwargs): # real signature unknown
        """ Cancel finalization of the object """
        pass

    def still_active(self, *args, **kwargs): # real signature unknown
        """ Return whether this finalizer is still waiting to invoke callback """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Run the callback unless it has already been called or cancelled """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Heap(object):
    # no doc
    def free(self, *args, **kwargs): # real signature unknown
        pass

    def malloc(self, *args, **kwargs): # real signature unknown
        pass

    def _absorb(self, *args, **kwargs): # real signature unknown
        pass

    def _free(self, *args, **kwargs): # real signature unknown
        pass

    def _malloc(self, *args, **kwargs): # real signature unknown
        pass

    def _roundup(n, alignment): # reliably restored by inspect
        # no doc
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _alignment = 8
    __dict__ = None # (!) real value is ''


# variables with complex values

__all__ = [
    'BufferWrapper',
]

