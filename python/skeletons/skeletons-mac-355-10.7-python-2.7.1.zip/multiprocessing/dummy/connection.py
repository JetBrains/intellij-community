# encoding: utf-8
# module multiprocessing.dummy.connection
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/dummy/connection.pyo by generator 1.99
# no doc
# no imports

# functions

def Client(address): # reliably restored by inspect
    # no doc
    pass


def Pipe(duplex=True): # reliably restored by inspect
    # no doc
    pass


# classes

class Connection(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def poll(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Listener(object):
    # no doc
    def accept(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    address = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

families = [
    None,
]

Queue = None # (!) real value is ''

__all__ = [
    'Client',
    'Listener',
    'Pipe',
]

