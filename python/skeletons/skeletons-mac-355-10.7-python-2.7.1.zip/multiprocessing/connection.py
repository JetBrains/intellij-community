# encoding: utf-8
# module multiprocessing.connection
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/connection.pyo by generator 1.99
# no doc

# imports
import tempfile as tempfile # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/tempfile.pyc
import errno as errno # <module 'errno' (built-in)>
import _multiprocessing as _multiprocessing # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_multiprocessing.so
import sys as sys # <module 'sys' (built-in)>
import socket as socket # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/socket.pyc
import itertools as itertools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/itertools.so
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from posix import close, duplicate

import multiprocessing as __multiprocessing


# Variables with simple values

BUFSIZE = 8192

CHALLENGE = '#CHALLENGE#'

CONNECTION_TIMEOUT = 20.0

default_family = 'AF_UNIX'

FAILURE = '#FAILURE#'

MESSAGE_LENGTH = 20

WELCOME = '#WELCOME#'

# functions

def address_type(address): # reliably restored by inspect
    """
    Return the types of the address
    
        This can be 'AF_INET', 'AF_UNIX', or 'AF_PIPE'
    """
    pass


def answer_challenge(connection, authkey): # reliably restored by inspect
    # no doc
    pass


def arbitrary_address(family): # reliably restored by inspect
    """ Return an arbitrary free address for the given family """
    pass


def Client(address, family=None, authkey=None): # reliably restored by inspect
    """ Returns a connection to the address of a `Listener` """
    pass


def current_process(): # reliably restored by inspect
    """ Return process object representing the current process """
    pass


def debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def deliver_challenge(connection, authkey): # reliably restored by inspect
    # no doc
    pass


def get_temp_dir(): # reliably restored by inspect
    # no doc
    pass


def Pipe(duplex=True): # reliably restored by inspect
    """ Returns pair of connection objects at either end of a pipe """
    pass


def SocketClient(address): # reliably restored by inspect
    """ Return a connection object connected to the socket given by `address` """
    pass


def sub_debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def XmlClient(*args, **kwds): # reliably restored by inspect
    # no doc
    pass


def _check_timeout(t): # reliably restored by inspect
    # no doc
    pass


def _init_timeout(timeout=20.0): # reliably restored by inspect
    # no doc
    pass


def _xml_dumps(obj): # reliably restored by inspect
    # no doc
    pass


def _xml_loads(s): # reliably restored by inspect
    # no doc
    pass


# classes

class AuthenticationError(__multiprocessing.ProcessError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class ConnectionWrapper(object):
    # no doc
    def recv(self, *args, **kwargs): # real signature unknown
        pass

    def send(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Finalize(object):
    """ Class which supports object finalization using weakrefs """
    def cancel(self, *args, **kwargs): # real signature unknown
        """ Cancel finalization of the object """
        pass

    def still_active(self, *args, **kwargs): # real signature unknown
        """ Return whether this finalizer is still waiting to invoke callback """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Run the callback unless it has already been called or cancelled """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Listener(object):
    """
    Returns a listener object.
    
        This is a wrapper for a bound socket which is 'listening' for
        connections, or for a Windows named pipe.
    """
    def accept(self, *args, **kwargs): # real signature unknown
        """
        Accept a connection on the bound socket or named pipe of `self`.
        
                Returns a `Connection` object.
        """
        pass

    def close(self, *args, **kwargs): # real signature unknown
        """ Close the bound socket or named pipe of `self`. """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    address = property(lambda self: object()) # default
    last_accepted = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class SocketListener(object):
    """ Representation of a socket which is bound to an address and listening """
    def accept(self, *args, **kwargs): # real signature unknown
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class XmlListener(Listener):
    # no doc
    def accept(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

families = [
    'AF_INET',
    'AF_UNIX',
]

_mmap_counter = None # (!) real value is ''

__all__ = [
    'Client',
    'Listener',
    'Pipe',
]

