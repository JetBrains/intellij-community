# encoding: utf-8
# module multiprocessing.sharedctypes
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/sharedctypes.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import ctypes as ctypes # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ctypes/__init__.pyc
import multiprocessing.heap as heap # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/heap.pyc
import weakref as weakref # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/weakref.pyc

# Variables with simple values

template = '\ndef get%s(self):\n    self.acquire()\n    try:\n        return self._obj.%s\n    finally:\n        self.release()\ndef set%s(self, value):\n    self.acquire()\n    try:\n        self._obj.%s = value\n    finally:\n        self.release()\n%s = property(get%s, set%s)\n'

# functions

def Array(typecode_or_type, size_or_initializer, **kwds): # reliably restored by inspect
    """ Return a synchronization wrapper for a RawArray """
    pass


def assert_spawning(self): # reliably restored by inspect
    # no doc
    pass


def copy(obj): # reliably restored by inspect
    # no doc
    pass


def make_property(name): # reliably restored by inspect
    # no doc
    pass


def RawArray(typecode_or_type, size_or_initializer): # reliably restored by inspect
    """ Returns a ctypes array allocated from shared memory """
    pass


def RawValue(typecode_or_type, *args): # reliably restored by inspect
    """ Returns a ctypes object allocated from shared memory """
    pass


def rebuild_ctype(type_, wrapper, length): # reliably restored by inspect
    # no doc
    pass


def reduce_ctype(obj): # reliably restored by inspect
    # no doc
    pass


def RLock(): # reliably restored by inspect
    """ Returns a recursive lock object """
    pass


def synchronized(obj, lock=None): # reliably restored by inspect
    # no doc
    pass


def Value(typecode_or_type, *args, **kwds): # reliably restored by inspect
    """ Return a synchronization wrapper for a Value """
    pass


def _new_value(type_): # reliably restored by inspect
    # no doc
    pass


# classes

class SynchronizedBase(object):
    # no doc
    def get_lock(self, *args, **kwargs): # real signature unknown
        pass

    def get_obj(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Synchronized(SynchronizedBase):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    value = property(lambda self: object()) # default


class SynchronizedArray(SynchronizedBase):
    # no doc
    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getslice__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __setslice__(self, *args, **kwargs): # real signature unknown
        pass


class SynchronizedString(SynchronizedArray):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    raw = property(lambda self: object()) # default
    value = property(lambda self: object()) # default


# variables with complex values

class_cache = None # (!) real value is ''

ForkingPickler = None # (!) real value is ''

prop_cache = {
    'raw': None, # (!) real value is ''
    'value': None, # (!) real value is ''
}

typecode_to_type = {
    'B': ctypes.c_ubyte,
    'H': ctypes.c_ushort,
    'I': ctypes.c_uint32,
    'L': ctypes.c_ulong,
    'b': ctypes.c_int8,
    'c': ctypes.c_char,
    'd': ctypes.c_double,
    'f': ctypes.c_float,
    'h': ctypes.c_short,
    'i': ctypes.c_int,
    'l': ctypes.c_longlong,
    'u': ctypes.c_wchar,
}

__all__ = [
    'RawValue',
    'RawArray',
    'Value',
    'Array',
    'copy',
    'synchronized',
]

