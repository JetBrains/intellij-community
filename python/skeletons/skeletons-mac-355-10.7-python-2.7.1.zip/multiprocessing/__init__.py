# encoding: utf-8
# module multiprocessing.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/__init__.pyo by generator 1.99
# no doc

# imports
import _multiprocessing as _multiprocessing # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/_multiprocessing.so
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

SUBDEBUG = 5
SUBWARNING = 25

__author__ = 'R. Oudkerk (r.m.oudkerk@gmail.com)'

__version__ = '0.70a1'

# functions

def active_children(): # reliably restored by inspect
    """ Return list of process objects corresponding to live child processes """
    pass


def allow_connection_pickling(): # reliably restored by inspect
    """ Install support for sending connections and sockets between processes """
    pass


def Array(typecode_or_type, size_or_initializer, **kwds): # reliably restored by inspect
    """ Returns a synchronized shared array """
    pass


def BoundedSemaphore(value=1): # reliably restored by inspect
    """ Returns a bounded semaphore object """
    pass


def Condition(lock=None): # reliably restored by inspect
    """ Returns a condition object """
    pass


def cpu_count(): # reliably restored by inspect
    """ Returns the number of CPUs in the system """
    pass


def current_process(): # reliably restored by inspect
    """ Return process object representing the current process """
    pass


def Event(): # reliably restored by inspect
    """ Returns an event object """
    pass


def freeze_support(): # reliably restored by inspect
    """
    Check whether this is a fake forked process in a frozen executable.
        If so then run code specified by commandline and exit.
    """
    pass


def get_logger(): # reliably restored by inspect
    """ Return package logger -- if it does not already exist then it is created """
    pass


def JoinableQueue(maxsize=0): # reliably restored by inspect
    """ Returns a queue object """
    pass


def Lock(): # reliably restored by inspect
    """ Returns a non-recursive lock object """
    pass


def log_to_stderr(level=None): # reliably restored by inspect
    """ Turn on logging and add a handler which prints to stderr """
    pass


def Manager(): # reliably restored by inspect
    """
    Returns a manager associated with a running server process
    
        The managers methods such as `Lock()`, `Condition()` and `Queue()`
        can be used to create shared objects.
    """
    pass


def Pipe(duplex=True): # reliably restored by inspect
    """ Returns two connection object connected by a pipe """
    pass


def Pool(processes=None, initializer=None, initargs='()', maxtasksperchild=None): # reliably restored by inspect
    """ Returns a process pool object """
    pass


def Queue(maxsize=0): # reliably restored by inspect
    """ Returns a queue object """
    pass


def RawArray(typecode_or_type, size_or_initializer): # reliably restored by inspect
    """ Returns a shared array """
    pass


def RawValue(typecode_or_type, *args): # reliably restored by inspect
    """ Returns a shared object """
    pass


def RLock(): # reliably restored by inspect
    """ Returns a recursive lock object """
    pass


def Semaphore(value=1): # reliably restored by inspect
    """ Returns a semaphore object """
    pass


def Value(typecode_or_type, *args, **kwds): # reliably restored by inspect
    """ Returns a synchronized shared object """
    pass


# classes

class ProcessError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class AuthenticationError(ProcessError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class BufferTooShort(ProcessError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Process(object):
    """
    Process objects represent activity that is run in a separate process
    
        The class is analagous to `threading.Thread`
    """
    def is_alive(self, *args, **kwargs): # real signature unknown
        """ Return whether process is alive """
        pass

    def join(self, *args, **kwargs): # real signature unknown
        """ Wait until child process terminates """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        """ Method to be run in sub-process; can be overridden in sub-class """
        pass

    def start(self, *args, **kwargs): # real signature unknown
        """ Start child process """
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        """ Terminate process; sends SIGTERM signal or uses TerminateProcess() """
        pass

    def _bootstrap(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    authkey = property(lambda self: object()) # default
    daemon = property(lambda self: object()) # default
    exitcode = property(lambda self: object()) # default
    ident = property(lambda self: object()) # default
    name = property(lambda self: object()) # default
    pid = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    _Popen = None
    __dict__ = None # (!) real value is ''


class TimeoutError(ProcessError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

__all__ = [
    'Process',
    'current_process',
    'active_children',
    'freeze_support',
    'Manager',
    'Pipe',
    'cpu_count',
    'log_to_stderr',
    'get_logger',
    'allow_connection_pickling',
    'BufferTooShort',
    'TimeoutError',
    'Lock',
    'RLock',
    'Semaphore',
    'BoundedSemaphore',
    'Condition',
    'Event',
    'Queue',
    'JoinableQueue',
    'Pool',
    'Value',
    'Array',
    'RawValue',
    'RawArray',
    'SUBDEBUG',
    'SUBWARNING',
]

