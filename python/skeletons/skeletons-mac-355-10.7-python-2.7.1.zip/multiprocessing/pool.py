# encoding: utf-8
# module multiprocessing.pool
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/multiprocessing/pool.pyo by generator 1.99
# no doc

# imports
import collections as collections # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/collections.pyc
import Queue as Queue # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/Queue.pyc
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/threading.pyc
import itertools as itertools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/itertools.so
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so
import multiprocessing as __multiprocessing


# Variables with simple values

CLOSE = 1

RUN = 0

TERMINATE = 2

# functions

def cpu_count(): # reliably restored by inspect
    """ Returns the number of CPUs in the system """
    pass


def debug(msg, *args): # reliably restored by inspect
    # no doc
    pass


def mapstar(args): # reliably restored by inspect
    # no doc
    pass


def worker(inqueue, outqueue, initializer=None, initargs='()', maxtasks=None): # reliably restored by inspect
    # no doc
    pass


# classes

class ApplyResult(object):
    # no doc
    def get(self, *args, **kwargs): # real signature unknown
        pass

    def ready(self, *args, **kwargs): # real signature unknown
        pass

    def successful(self, *args, **kwargs): # real signature unknown
        pass

    def wait(self, *args, **kwargs): # real signature unknown
        pass

    def _set(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Finalize(object):
    """ Class which supports object finalization using weakrefs """
    def cancel(self, *args, **kwargs): # real signature unknown
        """ Cancel finalization of the object """
        pass

    def still_active(self, *args, **kwargs): # real signature unknown
        """ Return whether this finalizer is still waiting to invoke callback """
        pass

    def __call__(self, *args, **kwargs): # real signature unknown
        """ Run the callback unless it has already been called or cancelled """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class IMapIterator(object):
    # no doc
    def next(self, *args, **kwargs): # real signature unknown
        pass

    def _set(self, *args, **kwargs): # real signature unknown
        pass

    def _set_length(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class IMapUnorderedIterator(IMapIterator):
    # no doc
    def _set(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class MapResult(ApplyResult):
    # no doc
    def _set(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Pool(object):
    """ Class which supports an async version of the `apply()` builtin """
    def apply(self): # real signature unknown; restored from __doc__
        """ Equivalent of `apply()` builtin """
        pass

    def apply_async(self, *args, **kwargs): # real signature unknown
        """ Asynchronous equivalent of `apply()` builtin """
        pass

    def close(self, *args, **kwargs): # real signature unknown
        pass

    def imap(self): # real signature unknown; restored from __doc__
        """ Equivalent of `itertools.imap()` -- can be MUCH slower than `Pool.map()` """
        pass

    def imap_unordered(self, *args, **kwargs): # real signature unknown
        """ Like `imap()` method but ordering of results is arbitrary """
        pass

    def join(self, *args, **kwargs): # real signature unknown
        pass

    def map(self): # real signature unknown; restored from __doc__
        """ Equivalent of `map()` builtin """
        pass

    def map_async(self, *args, **kwargs): # real signature unknown
        """ Asynchronous equivalent of `map()` builtin """
        pass

    def Process(self, *args, **kwargs): # real signature unknown
        """
        Process objects represent activity that is run in a separate process
        
            The class is analagous to `threading.Thread`
        """
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        pass

    def _get_tasks(func, it, size): # reliably restored by inspect
        # no doc
        pass

    def _handle_results(outqueue, get, cache): # reliably restored by inspect
        # no doc
        pass

    def _handle_tasks(taskqueue, put, outqueue, pool): # reliably restored by inspect
        # no doc
        pass

    def _handle_workers(pool): # reliably restored by inspect
        # no doc
        pass

    def _help_stuff_finish(inqueue, task_handler, size): # reliably restored by inspect
        # no doc
        pass

    def _join_exited_workers(self, *args, **kwargs): # real signature unknown
        """
        Cleanup after any worker processes which have exited due to reaching
                their specified lifetime.  Returns True if any workers were cleaned up.
        """
        pass

    def _maintain_pool(self, *args, **kwargs): # real signature unknown
        """ Clean up any exited workers and start replacements for them. """
        pass

    def _repopulate_pool(self, *args, **kwargs): # real signature unknown
        """
        Bring the number of pool processes up to the specified number,
                for use after reaping workers which have exited.
        """
        pass

    def _setup_queues(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def _terminate_pool(cls, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Process(object):
    """
    Process objects represent activity that is run in a separate process
    
        The class is analagous to `threading.Thread`
    """
    def is_alive(self, *args, **kwargs): # real signature unknown
        """ Return whether process is alive """
        pass

    def join(self, *args, **kwargs): # real signature unknown
        """ Wait until child process terminates """
        pass

    def run(self, *args, **kwargs): # real signature unknown
        """ Method to be run in sub-process; can be overridden in sub-class """
        pass

    def start(self, *args, **kwargs): # real signature unknown
        """ Start child process """
        pass

    def terminate(self, *args, **kwargs): # real signature unknown
        """ Terminate process; sends SIGTERM signal or uses TerminateProcess() """
        pass

    def _bootstrap(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    authkey = property(lambda self: object()) # default
    daemon = property(lambda self: object()) # default
    exitcode = property(lambda self: object()) # default
    ident = property(lambda self: object()) # default
    name = property(lambda self: object()) # default
    pid = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    _Popen = None
    __dict__ = None # (!) real value is ''


class ThreadPool(Pool):
    # no doc
    def Process(self, *args, **kwargs): # real signature unknown
        pass

    def _help_stuff_finish(inqueue, task_handler, size): # reliably restored by inspect
        # no doc
        pass

    def _setup_queues(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class TimeoutError(__multiprocessing.ProcessError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

job_counter = None # (!) real value is ''

__all__ = [
    'Pool',
]

