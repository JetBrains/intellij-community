# encoding: utf-8
# module Carbon.Fonts
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Fonts.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

appleMark = 20
applFont = 1

athens = 7

cairo = 11

checkMark = 18

commandMark = 17
courier = 22

diamondMark = 19

fixedFont = 45056L

fontWid = 44208L

fxdFntH = 45057L
fxdFntHW = 45059L
fxdFntW = 45058L

geneva = 3

helvetica = 21

kFMDefaultActivationContext = 0
kFMDefaultIterationScope = 0
kFMDefaultOptions = 0
kFMGlobalActivationContext = 1
kFMGlobalIterationScope = 1
kFMLocalActivationContext = 0
kFMLocalIterationScope = 0
kFMUseGlobalScopeOption = 1
kFontIDAthens = 7
kFontIDCairo = 11
kFontIDCourier = 22
kFontIDGeneva = 3
kFontIDHelvetica = 21
kFontIDLondon = 6
kFontIDLosAngeles = 12
kFontIDMobile = 24
kFontIDMonaco = 4
kFontIDNewYork = 2
kFontIDSanFrancisco = 8
kFontIDSymbol = 23
kFontIDTimes = 20
kFontIDToronto = 9
kFontIDVenice = 5

kNilOptions = 0

kPlatformDefaultGuiFontID = -1

london = 6
losAngeles = 12

mobile = 24
monaco = 4

newYork = 2

propFont = 36864L
prpFntH = 36865L
prpFntHW = 36867L
prpFntW = 36866L

sanFran = 8

symbol = 23
systemFont = 0

times = 20

toronto = 9

venice = 5

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
