# encoding: utf-8
# module Carbon.Menus
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Menus.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

gestaltContextualMenuAttr = 'cmnu'
gestaltContextualMenuHasAttributeAndModifierKeys = 2
gestaltContextualMenuHasUnicodeSupport = 3
gestaltContextualMenuTrapAvailable = 1
gestaltContextualMenuUnusedBit = 0

hierMenu = -1

hMenuCmd = 27

kCMHelpItemAppleGuide = 1
kCMHelpItemNoHelp = 0
kCMHelpItemOtherHelp = 2
kCMHelpItemRemoveHelp = 3
kCMMenuItemSelected = 1
kCMNothingSelected = 0
kCMShowHelpSelected = 3

keyContextualMenuAttributes = 'cmat'
keyContextualMenuCommandID = 'cmcd'
keyContextualMenuModifiers = 'cmmd'
keyContextualMenuName = 'pnam'
keyContextualMenuSubmenu = 'cmsb'

kHierarchicalFontMenuOption = 1

kInsertHierarchicalMenu = -1

kMenuAppleLogoFilledGlyph = 20
kMenuAppleLogoOutlineGlyph = 108
kMenuAttrAutoDisable = 4
kMenuAttrExcludesMarkColumn = 1
kMenuAttrHidden = 16
kMenuAttrUsePencilGlyph = 8
kMenuBlankGlyph = 97
kMenuCalcItemMsg = 5
kMenuCapsLockGlyph = 99
kMenuCGImageRefType = 7
kMenuCheckmarkGlyph = 18
kMenuChooseMsg = 1
kMenuClearGlyph = 28
kMenuColorIconType = 4
kMenuCommandGlyph = 17
kMenuContextualMenuGlyph = 109
kMenuControlGlyph = 6
kMenuControlISOGlyph = 138
kMenuControlModifier = 4
kMenuDefProcPtr = 0
kMenuDeleteLeftGlyph = 23
kMenuDeleteRightGlyph = 10
kMenuDiamondGlyph = 19
kMenuDisposeMsg = 9
kMenuDownArrowGlyph = 106
kMenuDownwardArrowDashedGlyph = 16
kMenuDrawItemMsg = 4
kMenuDrawItemsMsg = 12
kMenuDrawMsg = 0
kMenuEnterGlyph = 4
kMenuEscapeGlyph = 27
kMenuEventDontCheckSubmenus = 4
kMenuEventIncludeDisabledItems = 1
kMenuEventQueryOnly = 2
kMenuF10Glyph = 120
kMenuF11Glyph = 121
kMenuF12Glyph = 122
kMenuF13Glyph = 135
kMenuF14Glyph = 136
kMenuF15Glyph = 137
kMenuF1Glyph = 111
kMenuF2Glyph = 112
kMenuF3Glyph = 113
kMenuF4Glyph = 114
kMenuF5Glyph = 115
kMenuF6Glyph = 116
kMenuF7Glyph = 117
kMenuF8Glyph = 118
kMenuF9Glyph = 119
kMenuFindItemMsg = 10
kMenuHelpGlyph = 103
kMenuHiliteItemMsg = 11
kMenuIconRefType = 6
kMenuIconResourceType = 9
kMenuIconSuiteType = 5
kMenuIconType = 1
kMenuInitMsg = 8
kMenuItemAttrAutoRepeat = 512
kMenuItemAttrCustomDraw = 2048
kMenuItemAttrDisabled = 1
kMenuItemAttrDynamic = 8
kMenuItemAttrHidden = 32
kMenuItemAttrIconDisabled = 2
kMenuItemAttrIgnoreMeta = 256
kMenuItemAttrIncludeInCmdKeyMatching = 4096
kMenuItemAttrNotPreviousAlternate = 16
kMenuItemAttrSectionHeader = 128
kMenuItemAttrSeparator = 64
kMenuItemAttrSubmenuParentChoosable = 4
kMenuItemAttrUseVirtualKey = 1024
kMenuItemDataAllDataVersionOne = 1048575
kMenuItemDataAllDataVersionTwo = 2097151
kMenuItemDataAttributes = 65536
kMenuItemDataCFString = 131072
kMenuItemDataCmdKey = 4
kMenuItemDataCmdKeyGlyph = 8
kMenuItemDataCmdKeyModifiers = 16
kMenuItemDataCmdVirtualKey = 1048576
kMenuItemDataCommandID = 1024
kMenuItemDataEnabled = 64
kMenuItemDataFontID = 16384
kMenuItemDataIconEnabled = 128
kMenuItemDataIconHandle = 512
kMenuItemDataIconID = 256
kMenuItemDataIndent = 524288
kMenuItemDataMark = 2
kMenuItemDataProperties = 262144
kMenuItemDataRefcon = 32768
kMenuItemDataStyle = 32
kMenuItemDataSubmenuHandle = 8192
kMenuItemDataSubmenuID = 4096
kMenuItemDataText = 1
kMenuItemDataTextEncoding = 2048
kMenuLeftArrowDashedGlyph = 24
kMenuLeftArrowGlyph = 100
kMenuLeftDoubleQuotesJapaneseGlyph = 29
kMenuNoCommandModifier = 8
kMenuNoIcon = 0
kMenuNoModifiers = 0
kMenuNonmarkingReturnGlyph = 13
kMenuNorthwestArrowGlyph = 102
kMenuNullGlyph = 0
kMenuOptionGlyph = 7
kMenuOptionModifier = 2
kMenuPageDownGlyph = 107
kMenuPageUpGlyph = 98
kMenuParagraphKoreanGlyph = 21
kMenuPencilGlyph = 15
kMenuPopUpMsg = 3
kMenuPowerGlyph = 110
kMenuPropertyPersistent = 1
kMenuReturnGlyph = 11
kMenuReturnR2LGlyph = 12
kMenuRightArrowDashedGlyph = 26
kMenuRightArrowGlyph = 101
kMenuRightDoubleQuotesJapaneseGlyph = 30
kMenuShiftGlyph = 5
kMenuShiftModifier = 1
kMenuShrinkIconType = 2
kMenuSizeMsg = 2
kMenuSmallIconType = 3
kMenuSoutheastArrowGlyph = 105
kMenuSpaceGlyph = 9
kMenuStdMenuBarProc = 63
kMenuStdMenuProc = 63
kMenuSystemIconSelectorType = 8
kMenuTabLeftGlyph = 3
kMenuTabRightGlyph = 2
kMenuThemeSavvyMsg = 7
kMenuTrackingModeKeyboard = 2
kMenuTrackingModeMouse = 1
kMenuTrademarkJapaneseGlyph = 31
kMenuUpArrowDashedGlyph = 25
kMenuUpArrowGlyph = 104

kThemeSavvyMenuResponse = 29811

mCalcItemMsg = 5
mChooseMsg = 1

mctAllItems = -98
mctLastIDIndic = -99

mDrawItemMsg = 4
mDrawMsg = 0

mPopUpMsg = 3

mSizeMsg = 2

noMark = 0

textMenuProc = 0

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
