# encoding: utf-8
# module Carbon.Scrap
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Scrap.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
