# encoding: utf-8
# module Carbon.CoreGraphics
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/CoreGraphics.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

kCGEncodingFontSpecific = 0
kCGEncodingMacRoman = 1
kCGInterpolationDefault = 0
kCGInterpolationHigh = 3
kCGInterpolationLow = 2
kCGInterpolationNone = 1
kCGLineCapButt = 0
kCGLineCapRound = 1
kCGLineCapSquare = 2
kCGLineJoinBevel = 2
kCGLineJoinMiter = 0
kCGLineJoinRound = 1
kCGPathEOFill = 1
kCGPathEOFillStroke = 4
kCGPathFill = 0
kCGPathFillStroke = 3
kCGPathStroke = 2
kCGTextClip = 7
kCGTextFill = 0
kCGTextFillClip = 4
kCGTextFillStroke = 2
kCGTextFillStrokeClip = 6
kCGTextInvisible = 3
kCGTextStroke = 1
kCGTextStrokeClip = 5

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
