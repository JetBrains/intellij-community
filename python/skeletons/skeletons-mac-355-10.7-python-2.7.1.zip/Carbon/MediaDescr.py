# encoding: utf-8
# module Carbon.MediaDescr
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/MediaDescr.pyo by generator 1.99
# no doc

# imports
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/struct.pyc

# Variables with simple values

Error = 'MediaDescr.Error'

# functions

def _fromfixed(fixed): # reliably restored by inspect
    # no doc
    pass


def _fromstr31(str31): # reliably restored by inspect
    # no doc
    pass


def _tofixed(float): # reliably restored by inspect
    # no doc
    pass


def _tostr31(str): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

ImageDescription = None # (!) real value is ''

SampleDescription = None # (!) real value is ''

SoundDescription = None # (!) real value is ''

SoundDescriptionV1 = None # (!) real value is ''

_MediaDescriptionCodec = None # (!) real value is ''

