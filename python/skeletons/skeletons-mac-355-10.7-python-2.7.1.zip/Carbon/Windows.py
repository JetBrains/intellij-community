# encoding: utf-8
# module Carbon.Windows
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Windows.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

altDBoxProc = 3

dBoxProc = 1

deskPatID = 16

dialogKind = 2

documentProc = 0

false = 0

floatGrowProc = 1987
floatProc = 1985
floatSideGrowProc = 1995
floatSideProc = 1993
floatSideZoomGrowProc = 1999
floatSideZoomProc = 1997
floatZoomGrowProc = 1991
floatZoomProc = 1989

inCollapseBox = 11
inContent = 3
inDesk = 0
inDrag = 4
inGoAway = 6
inGrow = 5
inMenuBar = 1
inNoWindow = 0
inProxyIcon = 12
inStructure = 15
inSysWindow = 2
inToolbarButton = 13
inZoomIn = 7
inZoomOut = 8

kAlertVariantCode = 7
kAlertWindowClass = 1
kAltPlainWindowClass = 16
kApplicationWindowKind = 8

kDialogWindowKind = 2
kDocumentWindowClass = 6
kDocumentWindowVariantCode = 0
kDrawerWindowClass = 20

kFloatingWindowClass = 5
kFloatingWindowDefinition = 124

kHelpWindowClass = 10

kModalDialogVariantCode = 1
kModalWindowClass = 3
kMovableAlertVariantCode = 9
kMovableAlertWindowClass = 2
kMovableModalDialogVariantCode = 5
kMovableModalWindowClass = 4

kNextWindowGroup = 1

kOverlayWindowClass = 14

kPlainDialogVariantCode = 2
kPlainWindowClass = 13
kPreviousWindowGroup = 0

kRoundWindowDefinition = 1

kScrollWindowEraseToPortBackground = 2L
kScrollWindowInvalidate = 1L
kScrollWindowNoOptions = 0
kShadowDialogVariantCode = 3
kSheetAlertWindowClass = 15
kSheetWindowClass = 11
kSideFloaterVariantCode = 8
kStandardWindowDefinition = 0
kStoredBasicWindowDescriptionID = 'sbas'
kStoredWindowPascalTitleID = 's255'
kStoredWindowSystemTag = 'appl'

kToolbarWindowClass = 12

kUtilityWindowClass = 8

kWindowActivationScopeAll = 2
kWindowActivationScopeIndependent = 1
kWindowActivationScopeNone = 0
kWindowAlertPositionMainScreen = 12298
kWindowAlertPositionOnMainScreen = 7
kWindowAlertPositionOnParentWindow = 8
kWindowAlertPositionOnParentWindowScreen = 9
kWindowAlertPositionParentWindow = 45066
kWindowAlertPositionParentWindowScreen = 28682
kWindowAlertProc = 1044
kWindowCanCollapse = 4
kWindowCanDrawInCurrentPort = 512
kWindowCanGetWindowRegion = 16
kWindowCanGrow = 1
kWindowCanMeasureTitle = 2048
kWindowCanSetupProxyDragImage = 1024
kWindowCanZoom = 2
kWindowCascadeOnMainScreen = 4
kWindowCascadeOnParentWindow = 5
kWindowCascadeOnParentWindowScreen = 6
kWindowCascadeStartAtParentWindowScreen = 10
kWindowCenterMainScreen = 10250
kWindowCenterOnMainScreen = 1
kWindowCenterOnParentWindow = 2
kWindowCenterOnParentWindowScreen = 3
kWindowCenterParentWindow = 43018
kWindowCenterParentWindowScreen = 26634
kWindowCloseBoxAttribute = 1L
kWindowCloseBoxRgn = 2
kWindowCollapseBoxAttribute = 8L
kWindowCollapseBoxRgn = 7
kWindowConstrainAllowPartial = 4L
kWindowConstrainCalcOnly = 8L
kWindowConstrainMayResize = 1L
kWindowConstrainMoveRegardlessOfFit = 2L
kWindowConstrainStandardOptions = 2L
kWindowConstrainUseTransitionWindow = 16L
kWindowContentRgn = 33
kWindowDefaultPosition = 0
kWindowDefinitionVersionOne = 1
kWindowDefinitionVersionTwo = 2
kWindowDefObjectClass = 1
kWindowDefProcID = 2
kWindowDefProcPtr = 0
kWindowDefProcType = 'WDEF'
kWindowDefSupportsColorGrafPort = 1073741826
kWindowDialogDefProcResID = 65
kWindowDocumentDefProcResID = 64
kWindowDocumentProc = 1024
kWindowDragRgn = 5
kWindowFloatFullZoomGrowProc = 1071
kWindowFloatFullZoomProc = 1069
kWindowFloatGrowProc = 1059
kWindowFloatHorizZoomGrowProc = 1067
kWindowFloatHorizZoomProc = 1065
kWindowFloatProc = 1057
kWindowFloatSideFullZoomGrowProc = 1087
kWindowFloatSideFullZoomProc = 1085
kWindowFloatSideGrowProc = 1075
kWindowFloatSideHorizZoomGrowProc = 1083
kWindowFloatSideHorizZoomProc = 1081
kWindowFloatSideProc = 1073
kWindowFloatSideVertZoomGrowProc = 1079
kWindowFloatSideVertZoomProc = 1077
kWindowFloatVertZoomGrowProc = 1063
kWindowFloatVertZoomProc = 1061
kWindowFullZoomAttribute = 6L
kWindowFullZoomDocumentProc = 1030
kWindowFullZoomGrowDocumentProc = 1031
kWindowGlobalPortRgn = 40
kWindowGroupAttrHideOnCollapse = 16
kWindowGroupAttrLayerTogether = 4
kWindowGroupAttrMoveTogether = 2
kWindowGroupAttrPositionFixed = 2
kWindowGroupAttrSelectable = 1
kWindowGroupAttrSelectAsLayer = 1
kWindowGroupAttrSharedActivation = 8
kWindowGroupAttrZOrderFixed = 4
kWindowGroupContentsRecurse = 2
kWindowGroupContentsReturnWindows = 1
kWindowGroupContentsVisible = 4
kWindowGrowDocumentProc = 1025
kWindowGrowRgn = 6
kWindowHasTitleBar = 64
kWindowHideOnFullScreenAttribute = 67108864L
kWindowHideOnSuspendAttribute = 16777216L
kWindowHideTransitionAction = 2
kWindowHorizontalZoomAttribute = 2L
kWindowHorizZoomDocumentProc = 1028
kWindowHorizZoomGrowDocumentProc = 1029
kWindowInWindowMenuAttribute = 134217728L
kWindowIsAlert = 32
kWindowIsCollapsedState = 1L
kWindowIsModal = 8
kWindowIsOpaque = 16384
kWindowLatentVisibleAppHidden = 8
kWindowLatentVisibleCollapsedGroup = 32
kWindowLatentVisibleCollapsedOwner = 16
kWindowLatentVisibleFloater = 1
kWindowLatentVisibleFullScreen = 4
kWindowLatentVisibleSuspend = 2
kWindowLiveResizeAttribute = 268435456L
kWindowMenuIncludeRotate = 1
kWindowModalDialogProc = 1042
kWindowModalityAppModal = 2
kWindowModalityNone = 0
kWindowModalitySystemModal = 1
kWindowModalityWindowModal = 3
kWindowMovableAlertProc = 1045
kWindowMovableModalDialogProc = 1043
kWindowMovableModalGrowProc = 1046
kWindowMoveTransitionAction = 3
kWindowMsgCalculateShape = 2
kWindowMsgCleanUp = 4
kWindowMsgDragHilite = 9
kWindowMsgDraw = 0
kWindowMsgDrawGrowBox = 6
kWindowMsgDrawGrowOutline = 5
kWindowMsgDrawInCurrentPort = 11
kWindowMsgGetFeatures = 7
kWindowMsgGetGrowImageRegion = 19
kWindowMsgGetRegion = 8
kWindowMsgHitTest = 1
kWindowMsgInitialize = 3
kWindowMsgMeasureTitle = 14
kWindowMsgModified = 10
kWindowMsgSetupProxyDragImage = 12
kWindowMsgStateChanged = 13
kWindowNoActivatesAttribute = 131072L
kWindowNoAttributes = 0L
kWindowNoConstrainAttribute = 2147483648
kWindowNoPosition = 0
kWindowNoShadowAttribute = 2097152L
kWindowNoUpdatesAttribute = 65536L
kWindowOpaqueForEventsAttribute = 262144L
kWindowOpaqueRgn = 35
kWindowPaintProcOptionsNone = 0
kWindowPlainDialogProc = 1040
kWindowPropertyPersistent = 1
kWindowResizableAttribute = 16L
kWindowResizeTransitionAction = 4
kWindowShadowDialogProc = 1041
kWindowSheetAlertDefProcResID = 70
kWindowSheetAlertProc = 1120
kWindowSheetDefProcResID = 68
kWindowSheetProc = 1088
kWindowSheetTransitionEffect = 2
kWindowShowTransitionAction = 1
kWindowSideTitlebarAttribute = 32L
kWindowSimpleDefProcResID = 69
kWindowSimpleFrameProc = 1105
kWindowSimpleProc = 1104
kWindowSlideTransitionEffect = 3
kWindowStaggerMainScreen = 14346
kWindowStaggerParentWindow = 47114
kWindowStaggerParentWindowScreen = 30730
kWindowStandardDocumentAttributes = 31L
kWindowStandardFloatingAttributes = 9L
kWindowStandardHandlerAttribute = 33554432L
kWindowStateTitleChanged = 1
kWindowStructureRgn = 32
kWindowSupportsDragHilite = 128
kWindowSupportsGetGrowImageRegion = 8192
kWindowSupportsModifiedBit = 256
kWindowSupportsSetGrowImageRegion = 8192
kWindowTitleBarRgn = 0
kWindowTitleProxyIconRgn = 8
kWindowTitleTextRgn = 1
kWindowToolbarButtonAttribute = 64L
kWindowUpdateRgn = 34
kWindowUtilityDefProcResID = 66
kWindowUtilitySideTitleDefProcResID = 67
kWindowVerticalZoomAttribute = 4L
kWindowVertZoomDocumentProc = 1026
kWindowVertZoomGrowDocumentProc = 1027
kWindowWantsDisposeAtProcessDeath = 4096
kWindowZoomBoxRgn = 3
kWindowZoomTransitionEffect = 1

movableDBoxProc = 5

noGrowDocProc = 4

plainDBox = 2

rDocProc = 16

true = 1

userKind = 8

wCalcRgns = 2
wContentColor = 0

wDispose = 4
wDraw = 0
wDrawGIcon = 6

wFrameColor = 1

wGrow = 5

wHiliteColor = 3
wHit = 1

wInCollapseBox = 9
wInContent = 1
wInDrag = 2
wInGoAway = 4
wInGrow = 3
wInProxyIcon = 10
wInStructure = 13
wInToolbarButton = 11
wInZoomIn = 5
wInZoomOut = 6

wNew = 3
wNoHit = 0

wTextColor = 2
wTitleBarColor = 4

zoomDocProc = 8
zoomNoGrow = 12

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
