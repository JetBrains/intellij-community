# encoding: utf-8
# module Carbon.Resources
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Resources.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

kResFileNotOpened = -1
kRsrcChainAboveAllMaps = 4
kRsrcChainAboveApplicationMap = 2
kRsrcChainBelowApplicationMap = 1
kRsrcChainBelowSystemMap = 0

kSystemResFile = 0

mapChanged = 32
mapChangedBit = 5
mapCompact = 64
mapCompactBit = 6
mapReadOnly = 128
mapReadOnlyBit = 7

resChanged = 2
resChangedBit = 1
resLocked = 16
resLockedBit = 4
resPreload = 4
resPreloadBit = 2
resProtected = 8
resProtectedBit = 3
resPurgeable = 32
resPurgeableBit = 5
resSysHeap = 64
resSysHeapBit = 6
resSysRefBit = 7

# no functions
# no classes
