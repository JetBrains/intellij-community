# encoding: utf-8
# module Carbon.Components
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Components.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

cmpAliasNoFlags = 0
cmpAliasOnlyThisFile = 1
cmpIsMissing = 536870912L
cmpWantsRegisterMessage = 2147483648L

componentAutoVersionIncludeFlags = 4
componentDoAutoVersion = 1
componentHasMultiplePlatforms = 8
componentLoadResident = 16
componentWantsUnregister = 2

defaultComponentAnyFlags = 1
defaultComponentAnyFlagsAnyManufacturer = 3
defaultComponentAnyFlagsAnyManufacturerAnySubType = 7
defaultComponentAnyManufacturer = 2
defaultComponentAnySubType = 4
defaultComponentIdentical = 0

kAnyComponentFlagsMask = 0
kAnyComponentManufacturer = 0
kAnyComponentSubType = 0
kAnyComponentType = 0
kAppleManufacturer = 'appl'

kComponentAliasResourceType = 'thga'
kComponentCanDoSelect = -3
kComponentCloseSelect = -2
kComponentExecuteWiredActionSelect = -9
kComponentGetMPWorkFunctionSelect = -8
kComponentGetPublicResourceSelect = -10
kComponentOpenSelect = -1
kComponentRegisterSelect = -5
kComponentResourceType = 'thng'
kComponentTargetSelect = -6
kComponentUnregisterSelect = -7
kComponentVersionSelect = -4

mpWorkFlagCopyWorkBlock = 4
mpWorkFlagDoCompletion = 2
mpWorkFlagDontBlock = 8
mpWorkFlagDoWork = 1
mpWorkFlagGetIsRunning = 64
mpWorkFlagGetProcessorCount = 16

platform68k = 1
platformInterpreted = 3
platformPowerPC = 2
platformPowerPCNativeEntryPoint = 5
platformWin32 = 4

registerComponentAfterExisting = 4
registerComponentAliasesOnly = 8
registerComponentGlobal = 1
registerComponentNoDuplicates = 2

uppCallComponentCanDoProcInfo = 752
uppCallComponentCloseProcInfo = 1008
uppCallComponentGetMPWorkFunctionProcInfo = 4080
uppCallComponentGetPublicResourceProcInfo = 15344
uppCallComponentOpenProcInfo = 1008
uppCallComponentRegisterProcInfo = 240
uppCallComponentTargetProcInfo = 1008
uppCallComponentUnregisterProcInfo = 240
uppCallComponentVersionProcInfo = 240
uppComponentFunctionImplementedProcInfo = 752
uppComponentSetTargetProcInfo = 1008
uppGetComponentVersionProcInfo = 240

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
