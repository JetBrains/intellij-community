# encoding: utf-8
# module Carbon.Lists
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Lists.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

kListDefProcPtr = 0
kListDefStandardIconType = 2
kListDefStandardTextType = 1
kListDefUserProcType = 0

lCloseMsg = 3

lDoHAutoscroll = 1
lDoHAutoscrollBit = 0
lDoVAutoscroll = 2
lDoVAutoscrollBit = 1
lDrawingModeOff = 8
lDrawingModeOffBit = 3
lDrawMsg = 1

lExtendDrag = 64
lExtendDragBit = 6

lHiliteMsg = 2

lInitMsg = 0

listNotifyClick = 'clik'
listNotifyDoubleClick = 'dblc'
listNotifyNothing = 'nada'
listNotifyPreClick = 'pclk'

lNoDisjoint = 32
lNoDisjointBit = 5
lNoExtend = 16
lNoExtendBit = 4
lNoNilHilite = 2
lNoNilHiliteBit = 1
lNoRect = 8
lNoRectBit = 3

lOnlyOne = -128
lOnlyOneBit = 7

lUseSense = 4
lUseSenseBit = 2

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
