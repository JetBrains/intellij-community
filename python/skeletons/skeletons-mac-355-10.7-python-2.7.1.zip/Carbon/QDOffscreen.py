# encoding: utf-8
# module Carbon.QDOffscreen
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/QDOffscreen.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

alignPix = 262144L
alignPixBit = 18

clipPix = 268435456L
clipPixBit = 28

deviceIsAScreen = 128L
deviceIsDCISurface = 32L
deviceIsDDSurface = 16L
deviceIsExternalBuffer = 8L
deviceIsGDISurface = 64L
deviceIsIndirect = 1L
deviceIsOverlaySurface = 256L
deviceIsStatic = 4L
deviceNeedsLock = 2L

ditherPix = 1073741824L
ditherPixBit = 30

gwFlagErr = 2147483648L
gwFlagErrBit = 31

kAllocDirectDrawSurface = 16384L

keepLocal = 8L
keepLocalBit = 3

mapPix = 65536L
mapPixBit = 16

newDepth = 131072L
newDepthBit = 17
newRowBytes = 524288L
newRowBytesBit = 19

noNewDevice = 2L
noNewDeviceBit = 1

pixelsLocked = 128L
pixelsLockedBit = 7
pixelsPurgeable = 64L
pixelsPurgeableBit = 6
pixPurge = 1L
pixPurgeBit = 0

reallocPix = 1048576L
reallocPixBit = 20

stretchPix = 536870912L
stretchPixBit = 29

useDistantHdwrMem = 16L
useDistantHdwrMemBit = 4
useLocalHdwrMem = 32L
useLocalHdwrMemBit = 5
useTempMem = 4L
useTempMemBit = 2

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
