# encoding: utf-8
# module Carbon.Res
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Res.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _Res import (CloseResFile, Count1Resources, Count1Types, CountResources, 
    CountTypes, CurResFile, DetachResourceFile, FSOpenResFile, 
    FSOpenResourceFile, Get1IndResource, Get1IndType, Get1NamedResource, 
    Get1Resource, GetIndResource, GetIndType, GetNamedResource, 
    GetResFileAttrs, GetResource, Handle, InsertResourceFile, ResError, 
    Resource, ResourceType, SetResFileAttrs, SetResLoad, SetResPurge, 
    Unique1ID, UniqueID, UpdateResFile, UseResFile)


# no functions
# no classes
