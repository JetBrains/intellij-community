# encoding: utf-8
# module Carbon.OSA
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/OSA.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _OSA import OSAComponentInstance, OSAComponentInstanceType


# no functions
# no classes
