# encoding: utf-8
# module Carbon.MacHelp
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/MacHelp.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

errHMIllegalContentForMaximumState = -10981
errHMIllegalContentForMinimumState = -10980

kHelpTagEventHandlerTag = 'hevt'
kHMAbsoluteCenterAligned = 23
kHMBottomLeftCorner = 9
kHMBottomRightCorner = 10
kHMBottomSide = 3
kHMCFStringContent = 'cfst'
kHMContentNotProvided = 1
kHMContentNotProvidedDontPropagate = 2
kHMContentProvided = 0
kHMDefaultSide = 0
kHMDisposeContent = 1
kHMIllegalContentForMinimumState = -10980
kHMInsideBottomCenterAligned = 17
kHMInsideBottomLeftCorner = 21
kHMInsideBottomRightCorner = 22
kHMInsideLeftCenterAligned = 16
kHMInsideRightCenterAligned = 15
kHMInsideTopCenterAligned = 18
kHMInsideTopLeftCorner = 19
kHMInsideTopRightCorner = 20
kHMLeftBottomCorner = 8
kHMLeftSide = 2
kHMLeftTopCorner = 7
kHMMaximumContentIndex = 1
kHMMinimumContentIndex = 0
kHMNoContent = 'none'
kHMOutsideBottomCenterAligned = 14
kHMOutsideBottomLeftAligned = 9
kHMOutsideBottomRightAligned = 10
kHMOutsideBottomScriptAligned = 3
kHMOutsideLeftBottomAligned = 8
kHMOutsideLeftCenterAligned = 2
kHMOutsideLeftTopAligned = 7
kHMOutsideRightBottomAligned = 12
kHMOutsideRightCenterAligned = 4
kHMOutsideRightTopAligned = 11
kHMOutsideTopCenterAligned = 13
kHMOutsideTopLeftAligned = 5
kHMOutsideTopRightAligned = 6
kHMOutsideTopScriptAligned = 1
kHMPascalStrContent = 'pstr'
kHMRightBottomCorner = 12
kHMRightSide = 4
kHMRightTopCorner = 11
kHMStringResContent = 'str#'
kHMStrResContent = 'str '
kHMSupplyContent = 0
kHMTEHandleContent = 'txth'
kHMTextResContent = 'text'
kHMTopLeftCorner = 5
kHMTopRightCorner = 6
kHMTopSide = 1

kMacHelpVersion = 3

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
