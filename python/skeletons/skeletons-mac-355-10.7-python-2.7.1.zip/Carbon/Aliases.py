# encoding: utf-8
# module Carbon.Aliases
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Aliases.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

asiAliasName = 0
asiParentName = 1
asiServerName = -2
asiVolumeName = -1
asiZoneName = -3

false = False

kARMMountVol = 1
kARMMultVols = 8
kARMNoUI = 2
kARMSearch = 256
kARMSearchMore = 512
kARMSearchRelFirst = 1024

kResolveAliasFileNoUI = 1

rAliasType = 'alis'

true = True

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
