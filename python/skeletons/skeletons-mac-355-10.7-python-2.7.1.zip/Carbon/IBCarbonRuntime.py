# encoding: utf-8
# module Carbon.IBCarbonRuntime
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/IBCarbonRuntime.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

kIBCarbonRuntimeCantFindNibFile = -10960
kIBCarbonRuntimeCantFindObject = -10962
kIBCarbonRuntimeObjectNotOfRequestedType = -10961

# no functions
# no classes
