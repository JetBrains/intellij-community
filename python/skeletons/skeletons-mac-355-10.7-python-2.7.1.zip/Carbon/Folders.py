# encoding: utf-8
# module Carbon.Folders
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/Carbon/Folders.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

false = False

kALMLocationsFolderType = 'fall'
kALMModulesFolderType = 'walk'
kALMPreferencesFolderType = 'trip'
kAppearanceFolderType = 'appr'
kAppleExtrasFolderType = 'aex\xc4'
kAppleMenuFolderType = 'amnu'
kAppleShareAuthenticationFolderType = 'auth'
kAppleshareAutomountServerAliasesFolderType = 'srv\xc4'
kAppleShareSupportFolderType = 'shar'
kApplicationsFolderType = 'apps'
kApplicationSupportFolderType = 'asup'
kAssistantsFolderType = 'ast\xc4'
kAudioAlertSoundsFolderType = 'alrt'
kAudioComponentsFolderType = 'acmp'
kAudioPlugInsFolderType = 'aplg'
kAudioSoundBanksFolderType = 'bank'
kAudioSoundsFolderType = 'asnd'
kAudioSupportFolderType = 'adio'

kBlessedFolder = 'blsf'

kCachedDataFolderType = 'cach'
kCarbonLibraryFolderType = 'carb'
kChewableItemsFolderType = 'flnt'
kClassicDesktopFolderType = 'sdsk'
kClassicDomain = -32762
kColorSyncCMMFolderType = 'ccmm'
kColorSyncFolderType = 'sync'
kColorSyncProfilesFolderType = 'prof'
kColorSyncScriptingFolderType = 'cscr'
kComponentsFolderType = 'cmpd'
kContextualMenuItemsFolderType = 'cmnu'
kControlPanelDisabledFolderType = 'ctrD'
kControlPanelFolderType = 'ctrl'
kControlStripModulesFolderType = 'sdev'
kCoreServicesFolderType = 'csrv'
kCreateFolder = True
kCreateFolderAtBoot = 2
kCreateFolderAtBootBit = 1
kCurrentUserFolderLocation = 'cusf'
kCurrentUserFolderType = 'cusr'
kCurrentUserRemoteFolderLocation = 'rusf'
kCurrentUserRemoteFolderType = 'rusr'

kDesktopFolderType = 'desk'
kDesktopPicturesFolderType = 'dtp\xc4'
kDeveloperDocsFolderType = 'ddoc'
kDeveloperFolderType = 'devf'
kDeveloperHelpFolderType = 'devh'
kDirectoryServicesFolderType = 'dsrv'
kDirectoryServicesPlugInsFolderType = 'dplg'
kDisplayExtensionsFolderType = 'dspl'
kDocumentationFolderType = 'info'
kDocumentsFolderType = 'docs'
kDomainLibraryFolderType = 'dlib'
kDomainTopLevelFolderType = 'dtop'
kDoNotRemoveWheCurrentApplicationQuitsBit = 0
kDoNotRemoveWhenCurrentApplicationQuitsBit = 0
kDontCreateFolder = False

kEditorsFolderType = 'oded'
kExtensionDisabledFolderType = 'extD'
kExtensionFolderType = 'extn'

kFavoritesFolderType = 'favs'
kFileSystemSupportFolderType = 'fsys'
kFindByContentFolderType = 'fbcf'
kFindByContentPluginsFolderType = 'fbcp'
kFindFolderExtendedFlagsDoNotFollowAliasesBit = 0
kFindFolderExtendedFlagsDoNotUseUserFolderBit = 1
kFindFolderExtendedFlagsUseOtherUserRecord = 16777216
kFindFolderRedirectionFlagsUseGivenVRefNumAndDirIDAsRemoteUserFolderBit = 2
kFindFolderRedirectionFlagUseDistinctUserFoldersBit = 0
kFindFolderRedirectionFlagUseGivenVRefAndDirIDAsUserFolderBit = 1
kFindSupportFolderType = 'fnds'
kFolderActionsFolderType = 'fasf'
kFolderCreatedAdminPrivs = 16
kFolderCreatedAdminPrivsBit = 4
kFolderCreatedInvisible = 4
kFolderCreatedInvisibleBit = 2
kFolderCreatedNameLocked = 8
kFolderCreatedNameLockedBit = 3
kFolderInLocalOrRemoteUserFolder = 160
kFolderInRemoteUserFolderIfAvailable = 128
kFolderInRemoteUserFolderIfAvailableBit = 7
kFolderInUserFolder = 32
kFolderInUserFolderBit = 5
kFolderManagerFolderInMacOS9FolderIfMacOSXIsInstalledBit = 10
kFolderManagerFolderInMacOS9FolderIfMacOSXIsInstalledMask = 1024
kFolderManagerNotificationDiscardCachedData = 'dche'
kFolderManagerNotificationMessageLoginStartup = 'stup'
kFolderManagerNotificationMessagePostUserLogOut = 'logp'
kFolderManagerNotificationMessagePreUserLogIn = 'logj'
kFolderManagerNotificationMessageUserLogIn = 'log+'
kFolderManagerNotificationMessageUserLogOut = 'log-'
kFolderManagerUserRedirectionGlobalsCurrentVersion = 1
kFolderMustStayOnSameVolume = 512
kFolderMustStayOnSameVolumeBit = 9
kFolderNeverMatchedInIdentifyFolder = 256
kFolderNeverMatchedInIdentifyFolderBit = 8
kFolderTrackedByAlias = 64
kFolderTrackedByAliasBit = 6
kFontsFolderType = 'font'
kFrameworksFolderType = 'fram'

kGenEditorsFolderType = '\xc4edi'

kHelpFolderType = '\xc4hlp'

kInstallerLogsFolderType = 'ilgf'
kInstallerReceiptsFolderType = 'rcpt'
kInternetFolderType = 'int\xc4'
kInternetPlugInFolderType = '\xc4net'
kInternetSearchSitesFolderType = 'issf'
kInternetSitesFolderType = 'site'
kISSDownloadsFolderType = 'issd'

kKernelExtensionsFolderType = 'kext'
kKeychainFolderType = 'kchn'

kLauncherItemsFolderType = 'laun'
kLocalDomain = -32765
kLocalesFolderType = '\xc4loc'

kMacOSReadMesFolderType = 'mor\xc4'
kMIDIDriversFolderType = 'midi'
kModemScriptsFolderType = '\xc4mod'
kMovieDocumentsFolderType = 'mdoc'
kMultiprocessingFolderType = 'mpxf'
kMusicDocumentsFolderType = '\xb5doc'

kNetworkDomain = -32764

kOnAppropriateDisk = -32767
kOnSystemDisk = -32768L
kOpenDocEditorsFolderType = '\xc4odf'
kOpenDocFolderType = 'odod'
kOpenDocLibrariesFolderType = 'odlb'
kOpenDocShellPlugInsFolderType = 'odsp'

kPictureDocumentsFolderType = 'pdoc'
kPreferencesFolderType = 'pref'
kPreMacOS91AppleExtrasFolderType = '\x8cex\xc4'
kPreMacOS91ApplicationsFolderType = '\x8cpps'
kPreMacOS91AssistantsFolderType = '\x8cst\xc4'
kPreMacOS91AutomountedServersFolderType = '\xa7rv\xc4'
kPreMacOS91InstallerLogsFolderType = '\x94lgf'
kPreMacOS91InternetFolderType = '\x94nt\xc4'
kPreMacOS91MacOSReadMesFolderType = '\xb5or\xc4'
kPreMacOS91StationeryFolderType = '\xbfdst'
kPreMacOS91UtilitiesFolderType = '\x9fti\xc4'
kPrinterDescriptionFolderType = 'ppdf'
kPrinterDriverFolderType = '\xc4prd'
kPrintersFolderType = 'impr'
kPrintingPlugInsFolderType = 'pplg'
kPrintMonitorDocsFolderType = 'prnt'
kPrivateFrameworksFolderType = 'pfrm'
kPublicFolderType = 'pubb'

kQuickTimeComponentsFolderType = 'wcmp'
kQuickTimeExtensionsFolderType = 'qtex'

kRecentApplicationsFolderType = 'rapp'
kRecentDocumentsFolderType = 'rdoc'
kRecentServersFolderType = 'rsvr'
kRelativeFolder = 'relf'
kRootFolder = 'rotf'

kScriptingAdditionsFolderType = '\xc4scr'
kScriptsFolderType = 'scr\xc4'
kSharedLibrariesFolderType = '\xc4lib'
kSharedUserDataFolderType = 'sdat'
kShutdownFolderType = 'shdf'
kShutdownItemsDisabledFolderType = 'shdD'
kSoundSetsFolderType = 'snds'
kSpeakableItemsFolderType = 'spki'
kSpecialFolder = 'spcf'
kSpeechFolderType = 'spch'
kStartupFolderType = 'strt'
kStartupItemsDisabledFolderType = 'strD'
kStationeryFolderType = 'odst'
kStopIfAnyNotificationProcReturnsErrorBit = 31
kSystemControlPanelFolderType = 'sctl'
kSystemDesktopFolderType = 'sdsk'
kSystemDomain = -32766
kSystemExtensionDisabledFolderType = 'macD'
kSystemFolderType = 'macs'
kSystemPreferencesFolderType = 'sprf'
kSystemSoundsFolderType = 'ssnd'
kSystemTrashFolderType = 'strs'

kTemporaryFolderType = 'temp'
kTextEncodingsFolderType = '\xc4tex'
kThemesFolderType = 'thme'
kTrashFolderType = 'trsh'

kUserDomain = -32763
kUsersFolderType = 'usrs'
kUserSpecificTmpFolderType = 'utmp'
kUtilitiesFolderType = 'uti\xc4'

kVoicesFolderType = 'fvoc'
kVolumeRootFolderType = 'root'
kVolumeSettingsFolderType = 'vsfd'

kWhereToEmptyTrashFolderType = 'empt'

true = True

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
