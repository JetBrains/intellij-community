# encoding: utf-8
# module json.scanner
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/json/scanner.pyo by generator 1.99
""" JSON token scanner """

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
from _json import c_make_scanner, make_scanner


# functions

def py_make_scanner(context): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

NUMBER_RE = None # (!) real value is ''

__all__ = [
    'make_scanner',
]

