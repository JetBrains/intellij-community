# encoding: utf-8
# module json.tool
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/json/tool.pyo by generator 1.99
"""
Command-line tool to validate and pretty-print JSON

Usage::

    $ echo '{"json":"obj"}' | python -m json.tool
    {
        "json": "obj"
    }
    $ echo '{ 1.2:3.4}' | python -m json.tool
    Expecting property name: line 1 column 2 (char 2)
"""

# imports
import sys as sys # <module 'sys' (built-in)>
import json as json # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/json/__init__.pyc

# functions

def main(): # reliably restored by inspect
    # no doc
    pass


# no classes
