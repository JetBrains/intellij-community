# encoding: utf-8
# module OpenSSL.tsafe calls itself tsafe
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/twisted/test/raiser.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
# variables with complex values

Connection = None # (!) real value is ''

__weakref__ = None # (!) real value is ''

