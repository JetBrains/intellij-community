# encoding: utf-8
# module importlib.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/importlib/__init__.pyo by generator 1.99
""" Backport of importlib.import_module from 3.x. """

# imports
import sys as sys # <module 'sys' (built-in)>

# functions

def import_module(name, package=None): # reliably restored by inspect
    """
    Import a module.
    
        The 'package' argument is required when performing a relative import. It
        specifies the package to use as the anchor point from which to resolve the
        relative import to an absolute import.
    """
    pass


def _resolve_name(name, package, level): # reliably restored by inspect
    """ Return the absolute name of the module to be imported. """
    pass


# no classes
