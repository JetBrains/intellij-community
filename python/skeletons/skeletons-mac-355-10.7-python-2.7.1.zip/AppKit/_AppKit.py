# encoding: utf-8
# module AppKit._AppKit
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/PyObjC/AppKit/_AppKit.so by generator 1.99
# no doc
# no imports

# functions

def NSApplicationMain(int_argc, const_char, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ int NSApplicationMain(int argc, const char *argv[]); """
    pass


def NSConvertGlyphsToPackedGlyphs(*args, **kwargs): # real signature unknown
    pass


# no classes
