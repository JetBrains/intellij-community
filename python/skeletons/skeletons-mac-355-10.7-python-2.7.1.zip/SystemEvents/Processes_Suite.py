# encoding: utf-8
# module SystemEvents.Processes_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Processes_Suite.pyo by generator 1.99
"""
Suite Processes Suite: Terms and Events for controlling Processes
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import SystemEvents.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyc
import SystemEvents.Disk_Folder_File_Suite as Disk_Folder_File_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Disk_Folder_File_Suite.pyc
import SystemEvents.Folder_Actions_Suite as Folder_Actions_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Folder_Actions_Suite.pyc
import SystemEvents.Login_Items_Suite as Login_Items_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Login_Items_Suite.pyc

# Variables with simple values

_code = 'prcs'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

applications = application

application_process = None # (!) real value is ''

application_processes = application_process

desk_accessory_process = None # (!) real value is ''

desk_accessory_processes = desk_accessory_process

folder_actions_enabled = None # (!) real value is ''

process = None # (!) real value is ''

processes = process

Processes_Suite_Events = None # (!) real value is ''

properties = None # (!) real value is ''

_3c_Inheritance_3e_ = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
    'pcap': application_process,
    'pcda': desk_accessory_process,
    'prcs': process,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'appf': None, # (!) forward: _Prop_application_file, real value is ''
    'appt': None, # (!) forward: _Prop_total_partition_size, real value is ''
    'asty': None, # (!) forward: _Prop_file_type, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'clsc': None, # (!) forward: _Prop_classic, real value is ''
    'dafi': None, # (!) forward: _Prop_desk_accessory_file, real value is ''
    'faen': None, # (!) forward: _Prop_folder_actions_enabled, real value is ''
    'fcrt': None, # (!) forward: _Prop_creator_type, real value is ''
    'file': None, # (!) forward: _Prop_file, real value is ''
    'hscr': None, # (!) forward: _Prop_has_scripting_terminology, real value is ''
    'isab': None, # (!) forward: _Prop_accepts_high_level_events, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
    'pisf': None, # (!) forward: _Prop_frontmost, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'pusd': None, # (!) forward: _Prop_partition_space_used, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'revt': None, # (!) forward: _Prop_accepts_remote_events, real value is ''
}

_Prop_accepts_high_level_events = None # (!) real value is ''

_Prop_accepts_remote_events = None # (!) real value is ''

_Prop_application_file = None # (!) real value is ''

_Prop_classic = None # (!) real value is ''

_Prop_creator_type = None # (!) real value is ''

_Prop_desk_accessory_file = None # (!) real value is ''

_Prop_file = None # (!) real value is ''

_Prop_file_type = None # (!) real value is ''

_Prop_folder_actions_enabled = None # (!) real value is ''

_Prop_frontmost = None # (!) real value is ''

_Prop_has_scripting_terminology = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_partition_space_used = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop_total_partition_size = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

