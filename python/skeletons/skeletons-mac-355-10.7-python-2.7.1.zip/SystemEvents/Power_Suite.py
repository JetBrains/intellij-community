# encoding: utf-8
# module SystemEvents.Power_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Power_Suite.pyo by generator 1.99
"""
Suite Power Suite: Terms and Events for controlling System power
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import SystemEvents.Processes_Suite as Processes_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Processes_Suite.pyc
import SystemEvents.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import SystemEvents.Disk_Folder_File_Suite as Disk_Folder_File_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Disk_Folder_File_Suite.pyc
import SystemEvents.Folder_Actions_Suite as Folder_Actions_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Folder_Actions_Suite.pyc
import SystemEvents.Login_Items_Suite as Login_Items_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Login_Items_Suite.pyc

# Variables with simple values

_code = 'powr'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

applications = application

folder_actions_enabled = None # (!) real value is ''

Power_Suite_Events = None # (!) real value is ''

properties = None # (!) real value is ''

_3c_Inheritance_3e_ = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'faen': None, # (!) forward: _Prop_folder_actions_enabled, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
}

_Prop_folder_actions_enabled = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

