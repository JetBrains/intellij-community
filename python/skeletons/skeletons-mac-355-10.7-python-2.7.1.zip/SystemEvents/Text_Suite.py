# encoding: utf-8
# module SystemEvents.Text_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Text_Suite.pyo by generator 1.99
"""
Suite Text Suite: A set of basic classes for text processing.
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import SystemEvents.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = '????'

# no functions
# no classes
# variables with complex values

attachment = None # (!) real value is ''

attribute_run = None # (!) forward: attribute_runs, real value is ''

attribute_runs = None # (!) real value is ''

character = None # (!) forward: characters, real value is ''

characters = None # (!) real value is ''

paragraph = None # (!) forward: paragraphs, real value is ''

paragraphs = None # (!) real value is ''

text = None # (!) real value is ''

Text_Suite_Events = None # (!) real value is ''

word = None # (!) real value is ''

words = word

_classdeclarations = {
    'atts': attachment,
    'catr': attribute_runs,
    'cha ': characters,
    'cpar': paragraphs,
    'ctxt': text,
    'cwor': word,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'atfn': None, # (!) forward: _Prop_file_name, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'colr': None, # (!) forward: _Prop_color, real value is ''
    'font': None, # (!) forward: _Prop_font, real value is ''
    'ptsz': None, # (!) forward: _Prop_size, real value is ''
}

_Prop_color = None # (!) real value is ''

_Prop_file_name = None # (!) real value is ''

_Prop_font = None # (!) real value is ''

_Prop_size = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

