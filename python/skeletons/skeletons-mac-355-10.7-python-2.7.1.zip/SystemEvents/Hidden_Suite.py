# encoding: utf-8
# module SystemEvents.Hidden_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Hidden_Suite.pyo by generator 1.99
"""
Suite Hidden Suite: Hidden Terms and Events for controlling the System Events application
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'tpnm'

# no functions
# no classes
# variables with complex values

application_dictionary = None # (!) real value is ''

bounding_rectangle = None # (!) real value is ''

color_table = None # (!) real value is ''

dash_style = None # (!) real value is ''

double_integer = None # (!) real value is ''

extended_real = None # (!) real value is ''

fixed = None # (!) real value is ''

fixed_point = None # (!) real value is ''

fixed_rectangle = None # (!) real value is ''

Hidden_Suite_Events = None # (!) real value is ''

location_reference = None # (!) real value is ''

long_fixed = None # (!) real value is ''

long_fixed_point = None # (!) real value is ''

long_fixed_rectangle = None # (!) real value is ''

long_point = None # (!) real value is ''

long_rectangle = None # (!) real value is ''

machine_location = None # (!) real value is ''

menu = None # (!) real value is ''

menu_item = None # (!) real value is ''

null = None # (!) real value is ''

pixel_map_record = None # (!) real value is ''

plain_text = None # (!) forward: string, real value is ''

point = None # (!) real value is ''

PostScript_picture = None # (!) real value is ''

RGB16_color = None # (!) real value is ''

RGB96_color = None # (!) real value is ''

rotation = None # (!) real value is ''

scrap_styles = None # (!) real value is ''

small_integer = None # (!) real value is ''

small_real = None # (!) real value is ''

string = None # (!) real value is ''

system_dictionary = None # (!) real value is ''

target_id = None # (!) real value is ''

TIFF_picture = None # (!) real value is ''

type_class_info = None # (!) real value is ''

type_element_info = None # (!) real value is ''

type_event_info = None # (!) real value is ''

Type_Names_Suite_Events = None # (!) real value is ''

type_parameter_info = None # (!) real value is ''

type_property_info = None # (!) real value is ''

type_suite_info = None # (!) real value is ''

unsigned_integer = None # (!) real value is ''

version = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {}

