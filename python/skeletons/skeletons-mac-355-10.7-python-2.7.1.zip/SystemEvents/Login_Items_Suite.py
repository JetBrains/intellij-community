# encoding: utf-8
# module SystemEvents.Login_Items_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Login_Items_Suite.pyo by generator 1.99
"""
Suite Login Items Suite: Terms and Events for controlling the Login Items application
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import SystemEvents.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyc

# Variables with simple values

_code = 'logi'

# no functions
# no classes
# variables with complex values

login_item = None # (!) forward: login_items, real value is ''

login_items = None # (!) real value is ''

Login_Items_Suite_Events = None # (!) real value is ''

_classdeclarations = {
    'logi': login_items,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'hidn': None, # (!) forward: _Prop_hidden, real value is ''
    'kind': None, # (!) forward: _Prop_kind, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'ppth': None, # (!) forward: _Prop_path, real value is ''
}

_Prop_hidden = None # (!) real value is ''

_Prop_kind = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_path = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

