# encoding: utf-8
# module SystemEvents.Disk_Folder_File_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Disk_Folder_File_Suite.pyo by generator 1.99
"""
Suite Disk-Folder-File Suite: Terms and Events for controlling Disks, Folders, and Files
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import SystemEvents.Processes_Suite as Processes_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Processes_Suite.pyc
import SystemEvents.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyc
import SystemEvents.Folder_Actions_Suite as Folder_Actions_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Folder_Actions_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import SystemEvents.Login_Items_Suite as Login_Items_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Login_Items_Suite.pyc

# Variables with simple values

_code = 'cdis'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

applications = application

disk = None # (!) real value is ''

disks = disk

Disk_Folder_File_Suite_Events = None # (!) real value is ''

file = None # (!) real value is ''

files = file

folder = None # (!) real value is ''

folders = folder

folder_actions_enabled = None # (!) real value is ''

item = None # (!) forward: items, real value is ''

items = None # (!) real value is ''

properties = None # (!) real value is ''

_3c_Inheritance_3e_ = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
    'cdis': disk,
    'cfol': folder,
    'cobj': items,
    'file': file,
}

_compdeclarations = {}

_enumdeclarations = {
    'edfm': {
        'AppleShare_format': 'dfas',
        'Apple_Photo_format': 'dfph',
        'High_Sierra_format': 'dfhs',
        'ISO_9660_format': 'df96',
        'MS_2d_DOS_format': 'dfms',
        'Mac_OS_Extended_format': 'dfh+',
        'Mac_OS_format': 'dfhf',
        'NFS_format': 'dfnf',
        'ProDOS_format': 'dfpr',
        'QuickTake_format': 'dfqt',
        'UDF_format': 'dfud',
        'UFS_format': 'dfuf',
        'WebDAV_format': 'dfwd',
        'audio_format': 'dfau',
        'unknown_format': 'df??',
    },
}

_Enum_edfm = {
    'AppleShare_format': 'dfas',
    'Apple_Photo_format': 'dfph',
    'High_Sierra_format': 'dfhs',
    'ISO_9660_format': 'df96',
    'MS_2d_DOS_format': 'dfms',
    'Mac_OS_Extended_format': 'dfh+',
    'Mac_OS_format': 'dfhf',
    'NFS_format': 'dfnf',
    'ProDOS_format': 'dfpr',
    'QuickTake_format': 'dfqt',
    'UDF_format': 'dfud',
    'UFS_format': 'dfuf',
    'WebDAV_format': 'dfwd',
    'audio_format': 'dfau',
    'unknown_format': 'df??',
}

_propdeclarations = {
    'ascd': None, # (!) forward: _Prop_creation_date, real value is ''
    'asmo': None, # (!) forward: _Prop_modification_date, real value is ''
    'asty': None, # (!) forward: _Prop_file_type, real value is ''
    'busy': None, # (!) forward: _Prop_busy_status, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'capa': None, # (!) forward: _Prop_capacity, real value is ''
    'dfmt': None, # (!) forward: _Prop_format, real value is ''
    'extn': None, # (!) forward: _Prop_name_extension, real value is ''
    'faen': None, # (!) forward: _Prop_folder_actions_enabled, real value is ''
    'fcrt': None, # (!) forward: _Prop_creator_type, real value is ''
    'frsp': None, # (!) forward: _Prop_free_space, real value is ''
    'igpr': None, # (!) forward: _Prop_ignore_privileges, real value is ''
    'isej': None, # (!) forward: _Prop_ejectable, real value is ''
    'isrv': None, # (!) forward: _Prop_local_volume, real value is ''
    'istd': None, # (!) forward: _Prop_startup, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
    'phys': None, # (!) forward: _Prop_physical_size, real value is ''
    'pkgf': None, # (!) forward: _Prop_package_folder, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'posx': None, # (!) forward: _Prop_POSIX_path, real value is ''
    'ppth': None, # (!) forward: _Prop_path, real value is ''
    'pspd': None, # (!) forward: _Prop_stationery, real value is ''
    'ptsz': None, # (!) forward: _Prop_size, real value is ''
    'url ': None, # (!) forward: _Prop_url, real value is ''
    'ver2': None, # (!) forward: _Prop_product_version, real value is ''
    'vers': None, # (!) forward: _Prop_version, real value is ''
    'visi': None, # (!) forward: _Prop_visible, real value is ''
    'volu': None, # (!) forward: _Prop_volume, real value is ''
}

_Prop_busy_status = None # (!) real value is ''

_Prop_capacity = None # (!) real value is ''

_Prop_creation_date = None # (!) real value is ''

_Prop_creator_type = None # (!) real value is ''

_Prop_ejectable = None # (!) real value is ''

_Prop_file_type = None # (!) real value is ''

_Prop_folder_actions_enabled = None # (!) real value is ''

_Prop_format = None # (!) real value is ''

_Prop_free_space = None # (!) real value is ''

_Prop_ignore_privileges = None # (!) real value is ''

_Prop_local_volume = None # (!) real value is ''

_Prop_modification_date = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_name_extension = None # (!) real value is ''

_Prop_package_folder = None # (!) real value is ''

_Prop_path = None # (!) real value is ''

_Prop_physical_size = None # (!) real value is ''

_Prop_POSIX_path = None # (!) real value is ''

_Prop_product_version = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop_size = None # (!) real value is ''

_Prop_startup = None # (!) real value is ''

_Prop_stationery = None # (!) real value is ''

_Prop_url = None # (!) real value is ''

_Prop_version = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_volume = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

