# encoding: utf-8
# module SystemEvents.Standard_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyo by generator 1.99
"""
Suite Standard Suite: Common classes and commands for most applications.
Level 1, version 1

Generated from /System/Library/CoreServices/System Events.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = '????'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

applications = application

color = None # (!) real value is ''

colors = color

contains = None # (!) real value is ''

document = None # (!) forward: documents, real value is ''

documents = None # (!) real value is ''

ends_with = None # (!) real value is ''

frontmost = None # (!) real value is ''

item = None # (!) forward: items, real value is ''

items = None # (!) real value is ''

name = None # (!) real value is ''

Standard_Suite_Events = None # (!) real value is ''

starts_with = None # (!) real value is ''

version = None # (!) real value is ''

window = None # (!) real value is ''

windows = window

_3c_ = None # (!) real value is ''

_3c_Inheritance_3e_ = None # (!) real value is ''

_3d_ = None # (!) real value is ''

_3e_ = None # (!) real value is ''

_b2_ = None # (!) real value is ''

_b3_ = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
    'cobj': items,
    'colr': color,
    'cwin': window,
    'docu': documents,
}

_compdeclarations = {
    '<   ': _3c_,
    '<=  ': _b2_,
    '=   ': _3d_,
    '>   ': _3e_,
    '>=  ': _b3_,
    'bgwt': starts_with,
    'cont': contains,
    'ends': ends_with,
}

_enumdeclarations = {
    'savo': {
        'ask': 'ask ',
        'no': 'no  ',
        'yes': 'yes ',
    },
}

_Enum_savo = {
    'ask': 'ask ',
    'no': 'no  ',
    'yes': 'yes ',
}

_propdeclarations = {
    'ID  ': None, # (!) forward: _Prop_id, real value is ''
    'c@#^': None, # (!) forward: _Prop__3c_Inheritance_3e_, real value is ''
    'docu': None, # (!) forward: _Prop_document, real value is ''
    'hclb': None, # (!) forward: _Prop_closeable, real value is ''
    'imod': None, # (!) forward: _Prop_modified, real value is ''
    'isfl': None, # (!) forward: _Prop_floating, real value is ''
    'ismn': None, # (!) forward: _Prop_miniaturizable, real value is ''
    'iszm': None, # (!) forward: _Prop_zoomable, real value is ''
    'pALL': None, # (!) forward: _Prop_properties, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'pcls': None, # (!) forward: _Prop_class_, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pisf': None, # (!) forward: _Prop_frontmost, real value is ''
    'pmnd': None, # (!) forward: _Prop_miniaturized, real value is ''
    'pmod': None, # (!) forward: _Prop_modal, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'ppth': None, # (!) forward: _Prop_path, real value is ''
    'prsz': None, # (!) forward: _Prop_resizable, real value is ''
    'ptit': None, # (!) forward: _Prop_titled, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'pzum': None, # (!) forward: _Prop_zoomed, real value is ''
    'vers': None, # (!) forward: _Prop_version, real value is ''
}

_Prop_bounds = None # (!) real value is ''

_Prop_class_ = None # (!) real value is ''

_Prop_closeable = None # (!) real value is ''

_Prop_document = None # (!) real value is ''

_Prop_floating = None # (!) real value is ''

_Prop_frontmost = None # (!) real value is ''

_Prop_id = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_miniaturizable = None # (!) real value is ''

_Prop_miniaturized = None # (!) real value is ''

_Prop_modal = None # (!) real value is ''

_Prop_modified = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_path = None # (!) real value is ''

_Prop_properties = None # (!) real value is ''

_Prop_resizable = None # (!) real value is ''

_Prop_titled = None # (!) real value is ''

_Prop_version = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_zoomable = None # (!) real value is ''

_Prop_zoomed = None # (!) real value is ''

_Prop__3c_Inheritance_3e_ = None # (!) real value is ''

