# encoding: utf-8
# module SystemEvents.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/__init__.pyo by generator 1.99
""" Package generated from /System/Library/CoreServices/System Events.app """

# imports
import SystemEvents.Power_Suite as Power_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Power_Suite.pyc
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import SystemEvents.Processes_Suite as Processes_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Processes_Suite.pyc
import SystemEvents.Text_Suite as Text_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Text_Suite.pyc
import SystemEvents.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Standard_Suite.pyc
import StdSuites as StdSuites # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/__init__.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import SystemEvents.Disk_Folder_File_Suite as Disk_Folder_File_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Disk_Folder_File_Suite.pyc
import SystemEvents.Folder_Actions_Suite as Folder_Actions_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Folder_Actions_Suite.pyc
import SystemEvents.Login_Items_Suite as Login_Items_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/Login_Items_Suite.pyc
import SystemEvents.System_Events_Suite as System_Events_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/SystemEvents/System_Events_Suite.pyc

# Variables with simple values

Error = 'aetools.Error'

# functions

def getbaseclasses(v): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

application = System_Events_Suite.application

applications = System_Events_Suite.application

application_process = Processes_Suite.application_process

application_processes = Processes_Suite.application_process

attachment = Text_Suite.attachment

attribute_run = Text_Suite.attribute_runs

attribute_runs = Text_Suite.attribute_runs

character = Text_Suite.characters

characters = Text_Suite.characters

color = Standard_Suite.color

colors = Standard_Suite.color

contains = Standard_Suite.contains

desk_accessory_process = Processes_Suite.desk_accessory_process

desk_accessory_processes = Processes_Suite.desk_accessory_process

disk = Disk_Folder_File_Suite.disk

disks = Disk_Folder_File_Suite.disk

Disk_Folder_File_Suite_Events = Disk_Folder_File_Suite.Disk_Folder_File_Suite_Events

document = Standard_Suite.documents

documents = Standard_Suite.documents

ends_with = Standard_Suite.ends_with

file = Disk_Folder_File_Suite.file

files = Disk_Folder_File_Suite.file

folder = Disk_Folder_File_Suite.folder

folders = Disk_Folder_File_Suite.folder

folder_action = Folder_Actions_Suite.folder_actions

folder_actions = Folder_Actions_Suite.folder_actions

folder_actions_enabled = System_Events_Suite.folder_actions_enabled

Folder_Actions_Suite_Events = Folder_Actions_Suite.Folder_Actions_Suite_Events

frontmost = Standard_Suite.frontmost

item = Disk_Folder_File_Suite.items

items = Disk_Folder_File_Suite.items

login_item = Login_Items_Suite.login_items

login_items = Login_Items_Suite.login_items

Login_Items_Suite_Events = Login_Items_Suite.Login_Items_Suite_Events

name = Standard_Suite.name

paragraph = Text_Suite.paragraphs

paragraphs = Text_Suite.paragraphs

Power_Suite_Events = Power_Suite.Power_Suite_Events

process = Processes_Suite.process

processes = Processes_Suite.process

Processes_Suite_Events = Processes_Suite.Processes_Suite_Events

properties = System_Events_Suite.properties

script = Folder_Actions_Suite.scripts

scripts = Folder_Actions_Suite.scripts

Standard_Suite_Events = Standard_Suite.Standard_Suite_Events

starts_with = Standard_Suite.starts_with

SystemEvents = None # (!) real value is ''

System_Events_Suite_Events = System_Events_Suite.System_Events_Suite_Events

text = Text_Suite.text

Text_Suite_Events = Text_Suite.Text_Suite_Events

version = Standard_Suite.version

window = Standard_Suite.window

windows = Standard_Suite.window

word = Text_Suite.word

words = Text_Suite.word

_classdeclarations = {
    'atts': Text_Suite.attachment,
    'capp': System_Events_Suite.application,
    'catr': Text_Suite.attribute_runs,
    'cdis': Disk_Folder_File_Suite.disk,
    'cfol': Disk_Folder_File_Suite.folder,
    'cha ': Text_Suite.characters,
    'cobj': Disk_Folder_File_Suite.items,
    'colr': Standard_Suite.color,
    'cpar': Text_Suite.paragraphs,
    'ctxt': Text_Suite.text,
    'cwin': Standard_Suite.window,
    'cwor': Text_Suite.word,
    'docu': Standard_Suite.documents,
    'file': Disk_Folder_File_Suite.file,
    'foac': Folder_Actions_Suite.folder_actions,
    'logi': Login_Items_Suite.login_items,
    'pcap': Processes_Suite.application_process,
    'pcda': Processes_Suite.desk_accessory_process,
    'prcs': Processes_Suite.process,
    'scpt': Folder_Actions_Suite.scripts,
}

_code_to_fullname = {
    '????': (
        'SystemEvents.Text_Suite',
        'Text_Suite',
    ),
    'cdis': (
        'SystemEvents.Disk_Folder_File_Suite',
        'Disk_Folder_File_Suite',
    ),
    'faco': (
        'SystemEvents.Folder_Actions_Suite',
        'Folder_Actions_Suite',
    ),
    'logi': (
        'SystemEvents.Login_Items_Suite',
        'Login_Items_Suite',
    ),
    'powr': (
        'SystemEvents.Power_Suite',
        'Power_Suite',
    ),
    'prcs': (
        'SystemEvents.Processes_Suite',
        'Processes_Suite',
    ),
    'sevs': (
        'SystemEvents.System_Events_Suite',
        'System_Events_Suite',
    ),
}

_code_to_module = {
    '????': None, # (!) forward: Text_Suite, real value is ''
    'cdis': Power_Suite.Disk_Folder_File_Suite,
    'faco': Power_Suite.Folder_Actions_Suite,
    'logi': Power_Suite.Login_Items_Suite,
    'powr': None, # (!) forward: Power_Suite, real value is ''
    'prcs': Power_Suite.Processes_Suite,
    'sevs': None, # (!) forward: System_Events_Suite, real value is ''
}

