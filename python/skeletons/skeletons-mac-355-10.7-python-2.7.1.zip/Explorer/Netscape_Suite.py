# encoding: utf-8
# module Explorer.Netscape_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Netscape_Suite.pyo by generator 1.99
"""
Suite Netscape Suite: Events defined by Netscape
Level 1, version 1

Generated from /Applications/Internet Explorer.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'MOSS'

# no functions
# no classes
# variables with complex values

Netscape_Suite_Events = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {}

