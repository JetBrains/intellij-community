# encoding: utf-8
# module Explorer.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/__init__.pyo by generator 1.99
""" Package generated from /Applications/Internet Explorer.app """

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import Explorer.Web_Browser_Suite as Web_Browser_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Web_Browser_Suite.pyc
import StdSuites as StdSuites # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/__init__.pyc
import Explorer.Netscape_Suite as Netscape_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Netscape_Suite.pyc
import Explorer.URL_Suite as URL_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/URL_Suite.pyc
import Explorer.Required_Suite as Required_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Required_Suite.pyc
import Explorer.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import Explorer.Microsoft_Internet_Explorer as Microsoft_Internet_Explorer # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Microsoft_Internet_Explorer.pyc

# Variables with simple values

Error = 'aetools.Error'

# functions

def getbaseclasses(v): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

application = Standard_Suite.application

builtin_Suite_Events = Required_Suite.builtin_Suite_Events

Explorer = None # (!) real value is ''

Microsoft_Internet_Explorer_Events = Microsoft_Internet_Explorer.Microsoft_Internet_Explorer_Events

Netscape_Suite_Events = Netscape_Suite.Netscape_Suite_Events

Required_Suite_Events = Required_Suite.Required_Suite_Events

selected_text = Standard_Suite.selected_text

Standard_Suite_Events = Standard_Suite.Standard_Suite_Events

URL_Suite_Events = URL_Suite.URL_Suite_Events

Web_Browser_Suite_Events = Web_Browser_Suite.Web_Browser_Suite_Events

_classdeclarations = {
    'capp': Standard_Suite.application,
}

_code_to_fullname = {
    '****': (
        'Explorer.Standard_Suite',
        'Standard_Suite',
    ),
    'GURL': (
        'Explorer.URL_Suite',
        'URL_Suite',
    ),
    'MOSS': (
        'Explorer.Netscape_Suite',
        'Netscape_Suite',
    ),
    'MSIE': (
        'Explorer.Microsoft_Internet_Explorer',
        'Microsoft_Internet_Explorer',
    ),
    'WWW!': (
        'Explorer.Web_Browser_Suite',
        'Web_Browser_Suite',
    ),
    'reqd': (
        'Explorer.Required_Suite',
        'Required_Suite',
    ),
}

_code_to_module = {
    '****': None, # (!) forward: Standard_Suite, real value is ''
    'GURL': None, # (!) forward: URL_Suite, real value is ''
    'MOSS': None, # (!) forward: Netscape_Suite, real value is ''
    'MSIE': None, # (!) forward: Microsoft_Internet_Explorer, real value is ''
    'WWW!': None, # (!) forward: Web_Browser_Suite, real value is ''
    'reqd': None, # (!) forward: Required_Suite, real value is ''
}

