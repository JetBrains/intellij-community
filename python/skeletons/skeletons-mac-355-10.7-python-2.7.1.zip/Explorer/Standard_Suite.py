# encoding: utf-8
# module Explorer.Standard_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Explorer/Standard_Suite.pyo by generator 1.99
"""
Suite Standard Suite: Common terms for most applications
Level 1, version 1

Generated from /Applications/Internet Explorer.app
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = '****'

# no functions
# no classes
# variables with complex values

application = None # (!) real value is ''

selected_text = None # (!) real value is ''

Standard_Suite_Events = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'stxt': None, # (!) forward: _Prop_selected_text, real value is ''
}

_Prop_selected_text = None # (!) real value is ''

