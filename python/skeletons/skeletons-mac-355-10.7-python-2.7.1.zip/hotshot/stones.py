# encoding: utf-8
# module hotshot.stones
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/hotshot/stones.pyo by generator 1.99
# no doc

# imports
import errno as errno # <module 'errno' (built-in)>
import sys as sys # <module 'sys' (built-in)>
import hotshot as hotshot # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/hotshot/__init__.pyc
import test as test # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/test/__init__.pyc

# functions

def main(logfile): # reliably restored by inspect
    # no doc
    pass


# no classes
