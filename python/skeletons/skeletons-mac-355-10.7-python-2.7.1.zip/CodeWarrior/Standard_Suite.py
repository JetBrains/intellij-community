# encoding: utf-8
# module CodeWarrior.Standard_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/Standard_Suite.pyo by generator 1.99
"""
Suite Standard Suite: Common terms for most applications
Level 1, version 1

Generated from /Volumes/Sap/Applications (Mac OS 9)/Metrowerks CodeWarrior 7.0/Metrowerks CodeWarrior/CodeWarrior IDE 4.2.5
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'CoRe'

# no functions
# no classes
# variables with complex values

alias = None # (!) forward: aliases, real value is ''

aliases = None # (!) real value is ''

application = None # (!) real value is ''

applications = None # (!) real value is ''

builtin_Suite_Events = None # (!) real value is ''

character = None # (!) real value is ''

clipboard = None # (!) real value is ''

contains = None # (!) real value is ''

document = None # (!) forward: documents, real value is ''

documents = None # (!) real value is ''

ends_with = None # (!) real value is ''

file = None # (!) real value is ''

files = file

frontmost = None # (!) real value is ''

insertion_point = None # (!) real value is ''

insertion_points = None # (!) real value is ''

line = None # (!) real value is ''

lines = line

name = None # (!) real value is ''

selection = None # (!) real value is ''

selection_2d_object = None # (!) real value is ''

Standard_Suite_Events = None # (!) real value is ''

starts_with = None # (!) real value is ''

text = None # (!) real value is ''

user_interaction = None # (!) real value is ''

version = None # (!) real value is ''

window = None # (!) real value is ''

windows = window

_classdeclarations = {
    'capp': application,
    'cha ': character,
    'cins': insertion_point,
    'clin': line,
    'csel': selection_2d_object,
    'ctxt': text,
    'cwin': window,
    'docu': documents,
    'file': file,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'DKND': None, # (!) forward: _Prop_kind, real value is ''
    'FILE': None, # (!) forward: _Prop_location, real value is ''
    'PERM': None, # (!) forward: _Prop_file_permissions, real value is ''
    'cwin': None, # (!) forward: _Prop_window, real value is ''
    'docu': None, # (!) forward: _Prop_document, real value is ''
    'inte': None, # (!) forward: _Prop_user_interaction, real value is ''
    'pLen': None, # (!) forward: _Prop_length, real value is ''
    'pOff': None, # (!) forward: _Prop_offset, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'pcnt': None, # (!) forward: _Prop_contents, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'ppos': None, # (!) forward: _Prop_position, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'pzum': None, # (!) forward: _Prop_zoomed, real value is ''
}

_Prop_bounds = None # (!) real value is ''

_Prop_contents = None # (!) real value is ''

_Prop_document = None # (!) real value is ''

_Prop_file_permissions = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_kind = None # (!) real value is ''

_Prop_length = None # (!) real value is ''

_Prop_location = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_offset = None # (!) real value is ''

_Prop_position = None # (!) real value is ''

_Prop_user_interaction = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_window = None # (!) real value is ''

_Prop_zoomed = None # (!) real value is ''

