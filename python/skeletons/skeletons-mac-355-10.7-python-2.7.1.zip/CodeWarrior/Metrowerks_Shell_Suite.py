# encoding: utf-8
# module CodeWarrior.Metrowerks_Shell_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/Metrowerks_Shell_Suite.pyo by generator 1.99
"""
Suite Metrowerks Shell Suite: Events supported by the Metrowerks Project Shell
Level 1, version 1

Generated from /Volumes/Sap/Applications (Mac OS 9)/Metrowerks CodeWarrior 7.0/Metrowerks CodeWarrior/CodeWarrior IDE 4.2.5
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'MMPR'

# no functions
# no classes
# variables with complex values

Access_Paths = None # (!) real value is ''

base_class = None # (!) forward: base_classes, real value is ''

base_classes = None # (!) real value is ''

browser_catalog = None # (!) real value is ''

Browser_Coloring = None # (!) real value is ''

Build_Extras = None # (!) real value is ''

Build_Settings = None # (!) real value is ''

classes = None # (!) real value is ''

class_ = classes

Custom_Keywords = None # (!) real value is ''

data_member = None # (!) forward: data_members, real value is ''

data_members = None # (!) real value is ''

Debugger_Display = None # (!) real value is ''

Debugger_Global = None # (!) real value is ''

Debugger_Target = None # (!) real value is ''

Debugger_Windowing = None # (!) real value is ''

Editor = None # (!) real value is ''

Environment_Variable = None # (!) real value is ''

Error_Information = None # (!) real value is ''

Extras = None # (!) real value is ''

File_Mapping = None # (!) real value is ''

File_Mappings = None # (!) real value is ''

Font = None # (!) real value is ''

Function_Information = None # (!) real value is ''

Global_Source_Trees = None # (!) real value is ''

member_function = None # (!) forward: member_functions, real value is ''

member_functions = None # (!) real value is ''

Metrowerks_Shell_Suite_Events = None # (!) real value is ''

Path_Information = None # (!) real value is ''

Plugin_Settings = None # (!) real value is ''

ProjectFile = None # (!) real value is ''

Relative_Path = None # (!) real value is ''

Runtime_Settings = None # (!) real value is ''

Segment = None # (!) real value is ''

Shielded_Folder = None # (!) real value is ''

Shielded_Folders = None # (!) real value is ''

Source_Tree = None # (!) real value is ''

Syntax_Coloring = None # (!) real value is ''

Target_Settings = None # (!) real value is ''

Target_Source_Trees = None # (!) real value is ''

VCS_Setup = None # (!) real value is ''

_classdeclarations = {
    'BRKW': Browser_Coloring,
    'BSTG': Build_Settings,
    'BsCl': base_classes,
    'CUKW': Custom_Keywords,
    'Cata': browser_catalog,
    'Clas': classes,
    'DbDS': Debugger_Display,
    'DbGL': Debugger_Global,
    'DbTG': Debugger_Target,
    'DbWN': Debugger_Windowing,
    'DtMb': data_members,
    'EDTR': Editor,
    'EnvV': Environment_Variable,
    'ErrM': Error_Information,
    'FDef': Function_Information,
    'FLMP': File_Mappings,
    'FMap': File_Mapping,
    'GSTs': Global_Source_Trees,
    'GXTR': Extras,
    'LXTR': Build_Extras,
    'MbFn': member_functions,
    'PATH': Access_Paths,
    'PInf': Path_Information,
    'PSTG': Plugin_Settings,
    'RSTG': Runtime_Settings,
    'RlPt': Relative_Path,
    'SFit': Shielded_Folder,
    'SHFL': Shielded_Folders,
    'SNTX': Syntax_Coloring,
    'Seg ': Segment,
    'SrcF': ProjectFile,
    'SrcT': Source_Tree,
    'TARG': Target_Settings,
    'TSTs': Target_Source_Trees,
    'VCSs': VCS_Setup,
    'mFNT': Font,
}

_compdeclarations = {}

_enumdeclarations = {
    'Acce': {
        'private': 'Priv',
        'protected': 'Prot',
        'public': 'Publ',
    },
    'BXbr': {
        'Always_Build': 'BXb1',
        'Ask_Build': 'BXb2',
        'Never_Build': 'BXb3',
    },
    'DbSA': {
        'Close_Windows': 'DSA4',
        'Collapse_Windows': 'DSA3',
        'Hide_Windows': 'DSA2',
        'No_Action': 'DSA1',
    },
    'DgBL': {
        'Always': 'DgB0',
        'Ask': 'DgB2',
        'Never': 'DgB1',
    },
    'ErrT': {
        'compiler_error': 'ErCE',
        'compiler_warning': 'ErCW',
        'definition': 'ErDf',
        'find_result': 'ErFn',
        'generic_error': 'ErGn',
        'information': 'ErIn',
        'linker_error': 'ErLE',
        'linker_warning': 'ErLW',
    },
    'Inte': {
        'interact_with_all': 'eInA',
        'interact_with_local': 'eInL',
        'interact_with_self': 'eInS',
        'never_interact': 'eNvr',
    },
    'Lang': {
        'Assembler': 'LAsm',
        'C': 'LC  ',
        'C_2b__2b_': 'LC++',
        'Java': 'LJav',
        'Object_Pascal': 'LP++',
        'Pascal': 'LP  ',
        'Unknown': 'L?  ',
    },
    'PPrm': {
        'absolute': 'Abso',
        'project_relative': 'PRel',
        'root_relative': 'RRel',
        'shell_relative': 'SRel',
        'system_relative': 'YRel',
    },
    'PXdg': {
        'Diagnose_All': 'PXd3',
        'Diagnose_Errors': 'PXd2',
        'Diagnose_None': 'PXd1',
    },
    'PthF': {
        'Generic_Path': 'PFGn',
        'MacOS_Path': 'PFMc',
        'Unix_Path': 'PFUx',
        'Windows_Path': 'PFWn',
    },
    'RefP': {
        'QuickView': 'ALTV',
        'Think_Reference': 'DanR',
    },
    'STKd': {
        'Absolute_Path': 'STK0',
        'Environment_Variable': 'STK2',
        'Registry_Key': 'STK1',
    },
    'SrcT': {
        'source': 'FTxt',
        'unknown': 'FUnk',
    },
    'TmpB': {
        'Default': 'Dflt',
        'User_Specified': 'Usrs',
    },
    'TxtF': {
        'DOS': 'TxF1',
        'MacOS': 'TxF0',
        'Unix': 'TxF2',
    },
    'savo': {
        'ask': 'ask ',
        'no': 'no  ',
        'yes': 'yes ',
    },
}

_Enum_Acce = {
    'private': 'Priv',
    'protected': 'Prot',
    'public': 'Publ',
}

_Enum_BXbr = {
    'Always_Build': 'BXb1',
    'Ask_Build': 'BXb2',
    'Never_Build': 'BXb3',
}

_Enum_DbSA = {
    'Close_Windows': 'DSA4',
    'Collapse_Windows': 'DSA3',
    'Hide_Windows': 'DSA2',
    'No_Action': 'DSA1',
}

_Enum_DgBL = {
    'Always': 'DgB0',
    'Ask': 'DgB2',
    'Never': 'DgB1',
}

_Enum_ErrT = {
    'compiler_error': 'ErCE',
    'compiler_warning': 'ErCW',
    'definition': 'ErDf',
    'find_result': 'ErFn',
    'generic_error': 'ErGn',
    'information': 'ErIn',
    'linker_error': 'ErLE',
    'linker_warning': 'ErLW',
}

_Enum_Inte = {
    'interact_with_all': 'eInA',
    'interact_with_local': 'eInL',
    'interact_with_self': 'eInS',
    'never_interact': 'eNvr',
}

_Enum_Lang = {
    'Assembler': 'LAsm',
    'C': 'LC  ',
    'C_2b__2b_': 'LC++',
    'Java': 'LJav',
    'Object_Pascal': 'LP++',
    'Pascal': 'LP  ',
    'Unknown': 'L?  ',
}

_Enum_PPrm = {
    'absolute': 'Abso',
    'project_relative': 'PRel',
    'root_relative': 'RRel',
    'shell_relative': 'SRel',
    'system_relative': 'YRel',
}

_Enum_PthF = {
    'Generic_Path': 'PFGn',
    'MacOS_Path': 'PFMc',
    'Unix_Path': 'PFUx',
    'Windows_Path': 'PFWn',
}

_Enum_PXdg = {
    'Diagnose_All': 'PXd3',
    'Diagnose_Errors': 'PXd2',
    'Diagnose_None': 'PXd1',
}

_Enum_RefP = {
    'QuickView': 'ALTV',
    'Think_Reference': 'DanR',
}

_Enum_savo = {
    'ask': 'ask ',
    'no': 'no  ',
    'yes': 'yes ',
}

_Enum_SrcT = {
    'source': 'FTxt',
    'unknown': 'FUnk',
}

_Enum_STKd = {
    'Absolute_Path': 'STK0',
    'Environment_Variable': 'STK2',
    'Registry_Key': 'STK1',
}

_Enum_TmpB = {
    'Default': 'Dflt',
    'User_Specified': 'Usrs',
}

_Enum_TxtF = {
    'DOS': 'TxF1',
    'MacOS': 'TxF0',
    'Unix': 'TxF2',
}

_propdeclarations = {
    'Acce': None, # (!) forward: _Prop_access, real value is ''
    'BW00': None, # (!) forward: _Prop_Browser_Keywords, real value is ''
    'BW01': None, # (!) forward: _Prop_Classes_Color, real value is ''
    'BW02': None, # (!) forward: _Prop_Constants_Color, real value is ''
    'BW03': None, # (!) forward: _Prop_Enums_Color, real value is ''
    'BW04': None, # (!) forward: _Prop_Functions_Color, real value is ''
    'BW05': None, # (!) forward: _Prop_Globals_Color, real value is ''
    'BW06': None, # (!) forward: _Prop_Macros_Color, real value is ''
    'BW07': None, # (!) forward: _Prop_Templates_Color, real value is ''
    'BW08': None, # (!) forward: _Prop_Typedefs_Color, real value is ''
    'BW10': None, # (!) forward: _Prop_Template_Commands_in_Menu, real value is ''
    'BX01': None, # (!) forward: _Prop_Completion_Sound, real value is ''
    'BX02': None, # (!) forward: _Prop_Success_Sound, real value is ''
    'BX03': None, # (!) forward: _Prop_Failure_Sound, real value is ''
    'BX04': None, # (!) forward: _Prop_Build_Before_Running, real value is ''
    'BX05': None, # (!) forward: _Prop_Include_Cache_Size, real value is ''
    'BX06': None, # (!) forward: _Prop_Compiler_Thread_Stack_Size, real value is ''
    'BX07': None, # (!) forward: _Prop_Save_Before_Building, real value is ''
    'Bfor': None, # (!) forward: _Prop_initialize_before, real value is ''
    'CSiz': None, # (!) forward: _Prop_codesize, real value is ''
    'Clas': None, # (!) forward: _Prop_class_, real value is ''
    'DSiz': None, # (!) forward: _Prop_datasize, real value is ''
    'Db01': None, # (!) forward: _Prop_Show_Variable_Types, real value is ''
    'Db02': None, # (!) forward: _Prop_Sort_By_Method, real value is ''
    'Db03': None, # (!) forward: _Prop_Use_RTTI, real value is ''
    'Db04': None, # (!) forward: _Prop_Threads_in_Window, real value is ''
    'Db05': None, # (!) forward: _Prop_Variable_Hints, real value is ''
    'Db06': None, # (!) forward: _Prop_Watchpoint_Hilite, real value is ''
    'Db07': None, # (!) forward: _Prop_Variable_Changed_Hilite, real value is ''
    'Db08': None, # (!) forward: _Prop_Default_Array_Size, real value is ''
    'Db09': None, # (!) forward: _Prop_Show_Locals, real value is ''
    'Db10': None, # (!) forward: _Prop_Show_As_Decimal, real value is ''
    'DcEn': None, # (!) forward: _Prop_declaration_end_offset, real value is ''
    'DcFl': None, # (!) forward: _Prop_declaration_file, real value is ''
    'DcSt': None, # (!) forward: _Prop_declaration_start_offset, real value is ''
    'DfEn': None, # (!) forward: _Prop_implementation_end_offset, real value is ''
    'DfFl': None, # (!) forward: _Prop_implementation_file, real value is ''
    'DfSt': None, # (!) forward: _Prop_implementation_start_offset, real value is ''
    'Dg01': None, # (!) forward: _Prop_Ignore_Mod_Dates, real value is ''
    'Dg02': None, # (!) forward: _Prop_Open_All_Classes, real value is ''
    'Dg03': None, # (!) forward: _Prop_Launch_Apps_on_Open, real value is ''
    'Dg04': None, # (!) forward: _Prop_Confirm_Kill, real value is ''
    'Dg05': None, # (!) forward: _Prop_Stop_at_Main, real value is ''
    'Dg06': None, # (!) forward: _Prop_Select_Stack_Crawl, real value is ''
    'Dg07': None, # (!) forward: _Prop_Dont_Step_in_Runtime, real value is ''
    'Dg11': None, # (!) forward: _Prop_Auto_Target_Libraries, real value is ''
    'Dg12': None, # (!) forward: _Prop_Cache_Edited_Files, real value is ''
    'Dg13': None, # (!) forward: _Prop_File_Cache_Duration, real value is ''
    'Dt02': None, # (!) forward: _Prop_Log_System_Messages, real value is ''
    'Dt08': None, # (!) forward: _Prop_Update_Data_While_Running, real value is ''
    'Dt09': None, # (!) forward: _Prop_Data_Update_Interval, real value is ''
    'Dt10': None, # (!) forward: _Prop_Relocated_Executable_Path, real value is ''
    'Dt13': None, # (!) forward: _Prop_Stop_at_temp_breakpoint, real value is ''
    'Dt14': None, # (!) forward: _Prop_Temp_breakpoint_names, real value is ''
    'Dt15': None, # (!) forward: _Prop_Cache_symbolics, real value is ''
    'Dt16': None, # (!) forward: _Prop_Temp_Breakpoint_Type, real value is ''
    'Dw01': None, # (!) forward: _Prop_Debugging_Start_Action, real value is ''
    'Dw02': None, # (!) forward: _Prop_Do_Nothing_To_Projects, real value is ''
    'ED01': None, # (!) forward: _Prop_Flash_Delay, real value is ''
    'ED02': None, # (!) forward: _Prop_Dynamic_Scroll, real value is ''
    'ED03': None, # (!) forward: _Prop_Balance, real value is ''
    'ED04': None, # (!) forward: _Prop_Use_Drag__26__Drop_Editing, real value is ''
    'ED06': None, # (!) forward: _Prop_Sort_Function_Popup, real value is ''
    'ED07': None, # (!) forward: _Prop_Use_Multiple_Undo, real value is ''
    'ED08': None, # (!) forward: _Prop_Remember_Font, real value is ''
    'ED09': None, # (!) forward: _Prop_Remember_Selection, real value is ''
    'ED10': None, # (!) forward: _Prop_Remember_Window, real value is ''
    'ED12': None, # (!) forward: _Prop_Main_Text_Color, real value is ''
    'ED13': None, # (!) forward: _Prop_Background_Color, real value is ''
    'ED14': None, # (!) forward: _Prop_Context_Popup_Delay, real value is ''
    'ED15': None, # (!) forward: _Prop_Relaxed_C_Popup_Parsing, real value is ''
    'ED16': None, # (!) forward: _Prop_Left_Margin_Line_Select, real value is ''
    'ED17': None, # (!) forward: _Prop_Default_Text_File_Format, real value is ''
    'EX04': None, # (!) forward: _Prop_Modification_Date_Caching, real value is ''
    'EX07': None, # (!) forward: _Prop_Full_Screen_Zoom, real value is ''
    'EX08': None, # (!) forward: _Prop_External_Reference, real value is ''
    'EX09': None, # (!) forward: _Prop_Browser_Active, real value is ''
    'EX10': None, # (!) forward: _Prop_Use_Editor_Extensions, real value is ''
    'EX11': None, # (!) forward: _Prop_Use_External_Editor, real value is ''
    'EX12': None, # (!) forward: _Prop_Use_Script_Menu, real value is ''
    'EX16': None, # (!) forward: _Prop_Recent_Editor_Count, real value is ''
    'EX17': None, # (!) forward: _Prop_Recent_Project_Count, real value is ''
    'EX18': None, # (!) forward: _Prop_Use_ToolServer_Menu, real value is ''
    'EX19': None, # (!) forward: _Prop_Automatic_Toolbar_Help, real value is ''
    'EX30': None, # (!) forward: _Prop_Dump_Browser_Info, real value is ''
    'EX31': None, # (!) forward: _Prop_Cache_Subproject_Data, real value is ''
    'ErrL': None, # (!) forward: _Prop_lineNumber, real value is ''
    'ErrS': None, # (!) forward: _Prop_message, real value is ''
    'ErrT': None, # (!) forward: _Prop_messageKind, real value is ''
    'FMps': None, # (!) forward: _Prop_Mappings, real value is ''
    'FN01': None, # (!) forward: _Prop_Auto_Indent, real value is ''
    'FN02': None, # (!) forward: _Prop_Tab_Size, real value is ''
    'FN03': None, # (!) forward: _Prop_Tab_Indents_Selection, real value is ''
    'FN04': None, # (!) forward: _Prop_Tab_Inserts_Spaces, real value is ''
    'Frmt': None, # (!) forward: _Prop_format, real value is ''
    'Frmw': None, # (!) forward: _Prop_framework, real value is ''
    'GH01': None, # (!) forward: _Prop_Syntax_Coloring, real value is ''
    'GH02': None, # (!) forward: _Prop_Comment_Color, real value is ''
    'GH03': None, # (!) forward: _Prop_Keyword_Color, real value is ''
    'GH04': None, # (!) forward: _Prop_String_Color, real value is ''
    'GH05': None, # (!) forward: _Prop_Custom_Color_1, real value is ''
    'GH06': None, # (!) forward: _Prop_Custom_Color_2, real value is ''
    'GH07': None, # (!) forward: _Prop_Custom_Color_3, real value is ''
    'GH08': None, # (!) forward: _Prop_Custom_Color_4, real value is ''
    'HstF': None, # (!) forward: _Prop_host_flags, real value is ''
    'IncF': None, # (!) forward: _Prop_includes, real value is ''
    'Kind': None, # (!) forward: _Prop_path_kind, real value is ''
    'Lang': None, # (!) forward: _Prop_language, real value is ''
    'NumF': None, # (!) forward: _Prop_filecount, real value is ''
    'Orig': None, # (!) forward: _Prop_origin, real value is ''
    'PA01': None, # (!) forward: _Prop_User_Paths, real value is ''
    'PA02': None, # (!) forward: _Prop_Always_Full_Search, real value is ''
    'PA03': None, # (!) forward: _Prop_System_Paths, real value is ''
    'PA04': None, # (!) forward: _Prop_Convert_Paths, real value is ''
    'PA05': None, # (!) forward: _Prop_Require_Framework_Includes, real value is ''
    'PLck': None, # (!) forward: _Prop_seg_2d_locked, real value is ''
    'PR04': None, # (!) forward: _Prop_File_Type, real value is ''
    'PX01': None, # (!) forward: _Prop_Plugin_Diagnostics_Level, real value is ''
    'PX02': None, # (!) forward: _Prop_Disable_Third_Party_COM_Plugins, real value is ''
    'Path': None, # (!) forward: _Prop_path, real value is ''
    'Prel': None, # (!) forward: _Prop_seg_2d_preloaded, real value is ''
    'Prot': None, # (!) forward: _Prop_seg_2d_protected, real value is ''
    'Purg': None, # (!) forward: _Prop_seg_2d_purgeable, real value is ''
    'RS01': None, # (!) forward: _Prop_Host_Application, real value is ''
    'RS02': None, # (!) forward: _Prop_Command_Line_Arguments, real value is ''
    'RS03': None, # (!) forward: _Prop_Working_Directory, real value is ''
    'RS04': None, # (!) forward: _Prop_Environment_Variables, real value is ''
    'Recu': None, # (!) forward: _Prop_recursive, real value is ''
    'Root': None, # (!) forward: _Prop_root, real value is ''
    'SF01': None, # (!) forward: _Prop_Expression_To_Match, real value is ''
    'SF02': None, # (!) forward: _Prop_Skip_Project_Operations, real value is ''
    'SF03': None, # (!) forward: _Prop_Skip_Find_And_Compare_Operations, real value is ''
    'SFis': None, # (!) forward: _Prop_Shielded_Items, real value is ''
    'ST01': None, # (!) forward: _Prop_Source_Trees, real value is ''
    'SrcT': None, # (!) forward: _Prop_filetype, real value is ''
    'Stat': None, # (!) forward: _Prop_static, real value is ''
    'SubA': None, # (!) forward: _Prop_all_subclasses, real value is ''
    'SubC': None, # (!) forward: _Prop_subclasses, real value is ''
    'SymG': None, # (!) forward: _Prop_symbols, real value is ''
    'SysH': None, # (!) forward: _Prop_seg_2d_system_heap, real value is ''
    'TA01': None, # (!) forward: _Prop_Linker, real value is ''
    'TA02': None, # (!) forward: _Prop_Extension, real value is ''
    'TA03': None, # (!) forward: _Prop_Precompiled, real value is ''
    'TA04': None, # (!) forward: _Prop_Resource_File, real value is ''
    'TA05': None, # (!) forward: _Prop_Launchable, real value is ''
    'TA06': None, # (!) forward: _Prop_Ignored_by_Make, real value is ''
    'TA07': None, # (!) forward: _Prop_Compiler, real value is ''
    'TA09': None, # (!) forward: _Prop_Post_Linker, real value is ''
    'TA10': None, # (!) forward: _Prop_Target_Name, real value is ''
    'TA11': None, # (!) forward: _Prop_Output_Directory_Path, real value is ''
    'TA12': None, # (!) forward: _Prop_Output_Directory_Origin, real value is ''
    'TA13': None, # (!) forward: _Prop_Pre_Linker, real value is ''
    'TA15': None, # (!) forward: _Prop_Use_Relative_Paths, real value is ''
    'TA16': None, # (!) forward: _Prop_Output_Directory_Location, real value is ''
    'UpTD': None, # (!) forward: _Prop_up_to_date, real value is ''
    'VC01': None, # (!) forward: _Prop_VCS_Active, real value is ''
    'VC02': None, # (!) forward: _Prop_Connection_Method, real value is ''
    'VC03': None, # (!) forward: _Prop_Username, real value is ''
    'VC04': None, # (!) forward: _Prop_Password, real value is ''
    'VC05': None, # (!) forward: _Prop_Auto_Connect, real value is ''
    'VC06': None, # (!) forward: _Prop_Store_Password, real value is ''
    'VC07': None, # (!) forward: _Prop_Always_Prompt, real value is ''
    'VC08': None, # (!) forward: _Prop_Mount_Volume, real value is ''
    'VC09': None, # (!) forward: _Prop_Database_Path, real value is ''
    'VC10': None, # (!) forward: _Prop_Local_Path, real value is ''
    'VC11': None, # (!) forward: _Prop_Use_Global_Settings, real value is ''
    'Valu': None, # (!) forward: _Prop_value, real value is ''
    'Virt': None, # (!) forward: _Prop_virtual, real value is ''
    'Weak': None, # (!) forward: _Prop_weak_link, real value is ''
    'file': None, # (!) forward: _Prop_disk_file, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'ptps': None, # (!) forward: _Prop_Text_Size, real value is ''
    'ptxf': None, # (!) forward: _Prop_Text_Font, real value is ''
}

_Prop_access = None # (!) real value is ''

_Prop_all_subclasses = None # (!) real value is ''

_Prop_Always_Full_Search = None # (!) real value is ''

_Prop_Always_Prompt = None # (!) real value is ''

_Prop_Automatic_Toolbar_Help = None # (!) real value is ''

_Prop_Auto_Connect = None # (!) real value is ''

_Prop_Auto_Indent = None # (!) real value is ''

_Prop_Auto_Target_Libraries = None # (!) real value is ''

_Prop_Background_Color = None # (!) real value is ''

_Prop_Balance = None # (!) real value is ''

_Prop_Browser_Active = None # (!) real value is ''

_Prop_Browser_Keywords = None # (!) real value is ''

_Prop_Build_Before_Running = None # (!) real value is ''

_Prop_Cache_Edited_Files = None # (!) real value is ''

_Prop_Cache_Subproject_Data = None # (!) real value is ''

_Prop_Cache_symbolics = None # (!) real value is ''

_Prop_Classes_Color = None # (!) real value is ''

_Prop_class_ = None # (!) real value is ''

_Prop_codesize = None # (!) real value is ''

_Prop_Command_Line_Arguments = None # (!) real value is ''

_Prop_Comment_Color = None # (!) real value is ''

_Prop_Compiler = None # (!) real value is ''

_Prop_Compiler_Thread_Stack_Size = None # (!) real value is ''

_Prop_Completion_Sound = None # (!) real value is ''

_Prop_Confirm_Kill = None # (!) real value is ''

_Prop_Connection_Method = None # (!) real value is ''

_Prop_Constants_Color = None # (!) real value is ''

_Prop_Context_Popup_Delay = None # (!) real value is ''

_Prop_Convert_Paths = None # (!) real value is ''

_Prop_Custom_Color_1 = None # (!) real value is ''

_Prop_Custom_Color_2 = None # (!) real value is ''

_Prop_Custom_Color_3 = None # (!) real value is ''

_Prop_Custom_Color_4 = None # (!) real value is ''

_Prop_Database_Path = None # (!) real value is ''

_Prop_datasize = None # (!) real value is ''

_Prop_Data_Update_Interval = None # (!) real value is ''

_Prop_Debugging_Start_Action = None # (!) real value is ''

_Prop_declaration_end_offset = None # (!) real value is ''

_Prop_declaration_file = None # (!) real value is ''

_Prop_declaration_start_offset = None # (!) real value is ''

_Prop_Default_Array_Size = None # (!) real value is ''

_Prop_Default_Text_File_Format = None # (!) real value is ''

_Prop_Disable_Third_Party_COM_Plugins = None # (!) real value is ''

_Prop_disk_file = None # (!) real value is ''

_Prop_Dont_Step_in_Runtime = None # (!) real value is ''

_Prop_Do_Nothing_To_Projects = None # (!) real value is ''

_Prop_Dump_Browser_Info = None # (!) real value is ''

_Prop_Dynamic_Scroll = None # (!) real value is ''

_Prop_Enums_Color = None # (!) real value is ''

_Prop_Environment_Variables = None # (!) real value is ''

_Prop_Expression_To_Match = None # (!) real value is ''

_Prop_Extension = None # (!) real value is ''

_Prop_External_Reference = None # (!) real value is ''

_Prop_Failure_Sound = None # (!) real value is ''

_Prop_filecount = None # (!) real value is ''

_Prop_filetype = None # (!) real value is ''

_Prop_File_Cache_Duration = None # (!) real value is ''

_Prop_File_Type = None # (!) real value is ''

_Prop_Flash_Delay = None # (!) real value is ''

_Prop_format = None # (!) real value is ''

_Prop_framework = None # (!) real value is ''

_Prop_Full_Screen_Zoom = None # (!) real value is ''

_Prop_Functions_Color = None # (!) real value is ''

_Prop_Globals_Color = None # (!) real value is ''

_Prop_Host_Application = None # (!) real value is ''

_Prop_host_flags = None # (!) real value is ''

_Prop_Ignored_by_Make = None # (!) real value is ''

_Prop_Ignore_Mod_Dates = None # (!) real value is ''

_Prop_implementation_end_offset = None # (!) real value is ''

_Prop_implementation_file = None # (!) real value is ''

_Prop_implementation_start_offset = None # (!) real value is ''

_Prop_includes = None # (!) real value is ''

_Prop_Include_Cache_Size = None # (!) real value is ''

_Prop_initialize_before = None # (!) real value is ''

_Prop_Keyword_Color = None # (!) real value is ''

_Prop_language = None # (!) real value is ''

_Prop_Launchable = None # (!) real value is ''

_Prop_Launch_Apps_on_Open = None # (!) real value is ''

_Prop_Left_Margin_Line_Select = None # (!) real value is ''

_Prop_lineNumber = None # (!) real value is ''

_Prop_Linker = None # (!) real value is ''

_Prop_Local_Path = None # (!) real value is ''

_Prop_Log_System_Messages = None # (!) real value is ''

_Prop_Macros_Color = None # (!) real value is ''

_Prop_Main_Text_Color = None # (!) real value is ''

_Prop_Mappings = None # (!) real value is ''

_Prop_message = None # (!) real value is ''

_Prop_messageKind = None # (!) real value is ''

_Prop_Modification_Date_Caching = None # (!) real value is ''

_Prop_Mount_Volume = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_Open_All_Classes = None # (!) real value is ''

_Prop_origin = None # (!) real value is ''

_Prop_Output_Directory_Location = None # (!) real value is ''

_Prop_Output_Directory_Origin = None # (!) real value is ''

_Prop_Output_Directory_Path = None # (!) real value is ''

_Prop_Password = None # (!) real value is ''

_Prop_path = None # (!) real value is ''

_Prop_path_kind = None # (!) real value is ''

_Prop_Plugin_Diagnostics_Level = None # (!) real value is ''

_Prop_Post_Linker = None # (!) real value is ''

_Prop_Precompiled = None # (!) real value is ''

_Prop_Pre_Linker = None # (!) real value is ''

_Prop_Recent_Editor_Count = None # (!) real value is ''

_Prop_Recent_Project_Count = None # (!) real value is ''

_Prop_recursive = None # (!) real value is ''

_Prop_Relaxed_C_Popup_Parsing = None # (!) real value is ''

_Prop_Relocated_Executable_Path = None # (!) real value is ''

_Prop_Remember_Font = None # (!) real value is ''

_Prop_Remember_Selection = None # (!) real value is ''

_Prop_Remember_Window = None # (!) real value is ''

_Prop_Require_Framework_Includes = None # (!) real value is ''

_Prop_Resource_File = None # (!) real value is ''

_Prop_root = None # (!) real value is ''

_Prop_Save_Before_Building = None # (!) real value is ''

_Prop_seg_2d_locked = None # (!) real value is ''

_Prop_seg_2d_preloaded = None # (!) real value is ''

_Prop_seg_2d_protected = None # (!) real value is ''

_Prop_seg_2d_purgeable = None # (!) real value is ''

_Prop_seg_2d_system_heap = None # (!) real value is ''

_Prop_Select_Stack_Crawl = None # (!) real value is ''

_Prop_Shielded_Items = None # (!) real value is ''

_Prop_Show_As_Decimal = None # (!) real value is ''

_Prop_Show_Locals = None # (!) real value is ''

_Prop_Show_Variable_Types = None # (!) real value is ''

_Prop_Skip_Find_And_Compare_Operations = None # (!) real value is ''

_Prop_Skip_Project_Operations = None # (!) real value is ''

_Prop_Sort_By_Method = None # (!) real value is ''

_Prop_Sort_Function_Popup = None # (!) real value is ''

_Prop_Source_Trees = None # (!) real value is ''

_Prop_static = None # (!) real value is ''

_Prop_Stop_at_Main = None # (!) real value is ''

_Prop_Stop_at_temp_breakpoint = None # (!) real value is ''

_Prop_Store_Password = None # (!) real value is ''

_Prop_String_Color = None # (!) real value is ''

_Prop_subclasses = None # (!) real value is ''

_Prop_Success_Sound = None # (!) real value is ''

_Prop_symbols = None # (!) real value is ''

_Prop_Syntax_Coloring = None # (!) real value is ''

_Prop_System_Paths = None # (!) real value is ''

_Prop_Tab_Indents_Selection = None # (!) real value is ''

_Prop_Tab_Inserts_Spaces = None # (!) real value is ''

_Prop_Tab_Size = None # (!) real value is ''

_Prop_Target_Name = None # (!) real value is ''

_Prop_Templates_Color = None # (!) real value is ''

_Prop_Template_Commands_in_Menu = None # (!) real value is ''

_Prop_Temp_breakpoint_names = None # (!) real value is ''

_Prop_Temp_Breakpoint_Type = None # (!) real value is ''

_Prop_Text_Font = None # (!) real value is ''

_Prop_Text_Size = None # (!) real value is ''

_Prop_Threads_in_Window = None # (!) real value is ''

_Prop_Typedefs_Color = None # (!) real value is ''

_Prop_Update_Data_While_Running = None # (!) real value is ''

_Prop_up_to_date = None # (!) real value is ''

_Prop_Username = None # (!) real value is ''

_Prop_User_Paths = None # (!) real value is ''

_Prop_Use_Drag__26__Drop_Editing = None # (!) real value is ''

_Prop_Use_Editor_Extensions = None # (!) real value is ''

_Prop_Use_External_Editor = None # (!) real value is ''

_Prop_Use_Global_Settings = None # (!) real value is ''

_Prop_Use_Multiple_Undo = None # (!) real value is ''

_Prop_Use_Relative_Paths = None # (!) real value is ''

_Prop_Use_RTTI = None # (!) real value is ''

_Prop_Use_Script_Menu = None # (!) real value is ''

_Prop_Use_ToolServer_Menu = None # (!) real value is ''

_Prop_value = None # (!) real value is ''

_Prop_Variable_Changed_Hilite = None # (!) real value is ''

_Prop_Variable_Hints = None # (!) real value is ''

_Prop_VCS_Active = None # (!) real value is ''

_Prop_virtual = None # (!) real value is ''

_Prop_Watchpoint_Hilite = None # (!) real value is ''

_Prop_weak_link = None # (!) real value is ''

_Prop_Working_Directory = None # (!) real value is ''

