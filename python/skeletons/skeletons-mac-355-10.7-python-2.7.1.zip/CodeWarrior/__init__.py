# encoding: utf-8
# module CodeWarrior.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/__init__.pyo by generator 1.99
""" Package generated from /Volumes/Sap/Applications (Mac OS 9)/Metrowerks CodeWarrior 7.0/Metrowerks CodeWarrior/CodeWarrior IDE 4.2.5 """

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import StdSuites as StdSuites # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/__init__.pyc
import CodeWarrior.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import CodeWarrior.Metrowerks_Shell_Suite as Metrowerks_Shell_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/Metrowerks_Shell_Suite.pyc
import CodeWarrior.Required as Required # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/Required.pyc
import CodeWarrior.CodeWarrior_suite as CodeWarrior_suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/CodeWarrior_suite.pyc

# Variables with simple values

Error = 'aetools.Error'

# functions

def getbaseclasses(v): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

Access_Paths = Metrowerks_Shell_Suite.Access_Paths

alias = StdSuites.aliases

aliases = StdSuites.aliases

application = Standard_Suite.application

applications = StdSuites.application

base_class = Metrowerks_Shell_Suite.base_classes

base_classes = Metrowerks_Shell_Suite.base_classes

browser_catalog = Metrowerks_Shell_Suite.browser_catalog

Browser_Coloring = Metrowerks_Shell_Suite.Browser_Coloring

Build_Extras = Metrowerks_Shell_Suite.Build_Extras

build_progress_document = CodeWarrior_suite.build_progress_document

build_progress_documents = CodeWarrior_suite.build_progress_document

Build_Settings = Metrowerks_Shell_Suite.Build_Settings

builtin_Suite_Events = StdSuites.builtin_Suite_Events

catalog_document = CodeWarrior_suite.catalog_document

catalog_documents = CodeWarrior_suite.catalog_document

character = Standard_Suite.character

classes = Metrowerks_Shell_Suite.classes

class_ = Metrowerks_Shell_Suite.classes

class_browser = CodeWarrior_suite.class_browsers

class_browsers = CodeWarrior_suite.class_browsers

class_hierarchies = CodeWarrior_suite.class_hierarchy

class_hierarchy = CodeWarrior_suite.class_hierarchy

clipboard = StdSuites.clipboard

CodeWarrior = None # (!) real value is ''

CodeWarrior_suite_Events = CodeWarrior_suite.CodeWarrior_suite_Events

contains = StdSuites.contains

Custom_Keywords = Metrowerks_Shell_Suite.Custom_Keywords

data_member = Metrowerks_Shell_Suite.data_members

data_members = Metrowerks_Shell_Suite.data_members

Debugger_Display = Metrowerks_Shell_Suite.Debugger_Display

Debugger_Global = Metrowerks_Shell_Suite.Debugger_Global

Debugger_Target = Metrowerks_Shell_Suite.Debugger_Target

Debugger_Windowing = Metrowerks_Shell_Suite.Debugger_Windowing

document = Standard_Suite.documents

documents = Standard_Suite.documents

Editor = Metrowerks_Shell_Suite.Editor

editor_document = CodeWarrior_suite.editor_document

editor_documents = CodeWarrior_suite.editor_document

ends_with = StdSuites.ends_with

Environment_Variable = Metrowerks_Shell_Suite.Environment_Variable

Error_Information = Metrowerks_Shell_Suite.Error_Information

Extras = Metrowerks_Shell_Suite.Extras

file = Standard_Suite.file

files = Standard_Suite.file

file_compare_document = CodeWarrior_suite.file_compare_document

file_compare_documents = CodeWarrior_suite.file_compare_document

File_Mapping = Metrowerks_Shell_Suite.File_Mapping

File_Mappings = Metrowerks_Shell_Suite.File_Mappings

Font = Metrowerks_Shell_Suite.Font

frontmost = StdSuites.frontmost

Function_Information = Metrowerks_Shell_Suite.Function_Information

Global_Source_Trees = Metrowerks_Shell_Suite.Global_Source_Trees

insertion_point = Standard_Suite.insertion_point

insertion_points = StdSuites.insertion_points

line = Standard_Suite.line

lines = Standard_Suite.line

member_function = Metrowerks_Shell_Suite.member_functions

member_functions = Metrowerks_Shell_Suite.member_functions

message_document = CodeWarrior_suite.message_documents

message_documents = CodeWarrior_suite.message_documents

Metrowerks_Shell_Suite_Events = Metrowerks_Shell_Suite.Metrowerks_Shell_Suite_Events

name = StdSuites.name

Path_Information = Metrowerks_Shell_Suite.Path_Information

Plugin_Settings = Metrowerks_Shell_Suite.Plugin_Settings

ProjectFile = Metrowerks_Shell_Suite.ProjectFile

project_document = CodeWarrior_suite.project_documents

project_documents = CodeWarrior_suite.project_documents

project_inspector = CodeWarrior_suite.project_inspector

project_inspectors = CodeWarrior_suite.project_inspector

Relative_Path = Metrowerks_Shell_Suite.Relative_Path

Required_Events = Required.Required_Events

Required_Suite_Events = StdSuites.Required_Suite_Events

Runtime_Settings = Metrowerks_Shell_Suite.Runtime_Settings

Segment = Metrowerks_Shell_Suite.Segment

selection = StdSuites.selection

selection_2d_object = Standard_Suite.selection_2d_object

Shielded_Folder = Metrowerks_Shell_Suite.Shielded_Folder

Shielded_Folders = Metrowerks_Shell_Suite.Shielded_Folders

single_class_browser = CodeWarrior_suite.single_class_browsers

single_class_browsers = CodeWarrior_suite.single_class_browsers

single_class_hierarchies = CodeWarrior_suite.single_class_hierarchies

single_class_hierarchy = CodeWarrior_suite.single_class_hierarchies

Source_Tree = Metrowerks_Shell_Suite.Source_Tree

Standard_Suite_Events = Standard_Suite.Standard_Suite_Events

starts_with = StdSuites.starts_with

subtarget = CodeWarrior_suite.subtarget

subtargets = CodeWarrior_suite.subtarget

symbol_browser = CodeWarrior_suite.symbol_browser

symbol_browsers = CodeWarrior_suite.symbol_browser

Syntax_Coloring = Metrowerks_Shell_Suite.Syntax_Coloring

target = CodeWarrior_suite.targets

targets = CodeWarrior_suite.targets

target_file = CodeWarrior_suite.target_files

target_files = CodeWarrior_suite.target_files

Target_Settings = Metrowerks_Shell_Suite.Target_Settings

Target_Source_Trees = Metrowerks_Shell_Suite.Target_Source_Trees

text = Standard_Suite.text

text_document = CodeWarrior_suite.text_document

text_documents = CodeWarrior_suite.text_document

ToolServer_worksheet = CodeWarrior_suite.ToolServer_worksheet

ToolServer_worksheets = CodeWarrior_suite.ToolServer_worksheet

user_interaction = Standard_Suite.user_interaction

VCS_Setup = Metrowerks_Shell_Suite.VCS_Setup

version = Standard_Suite.version

window = Standard_Suite.window

windows = Standard_Suite.window

_classdeclarations = {
    '1BRW': CodeWarrior_suite.single_class_browsers,
    '1HIR': CodeWarrior_suite.single_class_hierarchies,
    'BRKW': Metrowerks_Shell_Suite.Browser_Coloring,
    'BROW': CodeWarrior_suite.class_browsers,
    'BSTG': Metrowerks_Shell_Suite.Build_Settings,
    'BsCl': Metrowerks_Shell_Suite.base_classes,
    'COMP': CodeWarrior_suite.file_compare_document,
    'CTLG': CodeWarrior_suite.catalog_document,
    'CUKW': Metrowerks_Shell_Suite.Custom_Keywords,
    'Cata': Metrowerks_Shell_Suite.browser_catalog,
    'Clas': Metrowerks_Shell_Suite.classes,
    'DbDS': Metrowerks_Shell_Suite.Debugger_Display,
    'DbGL': Metrowerks_Shell_Suite.Debugger_Global,
    'DbTG': Metrowerks_Shell_Suite.Debugger_Target,
    'DbWN': Metrowerks_Shell_Suite.Debugger_Windowing,
    'DtMb': Metrowerks_Shell_Suite.data_members,
    'EDIT': CodeWarrior_suite.editor_document,
    'EDTR': Metrowerks_Shell_Suite.Editor,
    'EnvV': Metrowerks_Shell_Suite.Environment_Variable,
    'ErrM': Metrowerks_Shell_Suite.Error_Information,
    'FDef': Metrowerks_Shell_Suite.Function_Information,
    'FLMP': Metrowerks_Shell_Suite.File_Mappings,
    'FMap': Metrowerks_Shell_Suite.File_Mapping,
    'GSTs': Metrowerks_Shell_Suite.Global_Source_Trees,
    'GXTR': Metrowerks_Shell_Suite.Extras,
    'HIER': CodeWarrior_suite.class_hierarchy,
    'INSP': CodeWarrior_suite.project_inspector,
    'LXTR': Metrowerks_Shell_Suite.Build_Extras,
    'MSSG': CodeWarrior_suite.message_documents,
    'MbFn': Metrowerks_Shell_Suite.member_functions,
    'PATH': Metrowerks_Shell_Suite.Access_Paths,
    'PInf': Metrowerks_Shell_Suite.Path_Information,
    'PRGS': CodeWarrior_suite.build_progress_document,
    'PRJD': CodeWarrior_suite.project_documents,
    'PSTG': Metrowerks_Shell_Suite.Plugin_Settings,
    'RSTG': Metrowerks_Shell_Suite.Runtime_Settings,
    'RlPt': Metrowerks_Shell_Suite.Relative_Path,
    'SBTG': CodeWarrior_suite.subtarget,
    'SFit': Metrowerks_Shell_Suite.Shielded_Folder,
    'SHFL': Metrowerks_Shell_Suite.Shielded_Folders,
    'SNTX': Metrowerks_Shell_Suite.Syntax_Coloring,
    'SRCF': CodeWarrior_suite.target_files,
    'SYMB': CodeWarrior_suite.symbol_browser,
    'Seg ': Metrowerks_Shell_Suite.Segment,
    'SrcF': Metrowerks_Shell_Suite.ProjectFile,
    'SrcT': Metrowerks_Shell_Suite.Source_Tree,
    'TARG': Metrowerks_Shell_Suite.Target_Settings,
    'TOOL': CodeWarrior_suite.ToolServer_worksheet,
    'TRGT': CodeWarrior_suite.targets,
    'TSTs': Metrowerks_Shell_Suite.Target_Source_Trees,
    'TXTD': CodeWarrior_suite.text_document,
    'VCSs': Metrowerks_Shell_Suite.VCS_Setup,
    'capp': Standard_Suite.application,
    'cha ': Standard_Suite.character,
    'cins': Standard_Suite.insertion_point,
    'clin': Standard_Suite.line,
    'csel': Standard_Suite.selection_2d_object,
    'ctxt': Standard_Suite.text,
    'cwin': Standard_Suite.window,
    'docu': Standard_Suite.documents,
    'file': Standard_Suite.file,
    'mFNT': Metrowerks_Shell_Suite.Font,
}

_code_to_fullname = {
    'CWIE': (
        'CodeWarrior.CodeWarrior_suite',
        'CodeWarrior_suite',
    ),
    'CoRe': (
        'CodeWarrior.Standard_Suite',
        'Standard_Suite',
    ),
    'MMPR': (
        'CodeWarrior.Metrowerks_Shell_Suite',
        'Metrowerks_Shell_Suite',
    ),
    'reqd': (
        'CodeWarrior.Required',
        'Required',
    ),
}

_code_to_module = {
    'CWIE': None, # (!) forward: CodeWarrior_suite, real value is ''
    'CoRe': CodeWarrior_suite.Standard_Suite,
    'MMPR': None, # (!) forward: Metrowerks_Shell_Suite, real value is ''
    'reqd': None, # (!) forward: Required, real value is ''
}

