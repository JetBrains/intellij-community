# encoding: utf-8
# module CodeWarrior.CodeWarrior_suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/CodeWarrior_suite.pyo by generator 1.99
"""
Suite CodeWarrior suite: Terms for scripting the CodeWarrior IDE
Level 0, version 0

Generated from /Volumes/Sap/Applications (Mac OS 9)/Metrowerks CodeWarrior 7.0/Metrowerks CodeWarrior/CodeWarrior IDE 4.2.5
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import CodeWarrior.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/CodeWarrior/Standard_Suite.pyc

# Variables with simple values

_code = 'CWIE'

# no functions
# no classes
# variables with complex values

build_progress_document = None # (!) real value is ''

build_progress_documents = build_progress_document

catalog_document = None # (!) real value is ''

catalog_documents = catalog_document

class_browser = None # (!) forward: class_browsers, real value is ''

class_browsers = None # (!) real value is ''

class_hierarchies = None # (!) forward: class_hierarchy, real value is ''

class_hierarchy = None # (!) real value is ''

CodeWarrior_suite_Events = None # (!) real value is ''

editor_document = None # (!) real value is ''

editor_documents = editor_document

file_compare_document = None # (!) real value is ''

file_compare_documents = file_compare_document

message_document = None # (!) forward: message_documents, real value is ''

message_documents = None # (!) real value is ''

project_document = None # (!) forward: project_documents, real value is ''

project_documents = None # (!) real value is ''

project_inspector = None # (!) real value is ''

project_inspectors = project_inspector

single_class_browser = None # (!) forward: single_class_browsers, real value is ''

single_class_browsers = None # (!) real value is ''

single_class_hierarchies = None # (!) real value is ''

single_class_hierarchy = single_class_hierarchies

subtarget = None # (!) real value is ''

subtargets = subtarget

symbol_browser = None # (!) real value is ''

symbol_browsers = symbol_browser

target = None # (!) forward: targets, real value is ''

targets = None # (!) real value is ''

target_file = None # (!) forward: target_files, real value is ''

target_files = None # (!) real value is ''

text_document = None # (!) real value is ''

text_documents = text_document

ToolServer_worksheet = None # (!) real value is ''

ToolServer_worksheets = ToolServer_worksheet

_classdeclarations = {
    '1BRW': single_class_browsers,
    '1HIR': single_class_hierarchies,
    'BROW': class_browsers,
    'COMP': file_compare_document,
    'CTLG': catalog_document,
    'EDIT': editor_document,
    'HIER': class_hierarchy,
    'INSP': project_inspector,
    'MSSG': message_documents,
    'PRGS': build_progress_document,
    'PRJD': project_documents,
    'SBTG': subtarget,
    'SRCF': target_files,
    'SYMB': symbol_browser,
    'TOOL': ToolServer_worksheet,
    'TRGT': targets,
    'TXTD': text_document,
}

_compdeclarations = {}

_enumdeclarations = {
    'DKND': {
        'ToolServer_worksheet': 'TOOL',
        'build_progress_document': 'PRGS',
        'catalog_document': 'CTLG',
        'class_browser': 'BROW',
        'class_hierarchy': 'HIER',
        'editor_document': 'EDIT',
        'file_compare': 'COMP',
        'message': 'MSSG',
        'project': 'PRJD',
        'project_inspector': 'INSP',
        'single_class_browser': '1BRW',
        'single_class_hierarchy': '1HIR',
        'symbol_browser': 'SYMB',
    },
    'FTYP': {
        'library_file': 'LIBF',
        'project_file': 'PRJF',
        'resource_file': 'RESF',
        'text_file': 'TXTF',
        'unknown_file': 'UNKN',
    },
    'Inte': {
        'interact_with_all': 'eInA',
        'interact_with_local': 'eInL',
        'interact_with_self': 'eInS',
        'never_interact': 'eNvr',
    },
    'PERM': {
        'checked_out_read_modify': 'CkRM',
        'checked_out_read_only': 'CkRO',
        'checked_out_read_write': 'CkRW',
        'locked': 'Lock',
        'none': 'LNNO',
        'read_only': 'Read',
        'read_write': 'RdWr',
    },
}

_Enum_DKND = {
    'ToolServer_worksheet': 'TOOL',
    'build_progress_document': 'PRGS',
    'catalog_document': 'CTLG',
    'class_browser': 'BROW',
    'class_hierarchy': 'HIER',
    'editor_document': 'EDIT',
    'file_compare': 'COMP',
    'message': 'MSSG',
    'project': 'PRJD',
    'project_inspector': 'INSP',
    'single_class_browser': '1BRW',
    'single_class_hierarchy': '1HIR',
    'symbol_browser': 'SYMB',
}

_Enum_FTYP = {
    'library_file': 'LIBF',
    'project_file': 'PRJF',
    'resource_file': 'RESF',
    'text_file': 'TXTF',
    'unknown_file': 'UNKN',
}

_Enum_Inte = {
    'interact_with_all': 'eInA',
    'interact_with_local': 'eInL',
    'interact_with_self': 'eInS',
    'never_interact': 'eNvr',
}

_Enum_PERM = {
    'checked_out_read_modify': 'CkRM',
    'checked_out_read_only': 'CkRO',
    'checked_out_read_write': 'CkRW',
    'locked': 'Lock',
    'none': 'LNNO',
    'read_only': 'Read',
    'read_write': 'RdWr',
}

_propdeclarations = {
    'CMPD': None, # (!) forward: _Prop_compiled_date, real value is ''
    'CSZE': None, # (!) forward: _Prop_code_size, real value is ''
    'CURT': None, # (!) forward: _Prop_current_target, real value is ''
    'DBUG': None, # (!) forward: _Prop_debug, real value is ''
    'DPND': None, # (!) forward: _Prop_dependents, real value is ''
    'DSZE': None, # (!) forward: _Prop_data_size, real value is ''
    'FILE': None, # (!) forward: _Prop_location, real value is ''
    'FTYP': None, # (!) forward: _Prop_type, real value is ''
    'ID  ': None, # (!) forward: _Prop_id, real value is ''
    'INIT': None, # (!) forward: _Prop_init_before, real value is ''
    'LIDX': None, # (!) forward: _Prop_link_index, real value is ''
    'LINK': None, # (!) forward: _Prop_linked, real value is ''
    'LNKO': None, # (!) forward: _Prop_link_against_output, real value is ''
    'MODD': None, # (!) forward: _Prop_modified_date, real value is ''
    'MRGE': None, # (!) forward: _Prop_merge_output, real value is ''
    'PRER': None, # (!) forward: _Prop_prerequisites, real value is ''
    'Path': None, # (!) forward: _Prop_path, real value is ''
    'PrjD': None, # (!) forward: _Prop_project_document, real value is ''
    'TrgT': None, # (!) forward: _Prop_target, real value is ''
    'WEAK': None, # (!) forward: _Prop_weak_link, real value is ''
    'c@#^': None, # (!) forward: _Prop_inherits, real value is ''
    'imod': None, # (!) forward: _Prop_modified, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'sele': None, # (!) forward: _Prop_selection, real value is ''
}

_Prop_code_size = None # (!) real value is ''

_Prop_compiled_date = None # (!) real value is ''

_Prop_current_target = None # (!) real value is ''

_Prop_data_size = None # (!) real value is ''

_Prop_debug = None # (!) real value is ''

_Prop_dependents = None # (!) real value is ''

_Prop_id = None # (!) real value is ''

_Prop_inherits = None # (!) real value is ''

_Prop_init_before = None # (!) real value is ''

_Prop_linked = None # (!) real value is ''

_Prop_link_against_output = None # (!) real value is ''

_Prop_link_index = None # (!) real value is ''

_Prop_location = None # (!) real value is ''

_Prop_merge_output = None # (!) real value is ''

_Prop_modified = None # (!) real value is ''

_Prop_modified_date = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_path = None # (!) real value is ''

_Prop_prerequisites = None # (!) real value is ''

_Prop_project_document = None # (!) real value is ''

_Prop_selection = None # (!) real value is ''

_Prop_target = None # (!) real value is ''

_Prop_type = None # (!) real value is ''

_Prop_weak_link = None # (!) real value is ''

