# encoding: utf-8
# module curses.ascii
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/curses/ascii.pyo by generator 1.99
""" Constants and membership tests for ASCII characters """
# no imports

# Variables with simple values

ACK = 6

BEL = 7

BS = 8

CAN = 24

CR = 13

DC1 = 17
DC2 = 18
DC3 = 19
DC4 = 20

DEL = 127

DLE = 16

EM = 25

ENQ = 5

EOT = 4

ESC = 27

ETB = 23
ETX = 3

FF = 12

FS = 28

GS = 29

HT = 9

LF = 10

NAK = 21

NL = 10

NUL = 0

RS = 30

SI = 15

SO = 14
SOH = 1

SP = 32

STX = 2

SUB = 26

SYN = 22

TAB = 9

US = 31

VT = 11

# functions

def alt(c): # reliably restored by inspect
    # no doc
    pass


def ascii(c): # reliably restored by inspect
    # no doc
    pass


def ctrl(c): # reliably restored by inspect
    # no doc
    pass


def isalnum(c): # reliably restored by inspect
    # no doc
    pass


def isalpha(c): # reliably restored by inspect
    # no doc
    pass


def isascii(c): # reliably restored by inspect
    # no doc
    pass


def isblank(c): # reliably restored by inspect
    # no doc
    pass


def iscntrl(c): # reliably restored by inspect
    # no doc
    pass


def isctrl(c): # reliably restored by inspect
    # no doc
    pass


def isdigit(c): # reliably restored by inspect
    # no doc
    pass


def isgraph(c): # reliably restored by inspect
    # no doc
    pass


def islower(c): # reliably restored by inspect
    # no doc
    pass


def ismeta(c): # reliably restored by inspect
    # no doc
    pass


def isprint(c): # reliably restored by inspect
    # no doc
    pass


def ispunct(c): # reliably restored by inspect
    # no doc
    pass


def isspace(c): # reliably restored by inspect
    # no doc
    pass


def isupper(c): # reliably restored by inspect
    # no doc
    pass


def isxdigit(c): # reliably restored by inspect
    # no doc
    pass


def unctrl(c): # reliably restored by inspect
    # no doc
    pass


def _ctoi(c): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

controlnames = [
    'NUL',
    'SOH',
    'STX',
    'ETX',
    'EOT',
    'ENQ',
    'ACK',
    'BEL',
    'BS',
    'HT',
    'LF',
    'VT',
    'FF',
    'CR',
    'SO',
    'SI',
    'DLE',
    'DC1',
    'DC2',
    'DC3',
    'DC4',
    'NAK',
    'SYN',
    'ETB',
    'CAN',
    'EM',
    'SUB',
    'ESC',
    'FS',
    'GS',
    'RS',
    'US',
    'SP',
]

