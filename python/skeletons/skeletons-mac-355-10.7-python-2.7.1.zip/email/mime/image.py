# encoding: utf-8
# module email.mime.image
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/mime/image.pyo by generator 1.99
""" Class representing image/* type MIME documents. """

# imports
import email.encoders as encoders # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/encoders.pyc
import imghdr as imghdr # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/imghdr.pyc

# no functions
# no classes
# variables with complex values

MIMEImage = None # (!) real value is ''

MIMENonMultipart = None # (!) real value is ''

__all__ = [
    'MIMEImage',
]

