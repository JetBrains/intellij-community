# encoding: utf-8
# module email.mime.base
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/mime/base.pyo by generator 1.99
""" Base class for MIME specializations. """

# imports
import email.message as message # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/message.pyc

# no functions
# no classes
# variables with complex values

MIMEBase = None # (!) real value is ''

__all__ = [
    'MIMEBase',
]

