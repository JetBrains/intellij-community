# encoding: utf-8
# module email.mime.application
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/mime/application.pyo by generator 1.99
""" Class representing application/* type MIME documents. """

# imports
import email.encoders as encoders # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/encoders.pyc

# no functions
# no classes
# variables with complex values

MIMEApplication = None # (!) real value is ''

MIMENonMultipart = None # (!) real value is ''

__all__ = [
    'MIMEApplication',
]

