# encoding: utf-8
# module email.generator
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/generator.pyo by generator 1.99
""" Classes to generate plain text from a message object tree. """

# imports
import random as random # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/random.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/warnings.pyc
import sys as sys # <module 'sys' (built-in)>
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so
from cStringIO import StringIO


# Variables with simple values

NL = '\n'

UNDERSCORE = '_'

_FMT = '[Non-text (%(type)s) part of message omitted, filename %(filename)s]'

_fmt = '%019d'

_width = 19

# functions

def _is8bitstring(s): # reliably restored by inspect
    # no doc
    pass


def _make_boundary(text=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

DecodedGenerator = None # (!) real value is ''

fcre = None # (!) real value is ''

Generator = None # (!) real value is ''

Header = None # (!) real value is ''

__all__ = [
    'Generator',
    'DecodedGenerator',
]

