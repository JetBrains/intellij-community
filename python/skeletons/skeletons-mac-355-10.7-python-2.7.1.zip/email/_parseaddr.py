# encoding: utf-8
# module email._parseaddr
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/_parseaddr.pyo by generator 1.99
"""
Email address parsing code.

Lifted directly from rfc822.py.  This should eventually be rewritten.
"""

# imports
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/time.so

# Variables with simple values

COMMASPACE = ', '

EMPTYSTRING = ''

SPACE = ' '

# functions

def mktime_tz(data): # reliably restored by inspect
    """ Turn a 10-tuple as returned by parsedate_tz() into a UTC timestamp. """
    pass


def parsedate(data): # reliably restored by inspect
    """ Convert a time string to a time tuple. """
    pass


def parsedate_tz(data): # reliably restored by inspect
    """
    Convert a date string to a time tuple.
    
        Accounts for military timezones.
    """
    pass


def quote(str): # reliably restored by inspect
    """
    Prepare string to be used in a quoted string.
    
        Turns backslash and double quote characters into quoted pairs.  These
        are the only characters that need to be quoted inside a quoted string.
        Does not add the surrounding double quotes.
    """
    pass


# no classes
# variables with complex values

AddressList = None # (!) real value is ''

AddrlistClass = None # (!) real value is ''

_daynames = [
    'mon',
    'tue',
    'wed',
    'thu',
    'fri',
    'sat',
    'sun',
]

_monthnames = [
    'jan',
    'feb',
    'mar',
    'apr',
    'may',
    'jun',
    'jul',
    'aug',
    'sep',
    'oct',
    'nov',
    'dec',
    'january',
    'february',
    'march',
    'april',
    'may',
    'june',
    'july',
    'august',
    'september',
    'october',
    'november',
    'december',
]

_timezones = {
    'ADT': -300,
    'AST': -400,
    'CDT': -500,
    'CST': -600,
    'EDT': -400,
    'EST': -500,
    'GMT': 0,
    'MDT': -600,
    'MST': -700,
    'PDT': -700,
    'PST': -800,
    'UT': 0,
    'UTC': 0,
    'Z': 0,
}

__all__ = [
    'mktime_tz',
    'parsedate',
    'parsedate_tz',
    'quote',
]

