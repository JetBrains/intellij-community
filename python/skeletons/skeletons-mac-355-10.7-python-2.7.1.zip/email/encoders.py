# encoding: utf-8
# module email.encoders
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/encoders.pyo by generator 1.99
""" Encodings and related functions. """

# imports
import base64 as base64 # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/base64.pyc

# functions

def encode_7or8bit(msg): # reliably restored by inspect
    """ Set the Content-Transfer-Encoding header to 7bit or 8bit. """
    pass


def encode_base64(msg): # reliably restored by inspect
    """
    Encode the message's payload in Base64.
    
        Also, add an appropriate Content-Transfer-Encoding header.
    """
    pass


def encode_noop(msg): # reliably restored by inspect
    """ Do nothing. """
    pass


def encode_quopri(msg): # reliably restored by inspect
    """
    Encode the message's payload in quoted-printable.
    
        Also, add an appropriate Content-Transfer-Encoding header.
    """
    pass


def _bencode(s): # reliably restored by inspect
    # no doc
    pass


def _encodestring(s, quotetabs=0, header=0): # reliably restored by inspect
    # no doc
    pass


def _qencode(s): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

__all__ = [
    'encode_7or8bit',
    'encode_base64',
    'encode_noop',
    'encode_quopri',
]

