# encoding: utf-8
# module email.header
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/header.pyo by generator 1.99
""" Header encoding and decoding functionality. """

# imports
import binascii as binascii # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/binascii.so
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import email as email # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/email/__init__.pyc
import email.errors as __email_errors


# Variables with simple values

MAXLINELEN = 76

NL = '\n'

SPACE = ' '
SPACE8 = '        '

UEMPTYSTRING = u''

USPACE = u' '

# functions

def decode_header(header): # reliably restored by inspect
    """
    Decode a message header value without converting charset.
    
        Returns a list of (decoded_string, charset) pairs containing each of the
        decoded parts of the header.  Charset is None for non-encoded parts of the
        header, otherwise a lower-case string containing the name of the character
        set specified in the encoded string.
    
        An email.errors.HeaderParseError may be raised when certain decoding error
        occurs (e.g. a base64 decoding exception).
    """
    pass


def make_header(decoded_seq, maxlinelen=None, header_name=None, continuation_ws=None): # reliably restored by inspect
    """
    Create a Header from a sequence of pairs as returned by decode_header()
    
        decode_header() takes a header value string and returns a sequence of
        pairs of the format (decoded_string, charset) where charset is the string
        name of the character set.
    
        This function takes one of those sequence of pairs and returns a Header
        instance.  Optional maxlinelen, header_name, and continuation_ws are as in
        the Header constructor.
    """
    pass


def _binsplit(splittable, charset, maxlinelen): # reliably restored by inspect
    # no doc
    pass


def _max_append(L, s, maxlen, extra=None): # reliably restored by inspect
    # no doc
    pass


def _split_ascii(s, firstlen, restlen, continuation_ws, splitchars): # reliably restored by inspect
    # no doc
    pass


# classes

class HeaderParseError(__email_errors.MessageParseError):
    """ Error while parsing headers. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

Charset = None # (!) real value is ''

ecre = None # (!) real value is ''

fcre = None # (!) real value is ''

Header = None # (!) real value is ''

USASCII = None # (!) real value is ''

UTF8 = None # (!) real value is ''

__all__ = [
    'Header',
    'decode_header',
    'make_header',
]

