# encoding: utf-8
# module numpy.core._sort
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/_sort.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
