# encoding: utf-8
# module numpy.core.multiarray_tests
# from /System/Library/Frameworks/Python.framework/Versions/2.7/Extras/lib/python/numpy/core/multiarray_tests.so by generator 1.99
# no doc
# no imports

# functions

def test_neighborhood_iterator(*args, **kwargs): # real signature unknown
    pass


def test_neighborhood_iterator_oob(*args, **kwargs): # real signature unknown
    pass


# no classes
