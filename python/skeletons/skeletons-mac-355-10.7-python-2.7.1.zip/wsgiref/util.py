# encoding: utf-8
# module wsgiref.util
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/wsgiref/util.pyo by generator 1.99
""" Miscellaneous WSGI-related Utilities """

# imports
import posixpath as posixpath # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/posixpath.pyc

# functions

def application_uri(environ): # reliably restored by inspect
    """ Return the application's base URI (no PATH_INFO or QUERY_STRING) """
    pass


def guess_scheme(environ): # reliably restored by inspect
    """ Return a guess for whether 'wsgi.url_scheme' should be 'http' or 'https' """
    pass


def is_hop_by_hop(header_name): # reliably restored by inspect
    """ Return true if 'header_name' is an HTTP/1.1 "Hop-by-Hop" header """
    pass


def request_uri(environ, include_query=1): # reliably restored by inspect
    """ Return the full request URI, optionally including the query string """
    pass


def setup_testing_defaults(environ): # reliably restored by inspect
    """
    Update 'environ' with trivial defaults for testing purposes
    
        This adds various parameters required for WSGI, including HTTP_HOST,
        SERVER_NAME, SERVER_PORT, REQUEST_METHOD, SCRIPT_NAME, PATH_INFO,
        and all of the wsgi.* variables.  It only supplies default values,
        and does not replace any existing settings for these variables.
    
        This routine is intended to make it easier for unit tests of WSGI
        servers and applications to set up dummy environments.  It should *not*
        be used by actual WSGI servers or applications, since the data is fake!
    """
    pass


def shift_path_info(environ): # reliably restored by inspect
    """
    Shift a name from PATH_INFO to SCRIPT_NAME, returning it
    
        If there are no remaining path segments in PATH_INFO, return None.
        Note: 'environ' is modified in-place; use a copy if you need to keep
        the original PATH_INFO or SCRIPT_NAME.
    
        Note: when PATH_INFO is just a '/', this returns '' and appends a trailing
        '/' to SCRIPT_NAME, even though empty path segments are normally ignored,
        and SCRIPT_NAME doesn't normally end in a '/'.  This is intentional
        behavior, to ensure that an application can tell the difference between
        '/x' and '/x/' when traversing to objects.
    """
    pass


def _hoppish(*args, **kwargs): # real signature unknown
    """ D.__contains__(k) -> True if D has a key k, else False """
    pass


# no classes
# variables with complex values

FileWrapper = None # (!) real value is ''

__all__ = [
    'FileWrapper',
    'guess_scheme',
    'application_uri',
    'request_uri',
    'shift_path_info',
    'setup_testing_defaults',
]

