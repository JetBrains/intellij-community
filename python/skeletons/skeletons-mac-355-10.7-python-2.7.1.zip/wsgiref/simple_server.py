# encoding: utf-8
# module wsgiref.simple_server
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/wsgiref/simple_server.pyo by generator 1.99
"""
BaseHTTPServer that implements the Python WSGI protocol (PEP 333, rev 1.21)

This is both an example of how WSGI can be implemented, and a basis for running
simple web applications on a local machine, such as might be done when testing
or debugging an application.  It has not been reviewed for security issues,
however, and we strongly recommend that you use a "real" web server for
production use.

For example usage, see the 'if __name__=="__main__"' block at the end of the
module.  See also the BaseHTTPServer module docs for other API information.
"""

# imports
import urllib as urllib # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/urllib.py
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

server_version = 'WSGIServer/0.1'

software_version = 'WSGIServer/0.1 Python/2.7.1'

sys_version = 'Python/2.7.1'

__version__ = '0.1'

# functions

def demo_app(environ, start_response): # reliably restored by inspect
    # no doc
    pass


def make_server(host, port, app, server_class='<class wsgiref.simple_server.WSGIServer at 0x101b5e120>', handler_class='<class wsgiref.simple_server.WSGIRequestHandler at 0x101b5e188>'): # reliably restored by inspect
    """ Create a new WSGI server listening on `host` and `port` for `app` """
    pass


# no classes
# variables with complex values

BaseHTTPRequestHandler = None # (!) real value is ''

HTTPServer = None # (!) real value is ''

ServerHandler = None # (!) real value is ''

SimpleHandler = None # (!) real value is ''

WSGIRequestHandler = None # (!) real value is ''

WSGIServer = None # (!) real value is ''

__all__ = [
    'WSGIServer',
    'WSGIRequestHandler',
    'demo_app',
    'make_server',
]

