# encoding: utf-8
# module Netscape.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/__init__.pyo by generator 1.99
""" Package generated from /Volumes/Sap/Applications (Mac OS 9)/Netscape Communicator™ Folder/Netscape Communicator™ """

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import StdSuites as StdSuites # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/StdSuites/__init__.pyc
import Netscape.Mozilla_suite as Mozilla_suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Mozilla_suite.pyc
import Netscape.Standard_Suite as Standard_Suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Standard_Suite.pyc
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc
import Netscape.WorldWideWeb_suite as WorldWideWeb_suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/WorldWideWeb_suite.pyc
import Netscape.Required_suite as Required_suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Required_suite.pyc
import Netscape.PowerPlant as PowerPlant # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/PowerPlant.pyc
import Netscape.Text as Text # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Text.pyc
import Netscape.Standard_URL_suite as Standard_URL_suite # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Standard_URL_suite.pyc

# Variables with simple values

Error = 'aetools.Error'

# functions

def getbaseclasses(v): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

alert_application = Standard_Suite.alert_application

alias = StdSuites.aliases

aliases = StdSuites.aliases

application = Standard_Suite.application

applications = StdSuites.application

builtin_Suite_Events = StdSuites.builtin_Suite_Events

character = Text.character

clipboard = StdSuites.clipboard

contains = StdSuites.contains

document = StdSuites.document

documents = StdSuites.document

ends_with = StdSuites.ends_with

file = StdSuites.files

files = StdSuites.files

frontmost = StdSuites.frontmost

insertion_point = StdSuites.insertion_points

insertion_points = StdSuites.insertion_points

kiosk_mode = Standard_Suite.kiosk_mode

line = StdSuites.line

lines = StdSuites.line

Mozilla_suite_Events = Mozilla_suite.Mozilla_suite_Events

name = StdSuites.name

Netscape = None # (!) real value is ''

paragraph = StdSuites.paragraphs

paragraphs = StdSuites.paragraphs

PowerPlant_Events = PowerPlant.PowerPlant_Events

Required_Suite_Events = StdSuites.Required_Suite_Events

Required_suite_Events = Required_suite.Required_suite_Events

selection = StdSuites.selection

selection_2d_object = StdSuites.selection_2d_object

Standard_Suite_Events = Standard_Suite.Standard_Suite_Events

Standard_URL_suite_Events = Standard_URL_suite.Standard_URL_suite_Events

starts_with = StdSuites.starts_with

styleset = Text.styleset

stylesets = Text.styleset

text = Text.text

Text_Events = Text.Text_Events

text_flow = StdSuites.text_flows

text_flows = StdSuites.text_flows

text_style_info = StdSuites.text_style_infos

text_style_infos = StdSuites.text_style_infos

Text_Suite_Events = StdSuites.Text_Suite_Events

version = Standard_Suite.version

window = Standard_Suite.window

windows = StdSuites.window

word = StdSuites.words

words = StdSuites.words

WorldWideWeb_suite_Events = WorldWideWeb_suite.WorldWideWeb_suite_Events

_classdeclarations = {
    'capp': Standard_Suite.application,
    'cflo': StdSuites.text_flows,
    'cha ': Text.character,
    'clin': StdSuites.line,
    'cpar': StdSuites.paragraphs,
    'ctxt': None, # (!) real value is ''
    'cwin': Standard_Suite.window,
    'cwor': StdSuites.words,
    'stys': Text.styleset,
    'tsty': StdSuites.text_style_infos,
}

_code_to_fullname = {
    'CoRe': (
        'Netscape.Standard_Suite',
        'Standard_Suite',
    ),
    'GURL': (
        'Netscape.Standard_URL_suite',
        'Standard_URL_suite',
    ),
    'MOSS': (
        'Netscape.Mozilla_suite',
        'Mozilla_suite',
    ),
    'TEXT': (
        'Netscape.Text',
        'Text',
    ),
    'WWW!': (
        'Netscape.WorldWideWeb_suite',
        'WorldWideWeb_suite',
    ),
    'ppnt': (
        'Netscape.PowerPlant',
        'PowerPlant',
    ),
    'reqd': (
        'Netscape.Required_suite',
        'Required_suite',
    ),
}

_code_to_module = {
    'CoRe': None, # (!) forward: Standard_Suite, real value is ''
    'GURL': None, # (!) forward: Standard_URL_suite, real value is ''
    'MOSS': None, # (!) forward: Mozilla_suite, real value is ''
    'TEXT': None, # (!) forward: Text, real value is ''
    'WWW!': None, # (!) forward: WorldWideWeb_suite, real value is ''
    'ppnt': None, # (!) forward: PowerPlant, real value is ''
    'reqd': None, # (!) forward: Required_suite, real value is ''
}

