# encoding: utf-8
# module Netscape.WorldWideWeb_suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/WorldWideWeb_suite.pyo by generator 1.99
"""
Suite WorldWideWeb suite, as defined in Spyglass spec.:
Level 1, version 1

Generated from /Volumes/Sap/Applications (Mac OS 9)/Netscape Communicator™ Folder/Netscape Communicator™
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'WWW!'

# no functions
# no classes
# variables with complex values

WorldWideWeb_suite_Events = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {}

