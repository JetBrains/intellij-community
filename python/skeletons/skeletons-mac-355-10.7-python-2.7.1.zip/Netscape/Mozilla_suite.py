# encoding: utf-8
# module Netscape.Mozilla_suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Mozilla_suite.pyo by generator 1.99
"""
Suite Mozilla suite: Experimental Mozilla suite
Level 1, version 1

Generated from /Volumes/Sap/Applications (Mac OS 9)/Netscape Communicator™ Folder/Netscape Communicator™
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'MOSS'

# no functions
# no classes
# variables with complex values

Mozilla_suite_Events = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {
    'comp': {
        'Calendar': 'cald',
        'Composer': 'cpsr',
        'Conference': 'conf',
        'InBox': 'inbx',
        'Navigator': 'navg',
        'Newsgroups': 'colb',
    },
    'dire': {
        'again': 'agai',
        'backward': 'prev',
        'forward': 'next',
        'home': 'home',
    },
    'ncmd': {
        'Get_new_mail': '\x00\x00\x04W',
        'Read_newsgroups': '\x00\x00\x04\x04',
        'Send_queued_messages': '\x00\x00\x04X',
        'Show_Address_Book_window': '\x00\x00\x04\t',
        'Show_Bookmarks_window': '\x00\x00\x04\x06',
        'Show_History_window': '\x00\x00\x04\x07',
        'Show_Inbox': '\x00\x00\x04\x05',
    },
}

_Enum_comp = {
    'Calendar': 'cald',
    'Composer': 'cpsr',
    'Conference': 'conf',
    'InBox': 'inbx',
    'Navigator': 'navg',
    'Newsgroups': 'colb',
}

_Enum_dire = {
    'again': 'agai',
    'backward': 'prev',
    'forward': 'next',
    'home': 'home',
}

_Enum_ncmd = {
    'Get_new_mail': '\x00\x00\x04W',
    'Read_newsgroups': '\x00\x00\x04\x04',
    'Send_queued_messages': '\x00\x00\x04X',
    'Show_Address_Book_window': '\x00\x00\x04\t',
    'Show_Bookmarks_window': '\x00\x00\x04\x06',
    'Show_History_window': '\x00\x00\x04\x07',
    'Show_Inbox': '\x00\x00\x04\x05',
}

_propdeclarations = {}

