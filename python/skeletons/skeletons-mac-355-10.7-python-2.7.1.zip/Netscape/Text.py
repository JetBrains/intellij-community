# encoding: utf-8
# module Netscape.Text
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Text.pyo by generator 1.99
"""
Suite Text:
Level 0, version 0

Generated from /Volumes/Sap/Applications (Mac OS 9)/Netscape Communicator™ Folder/Netscape Communicator™
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'TEXT'

# no functions
# no classes
# variables with complex values

character = None # (!) real value is ''

line = None # (!) real value is ''

lines = line

paragraph = None # (!) forward: paragraphs, real value is ''

paragraphs = None # (!) real value is ''

styleset = None # (!) real value is ''

stylesets = styleset

text = None # (!) real value is ''

Text_Events = None # (!) real value is ''

text_flow = None # (!) forward: text_flows, real value is ''

text_flows = None # (!) real value is ''

text_style_info = None # (!) real value is ''

text_style_infos = text_style_info

Text_Suite_Events = None # (!) real value is ''

word = None # (!) forward: words, real value is ''

words = None # (!) real value is ''

_classdeclarations = {
    'ctxt': text,
    'stys': styleset,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'bgng': None, # (!) forward: _Prop_beginning, real value is ''
    'colr': None, # (!) forward: _Prop_color, real value is ''
    'end ': None, # (!) forward: _Prop_end, real value is ''
    'font': None, # (!) forward: _Prop_font, real value is ''
    'pAft': None, # (!) forward: _Prop_justbehind, real value is ''
    'pBef': None, # (!) forward: _Prop_infront, real value is ''
    'pUpL': None, # (!) forward: _Prop_updateLevel, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'psct': None, # (!) forward: _Prop_writing_code, real value is ''
    'ptsz': None, # (!) forward: _Prop_size, real value is ''
    'txst': None, # (!) forward: _Prop_style, real value is ''
}

_Prop_beginning = None # (!) real value is ''

_Prop_color = None # (!) real value is ''

_Prop_end = None # (!) real value is ''

_Prop_font = None # (!) real value is ''

_Prop_infront = None # (!) real value is ''

_Prop_justbehind = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_size = None # (!) real value is ''

_Prop_style = None # (!) real value is ''

_Prop_updateLevel = None # (!) real value is ''

_Prop_writing_code = None # (!) real value is ''

