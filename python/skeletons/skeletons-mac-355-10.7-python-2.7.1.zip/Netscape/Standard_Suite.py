# encoding: utf-8
# module Netscape.Standard_Suite
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/Standard_Suite.pyo by generator 1.99
"""
Suite Standard Suite: Common terms for most applications
Level 1, version 1

Generated from /Volumes/Sap/Applications (Mac OS 9)/Netscape Communicator™ Folder/Netscape Communicator™
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'CoRe'

# no functions
# no classes
# variables with complex values

alert_application = None # (!) real value is ''

alias = None # (!) forward: aliases, real value is ''

aliases = None # (!) real value is ''

application = None # (!) real value is ''

applications = None # (!) real value is ''

builtin_Suite_Events = None # (!) real value is ''

clipboard = None # (!) real value is ''

contains = None # (!) real value is ''

document = None # (!) forward: documents, real value is ''

documents = None # (!) real value is ''

ends_with = None # (!) real value is ''

file = None # (!) real value is ''

files = file

frontmost = None # (!) real value is ''

insertion_point = None # (!) forward: insertion_points, real value is ''

insertion_points = None # (!) real value is ''

kiosk_mode = None # (!) real value is ''

name = None # (!) real value is ''

selection = None # (!) real value is ''

selection_2d_object = None # (!) real value is ''

Standard_Suite_Events = None # (!) real value is ''

starts_with = None # (!) real value is ''

version = None # (!) real value is ''

window = None # (!) real value is ''

windows = None # (!) real value is ''

_classdeclarations = {
    'capp': application,
    'cwin': window,
}

_compdeclarations = {}

_enumdeclarations = {}

_propdeclarations = {
    'ALAP': None, # (!) forward: _Prop_alert_application, real value is ''
    'KOSK': None, # (!) forward: _Prop_kiosk_mode, real value is ''
    'busy': None, # (!) forward: _Prop_busy, real value is ''
    'curl': None, # (!) forward: _Prop_URL, real value is ''
    'hclb': None, # (!) forward: _Prop_closeable, real value is ''
    'isfl': None, # (!) forward: _Prop_floating, real value is ''
    'iszm': None, # (!) forward: _Prop_zoomable, real value is ''
    'pbnd': None, # (!) forward: _Prop_bounds, real value is ''
    'pidx': None, # (!) forward: _Prop_index, real value is ''
    'pmod': None, # (!) forward: _Prop_modal, real value is ''
    'pnam': None, # (!) forward: _Prop_name, real value is ''
    'ppos': None, # (!) forward: _Prop_position, real value is ''
    'prsz': None, # (!) forward: _Prop_resizable, real value is ''
    'ptit': None, # (!) forward: _Prop_titled, real value is ''
    'pvis': None, # (!) forward: _Prop_visible, real value is ''
    'pzum': None, # (!) forward: _Prop_zoomed, real value is ''
    'wiid': None, # (!) forward: _Prop_unique_ID, real value is ''
}

_Prop_alert_application = None # (!) real value is ''

_Prop_bounds = None # (!) real value is ''

_Prop_busy = None # (!) real value is ''

_Prop_closeable = None # (!) real value is ''

_Prop_floating = None # (!) real value is ''

_Prop_index = None # (!) real value is ''

_Prop_kiosk_mode = None # (!) real value is ''

_Prop_modal = None # (!) real value is ''

_Prop_name = None # (!) real value is ''

_Prop_position = None # (!) real value is ''

_Prop_resizable = None # (!) real value is ''

_Prop_titled = None # (!) real value is ''

_Prop_unique_ID = None # (!) real value is ''

_Prop_URL = None # (!) real value is ''

_Prop_visible = None # (!) real value is ''

_Prop_zoomable = None # (!) real value is ''

_Prop_zoomed = None # (!) real value is ''

