# encoding: utf-8
# module Netscape.PowerPlant
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/lib-scriptpackages/Netscape/PowerPlant.pyo by generator 1.99
"""
Suite PowerPlant:
Level 0, version 0

Generated from /Volumes/Sap/Applications (Mac OS 9)/Netscape Communicator™ Folder/Netscape Communicator™
AETE/AEUT resource version 1/0, language 0, script 0
"""

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/MacOS.so
import aetools as aetools # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/plat-mac/aetools.pyc

# Variables with simple values

_code = 'ppnt'

# no functions
# no classes
# variables with complex values

PowerPlant_Events = None # (!) real value is ''

_classdeclarations = {}

_compdeclarations = {}

_enumdeclarations = {
    'dbac': {
        'DoNothing': '\x00\x00\x00\x00',
        'LowLevelDebugger': '\x00\x00\x00\x02',
        'PostAlert': '\x00\x00\x00\x01',
        'SourceDebugger': '\x00\x00\x00\x03',
    },
}

_Enum_dbac = {
    'DoNothing': '\x00\x00\x00\x00',
    'LowLevelDebugger': '\x00\x00\x00\x02',
    'PostAlert': '\x00\x00\x00\x01',
    'SourceDebugger': '\x00\x00\x00\x03',
}

_propdeclarations = {}

