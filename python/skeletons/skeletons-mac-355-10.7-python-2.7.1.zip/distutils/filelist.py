# encoding: utf-8
# module distutils.filelist
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/filelist.pyo by generator 1.99
"""
distutils.filelist

Provides the FileList class, used for poking about the filesystem
and building lists of files.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import fnmatch as fnmatch # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/fnmatch.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: filelist.py 75196 2009-10-03 00:07:35Z tarek.ziade $'

# functions

def convert_path(pathname): # reliably restored by inspect
    """
    Return 'pathname' as a name that will work on the native filesystem,
        i.e. split it on '/' and put it back together again using the current
        directory separator.  Needed because filenames in the setup script are
        always supplied in Unix style, and have to be converted to the local
        convention before we can actually use them in the filesystem.  Raises
        ValueError on non-Unix-ish systems if 'pathname' either starts or
        ends with a slash.
    """
    pass


def findall(dir=None): # reliably restored by inspect
    """
    Find all files under 'dir' and return the list of full filenames
        (relative to 'dir').
    """
    pass


def glob_to_re(pattern): # reliably restored by inspect
    """
    Translate a shell-like glob pattern to a regular expression.
    
        Return a string containing the regex.  Differs from
        'fnmatch.translate()' in that '*' does not match "special characters"
        (which are platform-specific).
    """
    pass


def translate_pattern(pattern, anchor=1, prefix=None, is_regex=0): # reliably restored by inspect
    """
    Translate a shell-like wildcard pattern to a compiled regular
        expression.
    
        Return the compiled regex.  If 'is_regex' true,
        then 'pattern' is directly compiled to a regex (if it's a string)
        or just returned as-is (assumes it's a regex object).
    """
    pass


# classes

class DistutilsInternalError(__distutils_errors.DistutilsError):
    """
    Internal inconsistencies or impossibilities (obviously, this
        should never be seen if the code is working!).
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsTemplateError(__distutils_errors.DistutilsError):
    """ Syntax error in a file list template. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

FileList = None # (!) real value is ''

