# encoding: utf-8
# module distutils.text_file
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/text_file.pyo by generator 1.99
"""
text_file

provides the TextFile class, which gives an interface to text files
that (optionally) takes care of stripping comments, ignoring blank
lines, and joining lines with backslashes.
"""

# imports
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

__revision__ = '$Id: text_file.py 76956 2009-12-21 01:22:46Z tarek.ziade $'

# no functions
# no classes
# variables with complex values

TextFile = None # (!) real value is ''

