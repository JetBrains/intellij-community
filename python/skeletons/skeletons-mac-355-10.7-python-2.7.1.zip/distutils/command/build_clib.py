# encoding: utf-8
# module distutils.command.build_clib
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/build_clib.pyo by generator 1.99
"""
distutils.command.build_clib

Implements the Distutils 'build_clib' command, to build a C/C++ library
that is included in the module distribution and needed by an extension
module.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: build_clib.py 84610 2010-09-07 22:18:34Z eric.araujo $'

# functions

def customize_compiler(compiler): # reliably restored by inspect
    """
    Do any platform-specific customization of a CCompiler instance.
    
        Mainly needed on Unix, so we can plug in the information that
        varies across Unices and is stored in Python's Makefile.
    """
    pass


def show_compilers(): # reliably restored by inspect
    # no doc
    pass


# classes

class DistutilsSetupError(__distutils_errors.DistutilsError):
    """
    For errors that can be definitely blamed on the setup script,
        such as invalid keyword arguments to 'setup()'.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

build_clib = None # (!) real value is ''

Command = None # (!) real value is ''

