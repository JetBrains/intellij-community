# encoding: utf-8
# module distutils.command.upload
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/upload.pyo by generator 1.99
"""
distutils.command.upload

Implements the Distutils 'upload' subcommand (upload package to PyPI).
"""

# imports
import socket as socket # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/socket.pyc
import cStringIO as StringIO # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/cStringIO.so
import urlparse as urlparse # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/urlparse.pyc
import platform as platform # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/platform.pyc
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
from _hashlib import md5

import distutils.errors as __distutils_errors
import urllib as __urllib
import urllib2 as __urllib2


# functions

def spawn(cmd, search_path=1, verbose=0, dry_run=0): # reliably restored by inspect
    """
    Run another program, specified as a command list 'cmd', in a new process.
    
        'cmd' is just the argument list for the new process, ie.
        cmd[0] is the program to run and cmd[1:] are the rest of its arguments.
        There is no way to run a program with a name different from that of its
        executable.
    
        If 'search_path' is true (the default), the system's executable
        search path will be used to find the program; otherwise, cmd[0]
        must be the exact path to the executable.  If 'dry_run' is true,
        the command will not actually be run.
    
        Raise DistutilsExecError if running the program fails in any way; just
        return on success.
    """
    pass


def standard_b64encode(s): # reliably restored by inspect
    """
    Encode a string using the standard Base64 alphabet.
    
        s is the string to encode.  The encoded string is returned.
    """
    pass


def urlopen(url, data=None, timeout='<object object at 0x10e39c0c0>'): # reliably restored by inspect
    # no doc
    pass


# classes

class DistutilsOptionError(__distutils_errors.DistutilsError):
    """
    Syntactic/semantic errors in command options, such as use of
        mutually conflicting options, or inconsistent options,
        badly-spelled values, etc.  No distinction is made between option
        values originating in the setup script, the command line, config
        files, or what-have-you -- but if we *know* something originated in
        the setup script, we'll raise DistutilsSetupError instead.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class HTTPError(__urllib2.URLError, __urllib.addinfourl):
    """ Raised when HTTP error occurs, but also acts like non-error return """
    def _HTTPError__super_init(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

PyPIRCCommand = None # (!) real value is ''

Request = None # (!) real value is ''

upload = None # (!) real value is ''

