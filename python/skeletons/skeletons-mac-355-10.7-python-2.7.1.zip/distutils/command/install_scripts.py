# encoding: utf-8
# module distutils.command.install_scripts
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/install_scripts.pyo by generator 1.99
"""
distutils.command.install_scripts

Implements the Distutils 'install_scripts' command, for installing
Python scripts.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

ST_MODE = 0

__revision__ = '$Id: install_scripts.py 68943 2009-01-25 22:09:10Z tarek.ziade $'

# no functions
# no classes
# variables with complex values

Command = None # (!) real value is ''

install_scripts = None # (!) real value is ''

