# encoding: utf-8
# module distutils.command.install_lib
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/install_lib.pyo by generator 1.99
"""
distutils.command.install_lib

Implements the Distutils 'install_lib' command
(install all Python modules).
"""

# imports
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

PYTHON_SOURCE_EXTENSION = '.py'

__revision__ = '$Id: install_lib.py 75671 2009-10-24 15:51:30Z tarek.ziade $'

# no functions
# classes

class DistutilsOptionError(__distutils_errors.DistutilsError):
    """
    Syntactic/semantic errors in command options, such as use of
        mutually conflicting options, or inconsistent options,
        badly-spelled values, etc.  No distinction is made between option
        values originating in the setup script, the command line, config
        files, or what-have-you -- but if we *know* something originated in
        the setup script, we'll raise DistutilsSetupError instead.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

Command = None # (!) real value is ''

install_lib = None # (!) real value is ''

