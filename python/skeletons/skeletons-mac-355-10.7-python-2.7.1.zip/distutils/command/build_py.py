# encoding: utf-8
# module distutils.command.build_py
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/build_py.pyo by generator 1.99
"""
distutils.command.build_py

Implements the Distutils 'build_py' command.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: build_py.py 76956 2009-12-21 01:22:46Z tarek.ziade $'

# functions

def convert_path(pathname): # reliably restored by inspect
    """
    Return 'pathname' as a name that will work on the native filesystem,
        i.e. split it on '/' and put it back together again using the current
        directory separator.  Needed because filenames in the setup script are
        always supplied in Unix style, and have to be converted to the local
        convention before we can actually use them in the filesystem.  Raises
        ValueError on non-Unix-ish systems if 'pathname' either starts or
        ends with a slash.
    """
    pass


def glob(pathname): # reliably restored by inspect
    """
    Return a list of paths matching a pathname pattern.
    
        The pattern may contain simple shell-style wildcards a la fnmatch.
    """
    pass


# classes

class DistutilsFileError(__distutils_errors.DistutilsError):
    """
    Any problems in the filesystem: expected file not found, etc.
        Typically this is for problems that we detect before IOError or
        OSError could be raised.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsOptionError(__distutils_errors.DistutilsError):
    """
    Syntactic/semantic errors in command options, such as use of
        mutually conflicting options, or inconsistent options,
        badly-spelled values, etc.  No distinction is made between option
        values originating in the setup script, the command line, config
        files, or what-have-you -- but if we *know* something originated in
        the setup script, we'll raise DistutilsSetupError instead.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

build_py = None # (!) real value is ''

Command = None # (!) real value is ''

