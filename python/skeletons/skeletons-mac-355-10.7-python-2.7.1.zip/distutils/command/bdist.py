# encoding: utf-8
# module distutils.command.bdist
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/bdist.pyo by generator 1.99
"""
distutils.command.bdist

Implements the Distutils 'bdist' command (create a built [binary]
distribution).
"""

# imports
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: bdist.py 77761 2010-01-26 22:46:15Z tarek.ziade $'

# functions

def get_platform(): # reliably restored by inspect
    """
    Return a string that identifies the current platform.  This is used
        mainly to distinguish platform-specific build directories and
        platform-specific built distributions.  Typically includes the OS name
        and version and the architecture (as supplied by 'os.uname()'),
        although the exact information included depends on the OS; eg. for IRIX
        the architecture isn't particularly important (IRIX only runs on SGI
        hardware), but for Linux the kernel version isn't particularly
        important.
    
        Examples of returned values:
           linux-i586
           linux-alpha (?)
           solaris-2.6-sun4u
           irix-5.3
           irix64-6.2
    
        Windows will return one of:
           win-amd64 (64bit Windows on AMD64 (aka x86_64, Intel64, EM64T, etc)
           win-ia64 (64bit Windows on Itanium)
           win32 (all others - specifically, sys.platform is returned)
    
        For other non-POSIX platforms, currently just returns 'sys.platform'.
    """
    pass


def show_formats(): # reliably restored by inspect
    """ Print list of available formats (arguments to "--format" option). """
    pass


# classes

class DistutilsOptionError(__distutils_errors.DistutilsError):
    """
    Syntactic/semantic errors in command options, such as use of
        mutually conflicting options, or inconsistent options,
        badly-spelled values, etc.  No distinction is made between option
        values originating in the setup script, the command line, config
        files, or what-have-you -- but if we *know* something originated in
        the setup script, we'll raise DistutilsSetupError instead.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsPlatformError(__distutils_errors.DistutilsError):
    """
    We don't know how to do something on the current platform (but
        we do know how to do it on some platform) -- eg. trying to compile
        C files on a platform not supported by a CCompiler subclass.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

bdist = None # (!) real value is ''

Command = None # (!) real value is ''

