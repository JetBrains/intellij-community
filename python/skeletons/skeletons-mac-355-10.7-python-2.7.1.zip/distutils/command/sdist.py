# encoding: utf-8
# module distutils.command.sdist
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/sdist.pyo by generator 1.99
"""
distutils.command.sdist

Implements the Distutils 'sdist' command (create a source distribution).
"""

# imports
import distutils.dir_util as dir_util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/dir_util.pyc
import distutils.dep_util as dep_util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/dep_util.pyc
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import distutils.archive_util as archive_util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/archive_util.pyc
import string as string # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/string.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.file_util as file_util # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/file_util.pyc
from _warnings import warn

import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: sdist.py 84713 2010-09-11 15:31:13Z eric.araujo $'

# functions

def convert_path(pathname): # reliably restored by inspect
    """
    Return 'pathname' as a name that will work on the native filesystem,
        i.e. split it on '/' and put it back together again using the current
        directory separator.  Needed because filenames in the setup script are
        always supplied in Unix style, and have to be converted to the local
        convention before we can actually use them in the filesystem.  Raises
        ValueError on non-Unix-ish systems if 'pathname' either starts or
        ends with a slash.
    """
    pass


def glob(pathname): # reliably restored by inspect
    """
    Return a list of paths matching a pathname pattern.
    
        The pattern may contain simple shell-style wildcards a la fnmatch.
    """
    pass


def show_formats(): # reliably restored by inspect
    """
    Print all possible values for the 'formats' option (used by
        the "--help-formats" command-line option).
    """
    pass


# classes

class DistutilsOptionError(__distutils_errors.DistutilsError):
    """
    Syntactic/semantic errors in command options, such as use of
        mutually conflicting options, or inconsistent options,
        badly-spelled values, etc.  No distinction is made between option
        values originating in the setup script, the command line, config
        files, or what-have-you -- but if we *know* something originated in
        the setup script, we'll raise DistutilsSetupError instead.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsPlatformError(__distutils_errors.DistutilsError):
    """
    We don't know how to do something on the current platform (but
        we do know how to do it on some platform) -- eg. trying to compile
        C files on a platform not supported by a CCompiler subclass.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsTemplateError(__distutils_errors.DistutilsError):
    """ Syntax error in a file list template. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

Command = None # (!) real value is ''

FileList = None # (!) real value is ''

sdist = None # (!) real value is ''

TextFile = None # (!) real value is ''

