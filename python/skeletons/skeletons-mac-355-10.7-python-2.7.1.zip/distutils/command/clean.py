# encoding: utf-8
# module distutils.command.clean
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/clean.pyo by generator 1.99
"""
distutils.command.clean

Implements the Distutils 'clean' command.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

__revision__ = '$Id: clean.py 70886 2009-03-31 20:50:59Z tarek.ziade $'

# functions

def remove_tree(directory, verbose=1, dry_run=0): # reliably restored by inspect
    """
    Recursively remove an entire directory tree.
    
        Any errors are ignored (apart from being reported to stdout if 'verbose'
        is true).
    """
    pass


# no classes
# variables with complex values

clean = None # (!) real value is ''

Command = None # (!) real value is ''

