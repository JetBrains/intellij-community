# encoding: utf-8
# module distutils.command.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/__init__.pyo by generator 1.99
"""
distutils.command

Package containing implementation of all the standard Distutils
commands.
"""
# no imports

# Variables with simple values

__revision__ = '$Id: __init__.py 71473 2009-04-11 14:55:07Z tarek.ziade $'

# no functions
# no classes
# variables with complex values

__all__ = [
    'build',
    'build_py',
    'build_ext',
    'build_clib',
    'build_scripts',
    'clean',
    'install',
    'install_lib',
    'install_headers',
    'install_scripts',
    'install_data',
    'sdist',
    'register',
    'bdist',
    'bdist_dumb',
    'bdist_rpm',
    'bdist_wininst',
    'upload',
    'check',
]

