# encoding: utf-8
# module distutils.command.check
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/check.pyo by generator 1.99
"""
distutils.command.check

Implements the Distutils 'check' command.
"""

# imports
import docutils.frontend as frontend # /Applications/PyCharm-112.3.app/helpers/docutils/frontend.py
import docutils.nodes as nodes # /Applications/PyCharm-112.3.app/helpers/docutils/nodes.py
import distutils.errors as __distutils_errors


# Variables with simple values

HAS_DOCUTILS = True

__revision__ = '$Id: check.py 75266 2009-10-05 22:32:48Z andrew.kuchling $'

# no functions
# classes

class DistutilsSetupError(__distutils_errors.DistutilsError):
    """
    For errors that can be definitely blamed on the setup script,
        such as invalid keyword arguments to 'setup()'.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

check = None # (!) real value is ''

Command = None # (!) real value is ''

Parser = None # (!) real value is ''

Reporter = None # (!) real value is ''

SilentReporter = None # (!) real value is ''

StringIO = None # (!) real value is ''

