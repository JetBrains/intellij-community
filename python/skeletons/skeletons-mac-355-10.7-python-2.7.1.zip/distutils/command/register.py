# encoding: utf-8
# module distutils.command.register
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/register.pyo by generator 1.99
"""
distutils.command.register

Implements the Distutils 'register' command (register with the repository).
"""

# imports
import urlparse as urlparse # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/urlparse.pyc
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import StringIO as StringIO # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/StringIO.pyc
import urllib2 as urllib2 # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/urllib2.py
import getpass as getpass # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/getpass.pyc
from _warnings import warn


# Variables with simple values

__revision__ = '$Id: register.py 77717 2010-01-24 00:33:32Z tarek.ziade $'

# no functions
# no classes
# variables with complex values

PyPIRCCommand = None # (!) real value is ''

register = None # (!) real value is ''

