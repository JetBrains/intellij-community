# encoding: utf-8
# module distutils.command.config
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/config.pyo by generator 1.99
"""
distutils.command.config

Implements the Distutils 'config' command, a (mostly) empty command class
that exists mainly to be sub-classed by specific module distributions and
applications.  The idea is that while every "config" command is different,
at least they're all named the same, and users always see "config" in the
list of standard commands.  Also, this is a good place to put common
configure-like tasks: "try to compile this C code", or "figure out where
this header file lives".
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: config.py 77704 2010-01-23 09:23:15Z tarek.ziade $'

# functions

def customize_compiler(compiler): # reliably restored by inspect
    """
    Do any platform-specific customization of a CCompiler instance.
    
        Mainly needed on Unix, so we can plug in the information that
        varies across Unices and is stored in Python's Makefile.
    """
    pass


def dump_file(filename, head=None): # reliably restored by inspect
    """
    Dumps a file content into log.info.
    
        If head is not None, will be dumped before the file content.
    """
    pass


# classes

class DistutilsExecError(__distutils_errors.DistutilsError):
    """
    Any problems executing an external program (such as the C
        compiler, when compiling C files).
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

Command = None # (!) real value is ''

config = None # (!) real value is ''

LANG_EXT = {
    'c': '.c',
    'c++': '.cxx',
}

