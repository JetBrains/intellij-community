# encoding: utf-8
# module distutils.command.install_data
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/install_data.pyo by generator 1.99
"""
distutils.command.install_data

Implements the Distutils 'install_data' command, for installing
platform-independent data files.
"""

# imports
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

__revision__ = '$Id: install_data.py 76849 2009-12-15 06:29:19Z tarek.ziade $'

# functions

def change_root(new_root, pathname): # reliably restored by inspect
    """
    Return 'pathname' with 'new_root' prepended.  If 'pathname' is
        relative, this is equivalent to "os.path.join(new_root,pathname)".
        Otherwise, it requires making 'pathname' relative and then joining the
        two, which is tricky on DOS/Windows and Mac OS.
    """
    pass


def convert_path(pathname): # reliably restored by inspect
    """
    Return 'pathname' as a name that will work on the native filesystem,
        i.e. split it on '/' and put it back together again using the current
        directory separator.  Needed because filenames in the setup script are
        always supplied in Unix style, and have to be converted to the local
        convention before we can actually use them in the filesystem.  Raises
        ValueError on non-Unix-ish systems if 'pathname' either starts or
        ends with a slash.
    """
    pass


# no classes
# variables with complex values

Command = None # (!) real value is ''

install_data = None # (!) real value is ''

