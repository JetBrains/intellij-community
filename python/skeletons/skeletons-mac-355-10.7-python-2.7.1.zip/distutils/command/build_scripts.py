# encoding: utf-8
# module distutils.command.build_scripts
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/command/build_scripts.pyo by generator 1.99
"""
distutils.command.build_scripts

Implements the Distutils 'build_scripts' command.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

ST_MODE = 0

__revision__ = '$Id: build_scripts.py 77704 2010-01-23 09:23:15Z tarek.ziade $'

# functions

def convert_path(pathname): # reliably restored by inspect
    """
    Return 'pathname' as a name that will work on the native filesystem,
        i.e. split it on '/' and put it back together again using the current
        directory separator.  Needed because filenames in the setup script are
        always supplied in Unix style, and have to be converted to the local
        convention before we can actually use them in the filesystem.  Raises
        ValueError on non-Unix-ish systems if 'pathname' either starts or
        ends with a slash.
    """
    pass


def newer(source, target): # reliably restored by inspect
    """
    Tells if the target is newer than the source.
    
        Return true if 'source' exists and is more recently modified than
        'target', or if 'source' exists and 'target' doesn't.
    
        Return false if both exist and 'target' is the same age or younger
        than 'source'. Raise DistutilsFileError if 'source' does not exist.
    
        Note that this test is not very accurate: files created in the same second
        will have the same "age".
    """
    pass


# no classes
# variables with complex values

build_scripts = None # (!) real value is ''

Command = None # (!) real value is ''

first_line_re = None # (!) real value is ''

