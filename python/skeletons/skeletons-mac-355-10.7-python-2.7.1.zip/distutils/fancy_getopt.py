# encoding: utf-8
# module distutils.fancy_getopt
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/fancy_getopt.pyo by generator 1.99
"""
distutils.fancy_getopt

Wrapper around the standard getopt module that provides the following
additional features:
  * short and long options are tied together
  * options have help strings, so fancy_getopt could potentially
    create a complete usage summary
  * options set attributes of a passed-in object
"""

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import string as string # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/string.pyc
import sys as sys # <module 'sys' (built-in)>
import getopt as getopt # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/getopt.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

longopt_pat = '[a-zA-Z](?:[a-zA-Z0-9-]*)'
longopt_xlate = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f !"#$%&\'()*+,_./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7f\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'

WS_TRANS = '\x00\x01\x02\x03\x04\x05\x06\x07\x08     \x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7f\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'

__revision__ = '$Id: fancy_getopt.py 76956 2009-12-21 01:22:46Z tarek.ziade $'

# functions

def fancy_getopt(options, negative_opt, object, args): # reliably restored by inspect
    # no doc
    pass


def translate_longopt(opt): # reliably restored by inspect
    """
    Convert a long option name to a valid Python identifier by
        changing "-" to "_".
    """
    pass


def wrap_text(text, width): # reliably restored by inspect
    """
    wrap_text(text : string, width : int) -> [string]
    
        Split 'text' into multiple lines of no more than 'width' characters
        each, and return the list of strings that results.
    """
    pass


# classes

class DistutilsArgError(__distutils_errors.DistutilsError):
    """
    Raised by fancy_getopt in response to getopt.error -- ie. an
        error in the command line usage.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsGetoptError(__distutils_errors.DistutilsError):
    """ The option table provided to 'fancy_getopt()' is bogus. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

FancyGetopt = None # (!) real value is ''

longopt_re = None # (!) real value is ''

neg_alias_re = None # (!) real value is ''

OptionDummy = None # (!) real value is ''

