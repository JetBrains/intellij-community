# encoding: utf-8
# module distutils.versionpredicate
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/versionpredicate.pyo by generator 1.99
""" Module for parsing and testing package version predicate strings. """

# imports
import distutils as distutils # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/__init__.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import operator as operator # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/lib-dynload/operator.so

# Variables with simple values

_provision_rx = None

# functions

def splitUp(pred): # reliably restored by inspect
    """
    Parse a single version comparison.
    
        Return (comparison string, StrictVersion)
    """
    pass


def split_provision(value): # reliably restored by inspect
    """
    Return the name and optional version number of a provision.
    
        The version number, if given, will be returned as a `StrictVersion`
        instance, otherwise it will be `None`.
    
        >>> split_provision('mypkg')
        ('mypkg', None)
        >>> split_provision(' mypkg( 1.2 ) ')
        ('mypkg', StrictVersion ('1.2'))
    """
    pass


# no classes
# variables with complex values

compmap = {
    '!=': operator.ne,
    '<': operator.lt,
    '<=': operator.le,
    '==': operator.eq,
    '>': operator.gt,
    '>=': operator.ge,
}

re_paren = None # (!) real value is ''

re_splitComparison = None # (!) real value is ''

re_validPackage = None # (!) real value is ''

VersionPredicate = None # (!) real value is ''

