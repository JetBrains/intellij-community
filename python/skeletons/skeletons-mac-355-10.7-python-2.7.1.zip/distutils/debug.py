# encoding: utf-8
# module distutils.debug
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/debug.pyo by generator 1.99
# no doc

# imports
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc

# Variables with simple values

DEBUG = None

__revision__ = '$Id: debug.py 68943 2009-01-25 22:09:10Z tarek.ziade $'

# no functions
# no classes
