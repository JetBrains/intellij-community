# encoding: utf-8
# module distutils.log
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyo by generator 1.99
""" A simple log mechanism styled after PEP 282. """

# imports
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

DEBUG = 1

ERROR = 4

FATAL = 5

INFO = 2

WARN = 3

# functions

def debug(*args, **kwargs): # real signature unknown
    pass


def error(*args, **kwargs): # real signature unknown
    pass


def fatal(*args, **kwargs): # real signature unknown
    pass


def info(*args, **kwargs): # real signature unknown
    pass


def log(*args, **kwargs): # real signature unknown
    pass


def set_threshold(level): # reliably restored by inspect
    # no doc
    pass


def set_verbosity(v): # reliably restored by inspect
    # no doc
    pass


def warn(*args, **kwargs): # real signature unknown
    pass


# no classes
# variables with complex values

Log = None # (!) real value is ''

_global_log = None # (!) real value is ''

