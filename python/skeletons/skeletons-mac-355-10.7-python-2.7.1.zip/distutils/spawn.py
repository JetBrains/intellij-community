# encoding: utf-8
# module distutils.spawn
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/spawn.pyo by generator 1.99
"""
distutils.spawn

Provides the 'spawn()' function, a front-end to various platform-
specific functions for launching another program in a sub-process.
Also provides the 'find_executable()' to search the path for a given
executable name.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

__revision__ = '$Id: spawn.py 73147 2009-06-02 15:58:43Z tarek.ziade $'

# functions

def find_executable(executable, path=None): # reliably restored by inspect
    """
    Tries to find 'executable' in the directories listed in 'path'.
    
        A string listing directories separated by 'os.pathsep'; defaults to
        os.environ['PATH'].  Returns the complete filename or None if not found.
    """
    pass


def spawn(cmd, search_path=1, verbose=0, dry_run=0): # reliably restored by inspect
    """
    Run another program, specified as a command list 'cmd', in a new process.
    
        'cmd' is just the argument list for the new process, ie.
        cmd[0] is the program to run and cmd[1:] are the rest of its arguments.
        There is no way to run a program with a name different from that of its
        executable.
    
        If 'search_path' is true (the default), the system's executable
        search path will be used to find the program; otherwise, cmd[0]
        must be the exact path to the executable.  If 'dry_run' is true,
        the command will not actually be run.
    
        Raise DistutilsExecError if running the program fails in any way; just
        return on success.
    """
    pass


def _nt_quote_args(args): # reliably restored by inspect
    """
    Quote command-line arguments for DOS/Windows conventions.
    
        Just wraps every argument which contains blanks in double quotes, and
        returns a new argument list.
    """
    pass


def _spawn_nt(cmd, search_path=1, verbose=0, dry_run=0): # reliably restored by inspect
    # no doc
    pass


def _spawn_os2(cmd, search_path=1, verbose=0, dry_run=0): # reliably restored by inspect
    # no doc
    pass


def _spawn_posix(cmd, search_path=1, verbose=0, dry_run=0): # reliably restored by inspect
    # no doc
    pass


# classes

class DistutilsExecError(__distutils_errors.DistutilsError):
    """
    Any problems executing an external program (such as the C
        compiler, when compiling C files).
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsPlatformError(__distutils_errors.DistutilsError):
    """
    We don't know how to do something on the current platform (but
        we do know how to do it on some platform) -- eg. trying to compile
        C files on a platform not supported by a CCompiler subclass.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


