# encoding: utf-8
# module distutils.dist
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/dist.pyo by generator 1.99
"""
distutils.dist

Provides the Distribution class, which represents the module distribution
being built/installed/distributed.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/log.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/warnings.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

DEBUG = None

PKG_INFO_ENCODING = 'utf-8'

__revision__ = '$Id: dist.py 86238 2010-11-06 04:06:18Z eric.araujo $'

# functions

def check_environ(): # reliably restored by inspect
    """
    Ensure that 'os.environ' has all the environment variables we
        guarantee that users can use in config files, command-line options,
        etc.  Currently this includes:
          HOME - user's home directory (Unix only)
          PLAT - description of the current platform, including hardware
                 and OS (see 'get_platform()')
    """
    pass


def fix_help_options(options): # reliably restored by inspect
    """
    Convert a 4-tuple 'help_options' list as found in various command
        classes to the 3-tuple form required by FancyGetopt.
    """
    pass


def message_from_file(fp, *args, **kws): # reliably restored by inspect
    """
    Read a file and parse its contents into a Message object model.
    
        Optional _class and strict are passed to the Parser constructor.
    """
    pass


def rfc822_escape(header): # reliably restored by inspect
    """
    Return a version of the string escaped for inclusion in an
        RFC-822 header, by ensuring there are 8 spaces space after each newline.
    """
    pass


def strtobool(val): # reliably restored by inspect
    """
    Convert a string representation of truth to true (1) or false (0).
    
        True values are 'y', 'yes', 't', 'true', 'on', and '1'; false values
        are 'n', 'no', 'f', 'false', 'off', and '0'.  Raises ValueError if
        'val' is anything else.
    """
    pass


def translate_longopt(opt): # reliably restored by inspect
    """
    Convert a long option name to a valid Python identifier by
        changing "-" to "_".
    """
    pass


# classes

class DistutilsArgError(__distutils_errors.DistutilsError):
    """
    Raised by fancy_getopt in response to getopt.error -- ie. an
        error in the command line usage.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsClassError(__distutils_errors.DistutilsError):
    """
    Some command class (or possibly distribution class, if anyone
        feels a need to subclass Distribution) is found not to be holding
        up its end of the bargain, ie. implementing some part of the
        "command "interface.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsModuleError(__distutils_errors.DistutilsError):
    """
    Unable to load an expected module, or to find an expected class
        within some module (in particular, command modules and classes).
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsOptionError(__distutils_errors.DistutilsError):
    """
    Syntactic/semantic errors in command options, such as use of
        mutually conflicting options, or inconsistent options,
        badly-spelled values, etc.  No distinction is made between option
        values originating in the setup script, the command line, config
        files, or what-have-you -- but if we *know* something originated in
        the setup script, we'll raise DistutilsSetupError instead.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

command_re = None # (!) real value is ''

Distribution = None # (!) real value is ''

DistributionMetadata = None # (!) real value is ''

FancyGetopt = None # (!) real value is ''

