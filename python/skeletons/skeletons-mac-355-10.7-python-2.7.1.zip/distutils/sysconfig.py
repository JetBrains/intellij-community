# encoding: utf-8
# module distutils.sysconfig
# from /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/distutils/sysconfig.pyo by generator 1.99
"""
Provide access to Python's configuration information.  The specific
configuration variables available depend heavily on the platform and
configuration.  The values may be retrieved using
get_config_var(name), and the list of variables is available via
get_config_vars().keys().  Additional convenience functions are also
available.

Written by:   Fred L. Drake, Jr.
Email:        <fdrake@acm.org>
"""

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/re.pyc
import string as string # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/string.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

EXEC_PREFIX = '/System/Library/Frameworks/Python.framework/Versions/2.7'

PREFIX = '/System/Library/Frameworks/Python.framework/Versions/2.7'

project_base = '/System/Library/Frameworks/Python.framework/Versions/2.7/Resources/Python.app/Contents/MacOS'

python_build = False

_config_vars = None

__revision__ = '$Id: sysconfig.py 86264 2010-11-06 14:16:30Z eric.araujo $'

# functions

def customize_compiler(compiler): # reliably restored by inspect
    """
    Do any platform-specific customization of a CCompiler instance.
    
        Mainly needed on Unix, so we can plug in the information that
        varies across Unices and is stored in Python's Makefile.
    """
    pass


def expand_makefile_vars(s, vars): # reliably restored by inspect
    """
    Expand Makefile-style variables -- "${foo}" or "$(foo)" -- in
        'string' according to 'vars' (a dictionary mapping variable names to
        values).  Variables not present in 'vars' are silently expanded to the
        empty string.  The variable values in 'vars' should not contain further
        variable expansions; if 'vars' is the output of 'parse_makefile()',
        you're fine.  Returns a variable-expanded version of 's'.
    """
    pass


def get_config_h_filename(): # reliably restored by inspect
    """ Return full pathname of installed pyconfig.h file. """
    pass


def get_config_var(name): # reliably restored by inspect
    """
    Return the value of a single variable using the dictionary
        returned by 'get_config_vars()'.  Equivalent to
        get_config_vars().get(name)
    """
    pass


def get_config_vars(*args): # reliably restored by inspect
    """
    With no arguments, return a dictionary of all configuration
        variables relevant for the current platform.  Generally this includes
        everything needed to build extensions and install both pure modules and
        extensions.  On Unix, this means every variable defined in Python's
        installed Makefile; on Windows and Mac OS it's a much smaller set.
    
        With arguments, return a list of values that result from looking up
        each argument in the configuration variable dictionary.
    """
    pass


def get_makefile_filename(): # reliably restored by inspect
    """ Return full pathname of installed Makefile from the Python build. """
    pass


def get_python_inc(plat_specific=0, prefix=None): # reliably restored by inspect
    """
    Return the directory containing installed Python header files.
    
        If 'plat_specific' is false (the default), this is the path to the
        non-platform-specific header files, i.e. Python.h and so on;
        otherwise, this is the path to platform-specific header files
        (namely pyconfig.h).
    
        If 'prefix' is supplied, use it instead of sys.prefix or
        sys.exec_prefix -- i.e., ignore 'plat_specific'.
    """
    pass


def get_python_lib(plat_specific=0, standard_lib=0, prefix=None): # reliably restored by inspect
    """
    Return the directory containing the Python library (standard or
        site additions).
    
        If 'plat_specific' is true, return the directory containing
        platform-specific modules, i.e. any module from a non-pure-Python
        module distribution; otherwise, return the platform-shared library
        directory.  If 'standard_lib' is true, return the directory
        containing standard Python library modules; otherwise, return the
        directory for site-specific modules.
    
        If 'prefix' is supplied, use it instead of sys.prefix or
        sys.exec_prefix -- i.e., ignore 'plat_specific'.
    """
    pass


def get_python_version(): # reliably restored by inspect
    """
    Return a string containing the major and minor Python version,
        leaving off the patchlevel.  Sample return values could be '1.5'
        or '2.2'.
    """
    pass


def parse_config_h(fp, g=None): # reliably restored by inspect
    """
    Parse a config.h-style file.
    
        A dictionary containing name/value pairs is returned.  If an
        optional dictionary is passed in as the second argument, it is
        used instead of a new dictionary.
    """
    pass


def parse_makefile(fn, g=None): # reliably restored by inspect
    """
    Parse a Makefile-style file.
    
        A dictionary containing name/value pairs is returned.  If an
        optional dictionary is passed in as the second argument, it is
        used instead of a new dictionary.
    """
    pass


def _init_nt(): # reliably restored by inspect
    """ Initialize the module as appropriate for NT """
    pass


def _init_os2(): # reliably restored by inspect
    """ Initialize the module as appropriate for OS/2 """
    pass


def _init_posix(): # reliably restored by inspect
    """ Initialize the module as appropriate for POSIX systems. """
    pass


def _python_build(): # reliably restored by inspect
    # no doc
    pass


# classes

class DistutilsPlatformError(__distutils_errors.DistutilsError):
    """
    We don't know how to do something on the current platform (but
        we do know how to do it on some platform) -- eg. trying to compile
        C files on a platform not supported by a CCompiler subclass.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

_findvar1_rx = None # (!) real value is ''

_findvar2_rx = None # (!) real value is ''

_variable_rx = None # (!) real value is ''

