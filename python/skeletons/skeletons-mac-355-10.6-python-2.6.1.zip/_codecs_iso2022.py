# encoding: utf-8
# module _codecs_iso2022
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_codecs_iso2022.so by generator 1.99
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass


# no classes
