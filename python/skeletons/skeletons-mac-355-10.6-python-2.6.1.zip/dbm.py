# encoding: utf-8
# module dbm
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/dbm.so by generator 1.99
# no doc
# no imports

# Variables with simple values

library = 'GNU gdbm'

# functions

def open(path, flag=None, mode=None): # real signature unknown; restored from __doc__
    """
    open(path[, flag[, mode]]) -> mapping
    Return a database object.
    """
    pass


# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


