# encoding: utf-8
# module _elementtree
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_elementtree.so by generator 1.99
# no doc

# imports
import xml.etree.ElementPath as ElementPath # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/xml/etree/ElementPath.pyc
from exceptions import XMLParserError


# Variables with simple values

VERSION = '1.0.6'

__version__ = '1.0.6'

# functions

def Comment(text=None): # reliably restored by inspect
    # no doc
    pass


def dump(elem): # reliably restored by inspect
    # no doc
    pass


def Element(*args, **kwargs): # real signature unknown
    pass


def fromstring(text): # reliably restored by inspect
    # no doc
    pass


def iselement(element): # reliably restored by inspect
    # no doc
    pass


def parse(source, parser=None): # reliably restored by inspect
    # no doc
    pass


def PI(target, text=None): # reliably restored by inspect
    # no doc
    pass


def ProcessingInstruction(target, text=None): # reliably restored by inspect
    # no doc
    pass


def SubElement(*args, **kwargs): # real signature unknown
    pass


def tostring(element, encoding=None): # reliably restored by inspect
    # no doc
    pass


def TreeBuilder(*args, **kwargs): # real signature unknown
    pass


def XML(text): # reliably restored by inspect
    # no doc
    pass


def XMLID(text): # reliably restored by inspect
    # no doc
    pass


def XMLParser(*args, **kwargs): # real signature unknown
    pass


def XMLTreeBuilder(*args, **kwargs): # real signature unknown
    pass


# classes

class iterparse(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    root = None
    __dict__ = None # (!) real value is ''


# variables with complex values

ElementTree = None # (!) real value is ''

QName = None # (!) real value is ''

