# encoding: utf-8
# module icglue
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/icglue.so by generator 1.99
""" Implements low-level Internet Config interface """

# imports
from MacOS import error


# functions

def ICStart(*args, **kwargs): # real signature unknown
    """ (OSType)->ic_instance; Create an Internet Config instance """
    pass


# no classes
