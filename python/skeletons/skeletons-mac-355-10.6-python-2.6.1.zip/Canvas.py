# encoding: utf-8
# module Canvas
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-tk/Canvas.pyo by generator 1.99
# no doc

# imports
from _tkinter import _flatten


# functions

def _cnfmerge(cnfs): # reliably restored by inspect
    """ Internal function. """
    pass


# no classes
# variables with complex values

Arc = None # (!) real value is ''

Bitmap = None # (!) real value is ''

Canvas = None # (!) real value is ''

CanvasItem = None # (!) real value is ''

CanvasText = None # (!) real value is ''

Group = None # (!) real value is ''

ImageItem = None # (!) real value is ''

Line = None # (!) real value is ''

Oval = None # (!) real value is ''

Polygon = None # (!) real value is ''

Rectangle = None # (!) real value is ''

Window = None # (!) real value is ''

