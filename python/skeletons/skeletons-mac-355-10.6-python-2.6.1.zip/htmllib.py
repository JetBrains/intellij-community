# encoding: utf-8
# module htmllib
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/htmllib.pyo by generator 1.99
"""
HTML 2.0 parser.

See the HTML 2.0 specification:
http://www.w3.org/hypertext/WWW/MarkUp/html-spec/html-spec_toc.html
"""

# imports
import sgmllib as sgmllib # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/sgmllib.pyc
import sgmllib as __sgmllib


# Variables with simple values

AS_IS = None

# functions

def test(args=None): # reliably restored by inspect
    # no doc
    pass


# classes

class HTMLParseError(__sgmllib.SGMLParseError):
    """ Error raised when an HTML document can't be parsed. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

HTMLParser = None # (!) real value is ''

__all__ = [
    'HTMLParser',
    'HTMLParseError',
]

