# encoding: utf-8
# module hotshot.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/hotshot/__init__.pyo by generator 1.99
""" High-perfomance logging profiler, mostly written in C. """

# imports
import _hotshot as _hotshot # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_hotshot.so

# functions

def _warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# classes

class ProfilerError(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

Profile = None # (!) real value is ''

