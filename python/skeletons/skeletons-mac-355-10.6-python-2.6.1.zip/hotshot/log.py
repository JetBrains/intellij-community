# encoding: utf-8
# module hotshot.log
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/hotshot/log.pyo by generator 1.99
# no doc

# imports
import parser as parser # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/parser.so
import _hotshot as _hotshot # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_hotshot.so
import symbol as symbol # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/symbol.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

ENTER = 0

EXIT = 1

LINE = 2

WHAT_ADD_INFO = 19

WHAT_DEFINE_FILE = 35
WHAT_DEFINE_FUNC = 67

WHAT_ENTER = 0
WHAT_EXIT = 1
WHAT_LINENO = 2

# no functions
# no classes
# variables with complex values

LogReader = None # (!) real value is ''

__all__ = [
    'LogReader',
    'ENTER',
    'EXIT',
    'LINE',
]

