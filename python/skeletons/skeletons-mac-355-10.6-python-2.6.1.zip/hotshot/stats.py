# encoding: utf-8
# module hotshot.stats
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/hotshot/stats.pyo by generator 1.99
""" Statistics analyzer for HotShot. """

# imports
import profile as profile # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/profile.pyc
import hotshot as hotshot # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/hotshot/__init__.pyc
import pstats as pstats # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/pstats.pyc

# Variables with simple values

ENTER = 0

EXIT = 1

# functions

def load(filename): # reliably restored by inspect
    # no doc
    pass


def _brokentimer(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

FakeCode = None # (!) real value is ''

FakeFrame = None # (!) real value is ''

Profile = None # (!) real value is ''

StatsLoader = None # (!) real value is ''

