# encoding: utf-8
# module code
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/code.pyo by generator 1.99
""" Utilities needed to emulate Python's interactive interpreter. """

# imports
import traceback as traceback # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/traceback.pyc
import sys as sys # <module 'sys' (built-in)>

# functions

def CommandCompiler(*args, **kwargs): # real signature unknown
    """
    Instances of this class have __call__ methods identical in
        signature to compile_command; the difference is that if the
        instance compiles program text containing a __future__ statement,
        the instance 'remembers' and compiles all subsequent program texts
        with the statement in force.
    """
    pass


def compile_command(source, filename=None, symbol=None): # reliably restored by inspect
    """
    Compile a command and determine whether it is incomplete.
    
        Arguments:
    
        source -- the source string; may contain \n characters
        filename -- optional filename from which source was read; default
                    "<input>"
        symbol -- optional grammar start symbol; "single" (default) or "eval"
    
        Return value / exceptions raised:
    
        - Return a code object if the command is complete and valid
        - Return None if the command is incomplete
        - Raise SyntaxError, ValueError or OverflowError if the command is a
          syntax error (OverflowError and ValueError can be produced by
          malformed literals).
    """
    pass


def interact(banner=None, readfunc=None, local=None): # reliably restored by inspect
    """
    Closely emulate the interactive Python interpreter.
    
        This is a backwards compatible interface to the InteractiveConsole
        class.  When readfunc is not specified, it attempts to import the
        readline module to enable GNU readline if it is available.
    
        Arguments (all optional, all default to None):
    
        banner -- passed to InteractiveConsole.interact()
        readfunc -- if not None, replaces InteractiveConsole.raw_input()
        local -- passed to InteractiveInterpreter.__init__()
    """
    pass


def softspace(file, newvalue): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

InteractiveConsole = None # (!) real value is ''

InteractiveInterpreter = None # (!) real value is ''

__all__ = [
    'InteractiveInterpreter',
    'InteractiveConsole',
    'interact',
    'compile_command',
]

