# encoding: utf-8
# module json.scanner
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/json/scanner.pyo by generator 1.99
""" Iterator based sre token scanner """

# imports
import sre_compile as sre_compile # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/sre_compile.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import sre_parse as sre_parse # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/sre_parse.pyc
import sre_constants as sre_constants # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/sre_constants.pyc

# Variables with simple values

BRANCH = 'branch'

DOTALL = 16

FLAGS = 88

MULTILINE = 8

SUBPATTERN = 'subpattern'

VERBOSE = 64

# functions

def pattern(pattern, flags=88): # reliably restored by inspect
    # no doc
    pass


# classes

class Scanner(object):
    # no doc
    def iterscan(self, *args, **kwargs): # real signature unknown
        """ Yield match, end_idx for each match """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

__all__ = [
    'Scanner',
    'pattern',
]

