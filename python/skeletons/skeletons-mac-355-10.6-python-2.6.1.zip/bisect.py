# encoding: utf-8
# module bisect
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/bisect.pyo by generator 1.99
""" Bisection algorithms. """

# imports
from _bisect import (bisect, bisect_left, bisect_right, insort, insort_left, 
    insort_right)


# no functions
# no classes
