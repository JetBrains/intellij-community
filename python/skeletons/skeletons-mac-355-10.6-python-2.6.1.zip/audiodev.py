# encoding: utf-8
# module audiodev
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/audiodev.pyo by generator 1.99
""" Classes for manipulating audio devices (currently only for Sun and SGI) """
# no imports

# functions

def AudioDev(): # reliably restored by inspect
    # no doc
    pass


def test(fn=None): # reliably restored by inspect
    # no doc
    pass


# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

Play_Audio_sgi = None # (!) real value is ''

Play_Audio_sun = None # (!) real value is ''

__all__ = [
    'error',
    'AudioDev',
]

