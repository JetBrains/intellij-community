# encoding: utf-8
# module CoreFoundation._CFBag
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFBag.so by generator 1.99
# no doc
# no imports

# functions

def CFBagCreate(*args, **kwargs): # real signature unknown
    pass


def CFBagCreateMutable(*args, **kwargs): # real signature unknown
    pass


def CFBagGetValues(*args, **kwargs): # real signature unknown
    pass


# no classes
