# encoding: utf-8
# module CoreFoundation._CFWriteStream
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFWriteStream.so by generator 1.99
# no doc
# no imports

# functions

def CFWriteStreamSetClient(*args, **kwargs): # real signature unknown
    pass


# no classes
