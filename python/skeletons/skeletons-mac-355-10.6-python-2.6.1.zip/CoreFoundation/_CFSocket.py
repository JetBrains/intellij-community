# encoding: utf-8
# module CoreFoundation._CFSocket
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFSocket.so by generator 1.99
# no doc
# no imports

# functions

def CFSocketCreate(*args, **kwargs): # real signature unknown
    pass


def CFSocketCreateConnectedToSocketSignature(*args, **kwargs): # real signature unknown
    pass


def CFSocketCreateWithNative(*args, **kwargs): # real signature unknown
    pass


def CFSocketCreateWithSocketSignature(*args, **kwargs): # real signature unknown
    pass


def CFSocketGetContext(*args, **kwargs): # real signature unknown
    pass


# no classes
