# encoding: utf-8
# module CoreFoundation._CFBitVector
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFBitVector.so by generator 1.99
# no doc
# no imports

# functions

def CFBitVectorCreate(*args, **kwargs): # real signature unknown
    pass


def CFBitVectorGetBits(*args, **kwargs): # real signature unknown
    pass


# no classes
