# encoding: utf-8
# module CoreFoundation._CFMachPort
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFMachPort.so by generator 1.99
# no doc
# no imports

# functions

def CFMachPortCreate(*args, **kwargs): # real signature unknown
    pass


def CFMachPortCreateWithPort(*args, **kwargs): # real signature unknown
    pass


def CFMachPortGetContext(*args, **kwargs): # real signature unknown
    pass


def CFMachPortGetInvalidationCallBack(*args, **kwargs): # real signature unknown
    pass


def CFMachPortSetInvalidationCallBack(*args, **kwargs): # real signature unknown
    pass


# no classes
