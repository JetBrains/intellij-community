# encoding: utf-8
# module CoreFoundation._CFTree
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFTree.so by generator 1.99
# no doc
# no imports

# functions

def CFTreeCreate(*args, **kwargs): # real signature unknown
    pass


def CFTreeGetChildren(*args, **kwargs): # real signature unknown
    pass


def CFTreeGetContext(*args, **kwargs): # real signature unknown
    pass


def CFTreeSetContext(*args, **kwargs): # real signature unknown
    pass


# no classes
