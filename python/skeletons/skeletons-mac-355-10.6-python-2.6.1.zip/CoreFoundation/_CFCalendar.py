# encoding: utf-8
# module CoreFoundation._CFCalendar
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFCalendar.so by generator 1.99
# no doc
# no imports

# functions

def CFCalendarAddComponents(*args, **kwargs): # real signature unknown
    pass


def CFCalendarComposeAbsoluteTime(*args, **kwargs): # real signature unknown
    pass


def CFCalendarDecomposeAbsoluteTime(*args, **kwargs): # real signature unknown
    pass


def CFCalendarGetComponentDifference(*args, **kwargs): # real signature unknown
    pass


# no classes
