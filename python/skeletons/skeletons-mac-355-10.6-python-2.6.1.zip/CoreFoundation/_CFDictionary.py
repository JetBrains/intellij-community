# encoding: utf-8
# module CoreFoundation._CFDictionary
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFDictionary.so by generator 1.99
# no doc
# no imports

# functions

def CFDictionaryGetKeysAndValues(*args, **kwargs): # real signature unknown
    pass


# no classes
