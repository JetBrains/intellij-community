# encoding: utf-8
# module CoreFoundation._CFSet
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFSet.so by generator 1.99
# no doc
# no imports

# functions

def CFSetGetValues(*args, **kwargs): # real signature unknown
    pass


# no classes
