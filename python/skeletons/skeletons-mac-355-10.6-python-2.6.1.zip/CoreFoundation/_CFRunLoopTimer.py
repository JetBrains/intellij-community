# encoding: utf-8
# module CoreFoundation._CFRunLoopTimer
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFRunLoopTimer.so by generator 1.99
# no doc
# no imports

# functions

def CFRunLoopTimerCreate(*args, **kwargs): # real signature unknown
    pass


def CFRunLoopTimerGetContext(*args, **kwargs): # real signature unknown
    pass


# no classes
