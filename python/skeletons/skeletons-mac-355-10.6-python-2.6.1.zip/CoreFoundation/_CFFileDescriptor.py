# encoding: utf-8
# module CoreFoundation._CFFileDescriptor
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFFileDescriptor.so by generator 1.99
# no doc
# no imports

# functions

def CFFileDescriptorCreate(*args, **kwargs): # real signature unknown
    pass


def CFFileDescriptorGetContext(*args, **kwargs): # real signature unknown
    pass


# no classes
