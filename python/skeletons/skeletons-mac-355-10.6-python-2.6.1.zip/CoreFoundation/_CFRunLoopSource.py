# encoding: utf-8
# module CoreFoundation._CFRunLoopSource
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/CoreFoundation/_CFRunLoopSource.so by generator 1.99
# no doc
# no imports

# functions

def CFRunLoopSourceCreate(*args, **kwargs): # real signature unknown
    pass


def CFRunLoopSourceGetContext(*args, **kwargs): # real signature unknown
    pass


# no classes
