# encoding: utf-8
# module colorsys
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/colorsys.pyo by generator 1.99
"""
Conversion functions between RGB and other color systems.

This modules provides two functions for each color system ABC:

  rgb_to_abc(r, g, b) --> a, b, c
  abc_to_rgb(a, b, c) --> r, g, b

All inputs and outputs are triples of floats in the range [0.0...1.0]
(with the exception of I and Q, which covers a slightly larger range).
Inputs outside the valid range may cause exceptions or invalid outputs.

Supported color systems:
RGB: Red, Green, Blue components
YIQ: Luminance, Chrominance (used by composite video signals)
HLS: Hue, Luminance, Saturation
HSV: Hue, Saturation, Value
"""
# no imports

# Variables with simple values

ONE_SIXTH = 0.16666666666666666
ONE_THIRD = 0.33333333333333331

TWO_THIRD = 0.66666666666666663

# functions

def hls_to_rgb(h, l, s): # reliably restored by inspect
    # no doc
    pass


def hsv_to_rgb(h, s, v): # reliably restored by inspect
    # no doc
    pass


def rgb_to_hls(r, g, b): # reliably restored by inspect
    # no doc
    pass


def rgb_to_hsv(r, g, b): # reliably restored by inspect
    # no doc
    pass


def rgb_to_yiq(r, g, b): # reliably restored by inspect
    # no doc
    pass


def yiq_to_rgb(y, i, q): # reliably restored by inspect
    # no doc
    pass


def _v(m1, m2, hue): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

__all__ = [
    'rgb_to_yiq',
    'yiq_to_rgb',
    'rgb_to_hls',
    'hls_to_rgb',
    'rgb_to_hsv',
    'hsv_to_rgb',
]

