# encoding: utf-8
# module commands
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/commands.pyo by generator 1.99
"""
Execute shell commands via os.popen() and return status, output.

Interface summary:

       import commands

       outtext = commands.getoutput(cmd)
       (exitstatus, outtext) = commands.getstatusoutput(cmd)
       outtext = commands.getstatus(file)  # returns output of "ls -ld file"

A trailing newline is removed from the output string.

Encapsulates the basic operation:

      pipe = os.popen('{ ' + cmd + '; } 2>&1', 'r')
      text = pipe.read()
      sts = pipe.close()

 [Note:  it would be nice to add functions to interpret the exit status.]
"""
# no imports

# functions

def getoutput(cmd): # reliably restored by inspect
    """ Return output (stdout or stderr) of executing cmd in a shell. """
    pass


def getstatus(file): # reliably restored by inspect
    """ Return output of "ls -ld <file>" in a string. """
    pass


def getstatusoutput(cmd): # reliably restored by inspect
    """ Return (status, output) of executing cmd in a shell. """
    pass


def mk2arg(head, x): # reliably restored by inspect
    # no doc
    pass


def mkarg(x): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

__all__ = [
    'getstatusoutput',
    'getoutput',
    'getstatus',
]

