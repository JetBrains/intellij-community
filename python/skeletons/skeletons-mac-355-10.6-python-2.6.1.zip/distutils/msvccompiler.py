# encoding: utf-8
# module distutils.msvccompiler
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/msvccompiler.pyo by generator 1.99
"""
distutils.msvccompiler

Contains MSVCCompiler, an implementation of the abstract CCompiler class
for the Microsoft Visual Studio.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/log.pyc
import string as string # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/string.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import distutils.errors as __distutils_errors


# Variables with simple values

_can_read_reg = 0

__revision__ = '$Id: msvccompiler.py 62197 2008-04-07 01:53:39Z mark.hammond $'

# functions

def convert_mbcs(s): # reliably restored by inspect
    # no doc
    pass


def gen_lib_options(compiler, library_dirs, runtime_library_dirs, libraries): # reliably restored by inspect
    """
    Generate linker options for searching library directories and
        linking with specific libraries.  'libraries' and 'library_dirs' are,
        respectively, lists of library names (not filenames!) and search
        directories.  Returns a list of command-line options suitable for use
        with some compiler (depending on the two format strings passed in).
    """
    pass


def gen_preprocess_options(macros, include_dirs): # reliably restored by inspect
    """
    Generate C pre-processor options (-D, -U, -I) as used by at least
        two types of compilers: the typical Unix compiler and Visual C++.
        'macros' is the usual thing, a list of 1- or 2-tuples, where (name,)
        means undefine (-U) macro 'name', and (name,value) means define (-D)
        macro 'name' to 'value'.  'include_dirs' is just a list of directory
        names to be added to the header file search path (-I).  Returns a list
        of command-line options suitable for either Unix compilers or Visual
        C++.
    """
    pass


def get_build_architecture(): # reliably restored by inspect
    """
    Return the processor architecture.
    
        Possible results are "Intel", "Itanium", or "AMD64".
    """
    pass


def get_build_version(): # reliably restored by inspect
    """
    Return the version of MSVC that was used to build Python.
    
        For Python 2.3 and up, the version number is included in
        sys.version.  For earlier versions, assume the compiler is MSVC 6.
    """
    pass


def normalize_and_reduce_paths(paths): # reliably restored by inspect
    """
    Return a list of normalized paths with duplicates removed.
    
        The current order of paths is maintained.
    """
    pass


def read_keys(base, key): # reliably restored by inspect
    """ Return list of registry keys. """
    pass


def read_values(base, key): # reliably restored by inspect
    """
    Return dict of registry keys and values.
    
        All names are converted to lowercase.
    """
    pass


# classes

class CompileError(__distutils_errors.CCompilerError):
    """ Failure to compile one or more C/C++ source files. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsExecError(__distutils_errors.DistutilsError):
    """
    Any problems executing an external program (such as the C
        compiler, when compiling C files).
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class DistutilsPlatformError(__distutils_errors.DistutilsError):
    """
    We don't know how to do something on the current platform (but
        we do know how to do it on some platform) -- eg. trying to compile
        C files on a platform not supported by a CCompiler subclass.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class LibError(__distutils_errors.CCompilerError):
    """
    Failure to create a static library from one or more C/C++ object
        files.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class LinkError(__distutils_errors.CCompilerError):
    """
    Failure to link one or more C/C++ object files into an executable
        or shared library file.
    """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

CCompiler = None # (!) real value is ''

MacroExpander = None # (!) real value is ''

MSVCCompiler = None # (!) real value is ''

