# encoding: utf-8
# module distutils.config
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/config.pyo by generator 1.99
"""
distutils.pypirc

Provides the PyPIRCCommand class, the base class for the command classes
that uses .pypirc in the distutils.command package.
"""

# imports
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

DEFAULT_PYPIRC = '[pypirc]\nservers =\n    pypi\n\n[pypi]\nusername:%s\npassword:%s\n'

# no functions
# no classes
# variables with complex values

Command = None # (!) real value is ''

ConfigParser = None # (!) real value is ''

PyPIRCCommand = None # (!) real value is ''

