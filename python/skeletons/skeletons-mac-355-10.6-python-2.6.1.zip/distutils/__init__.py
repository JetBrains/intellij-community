# encoding: utf-8
# module distutils.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/__init__.pyo by generator 1.99
"""
distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""
# no imports

# Variables with simple values

__revision__ = '$Id: __init__.py 67515 2008-12-04 02:59:51Z barry.warsaw $'

__version__ = '2.6.1'

# no functions
# no classes
