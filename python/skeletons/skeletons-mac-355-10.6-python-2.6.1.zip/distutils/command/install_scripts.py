# encoding: utf-8
# module distutils.command.install_scripts
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/command/install_scripts.pyo by generator 1.99
"""
distutils.command.install_scripts

Implements the Distutils 'install_scripts' command, for installing
Python scripts.
"""

# imports
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/log.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

ST_MODE = 0

__revision__ = '$Id: install_scripts.py 37828 2004-11-10 22:23:15Z loewis $'

# no functions
# no classes
# variables with complex values

Command = None # (!) real value is ''

install_scripts = None # (!) real value is ''

