# encoding: utf-8
# module distutils.command.install_headers
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/command/install_headers.pyo by generator 1.99
"""
distutils.command.install_headers

Implements the Distutils 'install_headers' command, to install C/C++ header
files to the Python include directory.
"""
# no imports

# Variables with simple values

__revision__ = '$Id: install_headers.py 61000 2008-02-23 17:40:11Z christian.heimes $'

# no functions
# no classes
# variables with complex values

Command = None # (!) real value is ''

install_headers = None # (!) real value is ''

