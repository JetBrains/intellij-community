# encoding: utf-8
# module distutils.command.install_egg_info
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/command/install_egg_info.pyo by generator 1.99
"""
distutils.command.install_egg_info

Implements the Distutils 'install_egg_info' command, for installing
a package's PKG-INFO metadata.
"""

# imports
import distutils.dir_util as dir_util # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/dir_util.pyc
import distutils.log as log # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/log.pyc
import sys as sys # <module 'sys' (built-in)>
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# functions

def safe_name(name): # reliably restored by inspect
    """
    Convert an arbitrary string to a standard distribution name
    
        Any runs of non-alphanumeric/. characters are replaced with a single '-'.
    """
    pass


def safe_version(version): # reliably restored by inspect
    """
    Convert an arbitrary string to a standard version string
    
        Spaces become dots, and all other non-alphanumeric characters become
        dashes, with runs of multiple dashes condensed to a single dash.
    """
    pass


def to_filename(name): # reliably restored by inspect
    """
    Convert a project or version name to its filename-escaped form
    
        Any '-' characters are currently replaced with '_'.
    """
    pass


# no classes
# variables with complex values

Command = None # (!) real value is ''

install_egg_info = None # (!) real value is ''

