# encoding: utf-8
# module distutils.debug
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/distutils/debug.pyo by generator 1.99
# no doc

# imports
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

DEBUG = None

__revision__ = '$Id: debug.py 37828 2004-11-10 22:23:15Z loewis $'

# no functions
# no classes
