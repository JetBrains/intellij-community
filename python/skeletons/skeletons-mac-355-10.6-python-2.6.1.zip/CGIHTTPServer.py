# encoding: utf-8
# module CGIHTTPServer
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/CGIHTTPServer.pyo by generator 1.99
"""
CGI-savvy HTTP Server.

This module builds on SimpleHTTPServer by implementing GET and POST
requests to cgi-bin scripts.

If the os.fork() function is not present (e.g. on Windows),
os.popen2() is used as a fallback, with slightly altered semantics; if
that function is not present either (e.g. on Macintosh), only Python
scripts are supported, and they are executed by the current process.

In all cases, the implementation is intentionally naive -- all
requests are executed sychronously.

SECURITY WARNING: DON'T USE THIS CODE UNLESS YOU ARE INSIDE A FIREWALL
-- it may execute arbitrary Python code or external programs.

Note that status code 200 is sent prior to execution of a CGI script, so
scripts cannot send other status codes such as 302 (redirect).
"""

# imports
import SimpleHTTPServer as SimpleHTTPServer # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/SimpleHTTPServer.pyc
import urllib as urllib # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/urllib.pyc
import sys as sys # <module 'sys' (built-in)>
import BaseHTTPServer as BaseHTTPServer # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/BaseHTTPServer.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import select as select # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/select.so

# Variables with simple values

nobody = None

__version__ = '0.4'

# functions

def executable(path): # reliably restored by inspect
    """ Test for executable file. """
    pass


def nobody_uid(): # reliably restored by inspect
    """ Internal routine to get nobody's uid """
    pass


def test(HandlerClass='<class CGIHTTPServer.CGIHTTPRequestHandler at 0x100631170>', ServerClass='<class BaseHTTPServer.HTTPServer at 0x1005d5b90>'): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

CGIHTTPRequestHandler = None # (!) real value is ''

__all__ = [
    'CGIHTTPRequestHandler',
]

