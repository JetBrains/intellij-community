# encoding: utf-8
# module bsddb185
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/bsddb185.so by generator 1.99
# no doc
# no imports

# functions

def btopen(*args, **kwargs): # real signature unknown
    pass


def hashopen(*args, **kwargs): # real signature unknown
    pass


def open(*args, **kwargs): # real signature unknown
    pass


def rnopen(*args, **kwargs): # real signature unknown
    pass


# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


