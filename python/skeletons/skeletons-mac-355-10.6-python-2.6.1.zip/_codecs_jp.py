# encoding: utf-8
# module _codecs_jp
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_codecs_jp.so by generator 1.99
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass


# no classes
# variables with complex values

__map_cp932ext = None # (!) real value is ''

__map_jisx0208 = None # (!) real value is ''

__map_jisx0212 = None # (!) real value is ''

__map_jisx0213_1_bmp = None # (!) real value is ''

__map_jisx0213_1_emp = None # (!) real value is ''

__map_jisx0213_2_bmp = None # (!) real value is ''

__map_jisx0213_2_emp = None # (!) real value is ''

__map_jisx0213_bmp = None # (!) real value is ''

__map_jisx0213_emp = None # (!) real value is ''

__map_jisx0213_pair = None # (!) real value is ''

__map_jisxcommon = None # (!) real value is ''

