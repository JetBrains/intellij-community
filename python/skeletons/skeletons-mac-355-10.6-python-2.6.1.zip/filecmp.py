# encoding: utf-8
# module filecmp
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/filecmp.pyo by generator 1.99
"""
Utilities for comparing files and directories.

Classes:
    dircmp

Functions:
    cmp(f1, f2, shallow=1) -> int
    cmpfiles(a, b, common) -> ([], [], [])
"""

# imports
import stat as stat # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/stat.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
from itertools import ifilter, ifilterfalse, imap, izip


# Variables with simple values

BUFSIZE = 8192

# functions

def cmp(f1, f2, shallow=1): # reliably restored by inspect
    """
    Compare two files.
    
        Arguments:
    
        f1 -- First file name
    
        f2 -- Second file name
    
        shallow -- Just check stat signature (do not read the files).
                   defaults to 1.
    
        Return value:
    
        True if the files are the same, False otherwise.
    
        This function uses a cache for past comparisons and the results,
        with a cache invalidation mechanism relying on stale signatures.
    """
    pass


def cmpfiles(a, b, common, shallow=1): # reliably restored by inspect
    """
    Compare common files in two directories.
    
        a, b -- directory names
        common -- list of file names found in both directories
        shallow -- if true, do comparison based solely on stat() information
    
        Returns a tuple of three lists:
          files that compare equal
          files that are different
          filenames that aren't regular files.
    """
    pass


def demo(): # reliably restored by inspect
    # no doc
    pass


def _cmp(a, b, sh, abs=abs, cmp='<function cmp at 0x1005231b8>'): # reliably restored by inspect
    # no doc
    pass


def _do_cmp(f1, f2): # reliably restored by inspect
    # no doc
    pass


def _filter(flist, skip): # reliably restored by inspect
    # no doc
    pass


def _sig(st): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

dircmp = None # (!) real value is ''

_cache = {}

__all__ = [
    'cmp',
    'dircmp',
    'cmpfiles',
]

