# encoding: utf-8
# module imghdr
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/imghdr.pyo by generator 1.99
""" Recognize image file formats based on their first few bytes. """
# no imports

# functions

def test(): # reliably restored by inspect
    # no doc
    pass


def testall(list, recursive, toplevel): # reliably restored by inspect
    # no doc
    pass


def test_bmp(h, f): # reliably restored by inspect
    # no doc
    pass


def test_exif(h, f): # reliably restored by inspect
    """ JPEG data in Exif format """
    pass


def test_gif(h, f): # reliably restored by inspect
    """ GIF ('87 and '89 variants) """
    pass


def test_jpeg(h, f): # reliably restored by inspect
    """ JPEG data in JFIF format """
    pass


def test_pbm(h, f): # reliably restored by inspect
    """ PBM (portable bitmap) """
    pass


def test_pgm(h, f): # reliably restored by inspect
    """ PGM (portable graymap) """
    pass


def test_png(h, f): # reliably restored by inspect
    # no doc
    pass


def test_ppm(h, f): # reliably restored by inspect
    """ PPM (portable pixmap) """
    pass


def test_rast(h, f): # reliably restored by inspect
    """ Sun raster file """
    pass


def test_rgb(h, f): # reliably restored by inspect
    """ SGI image library """
    pass


def test_tiff(h, f): # reliably restored by inspect
    """ TIFF (can be in Motorola or Intel byte order) """
    pass


def test_xbm(h, f): # reliably restored by inspect
    """ X bitmap (X10 or X11) """
    pass


def what(file, h=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

tests = [
    test_jpeg,
    test_exif,
    test_png,
    test_gif,
    test_tiff,
    test_rgb,
    test_pbm,
    test_pgm,
    test_ppm,
    test_rast,
    test_xbm,
    test_bmp,
]

__all__ = [
    'what',
]

