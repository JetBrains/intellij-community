# encoding: utf-8
# module gestalt
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/gestalt.so by generator 1.99
# no doc
# no imports

# functions

def gestalt(*args, **kwargs): # real signature unknown
    pass


# no classes
