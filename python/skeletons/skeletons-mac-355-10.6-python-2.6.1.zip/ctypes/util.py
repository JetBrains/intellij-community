# encoding: utf-8
# module ctypes.util
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/ctypes/util.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# functions

def find_library(name): # reliably restored by inspect
    # no doc
    pass


def test(): # reliably restored by inspect
    # no doc
    pass


def _dyld_find(name, executable_path=None, env=None): # reliably restored by inspect
    """ Find a library or framework using dyld semantics """
    pass


# no classes
