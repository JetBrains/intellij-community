# encoding: utf-8
# module ctypes.macholib.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/ctypes/macholib/__init__.pyo by generator 1.99
"""
Enough Mach-O to make your head spin.

See the relevant header files in /usr/include/mach-o

And also Apple's documentation.
"""
# no imports

# Variables with simple values

__version__ = '1.0'

# no functions
# no classes
