# encoding: utf-8
# module ctypes.macholib.dyld
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/ctypes/macholib/dyld.pyo by generator 1.99
""" dyld emulation """

# imports
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
from itertools import (chain, combinations, count, cycle, dropwhile, groupby, 
    ifilter, ifilterfalse, imap, islice, izip, izip_longest, permutations, 
    product, repeat, starmap, takewhile, tee)


# functions

def dyld_default_search(name, env=None): # reliably restored by inspect
    # no doc
    pass


def dyld_env(env, var): # reliably restored by inspect
    # no doc
    pass


def dyld_executable_path_search(name, executable_path=None): # reliably restored by inspect
    # no doc
    pass


def dyld_fallback_framework_path(env=None): # reliably restored by inspect
    # no doc
    pass


def dyld_fallback_library_path(env=None): # reliably restored by inspect
    # no doc
    pass


def dyld_find(name, executable_path=None, env=None): # reliably restored by inspect
    """ Find a library or framework using dyld semantics """
    pass


def dyld_framework_path(env=None): # reliably restored by inspect
    # no doc
    pass


def dyld_image_suffix(env=None): # reliably restored by inspect
    # no doc
    pass


def dyld_image_suffix_search(iterator, env=None): # reliably restored by inspect
    """ For a potential path iterator, add DYLD_IMAGE_SUFFIX semantics """
    pass


def dyld_library_path(env=None): # reliably restored by inspect
    # no doc
    pass


def dyld_override_search(name, env=None): # reliably restored by inspect
    # no doc
    pass


def dylib_info(filename): # reliably restored by inspect
    """
    A dylib name can take one of the following four forms:
            Location/Name.SomeVersion_Suffix.dylib
            Location/Name.SomeVersion.dylib
            Location/Name_Suffix.dylib
            Location/Name.dylib
    
        returns None if not found or a mapping equivalent to:
            dict(
                location='Location',
                name='Name.SomeVersion_Suffix.dylib',
                shortname='Name',
                version='SomeVersion',
                suffix='Suffix',
            )
    
        Note that SomeVersion and Suffix are optional and may be None
        if not present.
    """
    pass


def ensure_utf8(s): # reliably restored by inspect
    """ Not all of PyObjC and Python understand unicode paths very well yet """
    pass


def framework_find(fn, executable_path=None, env=None): # reliably restored by inspect
    """
    Find a framework using dyld semantics in a very loose manner.
    
        Will take input such as:
            Python
            Python.framework
            Python.framework/Versions/Current
    """
    pass


def framework_info(filename): # reliably restored by inspect
    """
    A framework name can take one of the following four forms:
            Location/Name.framework/Versions/SomeVersion/Name_Suffix
            Location/Name.framework/Versions/SomeVersion/Name
            Location/Name.framework/Name_Suffix
            Location/Name.framework/Name
    
        returns None if not found, or a mapping equivalent to:
            dict(
                location='Location',
                name='Name.framework/Versions/SomeVersion/Name_Suffix',
                shortname='Name',
                version='SomeVersion',
                suffix='Suffix',
            )
    
        Note that SomeVersion and Suffix are optional and may be None
        if not present
    """
    pass


def test_dyld_find(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

DEFAULT_FRAMEWORK_FALLBACK = [
    '/Users/jetbrains/Library/Frameworks',
    '/Library/Frameworks',
    '/Network/Library/Frameworks',
    '/System/Library/Frameworks',
]

DEFAULT_LIBRARY_FALLBACK = [
    '/Users/jetbrains/lib',
    '/usr/local/lib',
    '/lib',
    '/usr/lib',
]

__all__ = [
    'dyld_find',
    'framework_find',
    'framework_info',
    'dylib_info',
]

