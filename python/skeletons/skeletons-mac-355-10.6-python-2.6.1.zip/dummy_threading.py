# encoding: utf-8
# module dummy_threading
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/dummy_threading.pyo by generator 1.99
"""
Faux ``threading`` version using ``dummy_thread`` instead of ``thread``.

The module ``_dummy_threading`` is added to ``sys.modules`` in order
to not have ``threading`` considered imported.  Had ``threading`` been
directly imported it would have made all subsequent imports succeed
regardless of whether ``thread`` was available which is not desired.
"""

# imports
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/threading.pyc
import threading as __threading
import _threading_local as ___threading_local


# functions

def activeCount(): # reliably restored by inspect
    # no doc
    pass


def active_count(): # reliably restored by inspect
    # no doc
    pass


def BoundedSemaphore(*args, **kwargs): # reliably restored by inspect
    # no doc
    pass


def Condition(*args, **kwargs): # reliably restored by inspect
    # no doc
    pass


def currentThread(): # reliably restored by inspect
    # no doc
    pass


def current_thread(): # reliably restored by inspect
    # no doc
    pass


def enumerate(): # reliably restored by inspect
    # no doc
    pass


def Event(*args, **kwargs): # reliably restored by inspect
    # no doc
    pass


def Lock(): # reliably restored by inspect
    """ Dummy implementation of thread.allocate_lock(). """
    pass


def RLock(*args, **kwargs): # reliably restored by inspect
    # no doc
    pass


def Semaphore(*args, **kwargs): # reliably restored by inspect
    # no doc
    pass


def setprofile(func): # reliably restored by inspect
    # no doc
    pass


def settrace(func): # reliably restored by inspect
    # no doc
    pass


def stack_size(size=None): # reliably restored by inspect
    """ Dummy implementation of thread.stack_size(). """
    pass


def Timer(*args, **kwargs): # reliably restored by inspect
    # no doc
    pass


# classes

class local(___threading_local._localbase):
    # no doc
    def __delattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __del__(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setattr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class Thread(__threading._Verbose):
    # no doc
    def getName(self, *args, **kwargs): # real signature unknown
        pass

    def isAlive(self, *args, **kwargs): # real signature unknown
        pass

    def isDaemon(self, *args, **kwargs): # real signature unknown
        pass

    def is_alive(self, *args, **kwargs): # real signature unknown
        pass

    def join(self, *args, **kwargs): # real signature unknown
        pass

    def run(self, *args, **kwargs): # real signature unknown
        pass

    def setDaemon(self, *args, **kwargs): # real signature unknown
        pass

    def setName(self, *args, **kwargs): # real signature unknown
        pass

    def start(self, *args, **kwargs): # real signature unknown
        pass

    def _set_daemon(self, *args, **kwargs): # real signature unknown
        pass

    def _Thread__bootstrap(self, *args, **kwargs): # real signature unknown
        pass

    def _Thread__bootstrap_inner(self, *args, **kwargs): # real signature unknown
        pass

    def _Thread__delete(self, *args, **kwargs): # real signature unknown
        """ Remove current thread from the dict of currently running threads. """
        pass

    def _Thread__exc_clear(self, *args, **kwargs): # real signature unknown
        """
        exc_clear() -> None
        
        Clear global information on the current exception.  Subsequent calls to
        exc_info() will return (None,None,None) until another exception is raised
        in the current thread or the execution stack returns to a frame where
        another exception is being handled.
        """
        pass

    def _Thread__exc_info(self, *args, **kwargs): # real signature unknown
        """
        exc_info() -> (type, value, traceback)
        
        Return information about the most recent exception caught by an except
        clause in the current stack frame or in an older stack frame.
        """
        pass

    def _Thread__stop(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    daemon = property(lambda self: object()) # default
    ident = property(lambda self: object()) # default
    name = property(lambda self: object()) # default

    _Thread__initialized = False


# variables with complex values

__all__ = threading.__all__

