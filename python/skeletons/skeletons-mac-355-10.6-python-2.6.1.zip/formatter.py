# encoding: utf-8
# module formatter
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/formatter.pyo by generator 1.99
"""
Generic output formatting.

Formatter objects transform an abstract flow of formatting events into
specific output events on writer objects. Formatters manage several stack
structures to allow various properties of a writer object to be changed and
restored; writers need not be able to handle relative changes nor any sort
of ``change back'' operation. Specific writer properties which may be
controlled via formatter objects are horizontal alignment, font, and left
margin indentations. A mechanism is provided which supports providing
arbitrary, non-exclusive style settings to a writer as well. Additional
interfaces facilitate formatting events which are not reversible, such as
paragraph separation.

Writer objects encapsulate device interfaces. Abstract devices, such as
file formats, are supported as well as physical devices. The provided
implementations all work with abstract devices. The interface makes
available mechanisms for setting the properties which formatter objects
manage and inserting data into the output.
"""

# imports
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

AS_IS = None

# functions

def test(file=None): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

AbstractFormatter = None # (!) real value is ''

AbstractWriter = None # (!) real value is ''

DumbWriter = None # (!) real value is ''

NullFormatter = None # (!) real value is ''

NullWriter = None # (!) real value is ''

