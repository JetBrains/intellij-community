# encoding: utf-8
# module Foundation._data
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/Foundation/_data.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
