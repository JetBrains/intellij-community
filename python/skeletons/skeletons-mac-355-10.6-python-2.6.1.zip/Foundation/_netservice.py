# encoding: utf-8
# module Foundation._netservice
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/Foundation/_netservice.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
