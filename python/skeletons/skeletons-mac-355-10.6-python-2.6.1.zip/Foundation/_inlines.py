# encoding: utf-8
# module Foundation._inlines
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/Foundation/_inlines.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
# variables with complex values

_inline_list_ = None # (!) real value is ''

