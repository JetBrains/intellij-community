# encoding: utf-8
# module FixTk
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-tk/FixTk.pyo by generator 1.99
# no doc

# imports
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

prefix = '/System/Library/Frameworks/Python.framework/Versions/tcltk/lib'

# no functions
# no classes
