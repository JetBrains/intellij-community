# encoding: utf-8
# module copy_reg
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/copy_reg.pyo by generator 1.99
"""
Helper to provide extensibility for pickle/cPickle.

This is only useful to add pickle support for extension types defined in
C, not for instances of user-defined classes.
"""
# no imports

# Variables with simple values

_HEAPTYPE = 512

# functions

def add_extension(module, name, code): # reliably restored by inspect
    """ Register an extension code. """
    pass


def clear_extension_cache(): # reliably restored by inspect
    # no doc
    pass


def constructor(object): # reliably restored by inspect
    # no doc
    pass


def pickle(ob_type, pickle_function, constructor_ob=None): # reliably restored by inspect
    # no doc
    pass


def pickle_complex(c): # reliably restored by inspect
    # no doc
    pass


def remove_extension(module, name, code): # reliably restored by inspect
    """ Unregister an extension code.  For testing only. """
    pass


def _reconstructor(cls, base, state): # reliably restored by inspect
    # no doc
    pass


def _reduce_ex(self, proto): # reliably restored by inspect
    # no doc
    pass


def _slotnames(cls): # reliably restored by inspect
    """
    Return a list of slot names for a given class.
    
        This needs to find slots defined by the class and its bases, so we
        can't simply return the __slots__ attribute.  We must walk down
        the Method Resolution Order and concatenate the __slots__ of each
        class found there.  (This assumes classes don't modify their
        __slots__ attribute to misrepresent their slots after the class is
        defined.)
    """
    pass


def __newobj__(cls, *args): # reliably restored by inspect
    # no doc
    pass


# classes

class _ClassType(object):
    """
    classobj(name, bases, dict)
    
    Create a class object.  The name must be a string; the second argument
    a tuple of classes, and the third a dictionary.
    """
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, name, bases, dict): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    def __str__(self): # real signature unknown; restored from __doc__
        """ x.__str__() <==> str(x) """
        pass


# variables with complex values

dispatch_table = {
    complex: 
        pickle_complex
    ,
    None:  # (!) real value is ''
        None # (!) real value is ''
    ,
    None:  # (!) real value is ''
        None # (!) real value is ''
    ,
    None:  # (!) real value is ''
        None # (!) real value is ''
    ,
}

_extension_cache = {}

_extension_registry = {}

_inverted_registry = {}

__all__ = [
    'pickle',
    'constructor',
    'add_extension',
    'remove_extension',
    'clear_extension_cache',
]

