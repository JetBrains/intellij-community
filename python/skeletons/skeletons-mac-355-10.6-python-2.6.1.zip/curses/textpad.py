# encoding: utf-8
# module curses.textpad
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/curses/textpad.pyo by generator 1.99
""" Simple textbox editing widget with Emacs-like keybindings. """

# imports
import curses as curses # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/curses/__init__.pyc

# functions

def rectangle(win, uly, ulx, lry, lrx): # reliably restored by inspect
    """
    Draw a rectangle with corners at the provided upper-left
        and lower-right coordinates.
    """
    pass


# no classes
# variables with complex values

Textbox = None # (!) real value is ''

