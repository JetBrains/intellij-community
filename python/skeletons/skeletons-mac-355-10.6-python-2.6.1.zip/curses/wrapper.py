# encoding: utf-8
# module curses.wrapper
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/curses/wrapper.pyo by generator 1.99
"""
curses.wrapper

Contains one function, wrapper(), which runs another function which
should be the rest of your curses-based application.  If the
application raises an exception, wrapper() will restore the terminal
to a sane state so you can read the resulting traceback.
"""

# imports
import curses as curses # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/curses/__init__.pyc

# functions

def wrapper(func, *args, **kwds): # reliably restored by inspect
    """
    Wrapper function that initializes curses and calls another function,
        restoring normal keyboard/screen behavior on error.
        The callable object 'func' is then passed the main window 'stdscr'
        as its first argument, followed by any other arguments passed to
        wrapper().
    """
    pass


# no classes
