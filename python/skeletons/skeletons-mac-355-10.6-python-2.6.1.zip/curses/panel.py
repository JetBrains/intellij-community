# encoding: utf-8
# module curses.panel
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/curses/panel.pyo by generator 1.99
"""
curses.panel

Module for using panels with curses.
"""

# imports
from _curses_panel import (bottom_panel, error, new_panel, top_panel, 
    update_panels)


# Variables with simple values

version = '2.1'

__revision__ = '$Id: panel.py 36560 2004-07-18 06:16:08Z tim_one $'

# no functions
# no classes
