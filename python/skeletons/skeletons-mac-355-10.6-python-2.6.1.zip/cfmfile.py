# encoding: utf-8
# module cfmfile
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/cfmfile.pyo by generator 1.99
""" codefragments.py -- wrapper to modify code fragments. """

# imports
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/struct.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/warnings.pyc
import Carbon.Res as Res # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Res.pyc
import sys as sys # <module 'sys' (built-in)>
import Carbon as Carbon # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/__init__.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

BUFSIZE = 524288

DEBUG = 0

error = 'cfm.error'

__author__ = 'jvr'

__version__ = '0.8b3'

# functions

def mergecfmfiles(srclist, dst, architecture=None): # reliably restored by inspect
    """
    Merge all files in srclist into a new file dst.
    
        If architecture is given, only code fragments of that type will be used:
        "pwpc" for PPC, "m68k" for cfm68k. This does not work for "classic"
        68k code, since it does not use code fragments to begin with.
        If architecture is None, all fragments will be used, enabling FAT binaries.
    """
    pass


# no classes
# variables with complex values

CfrgResource = None # (!) real value is ''

FragmentDescriptor = None # (!) real value is ''

