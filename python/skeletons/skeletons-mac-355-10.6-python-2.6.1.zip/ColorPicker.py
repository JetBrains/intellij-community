# encoding: utf-8
# module ColorPicker
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/ColorPicker.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
