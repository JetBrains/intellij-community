# encoding: utf-8
# module dircache
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/dircache.pyo by generator 1.99
"""
Read and cache directory listings.

The listdir() routine returns a sorted list of the files in a directory,
using a cache to avoid reading the directory more often than necessary.
The annotate() routine appends slashes to directories.
"""

# imports
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# functions

def annotate(head, list): # reliably restored by inspect
    """ Add '/' suffixes to directories. """
    pass


def listdir(path): # reliably restored by inspect
    """ List directory contents, using cache. """
    pass


def opendir(path): # reliably restored by inspect
    """ List directory contents, using cache. """
    pass


def reset(): # reliably restored by inspect
    """ Reset the cache completely. """
    pass


# no classes
# variables with complex values

cache = {}

__all__ = [
    'listdir',
    'opendir',
    'annotate',
    'reset',
]

