# encoding: utf-8
# module io
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/io.pyo by generator 1.99

# imports
import abc as abc # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/abc.pyc
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
import _bytesio as _bytesio # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_bytesio.so
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/threading.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import _fileio as _fileio # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_fileio.so
import codecs as __codecs
import _bytesio as ___bytesio


# Variables with simple values

DEFAULT_BUFFER_SIZE = 8192

__author__ = u'Guido van Rossum <guido@python.org>, Mike Verdone <mike.verdone@gmail.com>, Mark Russell <mark.russell@zen.co.uk>'

# functions

def open(file, mode=None, buffering=None, encoding=None, errors=None, newline=None, closefd=True): # reliably restored by inspect
    pass


# classes

class BlockingIOError(IOError):
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class IOBase(object):
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def fileno(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def isatty(self, *args, **kwargs): # real signature unknown
        pass

    def next(self, *args, **kwargs): # real signature unknown
        pass

    def readable(self, *args, **kwargs): # real signature unknown
        pass

    def readline(self, *args, **kwargs): # real signature unknown
        pass

    def readlines(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def seekable(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def writable(self, *args, **kwargs): # real signature unknown
        pass

    def writelines(self, *args, **kwargs): # real signature unknown
        pass

    def _checkClosed(self, *args, **kwargs): # real signature unknown
        pass

    def _checkReadable(self, *args, **kwargs): # real signature unknown
        pass

    def _checkSeekable(self, *args, **kwargs): # real signature unknown
        pass

    def _checkWritable(self, *args, **kwargs): # real signature unknown
        pass

    def _unsupported(self, *args, **kwargs): # real signature unknown
        pass

    def __del__(self, *args, **kwargs): # real signature unknown
        pass

    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, and_its_subclasses): # real signature unknown; restored from __doc__
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        """
        Metaclass for defining Abstract Base Classes (ABCs).
        
            Use this metaclass to create an ABC.  An ABC can be subclassed
            directly, and then acts as a mix-in class.  You can also register
            unrelated concrete classes (even built-in classes) and unrelated
            ABCs as 'virtual subclasses' -- these and their descendants will
            be considered subclasses of the registering ABC by the built-in
            issubclass() function, but the registering ABC won't show up in
            their MRO (Method Resolution Order) nor will method
            implementations defined by the registering ABC be callable (not
            even via super()).
        """
        pass

    closed = property(lambda self: object()) # default
    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    _IOBase__closed = False
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class BufferedIOBase(IOBase):
    def read(self, *args, **kwargs): # real signature unknown
        pass

    def readinto(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class _BufferedIOMixin(BufferedIOBase):
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def fileno(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def isatty(self, *args, **kwargs): # real signature unknown
        pass

    def readable(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def seekable(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def writable(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    closed = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class BufferedReader(_BufferedIOMixin):
    def peek(self, *args, **kwargs): # real signature unknown
        pass

    def read(self): # real signature unknown; restored from __doc__
        pass

    def read1(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def _peek_unlocked(self, *args, **kwargs): # real signature unknown
        pass

    def _read_unlocked(self, *args, **kwargs): # real signature unknown
        pass

    def _reset_read_buf(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class BufferedWriter(_BufferedIOMixin):
    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def _flush_unlocked(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class BufferedRandom(BufferedWriter, BufferedReader):
    def peek(self, *args, **kwargs): # real signature unknown
        pass

    def read(self, *args, **kwargs): # real signature unknown
        pass

    def read1(self, *args, **kwargs): # real signature unknown
        pass

    def readinto(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class BufferedRWPair(BufferedIOBase):
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def isatty(self, *args, **kwargs): # real signature unknown
        pass

    def peek(self, *args, **kwargs): # real signature unknown
        pass

    def read(self, *args, **kwargs): # real signature unknown
        pass

    def read1(self, *args, **kwargs): # real signature unknown
        pass

    def readable(self, *args, **kwargs): # real signature unknown
        pass

    def readinto(self, *args, **kwargs): # real signature unknown
        pass

    def writable(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    closed = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class BytesIO(___bytesio._BytesIO, BufferedIOBase):
    """
    BytesIO([buffer]) -> object
    
    Create a buffered I/O implementation using an in-memory bytes
    buffer, ready for reading and writing.
    """
    def __init__(self, buffer=None): # real signature unknown; restored from __doc__
        pass

    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class RawIOBase(IOBase):
    def read(self, *args, **kwargs): # real signature unknown
        pass

    def readall(self, *args, **kwargs): # real signature unknown
        pass

    def readinto(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class FileIO(_FileIO, RawIOBase):
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    mode = property(lambda self: object()) # default
    name = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class IncrementalNewlineDecoder(__codecs.IncrementalDecoder):
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def getstate(self, *args, **kwargs): # real signature unknown
        pass

    def reset(self, *args, **kwargs): # real signature unknown
        pass

    def setstate(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    newlines = property(lambda self: object()) # default

    _CR = 2
    _CRLF = 4
    _LF = 1


class OpenWrapper(object):
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(cls, *args, **kwargs): # reliably restored by inspect
        # no doc
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class TextIOBase(IOBase):
    def read(self, *args, **kwargs): # real signature unknown
        pass

    def readline(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    encoding = property(lambda self: object()) # default
    newlines = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class TextIOWrapper(TextIOBase):
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def fileno(self, *args, **kwargs): # real signature unknown
        pass

    def flush(self, *args, **kwargs): # real signature unknown
        pass

    def isatty(self, *args, **kwargs): # real signature unknown
        pass

    def next(self, *args, **kwargs): # real signature unknown
        pass

    def read(self, *args, **kwargs): # real signature unknown
        pass

    def readable(self, *args, **kwargs): # real signature unknown
        pass

    def readline(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def seekable(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def writable(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def _get_decoded_chars(self, *args, **kwargs): # real signature unknown
        pass

    def _get_decoder(self, *args, **kwargs): # real signature unknown
        pass

    def _get_encoder(self, *args, **kwargs): # real signature unknown
        pass

    def _pack_cookie(self, *args, **kwargs): # real signature unknown
        pass

    def _read_chunk(self, *args, **kwargs): # real signature unknown
        pass

    def _rewind_decoded_chars(self, *args, **kwargs): # real signature unknown
        pass

    def _set_decoded_chars(self, *args, **kwargs): # real signature unknown
        pass

    def _unpack_cookie(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    closed = property(lambda self: object()) # default
    encoding = property(lambda self: object()) # default
    errors = property(lambda self: object()) # default
    line_buffering = property(lambda self: object()) # default
    newlines = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    _CHUNK_SIZE = 128
    __abstractmethods__ = None # (!) real value is ''


class StringIO(TextIOWrapper):
    def getvalue(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class UnsupportedOperation(ValueError, IOError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class _BytesIO(BufferedIOBase):
    def getvalue(self, *args, **kwargs): # real signature unknown
        pass

    def read(self, *args, **kwargs): # real signature unknown
        pass

    def read1(self, *args, **kwargs): # real signature unknown
        pass

    def readable(self, *args, **kwargs): # real signature unknown
        pass

    def seek(self, *args, **kwargs): # real signature unknown
        pass

    def seekable(self, *args, **kwargs): # real signature unknown
        pass

    def tell(self, *args, **kwargs): # real signature unknown
        pass

    def truncate(self, *args, **kwargs): # real signature unknown
        pass

    def writable(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class _DocDescriptor(object):
    def __get__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


class __metaclass__(object):
    """
    type(object) -> the object's type
    type(name, bases, dict) -> a new type
    """
    def mro(self): # real signature unknown; restored from __doc__
        """
        mro() -> list
        return a type's method resolution order
        """
        return []

    def __base__(self, *args, **kwargs): # real signature unknown
        """ The most base type """
        pass

    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __cmp__(self, y): # real signature unknown; restored from __doc__
        """ x.__cmp__(y) <==> cmp(x,y) """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __eq__(self, y): # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __ge__(self, y): # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y): # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __hash__(self): # real signature unknown; restored from __doc__
        """ x.__hash__() <==> hash(x) """
        pass

    def __init__(self, p_object): # real signature unknown; restored from __doc__
        pass

    def __instancecheck__(self, *args, **kwargs): # real signature unknown
        pass

    def __le__(self, y): # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y): # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __ne__(self, y): # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    def __subclasscheck__(self, *args, **kwargs): # real signature unknown
        pass

    def __subclasses__(self): # real signature unknown; restored from __doc__
        """ __subclasses__() -> list of immediate subclasses """
        return []

    __abstractmethods__ = property(lambda self: object()) # default

    __bases__ = (
        object,
    )
    __basicsize__ = 872
    __dictoffset__ = 264
    __dict__ = None # (!) real value is ''
    __flags__ = 2148423147
    __itemsize__ = 40
    __mro__ = (
        type,
        object,
    )
    __name__ = 'type'
    __weakrefoffset__ = 368


# variables with complex values

print_function = None # (!) real value is ''

unicode_literals = None # (!) real value is ''

__all__ = [
    u'BlockingIOError',
    u'open',
    u'IOBase',
    u'RawIOBase',
    u'FileIO',
    u'BytesIO',
    u'StringIO',
    u'BufferedIOBase',
    u'BufferedReader',
    u'BufferedWriter',
    u'BufferedRWPair',
    u'BufferedRandom',
    u'TextIOBase',
    u'TextIOWrapper',
]

