# encoding: utf-8
# module gzip
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/gzip.pyo by generator 1.99
"""
Functions that read and write gzipped files.

The user of the file doesn't have to worry about the compression,
but random access is not allowed.
"""

# imports
import __builtin__ as __builtin__ # <module '__builtin__' (built-in)>
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/struct.pyc
import sys as sys # <module 'sys' (built-in)>
import zlib as zlib # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/zlib.so
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/time.so

# Variables with simple values

FCOMMENT = 16

FEXTRA = 4

FHCRC = 2

FNAME = 8

FTEXT = 1

READ = 1

WRITE = 2

# functions

def open(filename, mode=None, compresslevel=9): # reliably restored by inspect
    """
    Shorthand for GzipFile(filename, mode, compresslevel).
    
        The filename argument is required; mode defaults to 'rb'
        and compresslevel defaults to 9.
    """
    pass


def read32(input): # reliably restored by inspect
    # no doc
    pass


def write32u(output, value): # reliably restored by inspect
    # no doc
    pass


def _test(): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

GzipFile = None # (!) real value is ''

__all__ = [
    'GzipFile',
    'open',
]

