# encoding: utf-8
# module dl
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/dl.so by generator 1.99
# no doc
# no imports

# Variables with simple values

RTLD_GLOBAL = 8
RTLD_LAZY = 1
RTLD_LOCAL = 4
RTLD_NODELETE = 128
RTLD_NOLOAD = 16
RTLD_NOW = 2

# functions

def open(*args, **kwargs): # real signature unknown
    pass


# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


