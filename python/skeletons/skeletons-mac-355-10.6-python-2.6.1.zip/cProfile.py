# encoding: utf-8
# module cProfile
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/cProfile.pyo by generator 1.99
"""
Python interface for the 'lsprof' profiler.
   Compatible with the 'profile' module.
"""

# imports
import _lsprof as _lsprof # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_lsprof.so
import _lsprof as ___lsprof


# functions

def help(): # reliably restored by inspect
    # no doc
    pass


def label(code): # reliably restored by inspect
    # no doc
    pass


def main(): # reliably restored by inspect
    # no doc
    pass


def run(statement, filename=None, sort=-1): # reliably restored by inspect
    """
    Run statement under profiler optionally saving results in filename
    
        This function takes a single argument that can be passed to the
        "exec" statement, and an optional file name.  In all cases this
        routine attempts to "exec" its first argument and gather profiling
        statistics from the execution. If no file name is present, then this
        function automatically prints a simple profiling report, sorted by the
        standard name string (file/line/function-name) that is presented in
        each line.
    """
    pass


def runctx(statement, globals, locals, filename=None): # reliably restored by inspect
    """
    Run statement under profiler, supplying your own globals and locals,
        optionally saving results in filename.
    
        statement and filename have the same semantics as profile.run
    """
    pass


# classes

class Profile(___lsprof.Profiler):
    """
    Profile(custom_timer=None, time_unit=None, subcalls=True, builtins=True)
    
        Builds a profiler object using the specified timer function.
        The default timer is a fast built-in one based on real time.
        For custom timer functions returning integers, time_unit can
        be a float specifying a scale (i.e. how long each integer unit
        is, in seconds).
    """
    def create_stats(self, *args, **kwargs): # real signature unknown
        pass

    def dump_stats(self, *args, **kwargs): # real signature unknown
        pass

    def print_stats(self, *args, **kwargs): # real signature unknown
        pass

    def run(self, *args, **kwargs): # real signature unknown
        pass

    def runcall(self, *args, **kwargs): # real signature unknown
        pass

    def runctx(self, *args, **kwargs): # real signature unknown
        pass

    def snapshot_stats(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, custom_timer=None, time_unit=None, subcalls=True, builtins=True): # real signature unknown; restored from __doc__
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

__all__ = [
    'run',
    'runctx',
    'help',
    'Profile',
]

