# encoding: utf-8
# module HTMLParser
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/HTMLParser.pyo by generator 1.99
""" A parser for HTML and XHTML. """

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import markupbase as markupbase # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/markupbase.pyc

# no functions
# classes

class HTMLParseError(Exception):
    """ Exception raised for all parse errors. """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

attrfind = None # (!) real value is ''

charref = None # (!) real value is ''

commentclose = markupbase._commentclose

endendtag = None # (!) real value is ''

endtagfind = None # (!) real value is ''

entityref = None # (!) real value is ''

HTMLParser = None # (!) real value is ''

incomplete = None # (!) real value is ''

interesting_cdata = None # (!) real value is ''

interesting_normal = None # (!) real value is ''

locatestarttagend = None # (!) real value is ''

piclose = endendtag

starttagopen = None # (!) real value is ''

tagfind = None # (!) real value is ''

