# encoding: utf-8
# module applesingle
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/applesingle.pyo by generator 1.99
""" Routines to decode AppleSingle files """

# imports
import MacOS as MacOS # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/MacOS.so
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/struct.pyc
import Carbon as Carbon # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/__init__.pyc
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

AS_DATAFORK = 1

AS_ENTRY_FORMAT = '>lll'
AS_ENTRY_LENGTH = 12

AS_HEADER_FORMAT = '>LL16sh'
AS_HEADER_LENGTH = 26

AS_MAGIC = 333312
AS_RESOURCEFORK = 2
AS_VERSION = 131072

# functions

def decode(infile, outpath, resonly=False, verbose=False): # reliably restored by inspect
    """
    decode(infile, outpath [, resonly=False, verbose=False])
    
        Creates a decoded file from an AppleSingle encoded file.
        If resonly is True, then it will create a regular file at
        outpath containing only the resource fork from infile.
        Otherwise it will create an AppleDouble file at outpath
        with the data and resource forks from infile.  On platforms
        without the MacOS module, it will create inpath and inpath+'.rsrc'
        with the data and resource forks respectively.
    """
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


def _test(): # reliably restored by inspect
    # no doc
    pass


# classes

class AppleSingle(object):
    # no doc
    def tofile(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    datafork = None
    resourcefork = None
    __dict__ = None # (!) real value is ''


class Error(ValueError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

AS_IGNORE = (
    3,
    4,
    5,
    6,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
)

