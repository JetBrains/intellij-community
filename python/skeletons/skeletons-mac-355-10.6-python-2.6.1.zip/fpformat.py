# encoding: utf-8
# module fpformat
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/fpformat.pyo by generator 1.99
"""
General floating point formatting functions.

Functions:
fix(x, digits_behind)
sci(x, digits_behind)

Each takes a number or a string and a number of digits as arguments.

Parameters:
x:             number to be formatted; or a string resembling a number
digits_behind: number of digits behind the decimal point
"""

# imports
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc

# functions

def extract(s): # reliably restored by inspect
    """
    Return (sign, intpart, fraction, expo) or raise an exception:
        sign is '+' or '-'
        intpart is 0 or more digits beginning with a nonzero
        fraction is 0 or more digits
        expo is an integer
    """
    pass


def fix(x, digs): # reliably restored by inspect
    """
    Format x as [-]ddd.ddd with 'digs' digits after the point
        and at least one digit before.
        If digs <= 0, the point is suppressed.
    """
    pass


def roundfrac(intpart, fraction, digs): # reliably restored by inspect
    """ Round or extend the fraction to size digs. """
    pass


def sci(x, digs): # reliably restored by inspect
    """
    Format x as [-]d.dddE[+-]ddd with 'digs' digits after the point
        and exactly one digit before.
        If digs is <= 0, one digit is kept and the point is suppressed.
    """
    pass


def test(): # reliably restored by inspect
    """ Interactive test run. """
    pass


def unexpo(intpart, fraction, expo): # reliably restored by inspect
    """ Remove the exponent by changing intpart and fraction. """
    pass


# classes

class NotANumber(ValueError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

decoder = None # (!) real value is ''

__all__ = [
    'fix',
    'sci',
    'NotANumber',
]

