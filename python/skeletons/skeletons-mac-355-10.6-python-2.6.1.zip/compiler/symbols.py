# encoding: utf-8
# module compiler.symbols
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/symbols.pyo by generator 1.99
""" Module symbol-table generator """

# imports
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/types.pyc
import compiler.ast as ast # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/ast.pyc
import sys as sys # <module 'sys' (built-in)>

# Variables with simple values

MANGLE_LEN = 256

SC_CELL = 4
SC_FREE = 3
SC_GLOBAL = 2
SC_LOCAL = 1
SC_UNKNOWN = 5

# functions

def list_eq(l1, l2): # reliably restored by inspect
    # no doc
    pass


def mangle(name, klass): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

ClassScope = None # (!) real value is ''

FunctionScope = None # (!) real value is ''

GenExprScope = None # (!) real value is ''

LambdaScope = None # (!) real value is ''

ModuleScope = None # (!) real value is ''

Scope = None # (!) real value is ''

SymbolVisitor = None # (!) real value is ''

