# encoding: utf-8
# module compiler.pyassem
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/pyassem.pyo by generator 1.99
""" A flow graph representation for Python bytecode """

# imports
import compiler.misc as misc # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/misc.pyc
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/types.pyc
import sys as sys # <module 'sys' (built-in)>
import dis as dis # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/dis.pyc

# Variables with simple values

CONV = 'CONV'
CO_NEWLOCALS = 2
CO_OPTIMIZED = 1
CO_VARARGS = 4
CO_VARKEYWORDS = 8

DONE = 'DONE'

FLAT = 'FLAT'

RAW = 'RAW'

# functions

def dfs_postorder(b, seen): # reliably restored by inspect
    """ Depth-first search of tree rooted at b, return in postorder """
    pass


def findDepth(*args, **kwargs): # real signature unknown
    pass


def getArgCount(args): # reliably restored by inspect
    # no doc
    pass


def isJump(opname): # reliably restored by inspect
    # no doc
    pass


def twobyte(val): # reliably restored by inspect
    """ Convert an int argument into high and low bytes """
    pass


# no classes
# variables with complex values

Block = None # (!) real value is ''

FlowGraph = None # (!) real value is ''

LineAddrTable = None # (!) real value is ''

PyFlowGraph = None # (!) real value is ''

StackDepthTracker = None # (!) real value is ''

TupleArg = None # (!) real value is ''

