# encoding: utf-8
# module compiler.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/__init__.pyo by generator 1.99
"""
Package for parsing and compiling Python source code

There are several functions defined at the top level that are imported
from modules contained in the package.

parse(buf, mode="exec") -> AST
    Converts a string containing Python source code to an abstract
    syntax tree (AST).  The AST is defined in compiler.ast.

parseFile(path) -> AST
    The same as parse(open(path))

walk(ast, visitor, verbose=None)
    Does a pre-order walk over the ast using the visitor instance.
    See compiler.visitor for details.

compile(source, filename, mode, flags=None, dont_inherit=None)
    Returns a code object.  A replacement for the builtin compile() function.

compileFile(filename)
    Generates a .pyc file by compiling filename.
"""
# no imports

# functions

def compile(source, filename, mode, flags=None, dont_inherit=None): # reliably restored by inspect
    """ Replacement for builtin compile() function """
    pass


def compileFile(filename, display=0): # reliably restored by inspect
    # no doc
    pass


def parse(buf, mode=None): # reliably restored by inspect
    # no doc
    pass


def parseFile(path): # reliably restored by inspect
    # no doc
    pass


def walk(tree, visitor, walker=None, verbose=None): # reliably restored by inspect
    # no doc
    pass


# no classes
