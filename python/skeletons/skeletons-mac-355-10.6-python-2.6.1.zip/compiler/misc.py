# encoding: utf-8
# module compiler.misc
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/misc.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

MANGLE_LEN = 256

# functions

def flatten(tup): # reliably restored by inspect
    # no doc
    pass


def mangle(name, klass): # reliably restored by inspect
    # no doc
    pass


def set_filename(filename, tree): # reliably restored by inspect
    """ Set the filename attribute to filename on every node in tree """
    pass


# no classes
# variables with complex values

Set = None # (!) real value is ''

Stack = None # (!) real value is ''

