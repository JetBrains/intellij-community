# encoding: utf-8
# module compiler.transformer
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/transformer.pyo by generator 1.99
"""
Parse tree transformation module.

Transforms Python source code into an abstract syntax tree (AST)
defined in the ast module.

The simplest ways to invoke this module are via parse and parseFile.
parse(buf) -> AST
parseFile(path) -> AST
"""

# imports
import token as token # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/token.pyc
import parser as parser # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/parser.so
import symbol as symbol # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/symbol.pyc

# Variables with simple values

CO_VARARGS = 4
CO_VARKEYWORDS = 8
k = 51

name = 'If'

OP_APPLY = 'OP_APPLY'
OP_ASSIGN = 'OP_ASSIGN'
OP_DELETE = 'OP_DELETE'
v = 'OP'

# functions

def asList(nodes): # reliably restored by inspect
    # no doc
    pass


def debug_tree(tree): # reliably restored by inspect
    # no doc
    pass


def extractLineNo(ast): # reliably restored by inspect
    # no doc
    pass


def flatten(seq): # reliably restored by inspect
    # no doc
    pass


def flatten_nodes(seq): # reliably restored by inspect
    # no doc
    pass


def Node(*args): # reliably restored by inspect
    # no doc
    pass


def parse(buf, mode=None): # reliably restored by inspect
    # no doc
    pass


def parseFile(path): # reliably restored by inspect
    # no doc
    pass


# classes

class WalkerError(StandardError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

Add = None # (!) real value is ''

And = None # (!) real value is ''

AssAttr = None # (!) real value is ''

Assert = None # (!) real value is ''

Assign = None # (!) real value is ''

AssList = None # (!) real value is ''

AssName = None # (!) real value is ''

AssTuple = None # (!) real value is ''

AugAssign = None # (!) real value is ''

Backquote = None # (!) real value is ''

Bitand = None # (!) real value is ''

Bitor = None # (!) real value is ''

Bitxor = None # (!) real value is ''

Break = None # (!) real value is ''

CallFunc = None # (!) real value is ''

Class = None # (!) real value is ''

Compare = None # (!) real value is ''

Const = None # (!) real value is ''

Continue = None # (!) real value is ''

Decorators = None # (!) real value is ''

Dict = None # (!) real value is ''

Discard = None # (!) real value is ''

Div = None # (!) real value is ''

Ellipsis = None # (!) real value is ''

EmptyNode = None # (!) real value is ''

Exec = None # (!) real value is ''

Expression = None # (!) real value is ''

FloorDiv = None # (!) real value is ''

For = None # (!) real value is ''

From = None # (!) real value is ''

Function = None # (!) real value is ''

GenExpr = None # (!) real value is ''

GenExprFor = None # (!) real value is ''

GenExprIf = None # (!) real value is ''

GenExprInner = None # (!) real value is ''

Getattr = None # (!) real value is ''

Global = None # (!) real value is ''

If = None # (!) forward: obj, real value is ''

IfExp = None # (!) real value is ''

Import = None # (!) real value is ''

Invert = None # (!) real value is ''

Keyword = None # (!) real value is ''

Lambda = None # (!) real value is ''

LeftShift = None # (!) real value is ''

List = None # (!) real value is ''

ListComp = None # (!) real value is ''

ListCompFor = None # (!) real value is ''

ListCompIf = None # (!) real value is ''

Mod = None # (!) real value is ''

Module = None # (!) real value is ''

Mul = None # (!) real value is ''

Name = None # (!) real value is ''

nodes = {
    'expression': 'Expression',
}

Not = None # (!) real value is ''

obj = None # (!) real value is ''

Or = None # (!) real value is ''

Pass = None # (!) real value is ''

Power = None # (!) real value is ''

Print = None # (!) real value is ''

Printnl = None # (!) real value is ''

Raise = None # (!) real value is ''

Return = None # (!) real value is ''

RightShift = None # (!) real value is ''

Slice = None # (!) real value is ''

Sliceobj = None # (!) real value is ''

Stmt = None # (!) real value is ''

Sub = None # (!) real value is ''

Subscript = None # (!) real value is ''

Transformer = None # (!) real value is ''

TryExcept = None # (!) real value is ''

TryFinally = None # (!) real value is ''

Tuple = None # (!) real value is ''

UnaryAdd = None # (!) real value is ''

UnarySub = None # (!) real value is ''

While = None # (!) real value is ''

With = None # (!) real value is ''

Yield = None # (!) real value is ''

_assign_types = [
    304,
    305,
    306,
    307,
    308,
    310,
    311,
    312,
    313,
    314,
    315,
    316,
]

_cmp_types = {
    20: '<',
    21: '>',
    22: '==',
    28: '==',
    29: '!=',
    30: '<=',
    31: '>=',
}

_doc_nodes = [
    270,
    327,
    301,
    304,
    305,
    306,
    307,
    308,
    310,
    311,
    312,
    313,
    314,
    315,
    316,
    317,
]

_legal_node_types = [
    262,
    329,
    267,
    269,
    275,
    268,
    292,
    270,
    272,
    273,
    274,
    276,
    277,
    278,
    280,
    281,
    289,
    290,
    291,
    293,
    294,
    295,
    296,
    297,
    300,
    327,
    301,
    304,
    306,
    307,
    308,
    326,
    310,
    311,
    312,
    313,
    314,
    315,
    316,
    317,
    318,
    279,
    340,
]

_names = {
    0: 'ENDMARKER',
    1: 'NAME',
    2: 'NUMBER',
    3: 'STRING',
    4: 'NEWLINE',
    5: 'INDENT',
    6: 'DEDENT',
    7: 'LPAR',
    8: 'RPAR',
    9: 'LSQB',
    10: 'RSQB',
    11: 'COLON',
    12: 'COMMA',
    13: 'SEMI',
    14: 'PLUS',
    15: 'MINUS',
    16: 'STAR',
    17: 'SLASH',
    18: 'VBAR',
    19: 'AMPER',
    20: 'LESS',
    21: 'GREATER',
    22: 'EQUAL',
    23: 'DOT',
    24: 'PERCENT',
    25: 'BACKQUOTE',
    26: 'LBRACE',
    27: 'RBRACE',
    28: 'EQEQUAL',
    29: 'NOTEQUAL',
    30: 'LESSEQUAL',
    31: 'GREATEREQUAL',
    32: 'TILDE',
    33: 'CIRCUMFLEX',
    34: 'LEFTSHIFT',
    35: 'RIGHTSHIFT',
    36: 'DOUBLESTAR',
    37: 'PLUSEQUAL',
    38: 'MINEQUAL',
    39: 'STAREQUAL',
    40: 'SLASHEQUAL',
    41: 'PERCENTEQUAL',
    42: 'AMPEREQUAL',
    43: 'VBAREQUAL',
    44: 'CIRCUMFLEXEQUAL',
    45: 'LEFTSHIFTEQUAL',
    46: 'RIGHTSHIFTEQUAL',
    47: 'DOUBLESTAREQUAL',
    48: 'DOUBLESLASH',
    49: 'DOUBLESLASHEQUAL',
    50: 'AT',
    51: 'OP',
    52: 'ERRORTOKEN',
    53: 'COMMENT',
    54: 'NL',
    256: 'NT_OFFSET',
    257: 'file_input',
    258: 'eval_input',
    259: 'decorator',
    260: 'decorators',
    261: 'decorated',
    262: 'funcdef',
    263: 'parameters',
    264: 'varargslist',
    265: 'fpdef',
    266: 'fplist',
    267: 'stmt',
    268: 'simple_stmt',
    269: 'small_stmt',
    270: 'expr_stmt',
    271: 'augassign',
    272: 'print_stmt',
    273: 'del_stmt',
    274: 'pass_stmt',
    275: 'flow_stmt',
    276: 'break_stmt',
    277: 'continue_stmt',
    278: 'return_stmt',
    279: 'yield_stmt',
    280: 'raise_stmt',
    281: 'import_stmt',
    282: 'import_name',
    283: 'import_from',
    284: 'import_as_name',
    285: 'dotted_as_name',
    286: 'import_as_names',
    287: 'dotted_as_names',
    288: 'dotted_name',
    289: 'global_stmt',
    290: 'exec_stmt',
    291: 'assert_stmt',
    292: 'compound_stmt',
    293: 'if_stmt',
    294: 'while_stmt',
    295: 'for_stmt',
    296: 'try_stmt',
    297: 'with_stmt',
    298: 'with_var',
    299: 'except_clause',
    300: 'suite',
    301: 'testlist_safe',
    302: 'old_test',
    303: 'old_lambdef',
    304: 'test',
    305: 'or_test',
    306: 'and_test',
    307: 'not_test',
    308: 'comparison',
    309: 'comp_op',
    310: 'expr',
    311: 'xor_expr',
    312: 'and_expr',
    313: 'shift_expr',
    314: 'arith_expr',
    315: 'term',
    316: 'factor',
    317: 'power',
    318: 'atom',
    319: 'listmaker',
    320: 'testlist_gexp',
    321: 'lambdef',
    322: 'trailer',
    323: 'subscriptlist',
    324: 'subscript',
    325: 'sliceop',
    326: 'exprlist',
    327: 'testlist',
    328: 'dictmaker',
    329: 'classdef',
    330: 'arglist',
    331: 'argument',
    332: 'list_iter',
    333: 'list_for',
    334: 'list_if',
    335: 'gen_iter',
    336: 'gen_for',
    337: 'gen_if',
    338: 'testlist1',
    339: 'encoding_decl',
    340: 'yield_expr',
}

