# encoding: utf-8
# module compiler.pycodegen
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/pycodegen.pyo by generator 1.99
# no doc

# imports
import compiler.misc as misc # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/misc.pyc
import compiler.syntax as syntax # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/syntax.pyc
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/struct.pyc
import imp as imp # <module 'imp' (built-in)>
import compiler.ast as ast # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/ast.pyc
import sys as sys # <module 'sys' (built-in)>
import compiler.pyassem as pyassem # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/pyassem.pyc
import compiler.symbols as symbols # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/symbols.pyc
import compiler.future as future # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compiler/future.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import marshal as marshal # <module 'marshal' (built-in)>
from cStringIO import StringIO


# Variables with simple values

CO_FUTURE_ABSIMPORT = 16384
CO_FUTURE_DIVISION = 8192

CO_FUTURE_PRINT_FUNCTION = 65536

CO_FUTURE_WITH_STATEMENT = 32768

CO_GENERATOR = 32
CO_NESTED = 16
CO_NEWLOCALS = 2
CO_VARARGS = 4
CO_VARKEYWORDS = 8

END_FINALLY = 4

EXCEPT = 2

LOOP = 1

SC_CELL = 4
SC_FREE = 3
SC_GLOBAL = 2
SC_LOCAL = 1

TRY_FINALLY = 3

VERSION = 2

# functions

def compile(source, filename, mode, flags=None, dont_inherit=None): # reliably restored by inspect
    """ Replacement for builtin compile() function """
    pass


def compileFile(filename, display=0): # reliably restored by inspect
    # no doc
    pass


def findOp(node): # reliably restored by inspect
    """ Find the op (DELETE, LOAD, STORE) in an AssTuple tree """
    pass


def generateArgList(arglist): # reliably restored by inspect
    """ Generate an arg list marking TupleArgs """
    pass


def is_constant_false(node): # reliably restored by inspect
    # no doc
    pass


def parse(buf, mode=None): # reliably restored by inspect
    # no doc
    pass


def walk(tree, visitor, walker=None, verbose=None): # reliably restored by inspect
    # no doc
    pass


def wrap_aug(node): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

AbstractClassCode = None # (!) real value is ''

AbstractCompileMode = None # (!) real value is ''

AbstractFunctionCode = None # (!) real value is ''

AugGetattr = None # (!) real value is ''

AugName = None # (!) real value is ''

AugSlice = None # (!) real value is ''

AugSubscript = None # (!) real value is ''

callfunc_opcode_info = {
    (
        0,
        0,
    ): 
        'CALL_FUNCTION'
    ,
    (
        0,
        1,
    ): 
        'CALL_FUNCTION_KW'
    ,
    (
        1,
        0,
    ): 
        'CALL_FUNCTION_VAR'
    ,
    (
        1,
        1,
    ): 
        'CALL_FUNCTION_VAR_KW'
    ,
}

ClassCodeGenerator = None # (!) real value is ''

CodeGenerator = None # (!) real value is ''

Delegator = None # (!) real value is ''

Expression = None # (!) real value is ''

ExpressionCodeGenerator = None # (!) real value is ''

FunctionCodeGenerator = None # (!) real value is ''

GenExprCodeGenerator = None # (!) real value is ''

Interactive = None # (!) real value is ''

InteractiveCodeGenerator = None # (!) real value is ''

LocalNameFinder = None # (!) real value is ''

Module = None # (!) real value is ''

ModuleCodeGenerator = None # (!) real value is ''

NestedScopeMixin = None # (!) real value is ''

OpFinder = None # (!) real value is ''

TupleArg = pyassem.TupleArg

wrapper = {
    ast.Getattr: 
        AugGetattr
    ,
    ast.Name: 
        AugName
    ,
    ast.Slice: 
        AugSlice
    ,
    ast.Subscript: 
        AugSubscript
    ,
}

