# encoding: utf-8
# module _json
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_json.so by generator 1.99
""" json speedups """
# no imports

# functions

def encode_basestring_ascii(basestring): # real signature unknown; restored from __doc__
    """ encode_basestring_ascii(basestring) -> str """
    return ""


def scanstring(basestring, end, encoding): # real signature unknown; restored from __doc__
    """ scanstring(basestring, end, encoding) -> (str, end) """
    pass


# no classes
