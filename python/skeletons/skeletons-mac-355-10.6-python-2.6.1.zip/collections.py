# encoding: utf-8
# module collections
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/collections.pyo by generator 1.99
# no doc

# imports
import _abcoll as _abcoll # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/_abcoll.pyc
import sys as _sys # <module 'sys' (built-in)>
from operator import _itemgetter

import _abcoll as ___abcoll


# functions

def namedtuple(typename, field_names, verbose=False): # reliably restored by inspect
    """
    Returns a new subclass of tuple with named fields.
    
        >>> Point = namedtuple('Point', 'x y')
        >>> Point.__doc__                   # docstring for the new class
        'Point(x, y)'
        >>> p = Point(11, y=22)             # instantiate with positional args or keywords
        >>> p[0] + p[1]                     # indexable like a plain tuple
        33
        >>> x, y = p                        # unpack like a regular tuple
        >>> x, y
        (11, 22)
        >>> p.x + p.y                       # fields also accessable by name
        33
        >>> d = p._asdict()                 # convert to a dictionary
        >>> d['x']
        11
        >>> Point(**d)                      # convert from a dictionary
        Point(x=11, y=22)
        >>> p._replace(x=100)               # _replace() is like str.replace() but targets named fields
        Point(x=100, y=22)
    """
    pass


def _iskeyword(*args, **kwargs): # real signature unknown
    """ x.__contains__(y) <==> y in x. """
    pass


# classes

class Callable(object):
    # no doc
    def __call__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        """
        Metaclass for defining Abstract Base Classes (ABCs).
        
            Use this metaclass to create an ABC.  An ABC can be subclassed
            directly, and then acts as a mix-in class.  You can also register
            unrelated concrete classes (even built-in classes) and unrelated
            ABCs as 'virtual subclasses' -- these and their descendants will
            be considered subclasses of the registering ABC by the built-in
            issubclass() function, but the registering ABC won't show up in
            their MRO (Method Resolution Order) nor will method
            implementations defined by the registering ABC be callable (not
            even via super()).
        """
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 1
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class Container(object):
    # no doc
    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        """
        Metaclass for defining Abstract Base Classes (ABCs).
        
            Use this metaclass to create an ABC.  An ABC can be subclassed
            directly, and then acts as a mix-in class.  You can also register
            unrelated concrete classes (even built-in classes) and unrelated
            ABCs as 'virtual subclasses' -- these and their descendants will
            be considered subclasses of the registering ABC by the built-in
            issubclass() function, but the registering ABC won't show up in
            their MRO (Method Resolution Order) nor will method
            implementations defined by the registering ABC be callable (not
            even via super()).
        """
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 1
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class defaultdict(dict):
    """
    defaultdict(default_factory) --> dict with default factory
    
    The default factory is called without arguments to produce
    a new value when a key is not present, in __getitem__ only.
    A defaultdict compares equal to a dict with the same items.
    """
    def copy(self): # real signature unknown; restored from __doc__
        """ D.copy() -> a shallow copy of D. """
        pass

    def __copy__(self, *args, **kwargs): # real signature unknown
        """ D.copy() -> a shallow copy of D. """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, default_factory=None, **kwargs): # known case of collections.defaultdict.__init__
        """
        defaultdict(default_factory) --> dict with default factory
        
        The default factory is called without arguments to produce
        a new value when a key is not present, in __getitem__ only.
        A defaultdict compares equal to a dict with the same items.
        
        # (copied from class doc)
        """
        pass

    def __missing__(self, key): # real signature unknown; restored from __doc__
        """
        __missing__(key) # Called by __getitem__ for missing key; pseudo-code:
          if self.default_factory is None: raise KeyError((key,))
          self[key] = value = self.default_factory()
          return value
        """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling. """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    default_factory = property(lambda self: object()) # default


class deque(object):
    """
    deque(iterable[, maxlen]) --> deque object
    
    Build an ordered collection accessible from endpoints only.
    """
    def append(self, *args, **kwargs): # real signature unknown
        """ Add an element to the right side of the deque. """
        pass

    def appendleft(self, *args, **kwargs): # real signature unknown
        """ Add an element to the left side of the deque. """
        pass

    def clear(self, *args, **kwargs): # real signature unknown
        """ Remove all elements from the deque. """
        pass

    def extend(self, *args, **kwargs): # real signature unknown
        """ Extend the right side of the deque with elements from the iterable """
        pass

    def extendleft(self, *args, **kwargs): # real signature unknown
        """ Extend the left side of the deque with elements from the iterable """
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        """ Remove and return the rightmost element. """
        pass

    def popleft(self, *args, **kwargs): # real signature unknown
        """ Remove and return the leftmost element. """
        pass

    def remove(self, value): # real signature unknown; restored from __doc__
        """ D.remove(value) -- remove first occurrence of value. """
        pass

    def rotate(self, *args, **kwargs): # real signature unknown
        """ Rotate the deque n steps to the right (default n=1).  If n is negative, rotates left. """
        pass

    def __copy__(self, *args, **kwargs): # real signature unknown
        """ Return a shallow copy of a deque. """
        pass

    def __delitem__(self, y): # real signature unknown; restored from __doc__
        """ x.__delitem__(y) <==> del x[y] """
        pass

    def __eq__(self, y): # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __getitem__(self, y): # real signature unknown; restored from __doc__
        """ x.__getitem__(y) <==> x[y] """
        pass

    def __ge__(self, y): # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y): # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __init__(self, iterable=(), maxlen=None): # known case of collections.deque.__init__
        """
        deque(iterable[, maxlen]) --> deque object
        
        Build an ordered collection accessible from endpoints only.
        # (copied from class doc)
        """
        pass

    def __iter__(self): # real signature unknown; restored from __doc__
        """ x.__iter__() <==> iter(x) """
        pass

    def __len__(self): # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass

    def __le__(self, y): # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y): # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __ne__(self, y): # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        """ Return state information for pickling. """
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    def __reversed__(self): # real signature unknown; restored from __doc__
        """ D.__reversed__() -- return a reverse iterator over the deque """
        pass

    def __setitem__(self, i, y): # real signature unknown; restored from __doc__
        """ x.__setitem__(i, y) <==> x[i]=y """
        pass

    __hash__ = None


class Hashable(object):
    # no doc
    def __hash__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        """
        Metaclass for defining Abstract Base Classes (ABCs).
        
            Use this metaclass to create an ABC.  An ABC can be subclassed
            directly, and then acts as a mix-in class.  You can also register
            unrelated concrete classes (even built-in classes) and unrelated
            ABCs as 'virtual subclasses' -- these and their descendants will
            be considered subclasses of the registering ABC by the built-in
            issubclass() function, but the registering ABC won't show up in
            their MRO (Method Resolution Order) nor will method
            implementations defined by the registering ABC be callable (not
            even via super()).
        """
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 0
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class Iterable(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        """
        Metaclass for defining Abstract Base Classes (ABCs).
        
            Use this metaclass to create an ABC.  An ABC can be subclassed
            directly, and then acts as a mix-in class.  You can also register
            unrelated concrete classes (even built-in classes) and unrelated
            ABCs as 'virtual subclasses' -- these and their descendants will
            be considered subclasses of the registering ABC by the built-in
            issubclass() function, but the registering ABC won't show up in
            their MRO (Method Resolution Order) nor will method
            implementations defined by the registering ABC be callable (not
            even via super()).
        """
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 0
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class Sized(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __metaclass__(self, *args, **kwargs): # real signature unknown
        """
        Metaclass for defining Abstract Base Classes (ABCs).
        
            Use this metaclass to create an ABC.  An ABC can be subclassed
            directly, and then acts as a mix-in class.  You can also register
            unrelated concrete classes (even built-in classes) and unrelated
            ABCs as 'virtual subclasses' -- these and their descendants will
            be considered subclasses of the registering ABC by the built-in
            issubclass() function, but the registering ABC won't show up in
            their MRO (Method Resolution Order) nor will method
            implementations defined by the registering ABC be callable (not
            even via super()).
        """
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 1
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __dict__ = None # (!) real value is ''


class MappingView(___abcoll.Sized):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 3
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class Set(___abcoll.Sized, ___abcoll.Iterable, ___abcoll.Container):
    """
    A set is a finite, iterable container.
    
        This class provides concrete generic implementations of all
        methods except for __contains__, __iter__ and __len__.
    
        To override the comparisons (presumably for speed, as the
        semantics are fixed), all you have to do is redefine __le__ and
        then the other operations will automatically follow suit.
    """
    def isdisjoint(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def _from_iterable(cls, *args, **kwargs): # real signature unknown
        """
        Construct an instance of the class from any iterable input.
        
                Must override this method if the class constructor signature
                does not accept an iterable for an input.
        """
        pass

    def _hash(self, *args, **kwargs): # real signature unknown
        """
        Compute the hash value of a set.
        
                Note that we don't define __hash__: not all sets are hashable.
                But if you define a hashable set type, its __hash__ should
                call this function.
        
                This must be compatible __eq__.
        
                All sets ought to compare equal if they contain the same
                elements, regardless of how they are implemented, and
                regardless of the order of the elements; so there's not much
                freedom for __eq__ or __hash__.  We match the algorithm used
                by the built-in frozenset type.
        """
        pass

    def __and__(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        pass

    def __ge__(self, *args, **kwargs): # real signature unknown
        pass

    def __gt__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __le__(self, *args, **kwargs): # real signature unknown
        pass

    def __lt__(self, *args, **kwargs): # real signature unknown
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        pass

    def __or__(self, *args, **kwargs): # real signature unknown
        pass

    def __sub__(self, *args, **kwargs): # real signature unknown
        pass

    def __xor__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 1
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __hash__ = None


class ItemsView(___abcoll.MappingView, ___abcoll.Set):
    # no doc
    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 3
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class Iterator(___abcoll.Iterable):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __next__(self, *args, **kwargs): # real signature unknown
        pass

    @classmethod
    def __subclasshook__(cls, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 1
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class KeysView(___abcoll.MappingView, ___abcoll.Set):
    # no doc
    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 3
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class Mapping(___abcoll.Sized, ___abcoll.Iterable, ___abcoll.Container):
    # no doc
    def get(self, *args, **kwargs): # real signature unknown
        pass

    def items(self, *args, **kwargs): # real signature unknown
        pass

    def iteritems(self, *args, **kwargs): # real signature unknown
        pass

    def iterkeys(self, *args, **kwargs): # real signature unknown
        pass

    def itervalues(self, *args, **kwargs): # real signature unknown
        pass

    def keys(self, *args, **kwargs): # real signature unknown
        pass

    def values(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __eq__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __ne__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 3
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __hash__ = None


class MutableMapping(___abcoll.Mapping):
    # no doc
    def clear(self, *args, **kwargs): # real signature unknown
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        pass

    def popitem(self, *args, **kwargs): # real signature unknown
        pass

    def setdefault(self, *args, **kwargs): # real signature unknown
        pass

    def update(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 8
    _abc_registry = None # (!) real value is ''
    _MutableMapping__marker = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class Sequence(___abcoll.Sized, ___abcoll.Iterable, ___abcoll.Container):
    """
    All the operations on a read-only sequence.
    
        Concrete subclasses must override __new__ or __init__,
        __getitem__, and __len__.
    """
    def count(self, *args, **kwargs): # real signature unknown
        pass

    def index(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    def __reversed__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 6
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class MutableSequence(___abcoll.Sequence):
    # no doc
    def append(self, *args, **kwargs): # real signature unknown
        pass

    def extend(self, *args, **kwargs): # real signature unknown
        pass

    def insert(self, *args, **kwargs): # real signature unknown
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        pass

    def remove(self, *args, **kwargs): # real signature unknown
        pass

    def reverse(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __iadd__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 7
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class MutableSet(___abcoll.Set):
    # no doc
    def add(self, *args, **kwargs): # real signature unknown
        """ Return True if it was added, False if already there. """
        pass

    def clear(self, *args, **kwargs): # real signature unknown
        """ This is slow (creates N new iterators!) but effective. """
        pass

    def discard(self, *args, **kwargs): # real signature unknown
        """ Return True if it was deleted, False if not there. """
        pass

    def pop(self, *args, **kwargs): # real signature unknown
        """ Return the popped value.  Raise KeyError if empty. """
        pass

    def remove(self, *args, **kwargs): # real signature unknown
        """ Remove an element. If not a member, raise a KeyError. """
        pass

    def __iand__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __ior__(self, *args, **kwargs): # real signature unknown
        pass

    def __isub__(self, *args, **kwargs): # real signature unknown
        pass

    def __ixor__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 2
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class ValuesView(___abcoll.MappingView):
    # no doc
    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 3
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


# variables with complex values

__all__ = [
    'deque',
    'defaultdict',
    'namedtuple',
    'Hashable',
    'Iterable',
    'Iterator',
    'Sized',
    'Container',
    'Callable',
    'Set',
    'MutableSet',
    'Mapping',
    'MutableMapping',
    'MappingView',
    'KeysView',
    'ItemsView',
    'ValuesView',
    'Sequence',
    'MutableSequence',
]

