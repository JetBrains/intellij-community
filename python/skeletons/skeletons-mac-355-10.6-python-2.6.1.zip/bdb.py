# encoding: utf-8
# module bdb
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/bdb.pyo by generator 1.99
""" Debugger basics """

# imports
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import types as types # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/types.pyc

# functions

def bar(a): # reliably restored by inspect
    # no doc
    pass


def checkfuncname(b, frame): # reliably restored by inspect
    """ Check whether we should break here because of `b.funcname`. """
    pass


def effective(file, line, frame): # reliably restored by inspect
    """
    Determine which breakpoint for this file:line is to be acted upon.
    
        Called only if we know there is a bpt at this
        location.  Returns breakpoint that was triggered and a flag
        that indicates if it is ok to delete a temporary bp.
    """
    pass


def foo(n): # reliably restored by inspect
    # no doc
    pass


def set_trace(): # reliably restored by inspect
    # no doc
    pass


def test(): # reliably restored by inspect
    # no doc
    pass


# classes

class BdbQuit(Exception):
    """ Exception to give up completely """
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

Bdb = None # (!) real value is ''

Breakpoint = None # (!) real value is ''

Tdb = None # (!) real value is ''

__all__ = [
    'BdbQuit',
    'Bdb',
    'Breakpoint',
]

