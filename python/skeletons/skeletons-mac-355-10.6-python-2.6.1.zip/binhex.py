# encoding: utf-8
# module binhex
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/binhex.pyo by generator 1.99
"""
Macintosh binhex compression/decompression.

easy interface:
binhex(inputfilename, outputfilename)
hexbin(inputfilename, outputfilename)
"""

# imports
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/struct.pyc
import binascii as binascii # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/binascii.so
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

LINELEN = 64

REASONABLY_LARGE = 32768

RUNCHAR = '\x90'

_DID_DATA = 1
_DID_HEADER = 0
_DID_RSRC = 2

# functions

def binhex(inp, out): # reliably restored by inspect
    """ (infilename, outfilename) - Create binhex-encoded copy of a file """
    pass


def getfileinfo(name): # reliably restored by inspect
    # no doc
    pass


def hexbin(inp, out): # reliably restored by inspect
    """ (infilename, outfilename) - Decode binhexed file """
    pass


def _test(): # reliably restored by inspect
    # no doc
    pass


# classes

class Error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


# variables with complex values

BinHex = None # (!) real value is ''

FInfo = None # (!) real value is ''

HexBin = None # (!) real value is ''

openrsrc = None # (!) real value is ''

_Hqxcoderengine = None # (!) real value is ''

_Hqxdecoderengine = None # (!) real value is ''

_Rlecoderengine = None # (!) real value is ''

_Rledecoderengine = None # (!) real value is ''

__all__ = [
    'binhex',
    'hexbin',
    'Error',
]

