# encoding: utf-8
# module SystemConfiguration._manual
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/SystemConfiguration/_manual.so by generator 1.99
# no doc
# no imports

# functions

def SCDynamicStoreCreate(*args, **kwargs): # real signature unknown
    pass


def SCDynamicStoreCreateWithOptions(*args, **kwargs): # real signature unknown
    pass


def SCNetworkConnectionCreateWithServiceID(*args, **kwargs): # real signature unknown
    pass


def SCNetworkReachabilitySetCallback(*args, **kwargs): # real signature unknown
    pass


def SCPreferencesSetCallback(*args, **kwargs): # real signature unknown
    pass


# no classes
