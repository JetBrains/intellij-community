# encoding: utf-8
# module UserString
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/UserString.pyo by generator 1.99
"""
A user-defined wrapper around string objects

Note: string objects have grown methods in Python 1.6
This module requires Python 1.6 or later.
"""

# imports
import sys as sys # <module 'sys' (built-in)>
import collections as collections # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/collections.pyc
import _abcoll as ___abcoll


# no functions
# classes

class UserString(___abcoll.Sequence):
    # no doc
    def capitalize(self, *args, **kwargs): # real signature unknown
        pass

    def center(self, *args, **kwargs): # real signature unknown
        pass

    def count(self, *args, **kwargs): # real signature unknown
        pass

    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def endswith(self, *args, **kwargs): # real signature unknown
        pass

    def expandtabs(self, *args, **kwargs): # real signature unknown
        pass

    def find(self, *args, **kwargs): # real signature unknown
        pass

    def index(self, *args, **kwargs): # real signature unknown
        pass

    def isalnum(self, *args, **kwargs): # real signature unknown
        pass

    def isalpha(self, *args, **kwargs): # real signature unknown
        pass

    def isdecimal(self, *args, **kwargs): # real signature unknown
        pass

    def isdigit(self, *args, **kwargs): # real signature unknown
        pass

    def islower(self, *args, **kwargs): # real signature unknown
        pass

    def isnumeric(self, *args, **kwargs): # real signature unknown
        pass

    def isspace(self, *args, **kwargs): # real signature unknown
        pass

    def istitle(self, *args, **kwargs): # real signature unknown
        pass

    def isupper(self, *args, **kwargs): # real signature unknown
        pass

    def join(self, *args, **kwargs): # real signature unknown
        pass

    def ljust(self, *args, **kwargs): # real signature unknown
        pass

    def lower(self, *args, **kwargs): # real signature unknown
        pass

    def lstrip(self, *args, **kwargs): # real signature unknown
        pass

    def partition(self, *args, **kwargs): # real signature unknown
        pass

    def replace(self, *args, **kwargs): # real signature unknown
        pass

    def rfind(self, *args, **kwargs): # real signature unknown
        pass

    def rindex(self, *args, **kwargs): # real signature unknown
        pass

    def rjust(self, *args, **kwargs): # real signature unknown
        pass

    def rpartition(self, *args, **kwargs): # real signature unknown
        pass

    def rsplit(self, *args, **kwargs): # real signature unknown
        pass

    def rstrip(self, *args, **kwargs): # real signature unknown
        pass

    def split(self, *args, **kwargs): # real signature unknown
        pass

    def splitlines(self, *args, **kwargs): # real signature unknown
        pass

    def startswith(self, *args, **kwargs): # real signature unknown
        pass

    def strip(self, *args, **kwargs): # real signature unknown
        pass

    def swapcase(self, *args, **kwargs): # real signature unknown
        pass

    def title(self, *args, **kwargs): # real signature unknown
        pass

    def translate(self, *args, **kwargs): # real signature unknown
        pass

    def upper(self, *args, **kwargs): # real signature unknown
        pass

    def zfill(self, *args, **kwargs): # real signature unknown
        pass

    def __add__(self, *args, **kwargs): # real signature unknown
        pass

    def __cmp__(self, *args, **kwargs): # real signature unknown
        pass

    def __complex__(self, *args, **kwargs): # real signature unknown
        pass

    def __contains__(self, *args, **kwargs): # real signature unknown
        pass

    def __float__(self, *args, **kwargs): # real signature unknown
        pass

    def __getitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __getslice__(self, *args, **kwargs): # real signature unknown
        pass

    def __hash__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __int__(self, *args, **kwargs): # real signature unknown
        pass

    def __len__(self, *args, **kwargs): # real signature unknown
        pass

    def __long__(self, *args, **kwargs): # real signature unknown
        pass

    def __mod__(self, *args, **kwargs): # real signature unknown
        pass

    def __mul__(self, *args, **kwargs): # real signature unknown
        pass

    def __radd__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    def __rmul__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''


class MutableString(UserString, ___abcoll.MutableSequence):
    """
    mutable string objects
    
        Python strings are immutable objects.  This has the advantage, that
        strings may be used as dictionary keys.  If this property isn't needed
        and you insist on changing string values in place instead, you may cheat
        and use MutableString.
    
        But the purpose of this class is an educational one: to prevent
        people from inventing their own mutable string class derived
        from UserString and than forget thereby to remove (override) the
        __hash__ method inherited from UserString.  This would lead to
        errors that would be very hard to track down.
    
        A faster and better solution is to rewrite your program using lists.
    """
    def immutable(self, *args, **kwargs): # real signature unknown
        pass

    def insert(self, *args, **kwargs): # real signature unknown
        pass

    def __delitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __delslice__(self, *args, **kwargs): # real signature unknown
        pass

    def __iadd__(self, *args, **kwargs): # real signature unknown
        pass

    def __imul__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __setitem__(self, *args, **kwargs): # real signature unknown
        pass

    def __setslice__(self, *args, **kwargs): # real signature unknown
        pass

    _abc_cache = None # (!) real value is ''
    _abc_negative_cache = None # (!) real value is ''
    _abc_negative_cache_version = 9
    _abc_registry = None # (!) real value is ''
    __abstractmethods__ = None # (!) real value is ''
    __hash__ = None


# variables with complex values

__all__ = [
    'UserString',
    'MutableString',
]

