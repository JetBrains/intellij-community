# encoding: utf-8
# module DocXMLRPCServer
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/DocXMLRPCServer.pyo by generator 1.99
"""
Self documenting XML-RPC Server.

This module can be used to create XML-RPC servers that
serve pydoc-style documentation in response to HTTP
GET requests. This documentation is dynamically generated
based on the functions and methods registered with the
server.

This module is built upon the pydoc and SimpleXMLRPCServer
modules.
"""

# imports
import sys as sys # <module 'sys' (built-in)>
import inspect as inspect # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/inspect.pyc
import pydoc as pydoc # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/pydoc.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc

# functions

def resolve_dotted_attribute(obj, attr, allow_dotted_names=True): # reliably restored by inspect
    """
    resolve_dotted_attribute(a, 'b.c.d') => a.b.c.d
    
        Resolves a dotted attribute name to an object.  Raises
        an AttributeError if any attribute in the chain starts with a '_'.
    
        If the optional allow_dotted_names argument is false, dots are not
        supported and this function operates similar to getattr(obj, attr).
    """
    pass


# no classes
# variables with complex values

CGIXMLRPCRequestHandler = None # (!) real value is ''

DocCGIXMLRPCRequestHandler = None # (!) real value is ''

DocXMLRPCRequestHandler = None # (!) real value is ''

DocXMLRPCServer = None # (!) real value is ''

ServerHTMLDoc = None # (!) real value is ''

SimpleXMLRPCRequestHandler = None # (!) real value is ''

SimpleXMLRPCServer = None # (!) real value is ''

XMLRPCDocGenerator = None # (!) real value is ''

