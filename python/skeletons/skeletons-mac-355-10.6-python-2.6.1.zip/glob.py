# encoding: utf-8
# module glob
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/glob.pyo by generator 1.99
""" Filename globbing utility. """

# imports
import sys as sys # <module 'sys' (built-in)>
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import fnmatch as fnmatch # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/fnmatch.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# functions

def glob(pathname): # reliably restored by inspect
    """
    Return a list of paths matching a pathname pattern.
    
        The pattern may contain simple shell-style wildcards a la fnmatch.
    """
    pass


def glob0(dirname, basename): # reliably restored by inspect
    # no doc
    pass


def glob1(dirname, pattern): # reliably restored by inspect
    # no doc
    pass


def has_magic(s): # reliably restored by inspect
    # no doc
    pass


def iglob(pathname): # reliably restored by inspect
    """
    Return a list of paths matching a pathname pattern.
    
        The pattern may contain simple shell-style wildcards a la fnmatch.
    """
    pass


# no classes
# variables with complex values

magic_check = None # (!) real value is ''

__all__ = [
    'glob',
    'iglob',
]

