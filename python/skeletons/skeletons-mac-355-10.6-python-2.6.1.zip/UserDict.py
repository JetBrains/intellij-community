# encoding: utf-8
# module UserDict
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/UserDict.pyo by generator 1.99
""" A more or less complete user-defined wrapper around dictionary objects. """

# imports
import _abcoll as _abcoll # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/_abcoll.pyc

# no functions
# no classes
# variables with complex values

DictMixin = None # (!) real value is ''

IterableUserDict = None # (!) real value is ''

UserDict = None # (!) real value is ''

