# encoding: utf-8
# module encodings.idna
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/encodings/idna.pyo by generator 1.99
# no doc

# imports
import stringprep as stringprep # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/stringprep.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
import codecs as __codecs


# Variables with simple values

ace_prefix = 'xn--'

uace_prefix = u'xn--'

# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


def nameprep(label): # reliably restored by inspect
    # no doc
    pass


def ToASCII(label): # reliably restored by inspect
    # no doc
    pass


def ToUnicode(label): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(__codecs.BufferedIncrementalDecoder):
    # no doc
    def _buffer_decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class IncrementalEncoder(__codecs.BufferedIncrementalEncoder):
    # no doc
    def _buffer_encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

Codec = None # (!) real value is ''

dots = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

unicodedata = stringprep.unicodedata

