# encoding: utf-8
# module encodings.utf_7
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/encodings/utf_7.pyo by generator 1.99
"""
Python 'utf-7' Codec

Written by Brian Quinlan (brian@sweetapp.com).
"""

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
from _codecs import encode

import codecs as __codecs


# functions

def decode(input, errors=None): # reliably restored by inspect
    # no doc
    pass


def getregentry(): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(__codecs.BufferedIncrementalDecoder):
    # no doc
    def _buffer_decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

