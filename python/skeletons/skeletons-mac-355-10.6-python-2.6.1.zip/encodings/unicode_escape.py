# encoding: utf-8
# module encodings.unicode_escape
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/encodings/unicode_escape.pyo by generator 1.99
"""
Python 'unicode-escape' Codec


Written by Marc-Andre Lemburg (mal@lemburg.com).

(c) Copyright CNRI, All Rights Reserved. NO WARRANTY.
"""

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
import codecs as __codecs


# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(__codecs.IncrementalDecoder):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates a IncrementalDecoder instance.
        
                The IncrementalDecoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

Codec = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

