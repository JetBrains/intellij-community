# encoding: utf-8
# module encodings.cp424
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/encodings/cp424.pyo by generator 1.99
""" Python Character Mapping Codec cp424 generated from 'MAPPINGS/VENDORS/MISC/CP424.TXT' with gencodec.py. """

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
import codecs as __codecs


# Variables with simple values

decoding_table = u'\x00\x01\x02\x03\x9c\t\x86\x7f\x97\x8d\x8e\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x9d\x85\x08\x87\x18\x19\x92\x8f\x1c\x1d\x1e\x1f\x80\x81\x82\x83\x84\n\x17\x1b\x88\x89\x8a\x8b\x8c\x05\x06\x07\x90\x91\x16\x93\x94\x95\x96\x04\x98\x99\x9a\x9b\x14\x15\x9e\x1a \u05d0\u05d1\u05d2\u05d3\u05d4\u05d5\u05d6\u05d7\u05d8\xa2.<(+|&\u05d9\u05da\u05db\u05dc\u05dd\u05de\u05df\u05e0\u05e1!$*);\xac-/\u05e2\u05e3\u05e4\u05e5\u05e6\u05e7\u05e8\u05e9\xa6,%_>?\ufffe\u05ea\ufffe\ufffe\xa0\ufffe\ufffe\ufffe\u2017`:#@\'="\ufffeabcdefghi\xab\xbb\ufffe\ufffe\ufffe\xb1\xb0jklmnopqr\ufffe\ufffe\ufffe\xb8\ufffe\xa4\xb5~stuvwxyz\ufffe\ufffe\ufffe\ufffe\ufffe\xae^\xa3\xa5\xb7\xa9\xa7\xb6\xbc\xbd\xbe[]\xaf\xa8\xb4\xd7{ABCDEFGHI\xad\ufffe\ufffe\ufffe\ufffe\ufffe}JKLMNOPQR\xb9\ufffe\ufffe\ufffe\ufffe\ufffe\\\xf7STUVWXYZ\xb2\ufffe\ufffe\ufffe\ufffe\ufffe0123456789\xb3\ufffe\ufffe\ufffe\ufffe\x9f'

# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(__codecs.IncrementalDecoder):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates a IncrementalDecoder instance.
        
                The IncrementalDecoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

Codec = None # (!) real value is ''

encoding_table = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

