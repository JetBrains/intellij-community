# encoding: utf-8
# module encodings.big5
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/encodings/big5.pyo by generator 1.99
# no doc

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
import _multibytecodec as mbc # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_multibytecodec.so
import _codecs_tw as _codecs_tw # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_codecs_tw.so
import codecs as __codecs


# functions

def getregentry(): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(MultibyteIncrementalDecoder, __codecs.IncrementalDecoder):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


class IncrementalEncoder(MultibyteIncrementalEncoder, __codecs.IncrementalEncoder):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


class StreamReader(Codec, MultibyteStreamReader, __codecs.StreamReader):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


class StreamWriter(Codec, MultibyteStreamWriter, __codecs.StreamWriter):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    codec = None # (!) forward: codec, real value is ''
    __dict__ = None # (!) real value is ''


# variables with complex values

Codec = None # (!) real value is ''

codec = None # (!) real value is ''

