# encoding: utf-8
# module encodings.punycode
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/encodings/punycode.pyo by generator 1.99
"""
Codec for the Punicode encoding, as specified in RFC 3492

Written by Martin v. L�.
"""

# imports
import codecs as codecs # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/codecs.pyc
import codecs as __codecs


# Variables with simple values

digits = 'abcdefghijklmnopqrstuvwxyz0123456789'

# functions

def adapt(delta, first, numchars): # reliably restored by inspect
    # no doc
    pass


def decode_generalized_number(extended, extpos, bias, errors): # reliably restored by inspect
    """ 3.3 Generalized variable-length integers """
    pass


def generate_generalized_integer(N, bias): # reliably restored by inspect
    """ 3.3 Generalized variable-length integers """
    pass


def generate_integers(baselen, deltas): # reliably restored by inspect
    """ 3.4 Bias adaptation """
    pass


def getregentry(): # reliably restored by inspect
    # no doc
    pass


def insertion_sort(base, extended, errors): # reliably restored by inspect
    """ 3.2 Insertion unsort coding """
    pass


def insertion_unsort(str, extended): # reliably restored by inspect
    """ 3.2 Insertion unsort coding """
    pass


def punycode_decode(text, errors): # reliably restored by inspect
    # no doc
    pass


def punycode_encode(text): # reliably restored by inspect
    # no doc
    pass


def segregate(str): # reliably restored by inspect
    """ 3.1 Basic code point segregation """
    pass


def selective_find(str, char, index, pos): # reliably restored by inspect
    """
    Return a pair (index, pos), indicating the next occurrence of
        char in str. index is the position of the character considering
        only ordinals up to and including char, and pos is the position in
        the full string. index/pos is the starting position in the full
        string.
    """
    pass


def selective_len(str, max): # reliably restored by inspect
    """ Return the length of str, considering only characters below max. """
    pass


def T(j, bias): # reliably restored by inspect
    # no doc
    pass


# classes

class IncrementalDecoder(__codecs.IncrementalDecoder):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates a IncrementalDecoder instance.
        
                The IncrementalDecoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


class IncrementalEncoder(__codecs.IncrementalEncoder):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Creates an IncrementalEncoder instance.
        
                The IncrementalEncoder may use different error handling schemes by
                providing the errors keyword argument. See the module docstring
                for a list of possible values.
        """
        pass


# variables with complex values

Codec = None # (!) real value is ''

StreamReader = None # (!) real value is ''

StreamWriter = None # (!) real value is ''

