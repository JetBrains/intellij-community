# encoding: utf-8
# module imaplib
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/imaplib.pyo by generator 1.99
"""
IMAP4 client.

Based on RFC 2060.

Public class:           IMAP4
Public variable:        Debug
Public functions:       Internaldate2tuple
                        Int2AP
                        ParseFlags
                        Time2Internaldate
"""

# imports
import random as random # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/random.pyc
import binascii as binascii # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/binascii.so
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import sys as sys # <module 'sys' (built-in)>
import ssl as ssl # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/ssl.pyc
import socket as socket # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/socket.pyc
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/time.so
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

CRLF = '\r\n'

Debug = 0

IMAP4_PORT = 143

IMAP4_SSL_PORT = 993

__version__ = '2.58'

# functions

def Int2AP(num): # reliably restored by inspect
    """ Convert integer to A-P string representation. """
    pass


def Internaldate2tuple(resp): # reliably restored by inspect
    """
    Convert IMAP4 INTERNALDATE to UT.
    
        Returns Python time module tuple.
    """
    pass


def ParseFlags(resp): # reliably restored by inspect
    """ Convert IMAP4 flags response to python tuple. """
    pass


def Time2Internaldate(date_time): # reliably restored by inspect
    """
    Convert 'date_time' to IMAP4 INTERNALDATE representation.
    
        Return string in form: '"DD-Mmm-YYYY HH:MM:SS +HHMM"'
    """
    pass


# no classes
# variables with complex values

AllowedVersions = (
    'IMAP4REV1',
    'IMAP4',
)

Commands = {
    'APPEND': (
        'AUTH',
        'SELECTED',
    ),
    'AUTHENTICATE': (
        'NONAUTH',
    ),
    'CAPABILITY': (
        'NONAUTH',
        'AUTH',
        'SELECTED',
        'LOGOUT',
    ),
    'CHECK': (
        'SELECTED',
    ),
    'CLOSE': '<value is a self-reference, replaced by this string>',
    'COPY': '<value is a self-reference, replaced by this string>',
    'CREATE': '<value is a self-reference, replaced by this string>',
    'DELETE': '<value is a self-reference, replaced by this string>',
    'DELETEACL': '<value is a self-reference, replaced by this string>',
    'EXAMINE': '<value is a self-reference, replaced by this string>',
    'EXPUNGE': '<value is a self-reference, replaced by this string>',
    'FETCH': '<value is a self-reference, replaced by this string>',
    'GETACL': '<value is a self-reference, replaced by this string>',
    'GETANNOTATION': '<value is a self-reference, replaced by this string>',
    'GETQUOTA': '<value is a self-reference, replaced by this string>',
    'GETQUOTAROOT': '<value is a self-reference, replaced by this string>',
    'LIST': '<value is a self-reference, replaced by this string>',
    'LOGIN': '<value is a self-reference, replaced by this string>',
    'LOGOUT': '<value is a self-reference, replaced by this string>',
    'LSUB': '<value is a self-reference, replaced by this string>',
    'MYRIGHTS': '<value is a self-reference, replaced by this string>',
    'NAMESPACE': '<value is a self-reference, replaced by this string>',
    'NOOP': '<value is a self-reference, replaced by this string>',
    'PARTIAL': '<value is a self-reference, replaced by this string>',
    'PROXYAUTH': (
        'AUTH',
    ),
    'RENAME': '<value is a self-reference, replaced by this string>',
    'SEARCH': '<value is a self-reference, replaced by this string>',
    'SELECT': '<value is a self-reference, replaced by this string>',
    'SETACL': '<value is a self-reference, replaced by this string>',
    'SETANNOTATION': '<value is a self-reference, replaced by this string>',
    'SETQUOTA': '<value is a self-reference, replaced by this string>',
    'SORT': '<value is a self-reference, replaced by this string>',
    'STATUS': '<value is a self-reference, replaced by this string>',
    'STORE': '<value is a self-reference, replaced by this string>',
    'SUBSCRIBE': '<value is a self-reference, replaced by this string>',
    'THREAD': '<value is a self-reference, replaced by this string>',
    'UID': '<value is a self-reference, replaced by this string>',
    'UNSUBSCRIBE': '<value is a self-reference, replaced by this string>',
}

Continuation = None # (!) real value is ''

Flags = None # (!) real value is ''

IMAP4 = None # (!) real value is ''

IMAP4_SSL = None # (!) real value is ''

IMAP4_stream = None # (!) real value is ''

InternalDate = None # (!) real value is ''

Literal = None # (!) real value is ''

MapCRLF = None # (!) real value is ''

Mon2num = {
    'Apr': 4,
    'Aug': 8,
    'Dec': 12,
    'Feb': 2,
    'Jan': 1,
    'Jul': 7,
    'Jun': 6,
    'Mar': 3,
    'May': 5,
    'Nov': 11,
    'Oct': 10,
    'Sep': 9,
}

Response_code = None # (!) real value is ''

Untagged_response = None # (!) real value is ''

Untagged_status = None # (!) real value is ''

_Authenticator = None # (!) real value is ''

__all__ = [
    'IMAP4',
    'IMAP4_stream',
    'Internaldate2tuple',
    'Int2AP',
    'ParseFlags',
    'Time2Internaldate',
    'IMAP4_SSL',
]

