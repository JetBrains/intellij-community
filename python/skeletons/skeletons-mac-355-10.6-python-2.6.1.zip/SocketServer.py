# encoding: utf-8
# module SocketServer
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/SocketServer.pyo by generator 1.99
"""
Generic socket server classes.

This module tries to capture the various aspects of defining a server:

For socket-based servers:

- address family:
        - AF_INET{,6}: IP (Internet Protocol) sockets (default)
        - AF_UNIX: Unix domain sockets
        - others, e.g. AF_DECNET are conceivable (see <socket.h>
- socket type:
        - SOCK_STREAM (reliable stream, e.g. TCP)
        - SOCK_DGRAM (datagrams, e.g. UDP)

For request-based servers (including socket-based):

- client address verification before further looking at the request
        (This is actually a hook for any processing that needs to look
         at the request before anything else, e.g. logging)
- how to handle multiple requests:
        - synchronous (one request is handled at a time)
        - forking (each request is handled by a new process)
        - threading (each request is handled by a new thread)

The classes in this module favor the server type that is simplest to
write: a synchronous TCP/IP server.  This is bad class design, but
save some typing.  (There's also the issue that a deep class hierarchy
slows down method lookups.)

There are five classes in an inheritance diagram, four of which represent
synchronous servers of four types:

        +------------+
        | BaseServer |
        +------------+
              |
              v
        +-----------+        +------------------+
        | TCPServer |------->| UnixStreamServer |
        +-----------+        +------------------+
              |
              v
        +-----------+        +--------------------+
        | UDPServer |------->| UnixDatagramServer |
        +-----------+        +--------------------+

Note that UnixDatagramServer derives from UDPServer, not from
UnixStreamServer -- the only difference between an IP and a Unix
stream server is the address family, which is simply repeated in both
unix server classes.

Forking and threading versions of each type of server can be created
using the ForkingMixIn and ThreadingMixIn mix-in classes.  For
instance, a threading UDP server class is created as follows:

        class ThreadingUDPServer(ThreadingMixIn, UDPServer): pass

The Mix-in class must come first, since it overrides a method defined
in UDPServer! Setting the various member variables also changes
the behavior of the underlying server mechanism.

To implement a service, you must derive a class from
BaseRequestHandler and redefine its handle() method.  You can then run
various versions of the service by combining one of the server classes
with your request handler class.

The request handler class must be different for datagram or stream
services.  This can be hidden by using the request handler
subclasses StreamRequestHandler or DatagramRequestHandler.

Of course, you still have to use your head!

For instance, it makes no sense to use a forking server if the service
contains state in memory that can be modified by requests (since the
modifications in the child process would never reach the initial state
kept in the parent process and passed to each child).  In this case,
you can use a threading server, but you will probably have to use
locks to avoid two requests that come in nearly simultaneous to apply
conflicting changes to the server state.

On the other hand, if you are building e.g. an HTTP server, where all
data is stored externally (e.g. in the file system), a synchronous
class will essentially render the service "deaf" while one request is
being handled -- which may be for a very long time if a client is slow
to reqd all the data it has requested.  Here a threading or forking
server is appropriate.

In some cases, it may be appropriate to process part of a request
synchronously, but to finish processing in a forked child depending on
the request data.  This can be implemented by using a synchronous
server and doing an explicit fork in the request handler class
handle() method.

Another approach to handling multiple simultaneous requests in an
environment that supports neither threads nor fork (or where these are
too expensive or inappropriate for the service) is to maintain an
explicit table of partially finished requests and to use select() to
decide which request to work on next (or whether to handle a new
incoming request).  This is particularly important for stream services
where each client can potentially be connected for a long time (if
threads or subprocesses cannot be used).

Future work:
- Standard classes for Sun RPC (which uses either UDP or TCP)
- Standard mix-in classes to implement various authentication
  and encryption schemes
- Standard framework for select-based multiplexing

XXX Open problems:
- What to do with out-of-band data?

BaseServer:
- split generic "request" functionality out into BaseServer class.
  Copyright (C) 2000  Luke Kenneth Casson Leighton <lkcl@samba.org>

  example: read entries from a SQL database (requires overriding
  get_request() to return a table entry from the database).
  entry is processed by a RequestHandlerClass.
"""

# imports
import select as select # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/select.so
import sys as sys # <module 'sys' (built-in)>
import socket as socket # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/socket.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import threading as threading # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/threading.pyc

# Variables with simple values

__version__ = '0.4'

# no functions
# no classes
# variables with complex values

BaseRequestHandler = None # (!) real value is ''

BaseServer = None # (!) real value is ''

DatagramRequestHandler = None # (!) real value is ''

ForkingMixIn = None # (!) real value is ''

ForkingTCPServer = None # (!) real value is ''

ForkingUDPServer = None # (!) real value is ''

StreamRequestHandler = None # (!) real value is ''

TCPServer = None # (!) real value is ''

ThreadingMixIn = None # (!) real value is ''

ThreadingTCPServer = None # (!) real value is ''

ThreadingUDPServer = None # (!) real value is ''

ThreadingUnixDatagramServer = None # (!) real value is ''

ThreadingUnixStreamServer = None # (!) real value is ''

UDPServer = None # (!) real value is ''

UnixDatagramServer = None # (!) real value is ''

UnixStreamServer = None # (!) real value is ''

__all__ = [
    'TCPServer',
    'UDPServer',
    'ForkingUDPServer',
    'ForkingTCPServer',
    'ThreadingUDPServer',
    'ThreadingTCPServer',
    'BaseRequestHandler',
    'StreamRequestHandler',
    'DatagramRequestHandler',
    'ThreadingMixIn',
    'ForkingMixIn',
    'UnixStreamServer',
    'UnixDatagramServer',
    'ThreadingUnixStreamServer',
    'ThreadingUnixDatagramServer',
]

