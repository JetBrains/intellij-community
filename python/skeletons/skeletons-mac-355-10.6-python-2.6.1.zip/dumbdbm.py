# encoding: utf-8
# module dumbdbm
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/dumbdbm.pyo by generator 1.99
"""
A dumb and slow but simple dbm clone.

For database spam, spam.dir contains the index (a text file),
spam.bak *may* contain a backup of the index (also a text file),
while spam.dat contains the data (a binary file).

XXX TO DO:

- seems to contain a bug when updating...

- reclaim free space (currently, space once occupied by deleted or expanded
items is never reused)

- support concurrent access (currently, if two processes take turns making
updates, they can mess up the index)

- support efficient access to large databases (currently, the whole index
is read when the database is opened, and some updates rewrite the whole index)

- support opening for read-only (flag = 'm')
"""

# imports
import os as _os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import UserDict as UserDict # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/UserDict.pyc
import __builtin__ as __builtin__ # <module '__builtin__' (built-in)>
from exceptions import error


# Variables with simple values

_BLOCKSIZE = 512

# functions

def open(file, flag=None, mode=438): # reliably restored by inspect
    """
    Open the database file, filename, and return corresponding object.
    
        The flag argument, used to control how the database is opened in the
        other DBM implementations, is ignored in the dumbdbm module; the
        database is always opened for update, and will be created if it does
        not exist.
    
        The optional mode argument is the UNIX mode of the file, used only when
        the database has to be created.  It defaults to octal code 0666 (and
        will be modified by the prevailing umask).
    """
    pass


def _open(*args, **kwargs): # real signature unknown
    """
    open(name[, mode[, buffering]]) -> file object
    
    Open a file using the file() type, returns a file object.  This is the
    preferred way to open a file.
    """
    pass


# no classes
# variables with complex values

_Database = None # (!) real value is ''

