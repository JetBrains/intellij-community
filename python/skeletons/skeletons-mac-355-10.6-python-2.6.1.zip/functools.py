# encoding: utf-8
# module functools
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/functools.pyo by generator 1.99
""" functools.py - Tools for working with functions and callable objects """

# imports
from _functools import reduce


# functions

def update_wrapper(wrapper, wrapped, assigned="('__module__', '__name__', '__doc__')", updated="('__dict__',)"): # reliably restored by inspect
    """
    Update a wrapper function to look like the wrapped function
    
           wrapper is the function to be updated
           wrapped is the original function
           assigned is a tuple naming the attributes assigned directly
           from the wrapped function to the wrapper function (defaults to
           functools.WRAPPER_ASSIGNMENTS)
           updated is a tuple naming the attributes of the wrapper that
           are updated with the corresponding attribute from the wrapped
           function (defaults to functools.WRAPPER_UPDATES)
    """
    pass


def wraps(wrapped, assigned="('__module__', '__name__', '__doc__')", updated="('__dict__',)"): # reliably restored by inspect
    """
    Decorator factory to apply update_wrapper() to a wrapper function
    
           Returns a decorator that invokes update_wrapper() with the decorated
           function as the wrapper argument and the arguments to wraps() as the
           remaining arguments. Default arguments are as for update_wrapper().
           This is a convenience function to simplify applying partial() to
           update_wrapper().
    """
    pass


# classes

class partial(object):
    """
    partial(func, *args, **keywords) - new function with partial application
    	of the given arguments and keywords.
    """
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, func, *args, **keywords): # real signature unknown; restored from __doc__
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    args = property(lambda self: object()) # default
    func = property(lambda self: object()) # default
    keywords = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

WRAPPER_ASSIGNMENTS = (
    '__module__',
    '__name__',
    '__doc__',
)

WRAPPER_UPDATES = (
    '__dict__',
)

