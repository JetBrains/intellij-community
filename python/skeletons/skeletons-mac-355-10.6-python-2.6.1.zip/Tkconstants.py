# encoding: utf-8
# module Tkconstants
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-tk/Tkconstants.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

ACTIVE = 'active'

ALL = 'all'

ANCHOR = 'anchor'

ARC = 'arc'

BASELINE = 'baseline'

BEVEL = 'bevel'

BOTH = 'both'
BOTTOM = 'bottom'

BROWSE = 'browse'

BUTT = 'butt'

CASCADE = 'cascade'

CENTER = 'center'

CHAR = 'char'
CHECKBUTTON = 'checkbutton'
CHORD = 'chord'

COMMAND = 'command'

CURRENT = 'current'

DISABLED = 'disabled'

DOTBOX = 'dotbox'
E = 'e'

END = 'end'

EW = 'ew'

EXTENDED = 'extended'

FALSE = 0

FIRST = 'first'

FLAT = 'flat'

GROOVE = 'groove'

HIDDEN = 'hidden'

HORIZONTAL = 'horizontal'

INSERT = 'insert'
INSIDE = 'inside'

LAST = 'last'

LEFT = 'left'

MITER = 'miter'

MOVETO = 'moveto'

MULTIPLE = 'multiple'
N = 'n'

NE = 'ne'

NO = 0
NONE = 'none'
NORMAL = 'normal'

NS = 'ns'
NSEW = 'nsew'

NUMERIC = 'numeric'

NW = 'nw'

OFF = 0

ON = 1

OUTSIDE = 'outside'

PAGES = 'pages'

PIESLICE = 'pieslice'

PROJECTING = 'projecting'

RADIOBUTTON = 'radiobutton'
RAISED = 'raised'

RIDGE = 'ridge'
RIGHT = 'right'

ROUND = 'round'
S = 's'

SCROLL = 'scroll'

SE = 'se'
SEL = 'sel'

SEL_FIRST = 'sel.first'
SEL_LAST = 'sel.last'

SEPARATOR = 'separator'

SINGLE = 'single'

SOLID = 'solid'

SUNKEN = 'sunken'

SW = 'sw'

TOP = 'top'

TRUE = 1

UNDERLINE = 'underline'
UNITS = 'units'

VERTICAL = 'vertical'
W = 'w'

WORD = 'word'
X = 'x'
Y = 'y'

YES = 1

# no functions
# no classes
