# encoding: utf-8
# module gettext
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/gettext.pyo by generator 1.99
"""
Internationalization and localization support.

This module provides internationalization (I18N) and localization (L10N)
support for your Python programs by providing an interface to the GNU gettext
message catalog library.

I18N refers to the operation by which a program is made aware of multiple
languages.  L10N refers to the adaptation of your program, once
internationalized, to the local language and cultural habits.
"""

# imports
import locale as locale # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/locale.pyc
import struct as struct # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/struct.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import sys as sys # <module 'sys' (built-in)>
import copy as copy # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/copy.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# Variables with simple values

ENOENT = 2

_current_domain = 'messages'

_default_localedir = '/System/Library/Frameworks/Python.framework/Versions/2.6/share/locale'

# functions

def bindtextdomain(domain, localedir=None): # reliably restored by inspect
    # no doc
    pass


def bind_textdomain_codeset(domain, codeset=None): # reliably restored by inspect
    # no doc
    pass


def c2py(plural): # reliably restored by inspect
    """
    Gets a C expression as used in PO files for plural forms and returns a
        Python lambda function that implements an equivalent expression.
    """
    pass


def Catalog(domain, localedir=None, languages=None, class_=None, fallback=False, codeset=None): # reliably restored by inspect
    # no doc
    pass


def dgettext(domain, message): # reliably restored by inspect
    # no doc
    pass


def dngettext(domain, msgid1, msgid2, n): # reliably restored by inspect
    # no doc
    pass


def find(domain, localedir=None, languages=None, all=0): # reliably restored by inspect
    # no doc
    pass


def gettext(message): # reliably restored by inspect
    # no doc
    pass


def install(domain, localedir=None, unicode=False, codeset=None, names=None): # reliably restored by inspect
    # no doc
    pass


def ldgettext(domain, message): # reliably restored by inspect
    # no doc
    pass


def ldngettext(domain, msgid1, msgid2, n): # reliably restored by inspect
    # no doc
    pass


def lgettext(message): # reliably restored by inspect
    # no doc
    pass


def lngettext(msgid1, msgid2, n): # reliably restored by inspect
    # no doc
    pass


def ngettext(msgid1, msgid2, n): # reliably restored by inspect
    # no doc
    pass


def test(condition, true, false): # reliably restored by inspect
    """
    Implements the C expression:
    
          condition ? true : false
    
        Required to correctly interpret plural forms.
    """
    pass


def textdomain(domain=None): # reliably restored by inspect
    # no doc
    pass


def translation(domain, localedir=None, languages=None, class_=None, fallback=False, codeset=None): # reliably restored by inspect
    # no doc
    pass


def _expand_lang(locale): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

GNUTranslations = None # (!) real value is ''

NullTranslations = None # (!) real value is ''

_localecodesets = {}

_localedirs = {}

_translations = {}

__all__ = [
    'NullTranslations',
    'GNUTranslations',
    'Catalog',
    'find',
    'translation',
    'install',
    'textdomain',
    'bindtextdomain',
    'dgettext',
    'dngettext',
    'gettext',
    'ngettext',
]

