# encoding: utf-8
# module OpenSSL.SSL
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/OpenSSL/SSL.so by generator 1.99
"""
Main file of the SSL sub module.
See the file RATIONALE for a short explanation of why this module was written.
"""
# no imports

# Variables with simple values

FILETYPE_ASN1 = 2
FILETYPE_PEM = 1

OP_ALL = 4095

OP_CIPHER_SERVER_PREFERENCE = 4194304

OP_DONT_INSERT_EMPTY_FRAGMENTS = 2048

OP_EPHEMERAL_RSA = 2097152

OP_MICROSOFT_BIG_SSLV3_BUFFER = 32

OP_MICROSOFT_SESS_ID_BUG = 1

OP_MSIE_SSLV2_RSA_PADDING = 64

OP_NETSCAPE_CA_DN_BUG = 536870912

OP_NETSCAPE_CHALLENGE_BUG = 2

OP_NETSCAPE_DEMO_CIPHER_CHANGE_BUG = 1073741824

OP_NETSCAPE_REUSE_CIPHER_CHANGE_BUG = 8

OP_NO_SSLv2 = 16777216
OP_NO_SSLv3 = 33554432
OP_NO_TLSv1 = 67108864

OP_PKCS1_CHECK_1 = 134217728
OP_PKCS1_CHECK_2 = 268435456

OP_SINGLE_DH_USE = 1048576

OP_SSLEAY_080_CLIENT_DH_BUG = 128

OP_SSLREF2_REUSE_CERT_TYPE_BUG = 16

OP_TLS_BLOCK_PADDING_BUG = 512

OP_TLS_D5_BUG = 256

OP_TLS_ROLLBACK_BUG = 8388608

RECEIVED_SHUTDOWN = 2

SENT_SHUTDOWN = 1

SSLv23_METHOD = 3

SSLv2_METHOD = 1

SSLv3_METHOD = 2

TLSv1_METHOD = 4

VERIFY_CLIENT_ONCE = 4

VERIFY_FAIL_IF_NO_PEER_CERT = 2

VERIFY_NONE = 0
VERIFY_PEER = 1

# functions

def Connection(*args, **kwargs): # real signature unknown
    """
    The factory function inserted in the module dictionary to create Connection
    objects
    
    Arguments: spam - Always NULL
               args - The Python argument tuple, should be:
                 ctx  - An SSL Context to use for this connection
                 sock - The socket to use for transport layer
    Returns:   The Connection object
    """
    pass


def Context(*args, **kwargs): # real signature unknown
    """
    The factory function inserted in the module dictionary to create Context
    objects
    
    Arguments: spam - Always NULL
               args - The Python argument tuple, should be:
                 method - The SSL method to use
    Returns:   The Context object
    """
    pass


# classes

class ConnectionType(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class ContextType(object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class Error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default


class SysCallError(Error):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class WantReadError(Error):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class WantWriteError(Error):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class WantX509LookupError(Error):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


class ZeroReturnError(Error):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass


# variables with complex values

_C_API = None # (!) real value is ''

