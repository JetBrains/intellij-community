# encoding: utf-8
# module compileall
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/compileall.pyo by generator 1.99
"""
Module/script to "compile" all .py files to .pyc (or .pyo) file.

When called as a script with arguments, this compiles the directories
given as arguments recursively; the -l option prevents it from
recursing into directories.

Without arguments, if compiles all modules on sys.path, without
recursing into subdirectories.  (Even though it should do so for
packages -- for now, you'll have to deal with packages separately.)

See module py_compile for details of the actual byte-compilation.
"""

# imports
import py_compile as py_compile # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/py_compile.pyc
import sys as sys # <module 'sys' (built-in)>
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# functions

def compile_dir(dir, maxlevels=10, ddir=None, force=0, rx=None, quiet=0): # reliably restored by inspect
    """
    Byte-compile all modules in the given directory tree.
    
        Arguments (only dir is required):
    
        dir:       the directory to byte-compile
        maxlevels: maximum recursion level (default 10)
        ddir:      if given, purported directory name (this is the
                   directory name that will show up in error messages)
        force:     if 1, force compilation, even if timestamps are up-to-date
        quiet:     if 1, be quiet during compilation
    """
    pass


def compile_path(skip_curdir=1, maxlevels=0, force=0, quiet=0): # reliably restored by inspect
    """
    Byte-compile all module on sys.path.
    
        Arguments (all optional):
    
        skip_curdir: if true, skip current directory (default true)
        maxlevels:   max recursion level (default 0)
        force: as for compile_dir() (default 0)
        quiet: as for compile_dir() (default 0)
    """
    pass


def main(): # reliably restored by inspect
    """ Script main program. """
    pass


# no classes
# variables with complex values

__all__ = [
    'compile_dir',
    'compile_path',
]

