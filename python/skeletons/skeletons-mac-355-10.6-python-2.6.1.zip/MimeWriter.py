# encoding: utf-8
# module MimeWriter
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/MimeWriter.pyo by generator 1.99
"""
Generic MIME writer.

This module defines the class MimeWriter.  The MimeWriter class implements
a basic formatter for creating MIME multi-part files.  It doesn't seek around
the output file nor does it use large amounts of buffer space. You must write
the parts out in the order that they should occur in the final file.
MimeWriter does buffer the headers you add, allowing you to rearrange their
order.
"""

# imports
import mimetools as mimetools # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/mimetools.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/warnings.pyc

# no functions
# no classes
# variables with complex values

MimeWriter = None # (!) real value is ''

__all__ = [
    'MimeWriter',
]

