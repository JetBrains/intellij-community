# encoding: utf-8
# module Carbon.CF
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/CF.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _CF import (CFAllocatorGetPreferredSizeForSize, CFAllocatorGetTypeID, 
    CFArrayCreateMutable, CFArrayCreateMutableCopy, CFArrayGetTypeID, 
    CFArrayRef, CFArrayRefType, CFCopyTypeIDDescription, CFDataCreate, 
    CFDataCreateMutable, CFDataCreateMutableCopy, CFDataCreateWithBytesNoCopy, 
    CFDataGetTypeID, CFDataRef, CFDataRefType, CFDictionaryCreateMutable, 
    CFDictionaryCreateMutableCopy, CFDictionaryGetTypeID, CFDictionaryRef, 
    CFDictionaryRefType, CFMutableArrayRef, CFMutableArrayRefType, 
    CFMutableDataRef, CFMutableDataRefType, CFMutableDictionaryRef, 
    CFMutableDictionaryRefType, CFMutableStringRef, CFMutableStringRefType, 
    CFPreferencesAddSuitePreferencesToApp, CFPreferencesAppSynchronize, 
    CFPreferencesCopyAppValue, CFPreferencesCopyApplicationList, 
    CFPreferencesCopyKeyList, CFPreferencesCopyMultiple, 
    CFPreferencesCopyValue, CFPreferencesGetAppBooleanValue, 
    CFPreferencesGetAppIntegerValue, 
    CFPreferencesRemoveSuitePreferencesFromApp, CFPreferencesSetAppValue, 
    CFPreferencesSetMultiple, CFPreferencesSetValue, CFPreferencesSynchronize, 
    CFStringConvertEncodingToIANACharSetName, 
    CFStringConvertEncodingToNSStringEncoding, 
    CFStringConvertEncodingToWindowsCodepage, 
    CFStringConvertNSStringEncodingToEncoding, 
    CFStringConvertWindowsCodepageToEncoding, CFStringCreateMutable, 
    CFStringCreateMutableCopy, CFStringCreateWithBytes, 
    CFStringCreateWithCString, CFStringCreateWithCStringNoCopy, 
    CFStringCreateWithCharacters, CFStringCreateWithCharactersNoCopy, 
    CFStringCreateWithPascalString, CFStringCreateWithPascalStringNoCopy, 
    CFStringGetMaximumSizeForEncoding, 
    CFStringGetMostCompatibleMacStringEncoding, CFStringGetNameOfEncoding, 
    CFStringGetSystemEncoding, CFStringGetTypeID, CFStringIsEncodingAvailable, 
    CFStringRef, CFStringRefType, CFTypeRef, CFTypeRefType, 
    CFURLCreateFromFSRef, CFURLCreateFromFileSystemRepresentation, 
    CFURLCreateFromFileSystemRepresentationRelativeToBase, 
    CFURLCreateWithBytes, CFURLGetTypeID, CFURLRef, CFURLRefType, toCF)


# no functions
# no classes
# variables with complex values

kCFPreferencesAnyApplication = None # (!) real value is ''

kCFPreferencesAnyHost = None # (!) real value is ''

kCFPreferencesAnyUser = None # (!) real value is ''

kCFPreferencesCurrentApplication = None # (!) real value is ''

kCFPreferencesCurrentHost = None # (!) real value is ''

kCFPreferencesCurrentUser = None # (!) real value is ''

