# encoding: utf-8
# module Carbon.Dlg
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Dlg.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
