# encoding: utf-8
# module Carbon.TextEdit
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/TextEdit.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

addSize = 16
addSizeBit = 4

clrBit = 3

doAll = 15
doColor = 8
doFace = 2
doFont = 1
doSize = 4
doToggle = 32

DRAWHook = 4

EOLHook = 0

faceBit = 1

fontBit = 0

HITTESTHook = 12

intDrawHook = 1
intEOLHook = 0
intHitTestHook = 3
intInlineInputTSMTEPostUpdateHook = 9
intInlineInputTSMTEPreUpdateHook = 8
intNWidthHook = 6
intTextWidthHook = 7
intWidthHook = 2

nWIDTHHook = 24

sizeBit = 2

teBitClear = 0
teBitSet = 1
teBitTest = -1
teCaret = -2
teCenter = 1
teDraw = -1
teFAutoScroll = 0
teFIdleWithEventLoopTimer = 7
teFind = 0
teFInlineInput = 3
teFInlineInputAutoScroll = 6
teFlushDefault = 0
teFlushLeft = -2
teFlushRight = -1
teForceLeft = -2
teFOutlineHilite = 2
teFromFind = 12
teFromRecal = 16
teFTextBuffering = 1
teFUseInlineInput = 5
teFUseTextServices = 4
teFUseWhiteBackground = 4
teHighlight = 1
teJustCenter = 1
teJustLeft = 0
teJustRight = -1
teWordDrag = 8
teWordSelect = 4

TextWidthHook = 28

toggleBit = 5

WIDTHHook = 8

# no functions
# no classes
