# encoding: utf-8
# module Carbon.CoreFoundation
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/CoreFoundation.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

kCFCompareAnchored = 8
kCFCompareBackwards = 4
kCFCompareCaseInsensitive = 1
kCFCompareEqualTo = 0
kCFCompareGreaterThan = 1
kCFCompareLessThan = -1
kCFCompareLocalized = 32
kCFCompareNonliteral = 16
kCFCompareNumerically = 64
kCFNotFound = -1
kCFPropertyListImmutable = 0
kCFPropertyListMutableContainers = 1
kCFPropertyListMutableContainersAndLeaves = 2
kCFStringEncodingASCII = 1536
kCFStringEncodingISOLatin1 = 513
kCFStringEncodingMacRoman = 0
kCFStringEncodingNextStepLatin = 2817
kCFStringEncodingNonLossyASCII = 3071
kCFStringEncodingUnicode = 256
kCFStringEncodingUTF8 = 134217984
kCFStringEncodingWindowsLatin1 = 1280
kCFURLHFSPathStyle = 1
kCFURLPOSIXPathStyle = 0
kCFURLWindowsPathStyle = 2

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
