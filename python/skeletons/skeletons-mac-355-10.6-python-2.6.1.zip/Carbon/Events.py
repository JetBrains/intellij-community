# encoding: utf-8
# module Carbon.Events
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Events.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

activateEvt = 8
activeFlag = 1
activeFlagBit = 0
activMask = 256

adbAddrMask = 16711680

alphaLock = 1024
alphaLockBit = 10

app1Evt = 12
app1Mask = 4096
app2Evt = 13
app2Mask = 8192
app3Evt = 14
app3Mask = 16384
app4Evt = 15
app4Mask = 32768

autoKey = 5
autoKeyMask = 32

btnState = 128
btnStateBit = 7

charCodeMask = 255

cmdKey = 256
cmdKeyBit = 8

controlKey = 4096
controlKeyBit = 12
convertClipboardFlag = 2

diskEvt = 7
diskMask = 128

driverEvt = 11
driverMask = 2048

everyEvent = 65535

highLevelEventMask = 1024

kAppleLogoCharCode = 20
kAppleLogoUnicode = 63743

kBackspaceCharCode = 8
kBellCharCode = 7
kBulletCharCode = 165
kBulletUnicode = 8226

kCheckCharCode = 18
kCheckUnicode = 10003
kClearCharCode = 27
kCommandCharCode = 17
kCommandUnicode = 8984
kControlUnicode = 8963

kDeleteCharCode = 127
kDiamondCharCode = 19
kDiamondUnicode = 9670
kDownArrowCharCode = 31

kEndCharCode = 4
kEnterCharCode = 3
kEscapeCharCode = 27

keyCodeMask = 65280
keyDown = 3
keyDownMask = 8
keyUp = 4
keyUpMask = 16

kFormFeedCharCode = 12
kFunctionKeyCharCode = 16

kHelpCharCode = 5
kHighLevelEvent = 23
kHomeCharCode = 1

kLeftArrowCharCode = 28
kLineFeedCharCode = 10

kNonBreakingSpaceCharCode = 202
kNullCharCode = 0

kOptionUnicode = 8997

kPageDownCharCode = 12
kPageUpCharCode = 11
kPencilUnicode = 9998

kReturnCharCode = 13
kRightArrowCharCode = 29

kShiftUnicode = 8679
kSpaceCharCode = 32

kTabCharCode = 9

kUpArrowCharCode = 30

kVerticalTabCharCode = 11

mDownMask = 2

mouseDown = 1
mouseMovedMessage = 250
mouseUp = 2

mUpMask = 4

networkEvt = 10
networkMask = 1024

nullEvent = 0

optionKey = 2048
optionKeyBit = 11

osEvt = 15
osMask = 32768

resumeFlag = 1

rightControlKey = 32768
rightControlKeyBit = 15
rightOptionKey = 16384
rightOptionKeyBit = 14
rightShiftKey = 8192
rightShiftKeyBit = 13

shiftKey = 512
shiftKeyBit = 9

suspendResumeMessage = 1

updateEvt = 6
updateMask = 64

# no functions
# no classes
