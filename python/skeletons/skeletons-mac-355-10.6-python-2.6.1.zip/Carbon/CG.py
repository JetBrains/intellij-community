# encoding: utf-8
# module Carbon.CG
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/CG.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _CG import CGContextRef, CGContextRefType


# no functions
# no classes
