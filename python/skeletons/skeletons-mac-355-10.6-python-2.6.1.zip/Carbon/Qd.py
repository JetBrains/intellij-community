# encoding: utf-8
# module Carbon.Qd
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Qd.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
