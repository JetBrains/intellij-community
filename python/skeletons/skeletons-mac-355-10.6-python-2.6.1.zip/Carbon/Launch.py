# encoding: utf-8
# module Carbon.Launch
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Launch.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _Launch import (LSCanRefAcceptItem, LSCanURLAcceptURL, 
    LSCopyDisplayNameForRef, LSCopyDisplayNameForURL, LSCopyItemInfoForRef, 
    LSCopyItemInfoForURL, LSCopyKindStringForRef, LSCopyKindStringForURL, 
    LSFindApplicationForInfo, LSGetApplicationForInfo, 
    LSGetApplicationForItem, LSGetApplicationForURL, LSGetExtensionInfo, 
    LSOpenCFURLRef, LSOpenFSRef, LSSetExtensionHiddenForRef, 
    LSSetExtensionHiddenForURL)


# no functions
# no classes
