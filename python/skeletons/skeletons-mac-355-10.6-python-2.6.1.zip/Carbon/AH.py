# encoding: utf-8
# module Carbon.AH
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/AH.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _AH import (AHGotoMainTOC, AHGotoPage, AHLookupAnchor, 
    AHRegisterHelpBook, AHSearch)


# no functions
# no classes
