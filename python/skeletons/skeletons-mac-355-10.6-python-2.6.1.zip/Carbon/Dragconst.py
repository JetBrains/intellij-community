# encoding: utf-8
# module Carbon.Dragconst
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Dragconst.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

addMax = 37
addOver = 34
addPin = 33
addSize = 16
addSizeBit = 4
adMax = 37
adMin = 39

allDevices = 4
allDevicesBit = 2
allInit = 12

baseAddr32 = 4

blackBit = 5
blackColor = 33
blend = 32
blueBit = 2
blueColor = 409

bold = 1

burstDevice = 7

chunky = 0
chunkyPlanar = 1

clrBit = 3
clutType = 0

colorXorXFer = 52
condense = 32
condenseBit = 5

crossCursor = 2

cursorDoesAnimate = 1L
cursorDoesHardware = 2L
cursorDoesUnreadableScreenBits = 4L
customXFer = 54

cyanBit = 8
cyanColor = 273

defQDColors = 127

directType = 2
ditherCopy = 64

doAll = 15
doColor = 8
doFace = 2
doFont = 1
dontMatchSeeds = 2
dontMatchSeedsBit = 1
doSize = 4
doToggle = 32

dragHasLeftSenderWindow = 1L
dragInsideSenderApplication = 2L
dragInsideSenderWindow = 4L
dragRegionBegin = 1
dragRegionDraw = 2
dragRegionEnd = 5
dragRegionHide = 3
dragRegionIdle = 4
dragTrackingEnterHandler = 1
dragTrackingEnterWindow = 2
dragTrackingInWindow = 3
dragTrackingLeaveHandler = 5
dragTrackingLeaveWindow = 4

DRAWHook = 4

EOLHook = 0

erase = 2

ext32Device = 8
extend = 64
extendBit = 6

faceBit = 1

fill = 4
fixedType = 1

fkDragActionAll = -1

flavorDataPromised = 512
flavorNotSaved = 4
flavorSenderOnly = 1
flavorSenderTranslated = 2
flavorSystemTranslated = 256
flavorTypeDirectory = 'diry'
flavorTypeHFS = 'hfs '
flavorTypePromiseHFS = 'phfs'

fontBit = 0

frame = 0

gdDevType = 0

grayishTextOr = 49
greenBit = 3
greenColor = 341

hasAuxMenuBar = 6

hilite = 50
hiliteBit = 7
hilitetransfermode = 50

HITTESTHook = 12

hwMirroredDevice = 4

iBeamCursor = 1

intDrawHook = 1
intEOLHook = 0
interlacedDevice = 2
intHitTestHook = 3
intInlineInputTSMTEPostUpdateHook = 9
intInlineInputTSMTEPreUpdateHook = 8
intNWidthHook = 6
intTextWidthHook = 7
intWidthHook = 2
invalColReq = -1
inverseBit = 1
invert = 3

italic = 2
italicBit = 1

k16BE555PixelFormat = 16
k16BE565PixelFormat = 'B565'
k16LE5551PixelFormat = '5551'
k16LE555PixelFormat = 'L555'
k16LE565PixelFormat = 'L565'
k1IndexedGrayPixelFormat = 33
k1MonochromePixelFormat = 1

k24BGRPixelFormat = '24BG'
k24RGBPixelFormat = 24
k2IndexedGrayPixelFormat = 34
k2IndexedPixelFormat = 2
k2vuyPixelFormat = '2vuy'

k32ABGRPixelFormat = 'ABGR'
k32ARGBPixelFormat = 32
k32BGRAPixelFormat = 'BGRA'
k32RGBAPixelFormat = 'RGBA'

k4IndexedGrayPixelFormat = 36
k4IndexedPixelFormat = 4

k8IndexedGrayPixelFormat = 40
k8IndexedPixelFormat = 8

kCursorComponentAnimate = 9
kCursorComponentDraw = 6
kCursorComponentErase = 7
kCursorComponentGetInfo = 2
kCursorComponentInit = 1
kCursorComponentLastReserved = 80
kCursorComponentMove = 8
kCursorComponentReconfigure = 5
kCursorComponentSetData = 4
kCursorComponentSetOutputMode = 3
kCursorComponentsVersion = 65537
kCursorComponentType = 'curs'
kCursorImageMajorVersion = 1
kCursorImageMinorVersion = 0

kDragActionAlias = 2L
kDragActionCopy = 1L
kDragActionDelete = 32L
kDragActionGeneric = 4L
kDragActionMove = 16L
kDragActionNothing = 0L
kDragActionPrivate = 8L
kDragBehaviorNone = 0
kDragBehaviorZoomBackAnimation = 1L
kDragDarkerImage = 2L
kDragDarkerTranslucency = 2L
kDragDarkImage = 1L
kDragDarkTranslucency = 1L
kDragFlavorTypeHFS = 'hfs '
kDragFlavorTypePromiseHFS = 'phfs'
kDragHasLeftSenderWindow = 1L
kDragInsideSenderApplication = 2L
kDragInsideSenderWindow = 4L
kDragOpaqueImage = 3L
kDragOpaqueTranslucency = 3L
kDragPromisedFlavor = 'fssP'
kDragPromisedFlavorFindFile = 'rWm1'
kDragPseudoCreatorVolumeOrDirectory = 'MACS'
kDragPseudoFileTypeDirectory = 'fold'
kDragPseudoFileTypeVolume = 'disk'
kDragRegionAndImage = 16L
kDragRegionBegin = 1
kDragRegionDraw = 2
kDragRegionEnd = 5
kDragRegionHide = 3
kDragRegionIdle = 4
kDragStandardImage = 0L
kDragStandardTranslucency = 0L
kDragTrackingEnterHandler = 1
kDragTrackingEnterWindow = 2
kDragTrackingInWindow = 3
kDragTrackingLeaveHandler = 5
kDragTrackingLeaveWindow = 4

kFlavorTypeClippingFilename = 'clfn'
kFlavorTypeClippingName = 'clnm'
kFlavorTypeDragToTrashOnly = 'fdtt'
kFlavorTypeFinderNoTrackingBehavior = 'fntb'

kHilite = 1
kHorizontalConstraint = 2

kNoConstraint = 0

kPrinterFontStatus = 0
kPrinterScalingStatus = 1

kQDGrafVerbErase = 2
kQDGrafVerbFill = 4
kQDGrafVerbFrame = 0
kQDGrafVerbInvert = 3
kQDGrafVerbPaint = 1
kQDParseRegionFromBottom = 2
kQDParseRegionFromBottomRight = 10
kQDParseRegionFromLeft = 4
kQDParseRegionFromRight = 8
kQDParseRegionFromTop = 1
kQDParseRegionFromTopLeft = 5
kQDRegionToRectsMsgInit = 1
kQDRegionToRectsMsgParse = 2
kQDRegionToRectsMsgTerminate = 3

kRenderCursorInHardware = 1L
kRenderCursorInSoftware = 2L

kUYVY422PixelFormat = 'UYVY'

kVerticalConstraint = 1

kXFer1PixelAtATime = 1
kXFerConvertPixelToRGB32 = 2

kYUV211PixelFormat = 'Y211'
kYUV411PixelFormat = 'Y411'
kYUVSPixelFormat = 'yuvs'
kYUVUPixelFormat = 'yuvu'
kYVU9PixelFormat = 'YVU9'
kYVYU422PixelFormat = 'YVYU'

kZoomAccelerate = 1
kZoomDecelerate = 2
kZoomNoAcceleration = 0

leftCaret = 0
leftStyleRun = 1

magentaBit = 7
magentaColor = 137
mainScreen = 11

middleStyleRun = 3

noDriver = 14
noiseXFer = 53
normal = 0
normalBit = 0
notPatBic = 15
notPatCopy = 12
notPatOr = 13
notPatXor = 14
notSrcBic = 7
notSrcCopy = 4
notSrcOr = 5
notSrcXor = 6
notTruncated = 0

nWIDTHHook = 24

onlyStyleRun = 0

outline = 8
outlineBit = 3

paint = 1
patBic = 11
patCopy = 8
patOr = 9
patXor = 10

pHiliteBit = 0

picLParen = 0
picRParen = 1

planar = 2
plusCursor = 3

ramInit = 10

redBit = 4
redColor = 205

RGBDirect = 16

rightCaret = -1
rightStyleRun = 2

roundedDevice = 5

screenActive = 15
screenDevice = 13

shadow = 16
shadowBit = 4

singleDevices = 1
singleDevicesBit = 0
sizeBit = 2

smBreakChar = 1
smBreakOverflow = 2
smBreakWord = 0
smHilite = 1
smLeftCaret = 0
smLeftStyleRun = 1
smMiddleStyleRun = 3
smNotTruncated = 0
smOnlyStyleRun = 0
smRightCaret = -1
smRightStyleRun = 2
smTruncated = 1
smTruncEnd = 0
smTruncErr = -1
smTruncMiddle = 16384

srcBic = 3
srcCopy = 0
srcOr = 1
srcXor = 2

subOver = 38
subPin = 35

sysPatListID = 0

teBitClear = 0
teBitSet = 1
teBitTest = -1
teCaret = -2
teCenter = 1
teDraw = -1
teFAutoScroll = 0
teFIdleWithEventLoopTimer = 7
teFind = 0
teFInlineInput = 3
teFInlineInputAutoScroll = 6
teFlushDefault = 0
teFlushLeft = -2
teFlushRight = -1
teForceLeft = -2
teFOutlineHilite = 2
teFromFind = 12
teFromRecal = 16
teFTextBuffering = 1
teFUseInlineInput = 5
teFUseTextServices = 4
teFUseWhiteBackground = 4
teHighlight = 1
teJustCenter = 1
teJustLeft = 0
teJustRight = -1
teWordDrag = 8
teWordSelect = 4

TextWidthHook = 28

tfAntiAlias = 1
tfUnicode = 2

toggleBit = 5

transparent = 36
truncated = 1
truncEnd = 0
truncErr = -1
truncMiddle = 16384

ulineBit = 2

underline = 4

watchCursor = 4

whiteColor = 30

WIDTHHook = 8

yellowBit = 6
yellowColor = 69

zoomAccelerate = 1
zoomDecelerate = 2
zoomNoAcceleration = 0

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
