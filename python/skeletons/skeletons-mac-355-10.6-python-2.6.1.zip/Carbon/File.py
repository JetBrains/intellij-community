# encoding: utf-8
# module Carbon.File
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/File.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _File import (FNNotifyAll, FNNotifyByPath, FSAllocateFork, FSCloseFork, 
    FSFlushFork, FSGetDataForkName, FSGetForkPosition, FSGetForkSize, 
    FSGetResourceForkName, FSNewAlias, FSPathMakeRef, FSResolveAliasFile, 
    FSResolveAliasFileWithMountFlags, FSSetForkPosition, FSSetForkSize, 
    FSUpdateAlias, pathname)


# no functions
# classes

class AliasType(object):
    # no doc
    def FSFollowFinderAlias(self, *args, **kwargs): # real signature unknown
        """ (Boolean logon) -> (FSRef fromFile, FSRef target, Boolean wasChanged) """
        pass

    def FSResolveAlias(self, *args, **kwargs): # real signature unknown
        """ (FSRef fromFile) -> (FSRef target, Boolean wasChanged) """
        pass

    def FSResolveAliasWithMountFlags(self, *args, **kwargs): # real signature unknown
        """ (FSRef fromFile, unsigned long mountFlags) -> (FSRef target, Boolean wasChanged) """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    data = property(lambda self: object()) # default


Alias = AliasType


class FSCatalogInfoType(object):
    # no doc
    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    accessDate = property(lambda self: object()) # default
    attributeModDate = property(lambda self: object()) # default
    backupDate = property(lambda self: object()) # default
    contentModDate = property(lambda self: object()) # default
    createDate = property(lambda self: object()) # default
    dataLogicalSize = property(lambda self: object()) # default
    dataPhysicalSize = property(lambda self: object()) # default
    nodeFlags = property(lambda self: object()) # default
    nodeID = property(lambda self: object()) # default
    parentDirID = property(lambda self: object()) # default
    permissions = property(lambda self: object()) # default
    rsrcLogicalSize = property(lambda self: object()) # default
    rsrcPhysicalSize = property(lambda self: object()) # default
    sharingFlags = property(lambda self: object()) # default
    userPrivileges = property(lambda self: object()) # default
    valence = property(lambda self: object()) # default
    volume = property(lambda self: object()) # default


FSCatalogInfo = FSCatalogInfoType


class FSRefType(object):
    # no doc
    def as_pathname(self, *args, **kwargs): # real signature unknown
        """ () -> string """
        pass

    def FNNotify(self, *args, **kwargs): # real signature unknown
        """ (FNMessage message, OptionBits flags) -> None """
        pass

    def FSCompareFSRefs(self, *args, **kwargs): # real signature unknown
        """ (FSRef ref2) -> None """
        pass

    def FSCreateDirectoryUnicode(self, *args, **kwargs): # real signature unknown
        """ (Buffer nameLength, FSCatalogInfoBitmap whichInfo, FSCatalogInfo catalogInfo) -> (FSRef newRef, FSSpec newSpec, UInt32 newDirID) """
        pass

    def FSCreateFileUnicode(self, *args, **kwargs): # real signature unknown
        """ (Buffer nameLength, FSCatalogInfoBitmap whichInfo, FSCatalogInfo catalogInfo) -> (FSRef newRef, FSSpec newSpec) """
        pass

    def FSCreateFork(self, *args, **kwargs): # real signature unknown
        """ (Buffer forkNameLength) -> None """
        pass

    def FSDeleteFork(self, *args, **kwargs): # real signature unknown
        """ (Buffer forkNameLength) -> None """
        pass

    def FSDeleteObject(self, *args, **kwargs): # real signature unknown
        """ () -> None """
        pass

    def FSExchangeObjects(self, *args, **kwargs): # real signature unknown
        """ (FSRef destRef) -> None """
        pass

    def FSGetCatalogInfo(self, *args, **kwargs): # real signature unknown
        """ (FSCatalogInfoBitmap whichInfo) -> (FSCatalogInfo catalogInfo, HFSUniStr255 outName, FSSpec fsSpec, FSRef parentRef) """
        pass

    def FSIsAliasFile(self, *args, **kwargs): # real signature unknown
        """ () -> (Boolean aliasFileFlag, Boolean folderFlag) """
        pass

    def FSMakeFSRefUnicode(self, *args, **kwargs): # real signature unknown
        """ (Buffer nameLength, TextEncoding textEncodingHint) -> (FSRef newRef) """
        pass

    def FSMoveObject(self, *args, **kwargs): # real signature unknown
        """ (FSRef destDirectory) -> (FSRef newRef) """
        pass

    def FSNewAliasMinimal(self, *args, **kwargs): # real signature unknown
        """ () -> (AliasHandle inAlias) """
        pass

    def FSOpenFork(self, *args, **kwargs): # real signature unknown
        """ (Buffer forkNameLength, SInt8 permissions) -> (SInt16 forkRefNum) """
        pass

    def FSRefMakePath(self, *args, **kwargs): # real signature unknown
        """ () -> string """
        pass

    def FSRenameUnicode(self, *args, **kwargs): # real signature unknown
        """ (Buffer nameLength, TextEncoding textEncodingHint) -> (FSRef newRef) """
        pass

    def FSSetCatalogInfo(self, *args, **kwargs): # real signature unknown
        """ (FSCatalogInfoBitmap whichInfo, FSCatalogInfo catalogInfo) -> None """
        pass

    def __delattr__(self, name): # real signature unknown; restored from __doc__
        """ x.__delattr__('name') <==> del x.name """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    def __setattr__(self, name, value): # real signature unknown; restored from __doc__
        """ x.__setattr__('name', value) <==> x.name = value """
        pass

    data = property(lambda self: object()) # default


FSRef = FSRefType


