# encoding: utf-8
# module Carbon.AE
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/AE.pyo by generator 1.99
# no doc

# imports
from MacOS import Error

from _AE import (AECallObjectAccessor, AECoercePtr, AECreateAppleEvent, 
    AECreateDesc, AECreateList, AEDesc, AEDescType, AEDisposeToken, 
    AEGetEventHandler, AEGetInteractionAllowed, AEInstallEventHandler, 
    AEInstallSpecialHandler, AEInteractWithUser, AEManagerInfo, AEObjectInit, 
    AEProcessAppleEvent, AERemoveEventHandler, AERemoveSpecialHandler, 
    AEReplaceDescData, AESetInteractionAllowed)


# no functions
# no classes
