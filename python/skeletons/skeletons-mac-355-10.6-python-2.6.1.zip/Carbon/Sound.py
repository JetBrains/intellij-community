# encoding: utf-8
# module Carbon.Sound
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Sound.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

aceBadCmd = 6
aceBadComp = 3
aceBadDest = 5
aceBadEncode = 4
aceMemFull = 1
aceNilBlock = 2
aceSuccess = 0

ampCmd = 43

audioAllChannels = 0
audioDoesIndependentChannels = 4L
audioDoesMono = 1L
audioDoesStereo = 2L
audioLeftChannel = 1
audioMuted = 1
audioRightChannel = 2
audioUnmuted = 0

availableCmd = 24

bufferCmd = 81

callBackCmd = 13

clockComponentCmd = 50

cmpSH = 254

continueCmd = 83
convertCmd = 91

dataOffsetFlag = 32768

dbBufferReady = 1
dbLastBuffer = 4

doubleBufferCmd = 84

eightToThree = 2

extSH = 255

firstSoundFormat = 1
fixedCompression = -1

flushCmd = 4

freeCmd = 2
freqCmd = 42
freqDurationCmd = 40

getAmpCmd = 45
getClockComponentCmd = 51
getRateCmd = 85
getRateMultiplierCmd = 87
getVolumeCmd = 47

initChan0 = 4
initChan1 = 5
initChan2 = 6
initChan3 = 7
initChanLeft = 2
initChanRight = 3
initCmd = 1
initCompMask = 65280
initMACE3 = 768
initMACE6 = 1024
initMono = 128
initNoDrop = 8
initNoInterp = 4
initPanMask = 3
initSRateMask = 48
initStereo = 192
initStereoMask = 192
insideCmpSH = 1

k16BitBigEndianFormat = 'twos'
k16BitIn = 4
k16BitLittleEndianFormat = 'sowt'
k16BitNativeEndianFormat = 'twos'
k16BitNonNativeEndianFormat = 'sowt'
k16BitOut = 1024

k24BitFormat = 'in24'

k32BitFormat = 'in32'
k32BitLittleEndianFormat = '23ni'

k8BitOffsetBinaryFormat = 'raw '
k8BitRawIn = 1
k8BitRawOut = 256
k8BitTwosIn = 2
k8BitTwosOut = 512

kActionMask = 16711680
kALawCompression = 'alaw'
kASCSubType = 'asc '
kAudioComponentType = 'adio'
kAudioEndianAtomType = 'enda'
kAudioFormatAtomType = 'frma'
kAudioGetBassSelect = 6
kAudioGetInfoSelect = 5
kAudioGetMuteSelect = 2
kAudioGetOutputDeviceSelect = 10
kAudioGetTrebleSelect = 8
kAudioGetVolumeSelect = 0
kAudioMuteOnEventSelect = 129
kAudioSetBassSelect = 7
kAudioSetMuteSelect = 3
kAudioSetToDefaultsSelect = 4
kAudioSetTrebleSelect = 9
kAudioSetVolumeSelect = 1
kAudioTerminatorAtomType = 0
kAudioVBRAtomType = 'vbra'
kAudioVisionHeadphoneSubType = 'telh'
kAudioVisionSpeakerSubType = 'telc'
kAVDisplayHeadphoneInsert = 1
kAVDisplayHeadphoneRemove = 0
kAVDisplayPlainTalkInsert = 3
kAVDisplayPlainTalkRemove = 2
kAwacsPhoneSubType = 'hphn'
kAwacsSubType = 'awac'

kBestQuality = 1
kBlueBoxSubType = 'bsnd'

kCDSource = 'cd  '
kCDXA2Compression = 'cdx2'
kCDXA4Compression = 'cdx4'
kClassicSubType = 'clas'
kConverterSubType = 'conv'
kCreateSoundSource = 262144L

kDAVInSource = 'idav'
kDelegatedSoundComponentSelectors = 256
kDirectSoundSnifferSubType = 'dssn'
kDirectSoundSubType = 'dsnd'
kDSPSubType = 'dsp '
kDVAudioFormat = 'dvca'
kDVDSource = 'dvda'
kDVIIntelIMAFormat = 1836253201

kEqualizerSubType = 'eqal'
kExtendedSoundBufferSizeValid = 2L
kExtendedSoundData = 16384
kExtendedSoundSampleCountNotValid = 1L
kExtMicSource = 'emic'

kFloat32Format = 'fl32'
kFloat64Format = 'fl64'
kFullMPEGLay3Format = '.mp3'
kFullVolume = 256

kGCAwacsSubType = 'awgc'

kHighQuality = 4194304L

kIMACompression = 'ima4'
kInputMask = 255
kIntMicSource = 'imic'

kLittleEndianFormat = 'sowt'

kMACE3Compression = 'MAC3'
kMACE6Compression = 'MAC6'
kMediaBaySource = 'mbay'
kMicrophoneArray = 'mica'
kMicrosoftADPCMFormat = 1836253186
kMiddleC = 60
kMixer16SubType = 'mixw'
kMixer8SubType = 'mixb'
kMixerType = 'mixr'
kModemSource = 'modm'
kMPEGLayer3Format = 1836253269

kNoChannelConversion = 16
kNoDecompression = 32
kNoMixing = 1
kNonInterleavedBuffer = 512
kNonPagingMixer = 1024
kNonRealTime = 8388608L
kNoRealtimeProcessing = 128
kNoSampleFormatConversion = 8
kNoSampleRateConversion = 2
kNoSampleSizeConversion = 4
kNoSoundComponentChain = 131072L
kNoSoundComponentType = '****'
kNoSource = 'none'
kNoVolume = 0
kNoVolumeConversion = 64

kOffsetBinary = 'raw '
kOutputMask = 65280
kOutputShift = 8

kPagingMixer = 4096
kPassThrough = 65536L
kPCCardSource = 'pcm '
kPhilipsFaderSubType = 'tvav'

kQDesign2Compression = 'QDM2'
kQDesignCompression = 'QDMC'
kQUALCOMMCompression = 'Qclp'

kRate16SubType = 'ratw'
kRate8SubType = 'ratb'
kRateConvert = 131072L
kRCAInSource = 'irca'
kReverse = 65536L

kScheduledSoundDoCallBack = 2
kScheduledSoundDoScheduled = 1
kScheduledSoundExtendedHdr = 4
kScheduledSource = 256
kSGSToneSubType = 'sgs0'
kSimpleBeepID = 1
kSinger2SubType = 'sng2'
kSingerSubType = 'sing'
kSndInputGetDeviceInfoSelect = 7
kSndInputGetStatusSelect = 6
kSndInputInitHardwareSelect = 9
kSndInputPauseRecordingSelect = 3
kSndInputReadAsyncSelect = 1
kSndInputReadSyncSelect = 2
kSndInputResumeRecordingSelect = 4
kSndInputSetDeviceInfoSelect = 8
kSndInputStopRecordingSelect = 5
kSndSourceSubType = 'sour'
kSoundBlasterSubType = 'sbls'
kSoundComponentAddSourceSelect = 257
kSoundComponentBits = 16777215
kSoundComponentGetInfoSelect = 259
kSoundComponentGetSourceDataSelect = 4
kSoundComponentGetSourceSelect = 3
kSoundComponentInitOutputDeviceSelect = 1
kSoundComponentPauseSourceSelect = 263
kSoundComponentPlaySourceBufferSelect = 264
kSoundComponentPPCType = 'nift'
kSoundComponentRemoveSourceSelect = 258
kSoundComponentSetInfoSelect = 260
kSoundComponentSetOutputSelect = 5
kSoundComponentSetSourceSelect = 2
kSoundComponentStartSourceSelect = 261
kSoundComponentStopSourceSelect = 262
kSoundComponentType = 'sift'
kSoundCompressor = 'scom'
kSoundConverterDidntFillBuffer = 1
kSoundConverterHasLeftOverData = 2
kSoundConverterMixer = 2048
kSoundDecompressor = 'sdec'
kSoundEffectsType = 'snfx'
kSoundInputDeviceType = 'sinp'
kSoundInSource = 'sinj'
kSoundNotCompressed = 'NONE'
kSoundOutputDeviceType = 'sdev'
kSourcePaused = 1
kSSpLocalizationSubType = 'snd3'
kStereoIn = 8
kStereoOut = 2048

kTVFMTunerSource = 'tvfm'
kTwosComplement = 'twos'

kULawCompression = 'ulaw'
kUNIXsdevSubType = 'un1x'
kUSBSubType = 'usb '
kUseOptionalOutputDevice = -1

kVMAwareMixer = 8192
kVMAwareness = 2097152L

kWaveInSnifferSubType = 'wisn'
kWaveInSubType = 'wavi'
kWaveOutSnifferSubType = 'wosn'
kWaveOutSubType = 'wavo'
kWhitSubType = 'whit'

kZoomVideoSource = 'zvpc'

leftOverBlockSize = 32

linkSoundComponentsCmd = 53

loadCmd = 27

MACE3snthID = 11
MACE6snthID = 13

notCompressed = 0

nullCmd = 0

outsideCmpSH = 0

pauseCmd = 11

phaseCmd = 61

quietCmd = 3

rate11025hz = 722534400
rate11khz = 729236945
rate16khz = 1048576000
rate22050hz = 1445068800
rate22khz = 1458473891
rate32khz = 2097152000
rate8khz = 524288000
rateCmd = 82
rateMultiplierCmd = 86

reInitCmd = 5
restCmd = 41
resumeCmd = 12

sampledSynth = 5

scheduledSoundCmd = 52

secondSoundFormat = 2

siActiveChannels = 'chac'
siActiveLevels = 'lmac'
siAGCOnOff = 'agc '
siAsync = 'asyn'
siAVDisplayBehavior = 'avdb'
siBestQuality = 'best'
siBetterQuality = 'betr'
siCDQuality = 'cd  '
siChannelAvailable = 'chav'
siCloseDriver = 'clos'
siCompressionAvailable = 'cmav'
siCompressionChannels = 'cpct'
siCompressionFactor = 'cmfa'
siCompressionHeader = 'cmhd'
siCompressionNames = 'cnam'
siCompressionParams = 'evaw'
siCompressionSampleRate = 'cprt'
siCompressionType = 'comp'
siContinuous = 'cont'
siDecompressionParams = 'wave'
siDeviceBufferInfo = 'dbin'
siDeviceConnected = 'dcon'
siDeviceIcon = 'icon'
siDeviceIsConnected = 1
siDeviceName = 'name'
siDeviceNotConnected = 0
siDontKnowIfConnected = -1
siEQSpectrumBands = 'eqsb'
siEQSpectrumLevels = 'eqlv'
siEQSpectrumOnOff = 'eqlo'
siEQSpectrumResolution = 'eqrs'
siEQToneControlGain = 'eqtg'
siEQToneControlOnOff = 'eqtc'
siGoodQuality = 'good'
siHardwareBalance = 'hbal'
siHardwareBalanceSteps = 'hbls'
siHardwareBass = 'hbas'
siHardwareBassSteps = 'hbst'
siHardwareBusy = 'hwbs'
siHardwareFormat = 'hwfm'
siHardwareMute = 'hmut'
siHardwareMuteNoPrefs = 'hmnp'
siHardwareTreble = 'htrb'
siHardwareTrebleSteps = 'hwts'
siHardwareVolume = 'hvol'
siHardwareVolumeSteps = 'hstp'
siHeadphoneMute = 'pmut'
siHeadphoneVolume = 'pvol'
siHeadphoneVolumeSteps = 'hdst'
siInitializeDriver = 'init'
siInputAvailable = 'inav'
siInputGain = 'gain'
siInputSource = 'sour'
siInputSourceNames = 'snam'
siLevelMeterOnOff = 'lmet'
siModemGain = 'mgai'
siMonitorAvailable = 'mnav'
siMonitorSource = 'mons'
siNoneQuality = 'none'
siNumberChannels = 'chan'
siOptionsDialog = 'optd'
siOSTypeInputAvailable = 'inav'
siOSTypeInputSource = 'inpt'
siOutputDeviceName = 'onam'
siOutputLatency = 'olte'
siPauseRecording = 'paus'
siPlayThruOnOff = 'plth'
siPostMixerSoundComponent = 'psmx'
siPreMixerSoundComponent = 'prmx'
siQuality = 'qual'
siRateConverterRollOffSlope = 'rcdb'
siRateMultiplier = 'rmul'
siReadPermission = 0
siRecordingQuality = 'qual'
siSampleRate = 'srat'
siSampleRateAvailable = 'srav'
siSampleSize = 'ssiz'
siSampleSizeAvailable = 'ssav'
siSetupCDAudio = 'sucd'
siSetupModemAudio = 'sumd'
siSlopeAndIntercept = 'flap'
siSoundClock = 'sclk'
siSpeakerMute = 'smut'
siSpeakerVolume = 'svol'
siSSpCPULoadLimit = '3dll'
siSSpLocalization = '3dif'
siSSpSpeakerSetup = '3dst'
siStereoInputGain = 'sgai'
siSubwooferMute = 'bmut'
siSupportedExtendedFlags = 'exfl'
siTerminalType = 'ttyp'
siTwosComplementOnOff = 'twos'
siUserInterruptProc = 'user'
siUseThisSoundClock = 'sclc'
siVendorProduct = 'vpro'
siVolume = 'volu'
siVoxRecordInfo = 'voxr'
siVoxStopInfo = 'voxs'
siWideStereo = 'wide'
siWritePermission = 1
sixToOne = 4
sixToOnePacketSize = 8
sizeCmd = 90

soundCmd = 80
soundListRsrc = 'snd '

squareWaveSynth = 1

stateBlockSize = 64
stdQLength = 128
stdSH = 0

syncCmd = 14
sysBeepDisable = 0
sysBeepEnable = 1
sysBeepSynchronous = 2

threeToOne = 3
threeToOnePacketSize = 16

timbreCmd = 44

totalLoadCmd = 26

twoToOne = 1

unitTypeNoSelection = 65535
unitTypeSeconds = 0

variableCompression = -2

versionCmd = 25

volumeCmd = 46

waitCmd = 10
waveInitChannel0 = 4
waveInitChannel1 = 5
waveInitChannel2 = 6
waveInitChannel3 = 7
waveInitChannelMask = 7
waveTableCmd = 60
waveTableSynth = 3

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
