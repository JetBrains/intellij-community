# encoding: utf-8
# module Carbon.AppleHelp
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/AppleHelp.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

kAHInternalErr = -10790
kAHInternetConfigPrefErr = -10791
kAHTOCTypeDeveloper = 1
kAHTOCTypeUser = 0

# no functions
# no classes
