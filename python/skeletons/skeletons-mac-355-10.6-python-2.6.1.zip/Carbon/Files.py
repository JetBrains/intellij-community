# encoding: utf-8
# module Carbon.Files
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Files.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

AppleShareMediaType = 'afpm'

asiAliasName = 0
asiParentName = 1
asiServerName = -2
asiVolumeName = -1
asiZoneName = -3

bAccessCntl = 18
bAllowCDiDataHandler = 17
bAncestorModDateChanges = 11

bDontShareIt = 21

bHasBlankAccessPrivileges = 4
bHasBTreeMgr = 5
bHasCatSearch = 7
bHasCopyFile = 14
bHasDesktopMgr = 12
bHasExtFSVol = 16
bHasFileIDs = 6
bHasFolderLock = 10
bHasMoveRename = 13
bHasOpenDeny = 15
bHasPersonalAccessPrivileges = 9
bHasShortName = 11
bHasUserGroupList = 8

bIsAutoMounted = 14
bIsEjectable = 0

bL2PCanMapFileBlocks = 9
bLimitFCBs = 31
bLocalWList = 30

bNoBootBlks = 19
bNoDeskItems = 20
bNoLclSync = 27
bNoMiniFndr = 29
bNoSwitchTo = 25
bNoSysDir = 17
bNoVNEdit = 28

bParentModDateChanges = 10

bSupports2TBFiles = 4
bSupportsAsyncRequests = 3
bSupportsFSCatalogSearch = 2
bSupportsFSExchangeObjects = 3
bSupportsHFSPlusAPIs = 1
bSupportsLongNames = 5
bSupportsMultiScriptNames = 6
bSupportsNamedForks = 7
bSupportsSubtreeIterators = 8
bSupportsSymbolicLinks = 13
bSupportsTrashVolumeCache = 2

bTrshOffLine = 26

false = False

fDesktop = -2
fDisk = 0

fHasBundle = 8192

fInvisible = 16384

fOnDesk = 1

forceReadBit = 6
forceReadMask = 64

fsAtMark = 0
fsCurPerm = 0
fsFromLEOF = 2
fsFromMark = 3
fsFromStart = 1
fsRdDenyPerm = 16
fsRdPerm = 1
fsRdWrPerm = 3
fsRdWrShPerm = 4
fsRtDirID = 2
fsRtParID = 1
fsSBAccessDate = 131072
fsSBAccessDateBit = 17
fsSBAttributeModDate = 65536
fsSBAttributeModDateBit = 16
fsSBDrBkDat = 2048
fsSBDrBkDatBit = 11
fsSBDrCrDat = 512
fsSBDrCrDatBit = 9
fsSBDrFndrInfo = 4096
fsSBDrFndrInfoBit = 12
fsSBDrMdDat = 1024
fsSBDrMdDatBit = 10
fsSBDrNmFls = 16
fsSBDrNmFlsBit = 4
fsSBDrParID = 8192
fsSBDrParIDBit = 13
fsSBDrUsrWds = 8
fsSBDrUsrWdsBit = 3
fsSBFlAttrib = 4
fsSBFlAttribBit = 2
fsSBFlBkDat = 2048
fsSBFlBkDatBit = 11
fsSBFlCrDat = 512
fsSBFlCrDatBit = 9
fsSBFlFndrInfo = 8
fsSBFlFndrInfoBit = 3
fsSBFlLgLen = 32
fsSBFlLgLenBit = 5
fsSBFlMdDat = 1024
fsSBFlMdDatBit = 10
fsSBFlParID = 8192
fsSBFlParIDBit = 13
fsSBFlPyLen = 64
fsSBFlPyLenBit = 6
fsSBFlRLgLen = 128
fsSBFlRLgLenBit = 7
fsSBFlRPyLen = 256
fsSBFlRPyLenBit = 8
fsSBFlXFndrInfo = 4096
fsSBFlXFndrInfoBit = 12
fsSBFullName = 2
fsSBFullNameBit = 1
fsSBNegate = 16384
fsSBNegateBit = 14
fsSBNodeID = 32768
fsSBNodeIDBit = 15
fsSBPartialName = 1
fsSBPartialNameBit = 0
fsSBPermissions = 262144
fsSBPermissionsBit = 18
fsUnixPriv = 1
fsWrDenyPerm = 32
fsWrPerm = 2

fTrash = -3

ioDirFlg = 4
ioDirMask = 16

kadministratorUser = 1

kAFPExtendedFlagsAlternateAddressMask = 1
kAFPTagLengthDDP = 6
kAFPTagLengthIP = 6
kAFPTagLengthIPPort = 8
kAFPTagTypeDDP = 3
kAFPTagTypeDNS = 4
kAFPTagTypeIP = 1
kAFPTagTypeIPPort = 2
kAppleMenuFolderAliasType = 'faam'
kApplicationAliasType = 'adrp'
kApplicationCPAliasType = 'acdp'
kApplicationDAAliasType = 'addp'
kAppPackageAliasType = 'fapa'
kARMMountVol = 1
kARMMultVols = 8
kARMNoUI = 2
kARMSearch = 256
kARMSearchMore = 512
kARMSearchRelFirst = 1024

kClippingCreator = 'drag'
kClippingPictureType = 'clpp'
kClippingSoundType = 'clps'
kClippingTextType = 'clpt'
kClippingUnknownType = 'clpu'
kColor = 14
kContainerAliasType = 'drop'
kContainerCDROMAliasType = 'cddr'
kContainerFloppyAliasType = 'flpy'
kContainerFolderAliasType = 'fdrp'
kContainerHardDiskAliasType = 'hdsk'
kContainerServerAliasType = 'srvr'
kContainerTrashAliasType = 'trsh'
kControlPanelFolderAliasType = 'fact'
kCustomBadgeResourceID = -16455
kCustomBadgeResourceType = 'badg'
kCustomBadgeResourceVersion = 0
kCustomIconResource = -16455

kDesktopPrinterAliasType = 'dtpa'
kDropFolderAliasType = 'fadr'

kEncryptPassword = 3
kExportedFolderAliasType = 'faet'
kExtendedFlagHasCustomBadge = 256
kExtendedFlagHasRoutingInfo = 4
kExtendedFlagsAreInvalid = 32768
kExtensionFolderAliasType = 'faex'

kFirstMagicBusyFiletype = 'bzy '
kFNDirectoryModifiedMessage = 1
kFNNoImplicitAllSubscription = 1
kFSAllocAllOrNothingMask = 1
kFSAllocContiguousMask = 2
kFSAllocDefaultFlags = 0
kFSAllocNoRoundUpMask = 4
kFSAllocReservedMask = 65528
kFSCatInfoAccessDate = 256
kFSCatInfoAllDates = 992
kFSCatInfoAttrMod = 128
kFSCatInfoBackupDate = 512
kFSCatInfoContentMod = 64
kFSCatInfoCreateDate = 32
kFSCatInfoDataSizes = 16384
kFSCatInfoFinderInfo = 2048
kFSCatInfoFinderXInfo = 4096
kFSCatInfoGettableInfo = 262143
kFSCatInfoNodeFlags = 2
kFSCatInfoNodeID = 16
kFSCatInfoNone = 0
kFSCatInfoParentDirID = 8
kFSCatInfoPermissions = 1024
kFSCatInfoRsrcSizes = 32768
kFSCatInfoSettableInfo = 8163
kFSCatInfoSharingFlags = 65536
kFSCatInfoTextEncoding = 1
kFSCatInfoUserAccess = 524288
kFSCatInfoUserPrivs = 131072
kFSCatInfoValence = 8192
kFSCatInfoVolume = 4
kFSInvalidVolumeRefNum = 0
kFSIterateDelete = 2
kFSIterateFlat = 0
kFSIterateSubtree = 1
kFSNodeCopyProtectBit = 6
kFSNodeCopyProtectMask = 64
kFSNodeDataOpenBit = 3
kFSNodeDataOpenMask = 8
kFSNodeForkOpenBit = 7
kFSNodeForkOpenMask = 128
kFSNodeInSharedBit = 2
kFSNodeInSharedMask = 4
kFSNodeIsDirectoryBit = 4
kFSNodeIsDirectoryMask = 16
kFSNodeIsMountedBit = 3
kFSNodeIsMountedMask = 8
kFSNodeIsSharePointBit = 5
kFSNodeIsSharePointMask = 32
kFSNodeLockedBit = 0
kFSNodeLockedMask = 1
kFSNodeResOpenBit = 2
kFSNodeResOpenMask = 4
kFSVolFlagDefaultVolumeBit = 5
kFSVolFlagDefaultVolumeMask = 32
kFSVolFlagFilesOpenBit = 6
kFSVolFlagFilesOpenMask = 64
kFSVolFlagHardwareLockedBit = 7
kFSVolFlagHardwareLockedMask = 128
kFSVolFlagSoftwareLockedBit = 15
kFSVolFlagSoftwareLockedMask = 32768
kFSVolInfoBackupDate = 4
kFSVolInfoBlocks = 128
kFSVolInfoCheckedDate = 8
kFSVolInfoCreateDate = 1
kFSVolInfoDataClump = 1024
kFSVolInfoDirCount = 32
kFSVolInfoDriveInfo = 32768
kFSVolInfoFileCount = 16
kFSVolInfoFinderInfo = 4096
kFSVolInfoFlags = 8192
kFSVolInfoFSInfo = 16384
kFSVolInfoGettableInfo = 65535
kFSVolInfoModDate = 2
kFSVolInfoNextAlloc = 256
kFSVolInfoNextID = 2048
kFSVolInfoNone = 0
kFSVolInfoRsrcClump = 512
kFSVolInfoSettableInfo = 12292
kFSVolInfoSizes = 64

kfullPrivileges = 458759

kGroupID2Name = 2
kGroupName2ID = 4

kHasBeenInited = 256
kHasBundle = 8192
kHasCustomIcon = 1024
kHasNoINITs = 128

kicnsIconFamily = 239

kInternetLocationAFP = 'ilaf'
kInternetLocationAppleTalk = 'ilat'
kInternetLocationCreator = 'drag'
kInternetLocationFile = 'ilfi'
kInternetLocationFTP = 'ilft'
kInternetLocationGeneric = 'ilge'
kInternetLocationHTTP = 'ilht'
kInternetLocationMail = 'ilma'
kInternetLocationNNTP = 'ilnw'
kInternetLocationNSL = 'ilns'

kioACAccessBlankAccessBit = 28
kioACAccessBlankAccessMask = 268435456
kioACAccessEveryoneReadBit = 17
kioACAccessEveryoneReadMask = 131072
kioACAccessEveryoneSearchBit = 16
kioACAccessEveryoneSearchMask = 65536
kioACAccessEveryoneWriteBit = 18
kioACAccessEveryoneWriteMask = 262144
kioACAccessGroupReadBit = 9
kioACAccessGroupReadMask = 512
kioACAccessGroupSearchBit = 8
kioACAccessGroupSearchMask = 256
kioACAccessGroupWriteBit = 10
kioACAccessGroupWriteMask = 1024
kioACAccessOwnerBit = 31
kioACAccessOwnerReadBit = 1
kioACAccessOwnerReadMask = 2
kioACAccessOwnerSearchBit = 0
kioACAccessOwnerSearchMask = 1
kioACAccessOwnerWriteBit = 2
kioACAccessOwnerWriteMask = 4
kioACAccessUserReadBit = 25
kioACAccessUserReadMask = 33554432
kioACAccessUserSearchBit = 24
kioACAccessUserSearchMask = 16777216
kioACAccessUserWriteBit = 26
kioACAccessUserWriteMask = 67108864
kioACUserNoMakeChangesBit = 2
kioACUserNoMakeChangesMask = 4
kioACUserNoSeeFilesBit = 1
kioACUserNoSeeFilesMask = 2
kioACUserNoSeeFolderBit = 0
kioACUserNoSeeFolderMask = 1
kioACUserNotOwnerBit = 7
kioACUserNotOwnerMask = 128
kioFCBFileLockedBit = 13
kioFCBFileLockedMask = 8192
kioFCBLargeFileBit = 11
kioFCBLargeFileMask = 2048
kioFCBModifiedBit = 15
kioFCBModifiedMask = 32768
kioFCBOwnClumpBit = 14
kioFCBOwnClumpMask = 16384
kioFCBResourceBit = 9
kioFCBResourceMask = 512
kioFCBSharedWriteBit = 12
kioFCBSharedWriteMask = 4096
kioFCBWriteBit = 8
kioFCBWriteLockedBit = 10
kioFCBWriteLockedMask = 1024
kioFCBWriteMask = 256
kioFlAttribCopyProtBit = 6
kioFlAttribCopyProtMask = 64
kioFlAttribDataOpenBit = 3
kioFlAttribDataOpenMask = 8
kioFlAttribDirBit = 4
kioFlAttribDirMask = 16
kioFlAttribFileOpenBit = 7
kioFlAttribFileOpenMask = 128
kioFlAttribInSharedBit = 2
kioFlAttribInSharedMask = 4
kioFlAttribLockedBit = 0
kioFlAttribLockedMask = 1
kioFlAttribMountedBit = 3
kioFlAttribMountedMask = 8
kioFlAttribResOpenBit = 2
kioFlAttribResOpenMask = 4
kioFlAttribSharePointBit = 5
kioFlAttribSharePointMask = 32
kioVAtrbDefaultVolumeBit = 5
kioVAtrbDefaultVolumeMask = 32
kioVAtrbFilesOpenBit = 6
kioVAtrbFilesOpenMask = 64
kioVAtrbHardwareLockedBit = 7
kioVAtrbHardwareLockedMask = 128
kioVAtrbSoftwareLockedBit = 15
kioVAtrbSoftwareLockedMask = 32768

kIsAlias = 32768
kIsInvisible = 16384
kIsOnDesk = 1
kIsShared = 64
kIsStationary = 2048
kIsStationery = 2048

kLarge4BitIcon = 2
kLarge4BitIconSize = 512
kLarge8BitIcon = 3
kLarge8BitIconSize = 1024
kLargeIcon = 1
kLargeIconSize = 256
kLastMagicBusyFiletype = 'bzy?'

kMagicBusyCreationDate = 1329266096
kMaximumBlocksIn4GB = 8388607
kMountedFolderAliasType = 'famn'

kNameLocked = 4096

knoGroup = 0
knoUser = 0

kNoUserAuthentication = 1

kOwnerID2Name = 1
kOwnerName2ID = 3

kownerPrivileges = 7

kPackageAliasType = 'fpka'
kPassword = 2
kPreferencesFolderAliasType = 'fapf'
kPrintMonitorDocsFolderAliasType = 'fapn'

kResolveAliasFileNoUI = 1
kReturnNextGroup = 2
kReturnNextUG = 3
kReturnNextUser = 1
kRoutingResourceID = 0
kRoutingResourceType = 'rout'

kSharedFolderAliasType = 'fash'
kSmall4BitIcon = 5
kSmall4BitIconSize = 128
kSmall8BitIcon = 6
kSmall8BitIconSize = 256
kSmallIcon = 4
kSmallIconSize = 64
kStartupFolderAliasType = 'fast'
kSystemFolderAliasType = 'fasy'

kTwoWayEncryptPassword = 6

kUseWidePositioning = 256

kVCBFlagsHardwareGoneBit = 5
kVCBFlagsHardwareGoneMask = 32
kVCBFlagsHFSPlusAPIsBit = 4
kVCBFlagsHFSPlusAPIsMask = 16
kVCBFlagsIdleFlushBit = 3
kVCBFlagsIdleFlushMask = 8
kVCBFlagsVolumeDirtyBit = 15
kVCBFlagsVolumeDirtyMask = 32768

kWidePosOffsetBit = 8

newLineBit = 7
newLineCharMask = 65280
newLineMask = 128

noCacheBit = 5
noCacheMask = 32

pleaseCacheBit = 4
pleaseCacheMask = 16

rAliasType = 'alis'

rdVerify = 64
rdVerifyBit = 6
rdVerifyMask = 64

true = True

volMountChangedBit = 14
volMountChangedMask = 16384
volMountExtendedFlagsBit = 7
volMountExtendedFlagsMask = 128
volMountFSReservedMask = 255
volMountInteractBit = 15
volMountInteractMask = 32768
volMountNoLoginMsgFlagBit = 0
volMountNoLoginMsgFlagMask = 1
volMountSysReservedMask = 65280

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
