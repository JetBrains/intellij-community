# encoding: utf-8
# module Carbon.Dialogs
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Carbon/Dialogs.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

appendDITLBottom = 2
appendDITLRight = 1

btnCtrl = 0

cancel = 2
cautionIcon = 2

chkCtrl = 1

ctrlItem = 4

editText = 16

iconItem = 32

itemDisable = 128

kAlertCautionAlert = 2
kAlertDefaultCancelText = -1
kAlertDefaultOKText = -1
kAlertDefaultOtherText = -1
kAlertFlagsAlertIsMovable = 4
kAlertFlagsUseControlHierarchy = 2
kAlertFlagsUseThemeBackground = 1
kAlertFlagsUseThemeControls = 8
kAlertNoteAlert = 1
kAlertPlainAlert = 3
kAlertStdAlertCancelButton = 2
kAlertStdAlertHelpButton = 4
kAlertStdAlertOKButton = 1
kAlertStdAlertOtherButton = 3
kAlertStopAlert = 0

kButtonDialogItem = 4

kCancelItemIndex = 2
kCautionIcon = 2
kCheckBoxDialogItem = 5
kControlDialogItem = 4

kDialogFlagsHandleMovableModal = 4
kDialogFlagsUseControlHierarchy = 2
kDialogFlagsUseThemeBackground = 1
kDialogFlagsUseThemeControls = 8
kDialogFontAddFontSizeMask = 256
kDialogFontAddToMetaFontMask = 1024
kDialogFontNoFontStyle = 0
kDialogFontUseAllMask = 255
kDialogFontUseBackColorMask = 16
kDialogFontUseFaceMask = 2
kDialogFontUseFontMask = 1
kDialogFontUseFontNameMask = 512
kDialogFontUseForeColorMask = 8
kDialogFontUseJustMask = 64
kDialogFontUseModeMask = 32
kDialogFontUseSizeMask = 4
kDialogFontUseThemeFontIDMask = 128

kEditTextDialogItem = 16

kHelpDialogItem = 1
kHICommandOther = 'othr'

kIconDialogItem = 32
kItemDisableBit = 128

kNoteIcon = 1

kOkItemIndex = 1

kPictureDialogItem = 64

kRadioButtonDialogItem = 6
kResourceControlDialogItem = 7

kStaticTextDialogItem = 8
kStdAlertDoNotAnimateOnCancel = 4
kStdAlertDoNotAnimateOnDefault = 2
kStdAlertDoNotAnimateOnOther = 8
kStdAlertDoNotDisposeSheet = 1
kStdCancelItemIndex = 2
kStdCFStringAlertVersionOne = 1
kStdOkItemIndex = 1
kStopIcon = 0

kUserDialogItem = 0

noteIcon = 1

ok = 1

overlayDITL = 0

picItem = 64

radCtrl = 2

resCtrl = 3

statText = 8
stopIcon = 0

userItem = 0

# functions

def FOUR_CHAR_CODE(x): # reliably restored by inspect
    # no doc
    pass


# no classes
