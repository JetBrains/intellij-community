# encoding: utf-8
# module _AH
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/_AH.so by generator 1.99
# no doc

# imports
from MacOS import Error


# functions

def AHGotoMainTOC(*args, **kwargs): # real signature unknown
    """ (AHTOCType toctype) -> None """
    pass


def AHGotoPage(*args, **kwargs): # real signature unknown
    """ (CFStringRef bookname, CFStringRef path, CFStringRef anchor) -> None """
    pass


def AHLookupAnchor(*args, **kwargs): # real signature unknown
    """ (CFStringRef bookname, CFStringRef anchor) -> None """
    pass


def AHRegisterHelpBook(*args, **kwargs): # real signature unknown
    """ (FSRef appBundleRef) -> None """
    pass


def AHSearch(*args, **kwargs): # real signature unknown
    """ (CFStringRef bookname, CFStringRef query) -> None """
    pass


# no classes
