# encoding: utf-8
# module genericpath
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/genericpath.pyo by generator 1.99
"""
Path operations common to more than one OS
Do not use directly.  The OS specific modules import the appropriate
functions from this module themselves.
"""

# imports
import stat as stat # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/stat.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc

# functions

def commonprefix(m): # reliably restored by inspect
    """ Given a list of pathnames, returns the longest common leading component """
    pass


def exists(path): # reliably restored by inspect
    """ Test whether a path exists.  Returns False for broken symbolic links """
    pass


def getatime(filename): # reliably restored by inspect
    """ Return the last access time of a file, reported by os.stat(). """
    pass


def getctime(filename): # reliably restored by inspect
    """ Return the metadata change time of a file, reported by os.stat(). """
    pass


def getmtime(filename): # reliably restored by inspect
    """ Return the last modification time of a file, reported by os.stat(). """
    pass


def getsize(filename): # reliably restored by inspect
    """ Return the size of a file, reported by os.stat(). """
    pass


def isdir(s): # reliably restored by inspect
    """ Return true if the pathname refers to an existing directory. """
    pass


def isfile(path): # reliably restored by inspect
    """ Test whether a path is a regular file """
    pass


def _splitext(p, sep, altsep, extsep): # reliably restored by inspect
    """
    Split the extension from a pathname.
    
        Extension is everything from the last dot to the end, ignoring
        leading dots.  Returns "(root, ext)"; ext may be empty.
    """
    pass


# no classes
# variables with complex values

__all__ = [
    'commonprefix',
    'exists',
    'getatime',
    'getctime',
    'getmtime',
    'getsize',
    'isdir',
    'isfile',
]

