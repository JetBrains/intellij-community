# encoding: utf-8
# module AppKit._carbon
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/AppKit/_carbon.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
