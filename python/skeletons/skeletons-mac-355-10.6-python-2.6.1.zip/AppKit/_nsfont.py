# encoding: utf-8
# module AppKit._nsfont
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/AppKit/_nsfont.so by generator 1.99
# no doc
# no imports

# functions

def NSConvertGlyphsToPackedGlyphs(*args, **kwargs): # real signature unknown
    pass


# no classes
