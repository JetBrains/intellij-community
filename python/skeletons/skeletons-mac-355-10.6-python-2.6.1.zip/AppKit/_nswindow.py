# encoding: utf-8
# module AppKit._nswindow
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/AppKit/_nswindow.so by generator 1.99
# no doc
# no imports

# no functions
# no classes
