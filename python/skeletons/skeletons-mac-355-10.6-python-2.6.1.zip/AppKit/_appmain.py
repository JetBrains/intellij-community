# encoding: utf-8
# module AppKit._appmain
# from /System/Library/Frameworks/Python.framework/Versions/2.6/Extras/lib/python/PyObjC/AppKit/_appmain.so by generator 1.99
# no doc
# no imports

# functions

def NSApplicationMain(int_argc, const_char, *args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """ int NSApplicationMain(int argc, const char *argv[]); """
    pass


# no classes
