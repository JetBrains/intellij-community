# encoding: utf-8
# module cgi
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/cgi.pyo by generator 1.99
"""
Support module for CGI (Common Gateway Interface) scripts.

This module defines a number of utilities for use by CGI scripts
written in Python.
"""

# imports
import mimetools as mimetools # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/mimetools.pyc
import urllib as urllib # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/urllib.pyc
import rfc822 as rfc822 # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/rfc822.pyc
import UserDict as UserDict # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/UserDict.pyc
import sys as sys # <module 'sys' (built-in)>
import urlparse as urlparse # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/urlparse.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
from cStringIO import StringIO

from operator import attrgetter

from _warnings import warn


# Variables with simple values

logfile = ''
logfp = None

maxlen = 0

__version__ = '2.6'

# functions

def dolog(fmt, *args): # reliably restored by inspect
    """ Write a log message to the log file.  See initlog() for docs. """
    pass


def escape(s, quote=None): # reliably restored by inspect
    """
    Replace special characters "&", "<" and ">" to HTML-safe sequences.
        If the optional flag quote is true, the quotation mark character (")
        is also translated.
    """
    pass


def filterwarnings(action, message=None, category="<type 'exceptions.Warning'>", module=None, lineno=0, append=0): # reliably restored by inspect
    """
    Insert an entry into the list of warnings filters (at the front).
    
        Use assertions to check that all arguments have the right type.
    """
    pass


def initlog(*allargs): # reliably restored by inspect
    """
    Write a log message, if there is a log file.
    
        Even though this function is called initlog(), you should always
        use log(); log is a variable that is set either to initlog
        (initially), to dolog (once the log file has been opened), or to
        nolog (when logging is disabled).
    
        The first argument is a format string; the remaining arguments (if
        any) are arguments to the % operator, so e.g.
            log("%s: %s", "a", "b")
        will write "a: b" to the log file, followed by a newline.
    
        If the global logfp is not None, it should be a file object to
        which log data is written.
    
        If the global logfp is None, the global logfile may be a string
        giving a filename to open, in append mode.  This file should be
        world writable!!!  If the file can't be opened, logging is
        silently disabled (since there is no safe place where we could
        send an error message).
    """
    pass


def log(*allargs): # reliably restored by inspect
    """
    Write a log message, if there is a log file.
    
        Even though this function is called initlog(), you should always
        use log(); log is a variable that is set either to initlog
        (initially), to dolog (once the log file has been opened), or to
        nolog (when logging is disabled).
    
        The first argument is a format string; the remaining arguments (if
        any) are arguments to the % operator, so e.g.
            log("%s: %s", "a", "b")
        will write "a: b" to the log file, followed by a newline.
    
        If the global logfp is not None, it should be a file object to
        which log data is written.
    
        If the global logfp is None, the global logfile may be a string
        giving a filename to open, in append mode.  This file should be
        world writable!!!  If the file can't be opened, logging is
        silently disabled (since there is no safe place where we could
        send an error message).
    """
    pass


def nolog(*allargs): # reliably restored by inspect
    """ Dummy function, assigned to log when logging is disabled. """
    pass


def parse(fp=None, environ="{'com.apple.java.jvmMode': 'client', 'SHELL': '/bin/bash', 'VERSIONER_PYTHON_PREFER_32_BIT': 'no', 'VERSIONER_PYTHON_VERSION': '2.6', 'JAVA_LIBRARY_PATH': '/Applications/PyCharm 2.0 EAP.app/Contents/Resources/Java:/System/Library/PrivateFrameworks/JavaApplicationLauncher.framework/Resources', 'SSH_AUTH_SOCK': '/tmp/launch-ewvQPe/Listeners', '__CF_USER_TEXT_ENCODING': '0x1F5:7:49', 'com.apple.java.jvmTask': 'BundledApp', 'Apple_PubSub_Socket_Render': '/tmp/launch-sqcauu/Render', 'LOGNAME': 'jetbrains', 'USER': 'jetbrains', 'HOME': '/Users/jetbrains', 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'DISPLAY': '/tmp/launch-xHikue/org.x:0', 'TMPDIR': '/var/folders/Iv/IvwK07FIEHCSdElPdRQ61++++TI/-Tmp-/', 'COMMAND_MODE': 'unix2003'}", keep_blank_values=0, strict_parsing=0): # reliably restored by inspect
    """
    Parse a query in the environment or from a file (default stdin)
    
            Arguments, all optional:
    
            fp              : file pointer; default: sys.stdin
    
            environ         : environment dictionary; default: os.environ
    
            keep_blank_values: flag indicating whether blank values in
                URL encoded forms should be treated as blank strings.
                A true value indicates that blanks should be retained as
                blank strings.  The default false value indicates that
                blank values are to be ignored and treated as if they were
                not included.
    
            strict_parsing: flag indicating what to do with parsing errors.
                If false (the default), errors are silently ignored.
                If true, errors raise a ValueError exception.
    """
    pass


def parse_header(line): # reliably restored by inspect
    """
    Parse a Content-type like header.
    
        Return the main content-type and a dictionary of options.
    """
    pass


def parse_multipart(fp, pdict): # reliably restored by inspect
    """
    Parse multipart input.
    
        Arguments:
        fp   : input file
        pdict: dictionary containing other parameters of content-type header
    
        Returns a dictionary just like parse_qs(): keys are the field names, each
        value is a list of values for that field.  This is easy to use but not
        much good if you are expecting megabytes to be uploaded -- in that case,
        use the FieldStorage class instead which is much more flexible.  Note
        that content-type is the raw, unparsed contents of the content-type
        header.
    
        XXX This does not parse nested multipart parts -- use FieldStorage for
        that.
    
        XXX This should really be subsumed by FieldStorage altogether -- no
        point in having two implementations of the same parsing algorithm.
        Also, FieldStorage protects itself better against certain DoS attacks
        by limiting the size of the data read in one chunk.  The API here
        does not support that kind of protection.  This also affects parse()
        since it can call parse_multipart().
    """
    pass


def parse_qs(qs, keep_blank_values=0, strict_parsing=0): # reliably restored by inspect
    """ Parse a query given as a string argument. """
    pass


def parse_qsl(qs, keep_blank_values=0, strict_parsing=0): # reliably restored by inspect
    """ Parse a query given as a string argument. """
    pass


def print_arguments(): # reliably restored by inspect
    # no doc
    pass


def print_directory(): # reliably restored by inspect
    """ Dump the current directory as HTML. """
    pass


def print_environ(environ="{'com.apple.java.jvmMode': 'client', 'SHELL': '/bin/bash', 'VERSIONER_PYTHON_PREFER_32_BIT': 'no', 'VERSIONER_PYTHON_VERSION': '2.6', 'JAVA_LIBRARY_PATH': '/Applications/PyCharm 2.0 EAP.app/Contents/Resources/Java:/System/Library/PrivateFrameworks/JavaApplicationLauncher.framework/Resources', 'SSH_AUTH_SOCK': '/tmp/launch-ewvQPe/Listeners', '__CF_USER_TEXT_ENCODING': '0x1F5:7:49', 'com.apple.java.jvmTask': 'BundledApp', 'Apple_PubSub_Socket_Render': '/tmp/launch-sqcauu/Render', 'LOGNAME': 'jetbrains', 'USER': 'jetbrains', 'HOME': '/Users/jetbrains', 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'DISPLAY': '/tmp/launch-xHikue/org.x:0', 'TMPDIR': '/var/folders/Iv/IvwK07FIEHCSdElPdRQ61++++TI/-Tmp-/', 'COMMAND_MODE': 'unix2003'}"): # reliably restored by inspect
    """ Dump the shell environment as HTML. """
    pass


def print_environ_usage(): # reliably restored by inspect
    """ Dump a list of environment variables used by CGI as HTML. """
    pass


def print_exception(type=None, value=None, tb=None, limit=None): # reliably restored by inspect
    # no doc
    pass


def print_form(form): # reliably restored by inspect
    """ Dump the contents of a form as HTML. """
    pass


def test(environ="{'com.apple.java.jvmMode': 'client', 'SHELL': '/bin/bash', 'VERSIONER_PYTHON_PREFER_32_BIT': 'no', 'VERSIONER_PYTHON_VERSION': '2.6', 'JAVA_LIBRARY_PATH': '/Applications/PyCharm 2.0 EAP.app/Contents/Resources/Java:/System/Library/PrivateFrameworks/JavaApplicationLauncher.framework/Resources', 'SSH_AUTH_SOCK': '/tmp/launch-ewvQPe/Listeners', '__CF_USER_TEXT_ENCODING': '0x1F5:7:49', 'com.apple.java.jvmTask': 'BundledApp', 'Apple_PubSub_Socket_Render': '/tmp/launch-sqcauu/Render', 'LOGNAME': 'jetbrains', 'USER': 'jetbrains', 'HOME': '/Users/jetbrains', 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'DISPLAY': '/tmp/launch-xHikue/org.x:0', 'TMPDIR': '/var/folders/Iv/IvwK07FIEHCSdElPdRQ61++++TI/-Tmp-/', 'COMMAND_MODE': 'unix2003'}"): # reliably restored by inspect
    """
    Robust test CGI script, usable as main program.
    
        Write minimal HTTP headers and dump all information provided to
        the script in HTML form.
    """
    pass


def valid_boundary(s, _vb_pattern=None): # reliably restored by inspect
    # no doc
    pass


# classes

class catch_warnings(object):
    """
    A context manager that copies and restores the warnings filter upon
        exiting the context.
    
        The 'record' argument specifies whether warnings should be captured by a
        custom implementation of warnings.showwarning() and be appended to a list
        returned by the context manager. Otherwise None is returned by the context
        manager. The objects appended to the list are arguments whose attributes
        mirror the arguments to showwarning().
    
        The 'module' argument is to specify an alternative module to the module
        named 'warnings' and imported under that name. This argument is only useful
        when testing the warnings module itself.
    """
    def __enter__(self, *args, **kwargs): # real signature unknown
        pass

    def __exit__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        """
        Specify whether to record warnings and if an alternative module
                should be used other than sys.modules['warnings'].
        
                For compatibility with Python 3.0, please consider all arguments to be
                keyword-only.
        """
        pass

    def __repr__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

FieldStorage = None # (!) real value is ''

FormContent = None # (!) real value is ''

FormContentDict = None # (!) real value is ''

InterpFormContentDict = None # (!) real value is ''

MiniFieldStorage = None # (!) real value is ''

SvFormContentDict = None # (!) real value is ''

__all__ = [
    'MiniFieldStorage',
    'FieldStorage',
    'FormContentDict',
    'SvFormContentDict',
    'InterpFormContentDict',
    'FormContent',
    'parse',
    'parse_qs',
    'parse_qsl',
    'parse_multipart',
    'parse_header',
    'print_exception',
    'print_environ',
    'print_form',
    'print_directory',
    'print_arguments',
    'print_environ_usage',
    'escape',
]

