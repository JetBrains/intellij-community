# encoding: utf-8
# module email.parser
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/parser.pyo by generator 1.99
""" A parser of RFC 2822 and MIME email messages. """

# imports
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/warnings.pyc
from cStringIO import StringIO


# no functions
# no classes
# variables with complex values

FeedParser = None # (!) real value is ''

HeaderParser = None # (!) real value is ''

Message = None # (!) real value is ''

Parser = None # (!) real value is ''

__all__ = [
    'Parser',
    'HeaderParser',
]

