# encoding: utf-8
# module email.mime.text
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/mime/text.pyo by generator 1.99
""" Class representing text/* type MIME documents. """
# no imports

# functions

def encode_7or8bit(msg): # reliably restored by inspect
    """ Set the Content-Transfer-Encoding header to 7bit or 8bit. """
    pass


# no classes
# variables with complex values

MIMENonMultipart = None # (!) real value is ''

MIMEText = None # (!) real value is ''

__all__ = [
    'MIMEText',
]

