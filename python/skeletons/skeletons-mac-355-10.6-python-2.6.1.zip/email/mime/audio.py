# encoding: utf-8
# module email.mime.audio
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/mime/audio.pyo by generator 1.99
""" Class representing audio/* type MIME documents. """

# imports
import email.encoders as encoders # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/encoders.pyc
import sndhdr as sndhdr # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/sndhdr.pyc
from cStringIO import StringIO


# functions

def _whatsnd(data): # reliably restored by inspect
    """
    Try to identify a sound file type.
    
        sndhdr.what() has a pretty cruddy interface, unfortunately.  This is why
        we re-do it here.  It would be easier to reverse engineer the Unix 'file'
        command and use the standard 'magic' file, as shipped with a modern Unix.
    """
    pass


# no classes
# variables with complex values

MIMEAudio = None # (!) real value is ''

MIMENonMultipart = None # (!) real value is ''

_sndhdr_MIMEmap = {
    'aifc': 'x-aiff',
    'aiff': 'x-aiff',
    'au': 'basic',
    'wav': 'x-wav',
}

__all__ = [
    'MIMEAudio',
]

