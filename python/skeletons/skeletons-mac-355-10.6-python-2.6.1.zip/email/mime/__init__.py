# encoding: utf-8
# module email.mime.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/mime/__init__.pyo by generator 1.99
# no doc
# no imports

# no functions
# no classes
