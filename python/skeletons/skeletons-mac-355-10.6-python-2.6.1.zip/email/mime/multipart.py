# encoding: utf-8
# module email.mime.multipart
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/mime/multipart.pyo by generator 1.99
""" Base class for MIME multipart/* type messages. """
# no imports

# no functions
# no classes
# variables with complex values

MIMEBase = None # (!) real value is ''

MIMEMultipart = None # (!) real value is ''

__all__ = [
    'MIMEMultipart',
]

