# encoding: utf-8
# module email.mime.message
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/mime/message.pyo by generator 1.99
""" Class representing message/* MIME documents. """

# imports
import email.message as message # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/message.pyc

# no functions
# no classes
# variables with complex values

MIMEMessage = None # (!) real value is ''

MIMENonMultipart = None # (!) real value is ''

__all__ = [
    'MIMEMessage',
]

