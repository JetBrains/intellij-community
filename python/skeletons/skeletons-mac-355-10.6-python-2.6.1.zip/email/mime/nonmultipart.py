# encoding: utf-8
# module email.mime.nonmultipart
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/mime/nonmultipart.pyo by generator 1.99
""" Base class for MIME type messages that are not multipart. """

# imports
import email.errors as errors # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/errors.pyc

# no functions
# no classes
# variables with complex values

MIMEBase = None # (!) real value is ''

MIMENonMultipart = None # (!) real value is ''

__all__ = [
    'MIMENonMultipart',
]

