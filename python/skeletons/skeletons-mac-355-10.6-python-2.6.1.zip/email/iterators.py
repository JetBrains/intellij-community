# encoding: utf-8
# module email.iterators
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/iterators.pyo by generator 1.99
""" Various types of useful iterators and generators. """

# imports
import sys as sys # <module 'sys' (built-in)>
from cStringIO import StringIO


# functions

def body_line_iterator(msg, decode=False): # reliably restored by inspect
    """
    Iterate over the parts, returning string payloads line-by-line.
    
        Optional decode (default False) is passed through to .get_payload().
    """
    pass


def typed_subpart_iterator(msg, maintype=None, subtype=None): # reliably restored by inspect
    """
    Iterate over the subparts with a given MIME type.
    
        Use `maintype' as the main MIME type to match against; this defaults to
        "text".  Optional `subtype' is the MIME subtype to match against; if
        omitted, only the main type is matched.
    """
    pass


def walk(self): # reliably restored by inspect
    """
    Walk over the message tree, yielding each subpart.
    
        The walk is performed in depth-first order.  This method is a
        generator.
    """
    pass


def _structure(msg, fp=None, level=0, include_default=False): # reliably restored by inspect
    """ A handy debugging aid """
    pass


# no classes
# variables with complex values

__all__ = [
    'body_line_iterator',
    'typed_subpart_iterator',
    'walk',
]

