# encoding: utf-8
# module email.__init__
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/__init__.pyo by generator 1.99
""" A package for parsing, handling, and generating email messages. """

# imports
import sys as sys # <module 'sys' (built-in)>
import email as email # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/__init__.pyc

# Variables with simple values

_name = 'Text'

__version__ = '4.0.1'

# functions

def message_from_file(fp, *args, **kws): # reliably restored by inspect
    """
    Read a file and parse its contents into a Message object model.
    
        Optional _class and strict are passed to the Parser constructor.
    """
    pass


def message_from_string(s, *args, **kws): # reliably restored by inspect
    """
    Parse a string into a Message object model.
    
        Optional _class and strict are passed to the Parser constructor.
    """
    pass


# classes

class LazyImporter(object):
    # no doc
    def __getattr__(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object()) # default

    __dict__ = None # (!) real value is ''


# variables with complex values

importer = email.MIMEText

_LOWERNAMES = [
    'Charset',
    'Encoders',
    'Errors',
    'FeedParser',
    'Generator',
    'Header',
    'Iterators',
    'Message',
    'Parser',
    'Utils',
    'base64MIME',
    'quopriMIME',
]

_MIMENAMES = [
    'Audio',
    'Base',
    'Image',
    'Message',
    'Multipart',
    'NonMultipart',
    'Text',
]

__all__ = [
    'base64MIME',
    'Charset',
    'Encoders',
    'Errors',
    'Generator',
    'Header',
    'Iterators',
    'Message',
    'MIMEAudio',
    'MIMEBase',
    'MIMEImage',
    'MIMEMessage',
    'MIMEMultipart',
    'MIMENonMultipart',
    'MIMEText',
    'Parser',
    'quopriMIME',
    'Utils',
    'message_from_string',
    'message_from_file',
    'base64mime',
    'charset',
    'encoders',
    'errors',
    'generator',
    'header',
    'iterators',
    'message',
    'mime',
    'parser',
    'quoprimime',
    'utils',
]

