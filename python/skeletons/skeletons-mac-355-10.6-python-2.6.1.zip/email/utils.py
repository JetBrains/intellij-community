# encoding: utf-8
# module email.utils
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/utils.pyo by generator 1.99
""" Miscellaneous utilities. """

# imports
import random as random # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/random.pyc
import base64 as base64 # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/base64.pyc
import urllib as urllib # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/urllib.pyc
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/warnings.pyc
import socket as socket # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/socket.pyc
import os as os # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/os.pyc
import time as time # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/time.so

# Variables with simple values

COMMASPACE = ', '

CRLF = '\r\n'

EMPTYSTRING = ''

TICK = "'"

UEMPTYSTRING = u''

# functions

def collapse_rfc2231_value(value, errors=None, fallback_charset=None): # reliably restored by inspect
    # no doc
    pass


def decode_params(params): # reliably restored by inspect
    """
    Decode parameters list according to RFC 2231.
    
        params is a sequence of 2-tuples containing (param name, string value).
    """
    pass


def decode_rfc2231(s): # reliably restored by inspect
    """ Decode string according to RFC 2231 """
    pass


def encode_rfc2231(s, charset=None, language=None): # reliably restored by inspect
    """
    Encode string according to RFC 2231.
    
        If neither charset nor language is given, then s is returned as-is.  If
        charset is given but not language, the string is encoded using the empty
        string for language.
    """
    pass


def fix_eols(s): # reliably restored by inspect
    """
    Replace all line-ending characters with 
    .
    """
    pass


def formataddr(pair): # reliably restored by inspect
    """
    The inverse of parseaddr(), this takes a 2-tuple of the form
        (realname, email_address) and returns the string value suitable
        for an RFC 2822 From, To or Cc header.
    
        If the first element of pair is false, then the second element is
        returned unmodified.
    """
    pass


def formatdate(timeval=None, localtime=False, usegmt=False): # reliably restored by inspect
    """
    Returns a date string as specified by RFC 2822, e.g.:
    
        Fri, 09 Nov 2001 01:08:47 -0000
    
        Optional timeval if given is a floating point time value as accepted by
        gmtime() and localtime(), otherwise the current time is used.
    
        Optional localtime is a flag that when True, interprets timeval, and
        returns a date relative to the local timezone instead of UTC, properly
        taking daylight savings time into account.
    
        Optional argument usegmt means that the timezone is written out as
        an ascii string, not numeric one (so "GMT" instead of "+0000"). This
        is needed for HTTP, and is only used when localtime==False.
    """
    pass


def getaddresses(fieldvalues): # reliably restored by inspect
    """ Return a list of (REALNAME, EMAIL) for each fieldvalue. """
    pass


def make_msgid(idstring=None): # reliably restored by inspect
    """
    Returns a string suitable for RFC 2822 compliant Message-ID, e.g:
    
        <20020201195627.33539.96671@nightshade.la.mastaler.com>
    
        Optional idstring if given is a string used to strengthen the
        uniqueness of the message id.
    """
    pass


def mktime_tz(data): # reliably restored by inspect
    """ Turn a 10-tuple as returned by parsedate_tz() into a UTC timestamp. """
    pass


def parseaddr(addr): # reliably restored by inspect
    # no doc
    pass


def parsedate(data): # reliably restored by inspect
    # no doc
    pass


def parsedate_tz(data): # reliably restored by inspect
    # no doc
    pass


def quote(str): # reliably restored by inspect
    """ Add quotes around a string. """
    pass


def unquote(str): # reliably restored by inspect
    """ Remove quotes from a string. """
    pass


def _bdecode(s): # reliably restored by inspect
    # no doc
    pass


def _bencode(s): # reliably restored by inspect
    # no doc
    pass


def _identity(s): # reliably restored by inspect
    # no doc
    pass


def _parsedate(data): # reliably restored by inspect
    """ Convert a time string to a time tuple. """
    pass


def _parsedate_tz(data): # reliably restored by inspect
    """
    Convert a date string to a time tuple.
    
        Accounts for military timezones.
    """
    pass


def _qdecode(s, header=0): # reliably restored by inspect
    # no doc
    pass


def _qencode(s): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

ecre = None # (!) real value is ''

escapesre = None # (!) real value is ''

rfc2231_continuation = None # (!) real value is ''

specialsre = None # (!) real value is ''

_AddressList = None # (!) real value is ''

__all__ = [
    'collapse_rfc2231_value',
    'decode_params',
    'decode_rfc2231',
    'encode_rfc2231',
    'formataddr',
    'formatdate',
    'getaddresses',
    'make_msgid',
    'parseaddr',
    'parsedate',
    'parsedate_tz',
    'unquote',
]

