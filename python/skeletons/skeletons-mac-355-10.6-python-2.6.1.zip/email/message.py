# encoding: utf-8
# module email.message
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/message.pyo by generator 1.99
""" Basic message object for the email package object model. """

# imports
import email.errors as errors # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/errors.pyc
import warnings as warnings # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/warnings.pyc
import binascii as binascii # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/lib-dynload/binascii.so
import re as re # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/re.pyc
import email as email # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/__init__.pyc
import uu as uu # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/uu.pyc
import email.utils as utils # /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/email/utils.pyc
from cStringIO import StringIO


# Variables with simple values

SEMISPACE = '; '

# functions

def _formatparam(param, value=None, quote=True): # reliably restored by inspect
    """
    Convenience function to format and return a key=value pair.
    
        This will quote the value if needed or if quote is true.
    """
    pass


def _parseparam(s): # reliably restored by inspect
    # no doc
    pass


def _splitparam(param): # reliably restored by inspect
    # no doc
    pass


def _unquotevalue(value): # reliably restored by inspect
    # no doc
    pass


# no classes
# variables with complex values

Message = None # (!) real value is ''

tspecials = None # (!) real value is ''

__all__ = [
    'Message',
]

