# encoding: utf-8
# module Audio_mac
# from /System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/plat-mac/Audio_mac.pyo by generator 1.99
# no doc
# no imports

# Variables with simple values

error = 'Audio_mac.error'

QSIZE = 100000

# functions

def test(): # reliably restored by inspect
    # no doc
    pass


def warnpy3k(message, category=None, stacklevel=1): # reliably restored by inspect
    """
    Issue a deprecation warning for Python 3.x related changes.
    
        Warnings are omitted unless Python is started with the -3 option.
    """
    pass


# no classes
# variables with complex values

Play_Audio_mac = None # (!) real value is ''

