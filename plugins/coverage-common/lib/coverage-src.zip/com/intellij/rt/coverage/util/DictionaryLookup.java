/*
 * User: anna
 * Date: 26-Feb-2010
 */
package com.intellij.rt.coverage.util;

public interface DictionaryLookup {
  int getDictionaryIndex(String className);
}