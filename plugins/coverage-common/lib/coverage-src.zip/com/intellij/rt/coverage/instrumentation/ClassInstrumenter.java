package com.intellij.rt.coverage.instrumentation;

import com.intellij.rt.coverage.data.LineData;
import com.intellij.rt.coverage.data.ProjectData;
import com.intellij.rt.coverage.util.LinesUtil;
import org.jetbrains.coverage.asm.ClassVisitor;
import org.jetbrains.coverage.asm.MethodVisitor;

public class ClassInstrumenter extends Instrumenter {
  public ClassInstrumenter(final ProjectData projectData, ClassVisitor classVisitor, String className) {
    super(projectData, classVisitor, className);
  }

  protected MethodVisitor createMethodLineEnumerator(MethodVisitor mv, String name, String desc, int access, String signature,
                                           String[] exceptions) {
    return new LineEnumerator(this, mv, access, name, desc, signature, exceptions);
  }

  protected void initLineData() {
    myClassData.setLines(LinesUtil.calcLineArray(myMaxLineNumber, myLines));
  }

  public LineData getLineData(int line) {
    return (LineData) myLines.get(line);
  }

}
