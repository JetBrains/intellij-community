package com.intellij.rt.coverage.data;

public interface CoverageData {
  void merge(CoverageData data);
}
