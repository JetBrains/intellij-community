package org.tmatesoft.svn.core.internal.io.svn.ssh;

import java.io.IOException;

public class SshHostDisposedException extends IOException {

    private static final long serialVersionUID = 1L;

}
