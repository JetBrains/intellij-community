package sample;

import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class Controller {
    public Label label;

    public void sayHello(ActionEvent event) {
       label.setText("Hello World!");
    }
}
