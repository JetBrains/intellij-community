#!/bin/sh

TARGET=mtnminds,eclemma@web.sourceforge.net:/home/frs/project/e/ec/eclemma/07_JaCoCo/trunk/

scp target/jacoco-*.zip $TARGET
