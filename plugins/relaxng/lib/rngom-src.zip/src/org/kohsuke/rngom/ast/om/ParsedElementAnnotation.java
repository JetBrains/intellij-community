package org.kohsuke.rngom.ast.om;

public interface ParsedElementAnnotation { }
