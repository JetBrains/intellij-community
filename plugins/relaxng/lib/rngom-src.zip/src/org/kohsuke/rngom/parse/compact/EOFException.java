package org.kohsuke.rngom.parse.compact;

public class EOFException extends Exception {
}
