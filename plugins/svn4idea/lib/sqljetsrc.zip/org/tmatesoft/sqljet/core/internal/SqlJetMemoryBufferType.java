package org.tmatesoft.sqljet.core.internal;

/**
 * Types of buffers implementation.
 */
public enum SqlJetMemoryBufferType {
    ARRAY, BUFFER, DIRECT
}