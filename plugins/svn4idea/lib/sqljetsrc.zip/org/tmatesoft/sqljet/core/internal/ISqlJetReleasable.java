package org.tmatesoft.sqljet.core.internal;

public interface ISqlJetReleasable {
    
    public void release();

}
