package org.tmatesoft.svn.core.internal.wc2;

public enum SvnWcGeneration {
    V16, V17, NOT_DETECTED;
}
