package org.tmatesoft.svn.core.wc2;

public enum SvnFileKind {
    FILE, DIRECTORY, SYMLINK, UNKNOWN;
}
