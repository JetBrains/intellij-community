package org.tmatesoft.svn.core.wc2;

public class SvnMarkReplaced extends SvnOperation<Void> {

    protected SvnMarkReplaced(SvnOperationFactory factory) {
        super(factory);
    }
}
