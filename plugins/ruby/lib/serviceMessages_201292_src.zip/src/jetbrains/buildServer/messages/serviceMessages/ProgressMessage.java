package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class ProgressMessage extends ServiceMessage {
  public String getMessage() {
    return getArgument();
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitProgressMessage(this);
  }
}
