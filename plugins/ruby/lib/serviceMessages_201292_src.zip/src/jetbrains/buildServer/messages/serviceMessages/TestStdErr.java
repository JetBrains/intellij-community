package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestStdErr extends BaseTestMessage {
  public String getStdErr() {
    return getAttributeValue("out");
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestStdErr(this);
  }
}
