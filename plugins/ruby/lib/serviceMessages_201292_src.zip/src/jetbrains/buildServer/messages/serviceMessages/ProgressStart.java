package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class ProgressStart extends ProgressMessage {

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitProgressStart(this);
  }
}
