package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class ProgressFinish extends ProgressMessage {

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitProgressFinish(this);
  }
}
