package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestIgnored extends BaseTestMessage {
  public String getIgnoreComment() {
    return getAttributeValue("message");
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestIgnored(this);
  }
}
