package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestStarted extends BaseTestMessage {

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestStarted(this);
  }
}
