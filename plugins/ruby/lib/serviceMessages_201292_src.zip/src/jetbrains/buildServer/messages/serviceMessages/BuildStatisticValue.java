package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class BuildStatisticValue extends ServiceMessage {
  public String getKey() {
    return getAttributeValue("key");
  }

  public String getValue() {
    return getAttributeValue("value");
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitBuildStatisticValue(this);
  }
}
