package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestSuiteStarted extends BaseTestSuiteMessage {

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestSuiteStarted(this);
  }
}
