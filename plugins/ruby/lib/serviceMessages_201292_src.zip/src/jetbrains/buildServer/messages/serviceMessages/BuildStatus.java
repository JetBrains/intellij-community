package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;
import jetbrains.buildServer.messages.Status;

public class BuildStatus extends ServiceMessage {
  public Status getStatus() {
    String status = getAttributeValue("status");
    if (status != null) {
      return Status.getStatus(status);
    }
    return null;
  }

  public String getText() {
    return getAttributeValue("text");
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitBuildStatus(this);
  }
}
