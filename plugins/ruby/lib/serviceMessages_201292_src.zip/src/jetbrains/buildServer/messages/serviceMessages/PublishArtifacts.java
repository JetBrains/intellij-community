package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class PublishArtifacts extends ServiceMessage {
  public String getArtifactsPath() {
    return getArgument();
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitPublishArtifacts(this);
  }
}
