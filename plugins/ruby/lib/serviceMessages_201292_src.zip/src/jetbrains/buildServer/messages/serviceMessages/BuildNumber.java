package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class BuildNumber extends ServiceMessage {
  public String getBuildNumber() {
    return getArgument();
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitBuildNumber(this);
  }
}
