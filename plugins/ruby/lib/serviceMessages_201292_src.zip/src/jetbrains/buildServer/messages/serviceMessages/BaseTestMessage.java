package jetbrains.buildServer.messages.serviceMessages;

public abstract class BaseTestMessage extends ServiceMessage {
  public String getTestName() {
    return getAttributeValue("name");
  }
}
