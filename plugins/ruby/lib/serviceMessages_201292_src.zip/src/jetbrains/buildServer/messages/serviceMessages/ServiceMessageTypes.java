package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NonNls;

/**
 * Contains known service message types
 */
public interface ServiceMessageTypes {
  @NonNls String PUBLISH_ARTIFACTS = "publishArtifacts";
  @NonNls String TEST_SUITE_STARTED = "testSuiteStarted";
  @NonNls String TEST_SUITE_FINISHED = "testSuiteFinished";
  @NonNls String TEST_STARTED = "testStarted";
  @NonNls String TEST_FINISHED = "testFinished";
  @NonNls String TEST_IGNORED = "testIgnored";
  @NonNls String TEST_STD_OUT = "testStdOut";
  @NonNls String TEST_STD_ERR = "testStdErr";
  @NonNls String TEST_FAILED = "testFailed";
  @NonNls String PROGRESS_MESSAGE = "progressMessage";
  @NonNls String PROGRESS_START = "progressStart";
  @NonNls String PROGRESS_FINISH = "progressFinish";
  @NonNls String BUILD_STATUS = "buildStatus";
  @NonNls String BUILD_NUMBER = "buildNumber";
  @NonNls String BUILD_STATISTIC_VALUE = "buildStatisticValue";
}
