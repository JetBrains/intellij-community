package jetbrains.buildServer.messages.serviceMessages;

import java.text.ParseException;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jetbrains.buildServer.util.StringUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Utility class to parse messages like
 *
 * ##teamcity[&lt;message name> &lt;param name>='&lt;param value>' &lt;param name>='&lt;param value>'...]
 * or
 * ##teamcity[&lt;message name> '&lt; argument>']
 * Argument is optional.
 *
 */
public class ServiceMessage {
  @NonNls private static final Pattern SERVICE_MESSAGE_PATTERN = Pattern.compile("##teamcity\\[(.*)\\]");

  private String myMessageName;
  private Map<String, String> myAttributes;
  private String myArgument;

  ServiceMessage() {
  }

  private void init(@NotNull final String key, @Nullable final String argumentsStr) throws ParseException {
    myMessageName = key;
    if (argumentsStr != null && argumentsStr.startsWith("'")) {
      parseArgument(argumentsStr);
    } else {
      parseAttributes(argumentsStr);
    }
  }

  /** If message is text message according to the pattern ##teamcity[key...], return parsed message. Otherwise, return null
   *  Throws ParseException if message is a service message but its arguments cannot be parsed.
   * @param message message to parse
   * @return see above
   * */
  @Nullable
  public static ServiceMessage parse(@NotNull String text) throws ParseException {
    return doParse(text);
  }

  /** @return name part of the service message */
  @NotNull
  public String getMessageName() {
    return myMessageName;
  }

  /** @return argument text for message ##teamcity[&lt;message name> '&lt; argument>'] or null
   **/
  @Nullable
  public String getArgument() {
    return myArgument;
  }

  /** @return map of parameters of the message in format ##teamcity[&lt;message name> &lt;param name>='&lt;param value>' &lt;param name>='&lt;param value>'...]
   **/
  public Map<String, String> getAttributes() {
    return myAttributes;
  }

  private void parseArgument(final String argumentsStr) throws ParseException {
    myArgument = argumentsStr == null ? null : stringToText(argumentsStr);
  }

  private void parseAttributes(final String argumentsStr) throws ParseException {
    if (argumentsStr != null) {
      myAttributes = StringUtil.stringToProperties(argumentsStr, STD_ESCAPER);
    }
    else {
      myAttributes = Collections.emptyMap();
    }
  }

  /**
   * Depending on this service message type calls corresponding method in the supplied visitor.
   * @param visitor visitor
   */
  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitServiceMessage(this);
  }

  @Nullable
  private static ServiceMessage doParse(final String text) throws ParseException {
    final Matcher matcher = SERVICE_MESSAGE_PATTERN.matcher(text.trim());
    if (!matcher.matches()) {
      return null;
    }

    final String keyWithArguments = matcher.group(1);
    final int sepIndex = keyWithArguments.indexOf(" ");
    String key = sepIndex == -1 ? keyWithArguments : keyWithArguments.substring(0, sepIndex);
    String argumentsStr = sepIndex == -1 ? null : keyWithArguments.substring(sepIndex).trim();

    Class<? extends ServiceMessage> clazz = myServiceMessageClasses.get(key);
    if (clazz == null) clazz = ServiceMessage.class;
    
    try {
      ServiceMessage msg = clazz.newInstance();
      msg.init(key, argumentsStr);
      return msg;
    } catch (ParseException e) {
      throw e;
    } catch (Throwable e) {
      throw new RuntimeException(e);
    }
  }

  protected String getAttributeValue(String attrName) {
    return getAttributes().get(attrName);
  }

  private static Map<String, Class<? extends ServiceMessage>> myServiceMessageClasses = new HashMap<String, Class<? extends ServiceMessage>>();
  static {
    myServiceMessageClasses.put(ServiceMessageTypes.PROGRESS_MESSAGE, ProgressMessage.class);
    myServiceMessageClasses.put(ServiceMessageTypes.PROGRESS_START, ProgressStart.class);
    myServiceMessageClasses.put(ServiceMessageTypes.PROGRESS_FINISH, ProgressFinish.class);
    myServiceMessageClasses.put(ServiceMessageTypes.PUBLISH_ARTIFACTS, PublishArtifacts.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_SUITE_STARTED, TestSuiteStarted.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_SUITE_FINISHED, TestSuiteFinished.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_STARTED, TestStarted.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_FAILED, TestFailed.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_FINISHED, TestFinished.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_IGNORED, TestIgnored.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_STD_OUT, TestStdOut.class);
    myServiceMessageClasses.put(ServiceMessageTypes.TEST_STD_ERR, TestStdErr.class);
    myServiceMessageClasses.put(ServiceMessageTypes.BUILD_STATUS, BuildStatus.class);
    myServiceMessageClasses.put(ServiceMessageTypes.BUILD_NUMBER, BuildNumber.class);
    myServiceMessageClasses.put(ServiceMessageTypes.BUILD_STATISTIC_VALUE, BuildStatisticValue.class);
  }

  private String stringToText(@NotNull String message) throws ParseException {
    message = message.trim();

    if (message.startsWith("'") && message.endsWith("'")) {
      return StringUtil.unescapeStr(message.substring(1, message.length() - 1), STD_ESCAPER);
    }
    else {
      throw new ParseException("Cannot extract text message [" + message + "]", 0);
    }
  }

  private static final StringUtil.EscapeInfoProvider STD_ESCAPER = new StringUtil.EscapeInfoProvider() {
    public char escape(final char c) {
      switch (c) {
        case '\n': return 'n';
        case '\r': return 'r';
        case '|': return '|';
        case '\'': return '\'';
        case '[': return '[';
        case ']': return ']';
        default:return 0;
      }
    }

    public char unescape(final char c) {
      switch (c) {
        case 'n': return '\n';
        case 'r': return '\r';
        case '\'': return '\'';
        case '|': return '|';
        case '[': return '[';
        case ']': return ']';
        default:return 0;
      }
    }

    public char escapeCharacter() {
      return '|';
    }
  };
}
