package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestFailed extends BaseTestMessage {
  public boolean isComparisonFailure() {
    return "comparisonFailure".equals(getAttributeValue("type"));
  }

  public String getFailureMessage() {
    return getAttributeValue("message");
  }

  public String getStacktrace() {
    return getAttributeValue("details");
  }

  public String getExpected() {
    return getAttributeValue("expected");
  }

  public String getActual() {
    return getAttributeValue("actual");
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestFailed(this);
  }
}
