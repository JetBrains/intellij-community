package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestFinished extends BaseTestMessage {

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestFinished(this);
  }
}
