package jetbrains.buildServer.messages.serviceMessages;

public abstract class BaseTestSuiteMessage extends ServiceMessage {
  public String getSuiteName() {
    return getAttributeValue("name");
  }
}
