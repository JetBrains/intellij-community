package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

public class TestStdOut extends BaseTestMessage {
  public String getStdOut() {
    return getAttributeValue("out");
  }

  public void visit(@NotNull ServiceMessageVisitor visitor) {
    visitor.visitTestStdOut(this);
  }
}
