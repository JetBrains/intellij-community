package jetbrains.buildServer.messages.serviceMessages;

import org.jetbrains.annotations.NotNull;

/**
 * Visitor which can be passed to {@link jetbrains.buildServer.messages.serviceMessages.ServiceMessage#visit(ServiceMessageVisitor)} method.
 * Depending on actual type of the service message corresponding method will be invoked.
 * If type of message is unknown {@link #visitServiceMessage(ServiceMessage)} will be called in the visitor.
 * <br/>
 * <br/>
 * see also {@link jetbrains.buildServer.messages.serviceMessages.DefaultServiceMessageVisitor}
 */
public interface ServiceMessageVisitor {
  void visitTestSuiteStarted(@NotNull TestSuiteStarted suiteStarted);

  void visitTestSuiteFinished(@NotNull TestSuiteFinished suiteFinished);

  void visitTestStarted(@NotNull TestStarted testStarted);

  void visitTestFinished(@NotNull TestFinished testFinished);

  void visitTestIgnored(@NotNull TestIgnored testIgnored);

  void visitTestStdOut(@NotNull TestStdOut testStdOut);

  void visitTestStdErr(@NotNull TestStdErr testStdErr);

  void visitTestFailed(@NotNull TestFailed testFailed);

  void visitPublishArtifacts(@NotNull PublishArtifacts publishArtifacts);

  void visitProgressMessage(@NotNull ProgressMessage progressMessage);

  void visitProgressStart(@NotNull ProgressStart progressStart);

  void visitProgressFinish(@NotNull ProgressFinish progressFinish);

  void visitBuildStatus(@NotNull BuildStatus buildStatus);

  void visitBuildNumber(@NotNull BuildNumber buildNumber);

  void visitBuildStatisticValue(@NotNull BuildStatisticValue buildStatsValue);

  void visitServiceMessage(@NotNull ServiceMessage msg);
}
