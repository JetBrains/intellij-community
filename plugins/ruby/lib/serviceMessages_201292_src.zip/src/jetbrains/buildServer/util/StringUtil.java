/*
 * Copyright (c) 2006, JetBrains, s.r.o. All Rights Reserved.
 */
package jetbrains.buildServer.util;

import com.intellij.util.StringBuilderSpinAllocator;
import com.intellij.openapi.diagnostic.Logger;
import java.awt.*;
import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.StringCharacterIterator;
import java.text.ParseException;
import java.util.*;
import java.util.List;
import java.util.regex.Pattern;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Kir
 */
@SuppressWarnings({"ClassNameSameAsAncestorName"})
public class StringUtil extends com.intellij.openapi.util.text.StringUtil {
  private static final Logger LOG = Logger.getInstance(StringUtil.class.getName());
  public static final char[] DEFAULT_SEPARATORS = new char[]{' ', ',', '\n', '\r', '\t',';'};
  public static final String EMPTY = "";
  @NonNls public static final String NA = "N/A";
  private static final String STD_EX_SUFFIX =
    "Valid property list format is (name( )*=( )*\'escaped_value\'( )*)* where escape simbol is \"|\"";

  private StringUtil() {
  }

  public static String escapeHTML(final String text, final boolean replaceQuotes) {
    if (text==null) {
      return "";
    }
    @NonNls final StringBuilder result = StringBuilderSpinAllocator.alloc();
    try {
      final StringCharacterIterator iterator = new StringCharacterIterator(text);
      char character = iterator.current();
      while (character != StringCharacterIterator.DONE) {
        if (character == '<') {
          result.append("&lt;");
        }
        else if (character == '>') {
          result.append("&gt;");
        }
        else if (character == '\"' && replaceQuotes) {
          result.append("&quot;");
        }
        else if (character == '\'' && replaceQuotes) {
          result.append("&#039;");
        }
        else if (character == '\\') {
          result.append("&#092;");
        }
        else if (character == '&') {
          result.append("&amp;");
        }
        else {
          result.append(character);
        }
        character = iterator.next();
      }
      return result.toString();
    }
    finally {
      StringBuilderSpinAllocator.dispose(result);
    }
  }

  public static String biteOffPostfix(final String line, final String postfix) {
    return line.substring(0, line.length() - postfix.length());
  }

  public static String lastPartOf(final String s, final char separator) {
    final int i = s.lastIndexOf(separator);
    if (i >= 0) {
      return s.substring(i + 1);
    }
    return s;
  }

  public static String truncateStringValue(final String str, int maxLength) {
    if (str == null) return null;
    if (str.length() > maxLength) {
      return str.substring(0, maxLength - 1);
    }

    return str;
  }

  @Nullable
  public static String truncateStringValueWithDots(final String str, int maxLength) {
    if (str == null) return null;
    if (str.length() > maxLength) {
      return str.substring(0, maxLength - 1 - 3) + "...";
    }

    return str;
  }

  /**
   * Section 2.2 of the XML spec describes which Unicode code points
   * are valid in XML:
   *
   * <blockquote><code>#x9 | #xA | #xD | [#x20-#xD7FF] |
   * [#xE000-#xFFFD] | [#x10000-#x10FFFF]</code></blockquote>
   *
   * Code points outside this set cannot be represented in XML.
   *
   * @param c The character to inspect.
   * @return Whether the specified character is valid in XML.
   */
  public static boolean isValidXMLChar(char c)
  {
      switch (c)
      {
      case 0x9:
      case 0xa:  // line feed, '\n'
      case 0xd:  // carriage return, '\r'
          return true;

      default:
          return ( (0x20 <= c && c <= 0xd7ff) ||
                   (0xe000 <= c && c <= 0xfffd) ||
                   (0x10000 <= c && c <= 0x10ffff) );
      }
  }

  /**
   * Looks for characters that cannot be presented in XML
   * @param value
   * @return index of invalid XML character in the string or -1 if all chars are valid
   */
  public static int findInvalidXMLChar(String value) {
    char[] chars = value.toCharArray();
    for (int i=0; i<chars.length; i++) {
      if (!StringUtil.isValidXMLChar(chars[i])) {
        return i;
      }
    }

    return -1;
  }

  /**
   * Generates unique hash value. Can be used for generating various identifiers like session id.
   * @return
   */
  public static String generateUniqueHash() {
    final StringBuilder sb = new StringBuilder();
    final Random random = createRandom();
    for(int i = 0; i < 32; i ++) {
      int rand = (int)(random.nextDouble() * 62);       // 62 = 26 + 26 + 10
      rand += ((rand < 10) ? 48 :             // create digits
               ((rand < 36) ? 55 : 61 ));     // create A-Z, a-z
      sb.append((char) rand);
    }
    return sb.toString();
  }

  private static Random createRandom() {
    Random random = new Random();
    try {
      random = SecureRandom.getInstance("SHA1PRNG");
    } catch (NoSuchAlgorithmException e) {
      //
    }
    finally {
      random.setSeed(System.nanoTime());
    }
    return random;
  }

  /**
   * Strips any combinations of \n and \r from both the beginning and the end of the given string.
   * For example, the result of using this method for string <code>"\r\nli\rne\r\n"</code> is <code>"li\rne"</code>
   * @param s source string
   * @return source string without \r \n characters at the edges
   */
  @NotNull
  public static String stripNewLine(@NotNull String s) {
    int endCharsOff = 0;
    while((s.length() > endCharsOff)) {
      final char lastChar = s.charAt(s.length()-endCharsOff-1);
      if(lastChar == '\n' || lastChar == '\r') {
        ++endCharsOff;
      }
      else {
        break;
      }
    }

    int beginCharsOff = 0;
    while((s.length() > (beginCharsOff + endCharsOff))) {
      final char firstChar = s.charAt(beginCharsOff);
      if(firstChar == '\n' || firstChar == '\r') {
        ++beginCharsOff;
      }
      else {
        break;
      }
    }

    return (endCharsOff > 0) || (beginCharsOff > 0) ?
           s.substring(beginCharsOff, s.length() - endCharsOff) : s;
  }
  
  /**
   * Returns RegEx pattern to search by specified keyword.
   * @param keyword
   * @param caseInsensitive
   * @return
   */
  public static Pattern searchByKeywordPattern(@NotNull String keyword, boolean caseInsensitive) {
    String escapedKeyword = escapeForRegex(keyword);
    int flags = 0;
    if (caseInsensitive) {
      flags = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    }
    return Pattern.compile(".*\\b" + escapedKeyword + ".*", flags);
  }

  private static String escapeForRegex(@NotNull String keyword) {
    StringBuilder builder = new StringBuilder();
    for (int i=0; i<keyword.length(); i++) {
      char c = keyword.charAt(i);
      switch (c) {
        case '\\':
        case '?':
        case '.':
        case '*':
        case '[':
        case ']':
        case '(':
        case ')':
        case '{':
        case '}':
        case '$':
          builder.append("\\");
      }
      builder.append(c);
    }
    return builder.toString();
  }
  
  public static List<String> split(final String values){
    return split(values, DEFAULT_SEPARATORS);
  }

  public static List<String> split(final String values,
                                   char... separators) {
    ArrayList<String> result = new ArrayList<String>();
    char[] currentWord = new char[values.length()];
    int currentEndPosition = 0;
    for (int i = 0; i < values.length(); i++) {
      char currentChar = values.charAt(i);
      if (isSeparator(currentChar, separators)) {
        if (currentEndPosition > 0) {
          result.add(new String(currentWord, 0,currentEndPosition));
          currentEndPosition = 0;
        }
        
      }
      else {
        currentWord[currentEndPosition] = currentChar;
        currentEndPosition++;
        
      }
    }
    
    if (currentEndPosition > 0) {
      result.add(new String(currentWord, 0,currentEndPosition));
    }
    
    return result;
  }

  private static boolean isSeparator(final char currentChar, final char[] separators) {
    for (char separator : separators) {
      if (currentChar == separator) return true;
    }
    return false;
  }

  public static boolean isAPositiveNumber(final String value) {
    try {
      int intValue = Integer.parseInt(value);
      return intValue > 0;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  public static boolean isNumber(final String value) {
    try {
      Integer.parseInt(value);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  /**
   * Formats AWT Color to HTML hex color string
   * @param color color to convert 
   * @return #rrggbb string
   */
  public static String formatHtmlColor(final Color color) {
    String rgb = Integer.toHexString(color.getRGB());
    rgb = rgb.substring(2, rgb.length());
    return '#' + rgb;
  }

  /** Return ordinal ending for a number, i.e. st for 1, nd for 2 and rd for 33.
   * @param number number, whose ordinal ending should be returned
   * @return see above
   * */
  public static String getOrdinal(int number) {
    int remains = number - 10 * ( number / 10 );
    String txt;
    switch (remains) {
      case 1: txt = "st"; break;
      case 2: txt = "nd"; break;
      case 3: txt = "rd"; break;
      default : txt = "th";
    }
    return txt;
  }

  public static String stackTrace(final Throwable exception) {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(buffer);
    exception.printStackTrace(printStream);
    printStream.close();
    
    return buffer.toString();
  }

  /**
   * Split string into tokens, ignores delimiters with escaping ('\')
   * @param string string data to tokenize
   * @param del selimiter
   * @return result iterator
   */
  public static Iterator<String> createEscapedTokenizer(final String string, final char del) {
    return new MyTokenizerIterator(string, del);
  }

  public static int indexOf(final String currentString, final char findWhat, final EscapeInfoProvider escaper) {
    for (int i = 0; i < currentString.length(); i++) {
      final char currentChar = currentString.charAt(i);
      if (escaper.escapeCharacter() == currentChar) {
        i++;
      }
      else if (currentChar == findWhat) {
        return i;
      }
    }
    
    return -1;
    
  }

  public static Map<String, String> stringToProperties(final String string, final EscapeInfoProvider escaper) throws ParseException {
    String currentString = string;
    final HashMap<String, String> result = new HashMap<String, String>();
    while (currentString.length() > 0) {
      final int nameSep = currentString.indexOf("=");
      if (nameSep == -1) throw new ParseException("Property value not found" + "\n" + STD_EX_SUFFIX, 0);
      final String name= currentString.substring(0, nameSep).trim();
      if (!isValidJavaIdentifier(name)) {
        throw new ParseException("Incorrect property name." + "\n" + STD_EX_SUFFIX, 0);
      }
      currentString = currentString.substring(nameSep + 1).trim();
      
      if (currentString.startsWith("'")) {
        currentString = currentString.substring(1);
        int endOfValue = indexOf(currentString, '\'', escaper);
        if (endOfValue >= 0) {
          String escapedValue = currentString.substring(0, endOfValue);
          currentString = currentString.substring(endOfValue + 1).trim();
          
          result.put(name,
                     unescapeStr(escapedValue, escaper));
          
        }
        else {
          throw new ParseException("Value should end with \"'\"" + "\n" + STD_EX_SUFFIX, 0);
        }
      }
      else {
        throw new ParseException("Value should start with \"'\"" + "\n" + STD_EX_SUFFIX, 0);
      }
    }

    return result;
  }

  private static boolean isValidJavaIdentifier(final String name) {
    if (name.length() == 0) return false;
    if (!Character.isJavaIdentifierStart(name.charAt(0))) return false;
    for (int i = 1; i < name.length(); i++) {
      if (!Character.isJavaIdentifierPart(name.charAt(i))) return false;
    }
    
    return true;
  }

  public static String repeat(final String whatRepeat, final String separator, final int length) {
    StringBuffer result = new StringBuffer();
    for (int i = 0; i < length; i++) {
      if (i > 0) {
        result.append(separator);
      }
      result.append(whatRepeat);
    }
    return result.toString();
  }

  public static boolean isTrue(final String property) {
    return Boolean.parseBoolean(property) || "yes".equalsIgnoreCase(property);
  }

  public interface LineProcessor {
    boolean processLine(String line); 
  }
  
  public static void  processLines(String str, LineProcessor procesor) throws IOException {
    final BufferedReader reader = new BufferedReader(new StringReader(str));

    try {
      processLines(reader, procesor);
    } finally {
      reader.close();
    }

  }

  private static void processLines(final BufferedReader reader, final LineProcessor procesor) throws IOException {
    String line;
    while ((line = reader.readLine()) != null) {
      if (procesor.processLine(line)) {
        return;
      }
    }
  }

  @NotNull public static java.lang.String formatFileSize(long size) {
    try {
      return com.intellij.openapi.util.text.StringUtil.formatFileSize(size);
    } catch (MissingResourceException e) {
      LOG.warn(e.toString());
      if (size == 1) return size + " byte";
      return size + " bytes";
    }
  }

  public static void  processLines(InputStream in, LineProcessor procesor) throws IOException {
    final BufferedReader reader = new BufferedReader(new InputStreamReader(in));

    processLines(reader, procesor);
  }
  
  public static void  processLines(File file, LineProcessor procesor) throws IOException {
    final BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
    try {
      processLines(in, procesor);
    } finally {
      in.close();
    }
  }

  /**
   * String escaping info provider.
   */
  public interface EscapeInfoProvider {
    char escape(char c);
    char unescape(char c);
    char escapeCharacter();
  }

  /**
   * Escapes characters specified by provider with '\' and specified character.
   * @param str initial string
   * @param p escape info provider.
   * @return escaped string.
   */
  public static String escapeStr(final String str, EscapeInfoProvider p) {
    if (str == null) return null;
    int finalCount = calcFinalEscapedStringCount(str, p);

    if (str.length() == finalCount) return str;

    char[] resultChars = new char[finalCount];
    int resultPos = 0;
    for (int i = 0; i < str.length(); i++) {
      char c = str.charAt(i);
      final char escaped = p.escape(c);
      if (escaped != 0) {
        resultChars[resultPos++] = p.escapeCharacter();
        resultChars[resultPos++] = escaped;        
      }
      else {
        resultChars[resultPos++] = c;        
      }
    }

    if (resultPos != finalCount) {
      throw new RuntimeException("Incorrect escaping for '" + str + "'");
    }
    return new String(resultChars);
  }

  private static int calcFinalEscapedStringCount(final String name, final EscapeInfoProvider p) {
    int result = 0;
    for (int i = 0; i < name.length(); i++) {
      char c = name.charAt(i);
      if (p.escape(c) != 0) {
        result += 2;
      }
      else {
        result += 1;
      }
    }

    return result;
  }
  
  /**
   * Unescapes characters specified by provider with '\' and specified character.
   * @param str initial string
   * @param p escape info provider.
   * @return unescaped string.
   */
  
  public static String unescapeStr(final String str, EscapeInfoProvider p) {
    if (str == null) return null;
    int finalCount = calcFinalUnescapedStringCount(str, p);

    int len = str.length();
    if (len == finalCount) return str;

    char[] resultChars = new char[finalCount];
    int resultPos = 0;
    for (int i = 0; i < len; i++) {
      char c = str.charAt(i);
      if (c == p.escapeCharacter() && i < len - 1) {
        char nextChar = str.charAt(i + 1);
        final char unescaped = p.unescape(nextChar);
        if (unescaped != 0) {
          c = unescaped;
          //noinspection AssignmentToForLoopParameter
          i += 1;
        } 
      }

      resultChars[resultPos++] = c;
    }

    if (resultPos != finalCount) {
      throw new RuntimeException("Incorrect unescaping for '" + str + "'");
    }

    return new String(resultChars);

  }

  private static int calcFinalUnescapedStringCount(final String name, final EscapeInfoProvider p) {
    int result = 0;
    int len = name.length();
    for (int i = 0; i < len; i++) {
      char c = name.charAt(i);
      if (c == p.escapeCharacter() && i < len - 1) {
        char nextChar = name.charAt(i + 1);        
        if (p.unescape(nextChar) != 0) {
          //noinspection AssignmentToForLoopParameter
          i += 1;
        }
      }

      result += 1;
    }

    return result;
  }

  private static class MyTokenizerIterator implements Iterator<String> {
    private int myNextPosition = 0;
    private String myString;
    private final char myDel;

    public MyTokenizerIterator(final String string,
                               final char del
    ) {
      myString = string;
      myDel = del;
      
    }

    public boolean hasNext() {
      return myNextPosition < myString.length();
    }

    public String next() {
      if (!hasNext()) throw new ArrayIndexOutOfBoundsException();
      
      int lastIndex = myNextPosition;
      while (lastIndex < myString.length()) {
        final char nextChar = myString.charAt(lastIndex);
        if (nextChar == '\\') {
          if (nextChar == myString.length() - 1) {
            try {
              return myString.substring(myNextPosition);
            } finally {
              myNextPosition = lastIndex + 1;
            }
          }
          else {
            lastIndex++;
            lastIndex++;
          }
        }
        else if(nextChar == myDel){
          try {
            return myString.substring(myNextPosition, lastIndex);
          } finally {
            myNextPosition = lastIndex + 1;
          }
        }
        else {
          lastIndex++;
        }
      }


      try {
        return myString.substring(myNextPosition);
      } finally {
        myNextPosition = lastIndex + 1;
      }
    }

    public void remove() {
      throw new RuntimeException("Remove not supported");
    }
  }

  /**
   * Formats text for showing on the web page preserving original text formatting.
   * Dangerous characters like < will be replaced with corresponding entities, line feeds will be replaced with br tag
   * @param txt initial text
   * @return text ready for publishing on Web page
   * */
  public static String formatTextForWeb(final String txt) {
    if (txt == null) return null;
    return StringUtil.escapeHTML(txt, true).replace("\r\n", "\n").replace("\n", "<br />\n");
  }


  private static final String NON_ALPHA_NUM = "[^A-Za-z0-9_]";

  /**
   * Replaces all characters except A-Za-z0-9_ to specified character.
   * @param originalStr original string
   * @param toReplace character to replace with
   * @return string with replaced characters
   */
  public static String replaceNonAlphaNumericChars(final String originalStr, char toReplace) {
    return originalStr.replaceAll(NON_ALPHA_NUM, String.valueOf(toReplace));
  }
}
