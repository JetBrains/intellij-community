#include <iostream>

void hello () {
  std::cout << "Hello, World!\n";
}
