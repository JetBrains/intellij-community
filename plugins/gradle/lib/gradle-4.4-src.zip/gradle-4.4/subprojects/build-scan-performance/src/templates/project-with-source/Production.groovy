package ${packageName};

public class ${productionClassName} {
    private final String property;

    public ${productionClassName}(String param) {
        this.property = param;
    }

    public String getProperty() {
        return property;
    }
}
