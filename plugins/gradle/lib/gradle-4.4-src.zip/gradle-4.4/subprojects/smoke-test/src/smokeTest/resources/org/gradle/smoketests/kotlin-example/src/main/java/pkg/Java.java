package pkg;

public class Java {
    public static String getGreeting() {
        return "Hello world!";
    }
}

