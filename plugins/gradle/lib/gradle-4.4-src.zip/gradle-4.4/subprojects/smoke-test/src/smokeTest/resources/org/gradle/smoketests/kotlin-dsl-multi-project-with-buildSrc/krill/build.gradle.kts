hello.doLast {
  println("- The weight of my species in summer is twice as heavy as all human beings.")
}
