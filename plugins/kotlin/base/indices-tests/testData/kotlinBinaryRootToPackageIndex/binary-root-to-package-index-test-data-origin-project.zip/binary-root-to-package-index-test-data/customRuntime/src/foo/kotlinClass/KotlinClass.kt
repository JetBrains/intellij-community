package foo.kotlinClass

class KotlinClass {
}
