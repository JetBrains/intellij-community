package onlyJava;

public record MyRecord() {
}
