package onlyJava;

public @interface MyAnnotation {
}
