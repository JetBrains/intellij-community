package months.javune;

// We want to ensure that Java-only packages are not picked up by the index.
public class Javune {
}
