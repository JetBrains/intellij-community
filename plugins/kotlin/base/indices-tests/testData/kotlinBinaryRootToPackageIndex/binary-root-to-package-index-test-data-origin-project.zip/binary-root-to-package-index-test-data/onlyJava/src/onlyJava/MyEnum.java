package onlyJava;

public enum MyEnum {
}
