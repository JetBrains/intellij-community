package months.may

// We want to ensure that the index picks up packages which only contain top-level functions.
fun whereIsMay(): Boolean = false
