package onlyJava;

public class MyClass {
}
