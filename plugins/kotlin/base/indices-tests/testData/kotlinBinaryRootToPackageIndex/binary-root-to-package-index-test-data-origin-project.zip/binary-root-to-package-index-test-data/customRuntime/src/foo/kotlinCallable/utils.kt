package foo.kotlinCallable

fun doSomething() { }
