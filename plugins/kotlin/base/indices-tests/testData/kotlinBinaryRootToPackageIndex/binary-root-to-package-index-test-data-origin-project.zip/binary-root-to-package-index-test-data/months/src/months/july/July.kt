package months.july

import months.june.June

// We want to test if the index picks up packages which only contain type aliases.
typealias July = June
