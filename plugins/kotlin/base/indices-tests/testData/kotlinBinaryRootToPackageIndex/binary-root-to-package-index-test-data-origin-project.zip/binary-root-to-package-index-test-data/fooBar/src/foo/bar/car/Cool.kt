package foo.bar.car

class Cool
