## Binary root to package index test data

This project contains several modules which are used to generate JARs/KLIBs/JRT images to test `KotlinBinaryRootToPackageIndex`.

#### Generating KLIBs

Example for `fooBar`:

```
cd fooBar/src
kotlinc-native foo -p library -o fooBar
```

#### Generating JRT images

The module `customRuntime` is used to generate a JRT image that contains a Kotlin declaration. This isn't an actual JDK,
but rather just a single-module "runtime" to test whether the binary root to package index correctly picks up `.class`
files from JRT file systems (with the right module name).

To build the JRT image for `customRuntime`, first build the artifact `customRuntime:jar`, then execute the following 
command:

```
cd customRuntime
jlink --output output --add-modules customRuntime --module-path ../out/artifacts/customRuntime_jar/customRuntime.jar --strip-debug --no-header-files --no-man-pages --compress=2
```

The resulting image will be `output/lib/modules`.
