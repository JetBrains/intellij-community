package months.javune.ghostMonth

// We want to ensure that the index picks up this package, but not `months.javune`, which only contains Java classes.
class October
