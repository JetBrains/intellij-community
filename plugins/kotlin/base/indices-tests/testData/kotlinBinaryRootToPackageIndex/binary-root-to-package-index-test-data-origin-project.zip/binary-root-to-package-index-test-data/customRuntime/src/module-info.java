module customRuntime {
    requires kotlin.stdlib;

    exports foo.javaClass;
    exports foo.kotlinCallable;
    exports foo.kotlinClass;
}
