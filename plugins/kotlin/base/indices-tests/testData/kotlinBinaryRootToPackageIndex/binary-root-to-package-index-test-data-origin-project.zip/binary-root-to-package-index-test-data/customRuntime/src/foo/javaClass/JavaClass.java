package foo.javaClass;

public class JavaClass {
}
