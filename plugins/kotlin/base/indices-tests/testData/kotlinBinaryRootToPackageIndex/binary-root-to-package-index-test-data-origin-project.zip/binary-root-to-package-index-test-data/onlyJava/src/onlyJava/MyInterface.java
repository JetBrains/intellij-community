package onlyJava;

public interface MyInterface {
}
