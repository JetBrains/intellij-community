package months.june

interface June
