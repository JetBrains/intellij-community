package org.testng.internal.annotations;

public interface IAfterGroups extends IBaseBeforeAfter {

}
