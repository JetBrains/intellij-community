package org.testng.internal.annotations;

public interface IBeforeMethod extends IBaseBeforeAfter {
}
