package org.testng.internal;

import org.testng.IConfigurationListener2;

public interface IResultListener2 extends IResultListener, IConfigurationListener2 {

}
