package org.testng;

/**
 * This is a marker interface for all objects that can be passed
 * as a -listener argument.
 * 
 * @author cbeust
 */
public interface ITestNGListener {
}
