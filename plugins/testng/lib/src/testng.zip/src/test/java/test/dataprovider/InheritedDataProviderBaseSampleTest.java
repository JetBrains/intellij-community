package test.dataprovider;

import org.testng.annotations.Test;

//@Test(description = "parent")
@Test (dataProviderClass=InheritedDataProviderSample1Test.class)
public class InheritedDataProviderBaseSampleTest {

}
