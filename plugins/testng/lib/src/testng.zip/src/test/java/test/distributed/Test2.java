package test.distributed;

import org.testng.annotations.Test;

public class Test2 {
  @Test 
  public void f2() {
//    ppp("f2");
  }
  
  private void ppp(String s) {
    System.out.println("[Test2] " + s);
  }    
}
