// Not that this file has no package (that's what we are testing) and therefore,
// it is at the wrong location, but it's easier to leave it here.
// Also, do not change the line numbers since the test will make sure
// that the tags are generated in hardcoded line numbers
import junit.framework.TestCase;
public class ConverterSample2 extends TestCase {
    @Override
    protected void setUp() throws Exception {
        super.setUp();

    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public final void testClassJunit() {
    }


    public final void testSetClassId() {
    }

    public final void testSetClassName() {
    }

}
