package test.factory;

import org.testng.annotations.Test;

public class FactoryBaseSampleTest {

  @Test
  public void f() {}
}
