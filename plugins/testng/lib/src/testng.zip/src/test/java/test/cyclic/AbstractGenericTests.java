package test.cyclic;

import org.testng.annotations.Test;

public abstract class AbstractGenericTests extends BaseIntegrationTest {

    @Test(groups="integration")
    public final void testSomething() {
        //...
    }

 }

