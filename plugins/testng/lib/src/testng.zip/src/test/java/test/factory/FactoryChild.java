package test.factory;

public class FactoryChild extends FactoryBase {

}
