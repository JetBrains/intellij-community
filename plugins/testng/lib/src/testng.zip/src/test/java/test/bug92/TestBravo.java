package test.bug92;

import org.testng.annotations.Test;

public class TestBravo extends TestBase {

	@Test
	public void test1() {
	}

	@Test
	public void test2() {
	}
}