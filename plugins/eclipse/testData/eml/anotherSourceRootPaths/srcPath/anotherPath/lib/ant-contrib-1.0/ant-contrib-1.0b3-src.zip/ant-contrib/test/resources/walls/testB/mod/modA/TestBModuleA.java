
package mod.modA;

public class TestBModuleA
{

};