
package mod.modB;

public class ModuleB
{
};