package eclipseLib;

/**
 * Created in IntelliJ IDEA.
 * By: Alexander.Chernikov
 * When: 19.02.2009, 20:55:48
 * Русский текст.
 */
public class SourceFour {
	public static final String ELIB_CONST = "value 4";

	public void elibMethod() {
	}
}
