package eclipseLib;

/**
 * Created in IntelliJ IDEA.
 * By: Alexander.Chernikov
 * When: 19.02.2009, 20:55:48
 * Русский текст.
 */
public class SourceAlpha {
	public static final String ELIB_CONST = "value a";

	public void elibMethod() {
	}
}
