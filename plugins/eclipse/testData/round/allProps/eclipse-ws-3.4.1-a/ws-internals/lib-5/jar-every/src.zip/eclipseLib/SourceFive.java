package eclipseLib;

/**
 * Created in IntelliJ IDEA.
 * By: Alexander.Chernikov
 * When: 19.02.2009, 20:55:48
 * Русский текст.
 */
public class SourceFive {
	public static final String ELIB_CONST = "value 5";

	public void elibMethod() {
	}
}
