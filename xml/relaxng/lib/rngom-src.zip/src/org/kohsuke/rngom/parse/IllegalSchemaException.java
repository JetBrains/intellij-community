package org.kohsuke.rngom.parse;

/**
 * Signals a violation of the RELAX NG spec.
 */
public class IllegalSchemaException extends Exception { }
