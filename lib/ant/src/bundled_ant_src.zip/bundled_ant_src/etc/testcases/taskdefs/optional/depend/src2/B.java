public class B {
}

