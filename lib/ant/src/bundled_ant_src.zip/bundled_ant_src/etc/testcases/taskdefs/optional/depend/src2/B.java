public class B {
}

