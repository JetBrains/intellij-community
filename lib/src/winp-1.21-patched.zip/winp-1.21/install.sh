#!/bin/bash -ex
cp native/Release/winp.dll src/main/resources/winp.dll
cp native/x64/Release/winp.dll src/main/resources/winp.x64.dll
