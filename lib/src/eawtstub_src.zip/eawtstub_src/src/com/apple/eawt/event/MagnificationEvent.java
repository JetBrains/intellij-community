package com.apple.eawt.event;

public class MagnificationEvent extends GestureEvent {
  MagnificationEvent(double v) {}

  public double getMagnification() { return 0; }
}