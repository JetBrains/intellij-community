/*
 * Copyright 2000-2021 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* this is stub code written based on Apple EAWT package javadoc published at
 * http://developer.apple.com.  It makes compiling code which uses Apple EAWT
 * on non-Mac platforms possible.  The compiled stub classes should never be
 * included in the final product.
 */

package com.apple.eawt;


public class Application {


    public static Application getApplication() {
        return null;
    }

    @Deprecated
    public Application() {}

    public void addAppEventListener(final java.awt.desktop.SystemEventListener listener) {}

    public void removeAppEventListener(final java.awt.desktop.SystemEventListener listener) {}

    public void setAboutHandler(final java.awt.desktop.AboutHandler aboutHandler) {}

    public void setPreferencesHandler(final java.awt.desktop.PreferencesHandler preferencesHandler) {}

    public void setOpenFileHandler(final java.awt.desktop.OpenFilesHandler openFileHandler) {}

    public void setPrintFileHandler(final java.awt.desktop.PrintFilesHandler printFileHandler) {}

    public void setOpenURIHandler(final java.awt.desktop.OpenURIHandler openURIHandler) {}

    public void setQuitHandler(final java.awt.desktop.QuitHandler quitHandler) {}

    public void setQuitStrategy(final java.awt.desktop.QuitStrategy strategy) {}

    // TODO remove these methods begin
    public void addAppEventListener(final com.apple.eawt.AppEventListener listener) {}
    public void removeAppEventListener(final com.apple.eawt.AppEventListener listener) {}
    public void setAboutHandler(final com.apple.eawt.AboutHandler aboutHandler) {}
    public void setPreferencesHandler(final com.apple.eawt.PreferencesHandler preferencesHandler) {}
    public void setOpenFileHandler(final com.apple.eawt.OpenFilesHandler openFileHandler) {}
    public void setPrintFileHandler(final com.apple.eawt.PrintFilesHandler printFileHandler) {}
    public void setOpenURIHandler(final com.apple.eawt.OpenURIHandler openURIHandler) {}
    public void setQuitHandler(final com.apple.eawt.QuitHandler quitHandler) {}
    public void setQuitStrategy(final com.apple.eawt.QuitStrategy strategy) {}
    // TODO remove these methods end

    public void enableSuddenTermination() {}

    public void disableSuddenTermination() {}

    public void requestForeground(final boolean allWindows) {}

    public void requestUserAttention(final boolean critical) {}

    public void openHelpViewer() {}

    public void setDockMenu(final java.awt.PopupMenu menu) {}

    public java.awt.PopupMenu getDockMenu() {
        return null;
    }

    public void setDockIconImage(final java.awt.Image image) {}

    public java.awt.Image getDockIconImage() {
        return null;
    }

    public void setDockIconBadge(final String badge) {}

    public void setDockIconProgress(final int value) {}

    public void setDefaultMenuBar(final javax.swing.JMenuBar menuBar) {}

    public void requestToggleFullScreen(final java.awt.Window window) {}

}
