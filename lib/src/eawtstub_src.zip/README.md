# eawtstub

eawtstub to compile with modern java.

```sh
# Generate class files
find . -name "*.java" -print | xargs javac -d ./build
cd build
# Build lib
jar cvf eawtstub.jar . 
```