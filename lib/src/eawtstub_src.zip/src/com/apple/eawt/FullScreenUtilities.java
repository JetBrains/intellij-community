package com.apple.eawt;

/**
 * @author Dennis.Ushakov
 */
public class FullScreenUtilities {
  FullScreenUtilities() { }

  public static void setWindowCanFullScreen(java.awt.Window window, boolean b) { }

  public static void addFullScreenListenerTo(java.awt.Window window, FullScreenListener listener) { }

  public static void removeFullScreenListenerFrom(java.awt.Window window, FullScreenListener listener) { }
}
