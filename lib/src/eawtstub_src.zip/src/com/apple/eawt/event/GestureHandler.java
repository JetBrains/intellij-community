/*
 * Copyright 2000-2011 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* this is stub code written based on Apple EAWT package javadoc published at
 * http://developer.apple.com.  It makes compiling code which uses Apple EAWT
 * on non-Mac platforms possible.  The compiled stub classes should never be
 * included in the final product.
 */

package com.apple.eawt.event;

final class GestureHandler  {

  static void addGestureListenerTo(javax.swing.JComponent component, GestureListener listener) {}

  static void removeGestureListenerFrom(javax.swing.JComponent component, GestureListener listener) {}

  static void handleGestureFromNative(java.awt.Window window, int i, double v, double v1, double v2, double v3) {}

  GestureHandler() {}

  void addListener(GestureListener listener) {}

  void removeListener(GestureListener listener) {}

  static GestureHandler getHandlerForComponent(java.awt.Component component) { return null; }

  static GestureHandler.PerComponentNotifier getNextNotifierForComponent(java.awt.Component component) { return null; }

  static class PerComponentNotifier  {

    public PerComponentNotifier(java.awt.Component component, GestureHandler handler) {}

    void recursivelyHandlePhaseChange(double v, GesturePhaseEvent event) {}

    void recursivelyHandleRotate(RotationEvent event) {}

    void recursivelyHandleMagnify(MagnificationEvent event) {}

    void recursivelyHandleSwipe(double v, double v1, SwipeEvent event) {}
  }
}