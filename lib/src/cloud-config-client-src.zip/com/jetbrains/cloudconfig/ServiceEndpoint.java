package com.jetbrains.cloudconfig;

abstract class ServiceEndpoint {
    public final String subdirectory;

    ServiceEndpoint(String subdirectory) {
        this.subdirectory = subdirectory;
    }
}

class FilesEndpoint extends ServiceEndpoint {
    FilesEndpoint(String subdirectory) {
        super(subdirectory);
    }

    static FilesEndpoint v2 = new FilesEndpoint("files-v2");
}

class VersionsEndpoint extends ServiceEndpoint {
    VersionsEndpoint(String subdirectory) {
        super(subdirectory);
    }

    static VersionsEndpoint v2 = new VersionsEndpoint("versions-v2");
}
