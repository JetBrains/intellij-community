package com.jetbrains.cloudconfig;

import com.jetbrains.cloudconfig.auth.AuthProvider;
import com.jetbrains.cloudconfig.auth.NoAuthProvider;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

/**
 * Cloud Config Client configuration.
 */
public class Configuration {
    private int connectTimeout = 0;

    private int readTimeout = 0;

    private int chunkSize = -1;

    private boolean followRedirects = false;

    private AuthProvider authProvider = NoAuthProvider.INSTANCE;

    private Proxy proxy;

    /**
     * Set socket connection timeout in milliseconds.
     * @return configuration instance itself
     * @see HttpURLConnection#setConnectTimeout(int)
     */
    public Configuration connectTimeout(int timeout) {
        this.connectTimeout = timeout;
        return this;
    }

    /**
     * Set socket read timeout in milliseconds.
     * @return configuration instance itself
     * @see HttpURLConnection#setReadTimeout(int)
     */
    public Configuration readTimeout(int timeout) {
        this.readTimeout = timeout;
        return this;
    }

    /**
     * Enables HTTP chunked encoding with given chunk size.
     * Can be useful for transferring large messages.
     * Streaming is off by default.
     * @return configuration instance itself
     * @see HttpURLConnection#setChunkedStreamingMode(int)
     */
    public Configuration chunkSize(int chunkSize) {
        this.chunkSize = chunkSize;
        return this;
    }

    /**
     * Sets whether HTTP redirects (3xx response codes) should be followed.
     * False by default.
     * @param follow to follow or not
     * @return configuration instance itself
     * @see HttpURLConnection#setFollowRedirects(boolean)
     */
    public Configuration followRedirects(boolean follow) {
        this.followRedirects = follow;
        return this;
    }

    /**
     * Sets authenticator for the client.
     * @param provider authentication provider
     * @return configuration instance itself
     */
    public Configuration auth(AuthProvider provider) {
        this.authProvider = provider;
        return this;
    }

    /**
     * Sets proxy server to pass through all the client requests.
     * @param proxy proxy server
     * @return configuration instance itself
     */
    public Configuration proxy(Proxy proxy) {
        this.proxy = proxy;
        return this;
    }

    HttpURLConnection openConnection(URL url) throws IOException {
        HttpURLConnection connection =
                (HttpURLConnection) (proxy != null ? url.openConnection(proxy) : url.openConnection());

        connection.setConnectTimeout(connectTimeout);
        connection.setReadTimeout(readTimeout);
        connection.setInstanceFollowRedirects(followRedirects);

        if (chunkSize > 0) {
            connection.setChunkedStreamingMode(chunkSize);
        }

        authProvider.authenticate(connection);

        return connection;
    }
}
