package com.jetbrains.cloudconfig.exception;

/**
 * Indicates that client do not have access to resource.
 * Corresponds to service status code 403.
 */
public class AccessDeniedException extends java.lang.SecurityException {
    public AccessDeniedException(String message) {
        super(message);
    }

    public AccessDeniedException(String message, Throwable cause) {
        super(message, cause);
    }
}
