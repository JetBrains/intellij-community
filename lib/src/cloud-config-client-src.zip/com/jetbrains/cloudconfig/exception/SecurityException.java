package com.jetbrains.cloudconfig.exception;

/**
 * Thrown on service authentication failure.
 */
public abstract class SecurityException extends RuntimeException {
    public SecurityException(String message) {
        super(message);
    }

    public SecurityException(String message, Throwable cause) {
        super(message, cause);
    }
}
