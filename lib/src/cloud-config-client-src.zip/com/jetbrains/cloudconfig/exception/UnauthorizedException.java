package com.jetbrains.cloudconfig.exception;

/**
 * Indicates invalid client credentials.
 * Corresponds to service status code 401.
 */
public class UnauthorizedException extends java.lang.SecurityException {
    public UnauthorizedException(String message) {
        super(message);
    }

    public UnauthorizedException(String message, Throwable cause) {
        super(message, cause);
    }
}
