package com.jetbrains.cloudconfig.exception;

/**
 * Indicates that passed versionId differs from the one on the server.
 * Corresponds to service status code 417.
 */
public class InvalidVersionIdException extends RuntimeException {
    public InvalidVersionIdException(String message) {
        super(message);
    }

    public InvalidVersionIdException(String message, Throwable cause) {
        super(message, cause);
    }
}