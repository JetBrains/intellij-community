package com.jetbrains.cloudconfig;

import java.io.*;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * HTTP client for Cloud Config RESTful service (file-based API).
 * <p/>
 * Usage example:
 * <pre>
 * final String PATH = "compiler.xml";
 *
 * CloudConfigFileClient client = new CloudConfigFileClient("http://localhost:8080/files");
 *
 * client.write(PATH, new FileInputStream("/Users/jetbrains/Projects/Test/.idea/compiler.xml"));
 *
 * System.out.println(new java.util.Scanner(client.read(PATH)).useDelimiter("\\A").next());
 *
 * System.out.println(client.list("/"));
 *
 * client.delete(PATH);
 * </pre>
 */
public class CloudConfigFileClient extends AbstractCloudConfigFileClient {

    private static final String LINE_FEED = "\r\n";


    /**
     * Creates client instance with default configuration.
     *
     * @param endpoint service URL address, e.g. "http://example.com/cloudconfig"
     */
    public CloudConfigFileClient(String endpoint) {
        super(endpoint);
    }

    /**
     * Created client instance with given configuration.
     *
     * @param endpoint    service URL address, e.g. "http://example.com/cloudconfig"
     * @param config      client configuration
     * @param eTagStorage ETag storage implementation
     */
    public CloudConfigFileClient(String endpoint, Configuration config, ETagStorage eTagStorage) {
        super(endpoint, config);
        this.eTagStorage = eTagStorage;
    }

    /**
     * Read file from service.
     *
     * @param file remote path of the file
     * @return content stream or null if it was not changed (according to ETag)
     */
    public InputStream read(String file) throws IOException {
        return read(file, null);
    }

    /**
     * Write file into service.
     *
     * @param file    remote path to store file under
     * @param content file content
     */
    public void write(String file, InputStream content) throws IOException {
        write(file, content, null);
    }

    /**
     * Write file into service handling output stream manually.
     * Useful for compression and other encodings.
     *
     * @param file remote path to store file under
     * @return output stream to write content into. Close the stream after all the content is written.
     */
    public OutputStream write(String file) throws IOException {
        HttpURLConnection connection = config.openConnection(url(file, null));

        connection.setRequestProperty(CONTENT_TYPE_HEADER_NAME, OCTET_STREAM_CONTENT_TYPE);
        connection.setRequestMethod(HTTP_PUT);

        connection.setDoOutput(true);

        OutputStream out = connection.getOutputStream();

        return new BufferedOutputStream(out) {
            private final AtomicBoolean closed = new AtomicBoolean(false);

            @Override
            public void close() throws IOException {
                if (closed.get() || !closed.compareAndSet(false, true)) return;

                super.close();

                assertSuccess(connection, HttpURLConnection.HTTP_NO_CONTENT);
            }
        };
    }

    public void write(String path, MultiUploadRequest request) throws IOException {
        if (request.getUploads().isEmpty()) {
            throw new IllegalArgumentException("Nothing to upload");
        }

        final String boundary = Long.toHexString(System.currentTimeMillis());

        upload(HTTP_PUT, url(path, null), new HashMap<>() {{
            put(CONTENT_TYPE_HEADER_NAME, MULTIPART_CONTENT_TYPE + "; boundary=" + boundary);
        }}, out -> {
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(out));

            for (Map.Entry<String, InputStream> entry : request.getUploads().entrySet()) {
                String name = entry.getKey();
                InputStream content = entry.getValue();

                writer.append("--").append(boundary).append(LINE_FEED);
                writer.append("Content-Disposition: form-data; name=\"").append(name)
                        .append("\"; filename=\"").append(name).append("\"").append(LINE_FEED);
                writer.append("Content-Type: application/octet-stream").append(LINE_FEED);
                writer.append("Content-Transfer-Encoding: binary").append(LINE_FEED);
                writer.append(LINE_FEED);
                writer.flush();

                drainStream(content, out);

                writer.append(LINE_FEED);
            }

            writer.append("--").append(boundary).append("--").append(LINE_FEED);
            writer.flush();
        }, (statusCode, headers, stream) -> {
            @SuppressWarnings("unchecked")
            Map<String, String> etags = GSON.fromJson(new InputStreamReader(stream), Map.class);

            for (Map.Entry<String, String> entry : etags.entrySet()) {
                eTagStorage.store(entry.getKey(), entry.getValue());
            }

            return null;
        }, HttpURLConnection.HTTP_OK);
    }

    /**
     * Delete from service.
     *
     * @param file remote path of the file
     * @throws IOException in case of error
     */
    public void delete(String file) throws IOException {
        delete(file, null);
    }

    /**
     * Lists remote folder.
     *
     * @param file remote path of the folder to list
     * @return list of folder's children files
     * @throws IOException in case of error
     */
    public List<String> list(String file) throws IOException {
        return list(file, null);
    }
}