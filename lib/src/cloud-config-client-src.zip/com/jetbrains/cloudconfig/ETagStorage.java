package com.jetbrains.cloudconfig;

/**
 * ETag storage interface, for backward compatibility only
 */
public interface ETagStorage extends HeaderStorage { }