package com.jetbrains.cloudconfig;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by dan
 */
public class CloudConfigFileClientV2 extends AbstractCloudConfigFileClient {

    public CloudConfigFileClientV2(String endpoint,
                                   Configuration config,
                                   ETagStorage eTagStorage,
                                   HeaderStorage versionIdStorage) {
        super(endpoint, config);
        this.eTagStorage = eTagStorage;
        this.versionIdStorage = versionIdStorage;
    }

    private final FilesEndpoint DEFAULT_FILES_ENDPOINT = FilesEndpoint.v2;
    private final VersionsEndpoint DEFAULT_VERSIONS_ENDPOINT = VersionsEndpoint.v2;

    /**
     * Read file from service.
     *
     * @param file remote path of the file
     * @return content stream or null if it was not changed (according to ETag)
     */
    public InputStream read(String file) throws IOException {
        return read(file, DEFAULT_FILES_ENDPOINT);
    }

    /**
     * Write file into service.
     *
     * @param file    remote path to store file under
     * @param content file content
     */
    public void write(String file, InputStream content) throws IOException {
        write(file, content, DEFAULT_FILES_ENDPOINT);
    }

    /**
     * Delete from service.
     *
     * @param file remote path of the file
     * @throws IOException in case of error
     */
    public void delete(String file) throws IOException {
        delete(file, DEFAULT_FILES_ENDPOINT);
    }

    /**
     * Lists remote folder.
     *
     * @param file remote path of the folder to list
     * @return list of folder's children files
     * @throws IOException in case of error
     */
    public List<String> list(String file) throws IOException {
        return list(file, DEFAULT_FILES_ENDPOINT);
    }

    /**
     * Return latest versionId from server
     * @param file remote file path
     * @return versionId and last modification date
     * @throws Exception in case of error
     */
    public FileVersionInfo getLatestVersion(String file) throws Exception {
        return getLatestVersion(file, DEFAULT_VERSIONS_ENDPOINT);
    }

    /**
     * Return all available versionIds from server
     * @param file remote file path
     * @return list of versionId and last modification date
     * @throws Exception in case of error
     */
    public List<FileVersionInfo> getVersions(String file) throws Exception {
        return getVersions(file, DEFAULT_VERSIONS_ENDPOINT);
    }
}
