package com.jetbrains.cloudconfig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Multiple files upload request.
 */
public class MultiUploadRequest implements AutoCloseable {
    private final Map<String, InputStream> uploads = new HashMap<>();

    /**
     * Add file for uploading.
     *
     * @param name remote name to store content under
     * @param in   file content
     * @return request itself
     */
    public MultiUploadRequest addFile(String name, InputStream in) {
        if (name == null)
            throw new IllegalArgumentException("name cannot be null");

        if (in == null)
            throw new IllegalArgumentException("input stream cannot be null");

        uploads.put(name, in);

        return this;
    }

    /**
     * Add bunch of files to upload. File names would be formed like <code>prefix + file.getName()</code>.
     *
     * @param prefix prefix to add to each file name
     * @param files  list of files to upload
     * @return request itself
     * @throws FileNotFoundException if local file cannot be found
     */
    public MultiUploadRequest addFiles(String prefix, File... files) throws FileNotFoundException {
        if (prefix == null)
            throw new IllegalArgumentException("prefix cannot be null");

        for (File file : files) {
            addFile(prefix + file.getName(), new FileInputStream(file));
        }

        return this;
    }

    public Map<String, InputStream> getUploads() {
        return uploads;
    }

    @Override
    public void close() throws Exception {
        for (Map.Entry<String, InputStream> entry : uploads.entrySet()) {
            try {
                entry.getValue().close();
            } catch (Exception e) {
                System.err.println("Error closing resource for file: " + entry.getKey());
                e.printStackTrace();
            }
        }
    }
}
