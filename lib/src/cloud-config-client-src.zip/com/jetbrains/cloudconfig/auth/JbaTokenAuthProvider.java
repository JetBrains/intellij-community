package com.jetbrains.cloudconfig.auth;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Implements JBA-Token authentication scheme.
 */
public class JbaTokenAuthProvider implements AuthProvider {
    private final String token;

    public JbaTokenAuthProvider(String token) {
        this.token = token;
    }

    @Override
    public void authenticate(HttpURLConnection connection) throws IOException {
        connection.setRequestProperty("Authorization", "JBA-Token " + token);
    }
}
