package com.jetbrains.cloudconfig.auth;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Authentication scheme provider.
 */
public interface AuthProvider {
    void authenticate(HttpURLConnection connection) throws IOException;
}
