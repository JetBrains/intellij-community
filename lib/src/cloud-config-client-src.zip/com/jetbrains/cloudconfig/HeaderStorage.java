package com.jetbrains.cloudconfig;

/**
 * Header storage interface
 */
public interface HeaderStorage {
    /**
     * Return stored header value for file with given path.
     *
     * @param path path of the file to get value for
     * @return file value or null if its value is unknown
     */
    String get(String path);

    /**
     * Store header value for file with given path.
     *
     * @param path  path of the file to store value for
     * @param value header value
     */
    void store(String path, String value);
}