rootProject.name = "cloud-config"

include(":client")
include(":service")