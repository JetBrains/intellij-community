package com.jetbrains.cloudconfig.test;


import com.jetbrains.cloudconfig.MultiUploadRequest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

/**
 * Created by dan
 */
public class CreateTest extends AbstractClientTest {

    private String subFolder = "test_files";

    @BeforeMethod
    void cleanup() throws Exception {
        client.delete("*");
    }

    @Test
    void writeUsingInputStreamTest() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;
        client.write(fullPath, new ByteArrayInputStream(testBytes));

        assertTrue(client.list(subFolder).contains(filename));
        assertEquals(new String(testBytes), asString(client.read(fullPath)));
    }

    @Test
    void writeUsingOutputStreamTest() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;

        try (OutputStream outputStream = client.write(fullPath)) {
            outputStream.write(testBytes);
        }

        assertEquals(new String(testBytes), asString(client.read(fullPath)));
    }

    @Test
    void writeUsingUploadRequestTest() throws Exception {
        MultiUploadRequest request = new MultiUploadRequest();
        request.addFile("uploaded_01.file", new ByteArrayInputStream(testBytes));
        request.addFile("uploaded_02.file", new ByteArrayInputStream(testBytes));

        client.write(subFolder, request);

        List<String> fileNames = client.list(subFolder);
        assertEquals(2, fileNames.size());

        for (String filename : fileNames) {
            assertEquals(new String(testBytes), asString(client.read(subFolder + "/" + filename)));
        }
    }

    @Test(expectedExceptions = {RuntimeException.class}, expectedExceptionsMessageRegExp = ".*(Maximum path depth exceeded).*")
    void exceedPathDepthTest() throws Exception {
        MultiUploadRequest request = new MultiUploadRequest();
        request.addFile("testFolder/uploaded_XX.file", new ByteArrayInputStream(testBytes));

        client.write(subFolder, request);
    }

    @Test(expectedExceptions = {RuntimeException.class}, expectedExceptionsMessageRegExp = ".*(Too long path).*")
    void exceedPathLengthTest() throws Exception {
        char[] ca = new char[1024];
        Arrays.fill(ca, 'A');
        String str = new String(ca);

        client.write(str, new ByteArrayInputStream(testBytes));
    }

    @Test(expectedExceptions = {RuntimeException.class}, expectedExceptionsMessageRegExp = ".*(Storage limit violation: only 524288 bytes allowed to persist).*")
    void exceedQuoteUsingStreamTest() throws Exception {
        byte[] ba = new byte[512 * 1024 + 1];
        client.write("test/file.txt", new ByteArrayInputStream(ba));
    }

    @Test(expectedExceptions = {RuntimeException.class}, expectedExceptionsMessageRegExp = ".*(Storage limit reached: 524288).*")
    void exceedQuoteUsingMultipartRequestTest() throws Exception {
        byte[] ba = new byte[512 * 1024 + 1];

        MultiUploadRequest request = new MultiUploadRequest();
        request.addFile("uploaded_max.file", new ByteArrayInputStream(ba));
        client.write(subFolder, request);
    }
}