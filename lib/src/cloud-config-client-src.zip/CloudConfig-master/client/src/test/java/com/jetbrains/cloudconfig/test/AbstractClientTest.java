package com.jetbrains.cloudconfig.test;

import com.jetbrains.cloudconfig.CloudConfigFileClient;
import com.jetbrains.cloudconfig.Configuration;
import com.jetbrains.cloudconfig.ETagStorage;
import com.jetbrains.cloudconfig.auth.JbaTokenAuthProvider;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.UUID;

class AbstractClientTest {

    protected String authToken = "dc7rt73vclx6o9p55yjbkgelu"; // linkov.denis@gmail.com
    protected String endpoint = "https://cloudconfig.jetbrains.com/cloudconfig/files";
    protected String endpointV2 = "https://stgn.cloudconfig.jetbrains.com/cloudconfig";

    protected final String authTokenEnv = System.getenv("cloud-config-token");
    protected final String endpointEnv = System.getenv("cloud-config-url");
    protected final String endpointV2Env = System.getenv("cloud-config-url-v2");

    CloudConfigFileClient client = prepareClient(
            endpointEnv != null ? endpointEnv : endpoint,
            authTokenEnv != null ? authTokenEnv : authToken
    );

    byte[] testBytes = "THIS IS A TEST CONTENT\r\n\tTHIS IS A TEST CONTENT".getBytes(StandardCharsets.UTF_8);

    protected static final ETagStorage DUMMY_ETAG_STORAGE = new ETagStorage() {
        @Override
        public String get(String path) {
            return null;
        }

        @Override
        public void store(String path, String value) {
            // do nothing
        }
    };

    private CloudConfigFileClient prepareClient(String endpoint, String token) {
        JbaTokenAuthProvider tokenProvider = new JbaTokenAuthProvider(token);
        Configuration configuration = new Configuration();
        configuration.auth(tokenProvider);
        return new CloudConfigFileClient(endpoint, configuration, DUMMY_ETAG_STORAGE);
    }

    String randomFilename() {
        return UUID.randomUUID().toString().substring(0, 8) + ".txt";
    }

    String asString(InputStream inputStream) {
        Scanner s = new Scanner(inputStream).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }
}