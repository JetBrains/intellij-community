package com.jetbrains.cloudconfig.test;

import org.testng.annotations.Test;

import java.io.ByteArrayInputStream;

import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

/**
 * Created by dan
 */
public class DeleteTest extends AbstractClientTest {

    @Test
    void deleteFileTest() throws Exception {
        String filename = randomFilename();
        client.write(filename, new ByteArrayInputStream(testBytes));
        assertTrue(client.list("").contains(filename));

        client.delete(filename);
        assertFalse(client.list("").contains(filename));
    }

    @Test
    void deleteFileInFolderTest() throws Exception {
        String folder = "to_delete";
        String filename = randomFilename();
        String fullPath = folder + "/" + filename;

        client.write(fullPath, new ByteArrayInputStream(testBytes));
        assertTrue(client.list(folder).contains(filename));

        client.delete(fullPath);
        assertFalse(client.list(folder).contains(filename));
    }

    @Test
    void deleteUserFolderTest() throws Exception {
        String folder = "to_delete";
        String filename = randomFilename();
        String fullPath = folder + "/" + filename;

        client.write(fullPath, new ByteArrayInputStream(testBytes));
        assertTrue(client.list(folder).contains(filename));

        client.delete("*");
        assertTrue(client.list("").isEmpty());
    }
}