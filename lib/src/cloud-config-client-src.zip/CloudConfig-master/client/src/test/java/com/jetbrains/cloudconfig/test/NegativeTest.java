package com.jetbrains.cloudconfig.test;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.AssertJUnit.assertTrue;

/**
 * Created by dan
 */
public class NegativeTest extends AbstractClientTest {

    @Test
    void deleteNonExistingFileTest() throws Exception {
        client.delete("non_existing_file"); // no exception is thrown
    }

    @Test(expectedExceptions = {FileNotFoundException.class})
    void readNonExistentFileTest() throws Exception {
        client.read("non_existent_file");
    }

    @Test
    void listNonExistentFolder() throws Exception {
        assertTrue(client.list("non_existent_folder").isEmpty());
    }
}