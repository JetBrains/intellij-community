package com.jetbrains.cloudconfig.test;

import com.jetbrains.cloudconfig.CloudConfigFileClientV2;
import com.jetbrains.cloudconfig.Configuration;
import com.jetbrains.cloudconfig.FileVersionInfo;
import com.jetbrains.cloudconfig.HeaderStorage;
import com.jetbrains.cloudconfig.auth.JbaTokenAuthProvider;
import com.jetbrains.cloudconfig.exception.InvalidVersionIdException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;

import static org.testng.AssertJUnit.*;

/**
 * Created by dan
 */
public class VersionedStorageTest extends AbstractClientTest {

    CloudConfigFileClientV2 clientV2 = prepareClientV2(
            endpointV2Env != null ? endpointV2Env : endpointV2,
            authTokenEnv != null ? authTokenEnv : authToken
    );

    private final String subFolder = "test_files";

    @BeforeMethod
    void cleanup() throws Exception {
        clientV2.delete("*");
    }

    @Test
    void rewriteFileWithVersioning() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;
        clientV2.write(fullPath, new ByteArrayInputStream(testBytes));

        String versionId = DUMMY_VERSION_ID_STORAGE.get(fullPath);

        assertTrue(clientV2.list(subFolder).contains(filename));
        assertNotNull(versionId);
        assertEquals(new String(testBytes), asString(clientV2.read(fullPath)));

        byte[] modifiedBytes = "UPDATED CONTENT FOR THE FILE".getBytes(StandardCharsets.UTF_8);

        clientV2.write(fullPath, new ByteArrayInputStream(modifiedBytes));
        String nextVersionId = DUMMY_VERSION_ID_STORAGE.get(fullPath);
        assertNotSame(versionId, nextVersionId);
    }

    @Test
    void getLatestFileVersion() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;
        clientV2.write(fullPath, new ByteArrayInputStream(testBytes));

        String versionId = DUMMY_VERSION_ID_STORAGE.get(fullPath);
        assertNotNull(versionId);

        String versionIdOnServer = clientV2.getLatestVersion(fullPath).getVersionId();
        assertEquals(versionId, versionIdOnServer);
    }

    @Test
    void getFileVersionList() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;

        byte[] modifiedBytes = "UPDATED CONTENT FOR THE FILE".getBytes(StandardCharsets.UTF_8);
        clientV2.write(fullPath, new ByteArrayInputStream(testBytes));
        clientV2.write(fullPath, new ByteArrayInputStream(modifiedBytes));

        String versionId = DUMMY_VERSION_ID_STORAGE.get(fullPath);
        assertNotNull(versionId);

        List<FileVersionInfo> versions = clientV2.getVersions(fullPath);
        assertEquals(2, versions.size());
        assertEquals(versionId, versions.get(0).getVersionId());
    }

    @Test
    void getLatestVersionForNonExistingFile() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;

        FileVersionInfo fileVersionInfo = clientV2.getLatestVersion(fullPath);
        assertNull(fileVersionInfo);
    }

    @Test(expectedExceptions = {InvalidVersionIdException.class})
    void attemptToWriteFileWithAnotherVersionId() throws Exception {
        String filename = randomFilename();
        String fullPath = subFolder + "/" + filename;
        clientV2.write(fullPath, new ByteArrayInputStream(testBytes));

        String versionId = DUMMY_VERSION_ID_STORAGE.get(fullPath);
        assertNotNull(versionId);
        DUMMY_VERSION_ID_STORAGE.store(fullPath, versionId + "_other");

        byte[] modifiedBytes = "UPDATED CONTENT FOR THE FILE".getBytes(StandardCharsets.UTF_8);

        clientV2.write(fullPath, new ByteArrayInputStream(modifiedBytes));
    }

    private static final HeaderStorage DUMMY_VERSION_ID_STORAGE = new HeaderStorage() {
        private final HashMap<String, String> storage = new HashMap<>();
        @Override
        public String get(String path) {
            return storage.get(path);
        }

        @Override
        public void store(String path, String value) {
            storage.put(path, value);
        }
    };

    private CloudConfigFileClientV2 prepareClientV2(String endpoint, String token) {
        JbaTokenAuthProvider tokenProvider = new JbaTokenAuthProvider(token);
        Configuration configuration = new Configuration();
        configuration.auth(tokenProvider);
        return new CloudConfigFileClientV2(endpoint, configuration, DUMMY_ETAG_STORAGE, DUMMY_VERSION_ID_STORAGE);
    }
}
