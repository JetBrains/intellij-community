package com.jetbrains.cloudconfig;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FileVersionInfo {
    private String versionId;
    private String lastModified;
    private String isLatest;

    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z");

    public String getVersionId() {
        return versionId;
    }

    public Date getModifiedDate() {
        return new Date(Long.parseLong(lastModified));
    }

    public Boolean isLatest() {
        return Boolean.parseBoolean(isLatest);
    }

    @Override
    public String toString() {
        return "FileVersionInfo['" + versionId + "', '" + sdf.format(getModifiedDate()) + "', '" + isLatest + "']";
    }
}
