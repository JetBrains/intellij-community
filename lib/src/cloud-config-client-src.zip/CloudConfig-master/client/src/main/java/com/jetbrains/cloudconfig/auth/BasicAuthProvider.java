package com.jetbrains.cloudconfig.auth;

import com.jetbrains.cloudconfig.CloudConfigFileClient;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Base64;

/**
 * Implements Basic HTTP authentication scheme.
 * The service should support this scheme to authenticate.
 */
public class BasicAuthProvider implements AuthProvider {
    private final String username;
    private final String password;

    public BasicAuthProvider(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public void authenticate(HttpURLConnection connection) throws IOException {
        connection.setRequestProperty(
                "Authorization",
                "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes(CloudConfigFileClient.ENCODING))
        );
    }
}
