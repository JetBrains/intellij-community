package com.jetbrains.cloudconfig.auth;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Doesn't do any authentication.
 */
public class NoAuthProvider implements AuthProvider {
    public static final AuthProvider INSTANCE = new NoAuthProvider();

    private NoAuthProvider() {
        // do nothing
    }

    @Override
    public void authenticate(HttpURLConnection connection) throws IOException {
        // do nothing
    }
}
