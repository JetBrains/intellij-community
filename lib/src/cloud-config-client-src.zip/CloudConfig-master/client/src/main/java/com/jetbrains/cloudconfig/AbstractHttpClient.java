package com.jetbrains.cloudconfig;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jetbrains.cloudconfig.exception.AccessDeniedException;
import com.jetbrains.cloudconfig.exception.InvalidVersionIdException;
import com.jetbrains.cloudconfig.exception.UnauthorizedException;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.zip.DeflaterInputStream;
import java.util.zip.GZIPInputStream;

/**
 * Base class for HTTP clients.
 */
abstract class AbstractHttpClient {
    static final String OCTET_STREAM_CONTENT_TYPE = "application/octet-stream";
    static final String MULTIPART_CONTENT_TYPE = "multipart/form-data";

    static final String CONTENT_TYPE_HEADER_NAME = "Content-Type";
    static final String IF_NONE_MATCH_HEADER_NAME = "If-None-Match";
    static final String ETAG_HEADER_NAME = "ETag";
    static final String VERSION_ID_HEADER_NAME = "Version-Id";

    static final String ACCEPT_ENC_HEADER_NAME = "Accept-Encoding";
    static final String CONTENT_ENC_HEADER_NAME = "Content-Encoding";

    static final String DEFLATE_METHOD_NAME = "deflate";
    static final String GZIP_METHOD_NAME = "gzip";

    static final String HTTP_GET = "GET";
    static final String HTTP_PUT = "PUT";
    static final String HTTP_DELETE = "DELETE";
    static final String HTTP_OPTIONS = "OPTIONS";

    public static final String ENCODING = "UTF-8";

    protected static final Gson GSON = new GsonBuilder().serializeNulls().create();

    protected final String endpoint;

    protected final Configuration config;

    /**
     * Creates client instance with default configuration.
     *
     * @param endpoint service URL address, e.g. "http://example.com/cloudconfig"
     */
    protected AbstractHttpClient(String endpoint) {
        this(endpoint, new Configuration());
    }

    /**
     * Created client instance with given configuration.
     *
     * @param endpoint service URL address, e.g. "http://example.com/cloudconfig"
     * @param config   client configuration
     */
    protected AbstractHttpClient(String endpoint, Configuration config) {
        if (!endpoint.matches("^https?://.*$")) {
            throw new IllegalArgumentException("Invalid protocol: " + endpoint);
        }

        if (config == null) {
            throw new IllegalArgumentException("Client configuration must be passed");
        }

        this.endpoint = endpoint.replaceFirst("/+$", "");
        this.config = config;
    }

    protected <T> T download(String method,
                             URL url,
                             Map<String, String> props,
                             ResponseParser<T> parser,
                             boolean closeStream) throws IOException {
        HttpURLConnection connection = config.openConnection(url);

        for (Map.Entry<String, String> entry : props.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }

        connection.setRequestProperty(ACCEPT_ENC_HEADER_NAME, GZIP_METHOD_NAME + ", " + DEFLATE_METHOD_NAME);

        connection.setRequestMethod(method);

        InputStream in;

        try {
            in = connection.getInputStream();
        } catch (IOException e) {
            if (connection.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED)
                throw new UnauthorizedException("Invalid credentials", e);
            else if (connection.getResponseCode() == HttpURLConnection.HTTP_FORBIDDEN)
                throw new AccessDeniedException("Access denied for given credentials", e);
            else
                throw e;
        }

        try {
            String responseEncoding = connection.getHeaderField(CONTENT_ENC_HEADER_NAME);

            if (GZIP_METHOD_NAME.equalsIgnoreCase(responseEncoding))
                in = new GZIPInputStream(in);
            else if (DEFLATE_METHOD_NAME.equalsIgnoreCase(responseEncoding))
                in = new DeflaterInputStream(in);

            return parser.parse(connection.getResponseCode(), connection.getHeaderFields(), in);
        } finally {
            if (closeStream) closeSafely(in);
        }
    }

    protected void upload(String method, URL url, Map<String, String> props, StreamWriter writer,
                          ResponseParser parser, int expectedStatus) throws IOException {
        HttpURLConnection connection = config.openConnection(url);

        for (Map.Entry<String, String> entry : props.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }

        connection.setRequestMethod(method);

        connection.setDoOutput(true);

        OutputStream out = connection.getOutputStream();

        try {
            writer.write(out);

            assertSuccess(connection, expectedStatus);

            if (parser != null) {
                InputStream in = null;
                try {
                    in = connection.getInputStream();
                    parser.parse(connection.getResponseCode(), connection.getHeaderFields(), in);
                } finally {
                    if (in != null) closeSafely(in);
                }
            }
        } finally {
            closeSafely(out);
        }
    }

    protected void assertSuccess(HttpURLConnection connection, int expectedStatus) throws IOException {
        int responseCode = connection.getResponseCode();

        if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED)
            throw new UnauthorizedException("Failed to authenticate with given credentials");
        else if (responseCode == HttpURLConnection.HTTP_FORBIDDEN)
            throw new AccessDeniedException("Access denied for given credentials");
        else if (responseCode == 417)
            throw new InvalidVersionIdException("VersionId differs from the last available on server");
        else if (responseCode != expectedStatus) {
            String message = "";

            InputStream errorStream = connection.getErrorStream();

            if (errorStream != null) try {
                Scanner scanner = new Scanner(errorStream).useDelimiter("\\A");

                if (scanner.hasNext())
                    message = scanner.next();

                @SuppressWarnings("ThrowableResultOfMethodCallIgnored")
                IOException ioException = scanner.ioException();

                if (ioException != null) {
                    System.err.println("Failed to read error message");
                    ioException.printStackTrace();
                }
            } finally {
                closeSafely(errorStream);
            }

            throw new RuntimeException(String.format("Unexpected response (code: %s, message: %s)",
                    responseCode, message));
        }
    }

    protected void closeSafely(Closeable closeable) {
        try {
            closeable.close();
        } catch (IOException e) {
            System.err.println("Failed to close resource");
            e.printStackTrace();
        }
    }

    protected void drainStream(InputStream source, OutputStream dest) throws IOException {
        int read;
        byte[] buf = new byte[8192];
        while ((read = source.read(buf)) != -1) {
            dest.write(buf, 0, read);
        }
    }

    protected interface ResponseParser<T> {
        T parse(int statusCode, Map<String, List<String>> headers, InputStream stream) throws IOException;
    }

    protected interface StreamWriter {
        void write(OutputStream stream) throws IOException;
    }
}