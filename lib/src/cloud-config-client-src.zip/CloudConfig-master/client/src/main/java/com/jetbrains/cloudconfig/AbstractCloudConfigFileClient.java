package com.jetbrains.cloudconfig;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

abstract class AbstractCloudConfigFileClient extends AbstractHttpClient {

    protected ETagStorage eTagStorage = DUMMY_ETAG_STORAGE;
    protected HeaderStorage versionIdStorage = null;

    protected AbstractCloudConfigFileClient(String endpoint) {
        super(endpoint);
    }

    protected AbstractCloudConfigFileClient(String endpoint, Configuration config) {
        super(endpoint, config);
    }

    protected InputStream read(String file, FilesEndpoint serviceEndpoint) throws IOException {
        return download(HTTP_GET, url(file, serviceEndpoint), new HashMap<>() {{
            put(CONTENT_TYPE_HEADER_NAME, OCTET_STREAM_CONTENT_TYPE);

            String etag = eTagStorage.get(file);
            if (eTagStorage != null && etag != null) {
                put(IF_NONE_MATCH_HEADER_NAME, etag);
            }

            String versionId = getVersionId(file);
            if (versionId != null) {
                put(VERSION_ID_HEADER_NAME, versionId);
            }
        }}, (statusCode, headers, stream) -> {
            if (statusCode == HttpURLConnection.HTTP_NOT_MODIFIED) {
                closeSafely(stream);
                return null;
            }

            saveEtag(headers, file);
            saveVersionId(headers, file);

            return stream;
        }, false);
    }

    protected void write(String file, InputStream content, FilesEndpoint serviceEndpoint) throws IOException {
        upload(HTTP_PUT, url(file, serviceEndpoint), new HashMap<>() {{
            put(CONTENT_TYPE_HEADER_NAME, OCTET_STREAM_CONTENT_TYPE);
            String versionId = getVersionId(file);
            if (versionId != null) {
                put(VERSION_ID_HEADER_NAME, versionId);
            }
        }}, stream -> drainStream(content, stream), (statusCode, headers, stream) -> {
            saveEtag(headers, file);
            saveVersionId(headers, file);
            return null;
        }, HttpURLConnection.HTTP_NO_CONTENT);
    }

    public void delete(String file, FilesEndpoint serviceEndpoint) throws IOException {
        HttpURLConnection connection = config.openConnection(url(file, serviceEndpoint));
        connection.setRequestMethod(HTTP_DELETE);
        assertSuccess(connection, HttpURLConnection.HTTP_NO_CONTENT);
    }

    public List<String> list(String file, FilesEndpoint serviceEndpoint) throws IOException {
        return download(HTTP_OPTIONS, url(file, serviceEndpoint), Collections.emptyMap(), (statusCode, headers, stream) -> {
            //noinspection unchecked
            return GSON.fromJson(new InputStreamReader(stream), List.class);
        }, true);
    }

    protected FileVersionInfo getLatestVersion(String file, VersionsEndpoint serviceEndpoint) throws IOException {
        return download(
                HTTP_GET,
                url(file, serviceEndpoint),
                Collections.emptyMap(),
                (statusCode, headers, stream) -> GSON.fromJson(new InputStreamReader(stream), FileVersionInfo.class),
                true
        );
    }

    protected List<FileVersionInfo> getVersions(String file, VersionsEndpoint serviceEndpoint) throws Exception {
        return download(
                HTTP_OPTIONS,
                url(file, serviceEndpoint),
                Collections.emptyMap(),
                (statusCode, headers, stream) -> Arrays.asList(GSON.fromJson(new InputStreamReader(stream), FileVersionInfo[].class)),
                true
        );
    }

    protected URL url(String path, ServiceEndpoint serviceEndpoint) throws IOException {
        if (serviceEndpoint != null) {
            return new URL(String.format("%s/%s/%s", endpoint, serviceEndpoint.subdirectory, path.replaceFirst("^/", "")));
        } else {
            return new URL(String.format("%s/%s", endpoint, path.replaceFirst("^/", "")));
        }
    }

    private void saveEtag(Map<String, List<String>> headers, String file) {
        List<String> etag = headers.get(ETAG_HEADER_NAME);

        if (etag != null && etag.size() == 1) {
            eTagStorage.store(file, etag.get(0));
        }
    }

    private void saveVersionId(Map<String, List<String>> headers, String file) {
        List<String> versionId = headers.get(VERSION_ID_HEADER_NAME);

        if (versionIdStorage != null && versionId != null && versionId.size() == 1) {
            versionIdStorage.store(file, versionId.get(0));
        }
    }

    private String getVersionId(String path) {
        return versionIdStorage != null ? versionIdStorage.get(path) : null;
    }

    protected static final ETagStorage DUMMY_ETAG_STORAGE = new ETagStorage() {
        @Override
        public String get(String path) {
            return null;
        }

        @Override
        public void store(String path, String value) {
            // do nothing
        }
    };
}