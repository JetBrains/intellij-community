version = rootProject.version

plugins {
    `java-library`
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(11))
    }
}

tasks.jar {
    archiveBaseName.set("cloud-config-client")
}

tasks.test {
    useTestNG()
}

dependencies {
    implementation("com.google.code.gson", "gson", "2.8.8")
    testImplementation("org.testng", "testng", "7.4.0")
}