[![internal JetBrains project](http://jb.gg/badges/internal.svg)](https://confluence.jetbrains.com/display/ALL/JetBrains+on+GitHub)

# CloudConfig
JetBrains Cloud Config Service