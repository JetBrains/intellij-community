group = "com.jetbrains.cloudconfig"

allprojects {
    repositories {
        mavenCentral()
        maven("https://repo.labs.intellij.net/intdev") {
            metadataSources {
                mavenPom()
                artifact()
            }
        }
    }
}