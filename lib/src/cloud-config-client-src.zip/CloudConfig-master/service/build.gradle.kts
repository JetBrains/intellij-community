version = rootProject.version

plugins {
    kotlin("jvm") version "1.5.31"
    war
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(8))
    }
}

tasks.processResources {
    val baseConfFile = file("src/main/resources/build.version")
    val buildNumber = System.getenv("BUILD_NUMBER") ?: "dev_build"
    val content = baseConfFile.readText().replace("@SNAPSHOT@", buildNumber)
    baseConfFile.writeText(content)
}

tasks.war {
    archiveBaseName.set("cloud-config")
}

tasks.test {
    useTestNG()
}

dependencies {
    compileOnly("javax.servlet", "javax.servlet-api", "3.1.0")
    implementation("org.jetbrains.kotlin", "kotlin-reflect", "1.5.31")
    implementation("kara", "kara", "0.1.25") {
        exclude("org.jetbrains.kotlin")
    }
    implementation("com.fasterxml.jackson.module", "jackson-module-kotlin", "2.12.5")
    implementation("com.amazonaws", "aws-java-sdk-s3", "1.12.70")
    implementation("org.slf4j", "slf4j-api", "1.7.32")
    implementation("org.slf4j", "slf4j-log4j12", "1.7.32") {
        exclude("log4j", "log4j")
    }

    testImplementation("io.rest-assured", "rest-assured", "4.4.0")
    testImplementation("org.eclipse.jetty.aggregate", "jetty-all", "9.4.43.v20210629")
    testImplementation("org.testng", "testng", "7.4.0")
    testImplementation("log4j", "log4j", "1.2.17")
    testImplementation("org.apache.tomcat", "tomcat-catalina", "8.5.71")
    testImplementation("org.apache.tomcat", "tomcat-util", "8.5.71")
}


