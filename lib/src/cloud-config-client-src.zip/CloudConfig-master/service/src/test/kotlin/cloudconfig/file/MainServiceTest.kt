package cloudconfig.file

import cloudconfig.EnvironmentConfigurator
import cloudconfig.JbaTokenAuthScheme
import cloudconfig.http.Header
import cloudconfig.http.StorageAction
import cloudconfig.http.v2.VersionWebService
import cloudconfig.storage.AmazonS3FileStorage
import cloudconfig.storage.FileVersion
import io.restassured.RestAssured
import io.restassured.RestAssured.`when`
import io.restassured.RestAssured.given
import io.restassured.http.ContentType
import org.hamcrest.Matchers
import org.testng.Assert.assertNotEquals
import org.testng.AssertJUnit.*
import org.testng.annotations.AfterClass
import org.testng.annotations.BeforeClass
import org.testng.annotations.Test
import java.util.*
import cloudconfig.http.v1.FileWebService as FileWebServiceV1
import cloudconfig.http.v2.FileWebService as FileWebServiceV2

class MainServiceTest : AbstractFileServiceTest() {
    companion object : EnvironmentConfigurator() {
        val MAX_PATH_LEN: Int
            get() =
                AmazonS3FileStorage.MAX_PATH_LEN -
                        AmazonS3FileStorage.prefix.length -
                        "/${user01.username}".length
    }

    @BeforeClass fun setup() {
        setupEnvironment()

        // configure authentication
        RestAssured.authentication = JbaTokenAuthScheme(user01)

        // log failed requests
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails()
    }

    @AfterClass fun shutdown() {
        shutdownEnvironment()

        // restore auth scheme to default
        RestAssured.authentication = RestAssured.DEFAULT_AUTH
    }

    @Test fun testGetWithoutPath() {
        `when`().
            get("").
        then().
            statusCode(404)
    }

    @Test fun testSimplePutAndGetV1() {
        val BODY = "Hello World! V1"

        fun test(file: String) {
            given().
                body(BODY).
            `when`().
                put(file).
            then().
                statusCode(204).
                header(Header.ETAG, Matchers.notNullValue())

            `when`().
                get(file).
            then().
                statusCode(200).
                header(Header.ETAG, Matchers.notNullValue()).
                body(BODY)
        }

        listOf(TOP_LEVEL_FILE, SECOND_LEVEL_FILE).forEach(::test)
    }

    @Test fun `v2 - test put and get`() {
        val BODY = "Hello World! V2"

        fun test(file: String) {
            val versionId =
                given()
                    .body(BODY)
                .`when`()
                    .put(file)
                .then()
                    .statusCode(204)
                    .header(Header.ETAG, Matchers.notNullValue())
                    .header(Header.VERSION_ID, Matchers.notNullValue())
                    .extract().header(Header.VERSION_ID)

            given()
                .header(Header.VERSION_ID, versionId)
            .`when`()
                .get(file)
            .then()
                .statusCode(200)
                .header(Header.ETAG, Matchers.notNullValue())
                .header(Header.VERSION_ID, Matchers.nullValue())
                .body(BODY)
        }

        val namespaceV2 = FileWebServiceV2.NAMESPACE
        listOf(
            "$namespaceV2/topLevelFile",
            "$namespaceV2/topLevel/secondLevelFile",
        ).forEach(::test)
    }

    @Test fun `v2 - list file versions`() {
        val BODY = "Hello World! V2"
        val fileNamespaceV2 = FileWebServiceV2.NAMESPACE
        val versionsNamespace = VersionWebService.NAMESPACE

        fun test(file: String) {

            val versionId =
                given()
                    .body(BODY)
                .`when`()
                    .put("$fileNamespaceV2/$file")
                .then()
                    .statusCode(204)
                    .header(Header.ETAG, Matchers.notNullValue())
                    .header(Header.VERSION_ID, Matchers.notNullValue())
                    .extract().header(Header.VERSION_ID)

            val fileVersions =
                `when`()
                    .options("$versionsNamespace/$file")
                .then()
                    .statusCode(200)
                    .extract().body().`as`(Array<FileVersion>::class.java)

            assertEquals(versionId, fileVersions.singleOrNull()?.versionId)
        }

        listOf(
            "topLevelFile",
            "topLevel/secondLevelFile",
        ).forEach(::test)
    }

    @Test
    fun `v2 - test wrong version-id header passed`() {
        val BODY = "Hello World! V2"

        fun test(file: String) {
            given()
                .body(BODY)
            .`when`()
                .put(file)
            .then()
                .statusCode(204)
                .header(Header.ETAG, Matchers.notNullValue())
                .header(Header.VERSION_ID, Matchers.notNullValue())
                .extract().header(Header.VERSION_ID)

            given()
                .header(Header.VERSION_ID, "wrong_version_id")
            .`when`()
                .get(file)
            .then()
                .statusCode(404)
        }

        val namespaceV2 = FileWebServiceV2.NAMESPACE
        listOf(
            "$namespaceV2/topLevelFile",
            "$namespaceV2/topLevel/secondLevelFile",
        ).forEach(::test)
    }

    @Test fun testPathDepthRestriction() {
        given().
            body("Hello World").
        `when`().
            put(THIRD_LEVEL_FILE).
        then().
            statusCode(404)

        `when`().
            put(THIRD_LEVEL_FILE).
        then().
            statusCode(404)

        `when`().
            options(THIRD_LEVEL_FILE).
        then().
            statusCode(404)

        `when`().
            delete(THIRD_LEVEL_FILE).
        then().
            statusCode(404)
    }

    @Test fun testCornerCaseSizeUploads() {
        fun test(body: ByteArray) {
            given().
                body(body).
            `when`().
                put(TOP_LEVEL_FILE).
            then().
                statusCode(204)

            val topLevelFileContent =
                `when`().get(TOP_LEVEL_FILE).then().statusCode(200).extract().asByteArray()

            assertEquals(body.size, topLevelFileContent.size)
            assertTrue(body.contentEquals(topLevelFileContent))
        }

        listOf(ByteArray(0), RandomCode.nextBytes(StorageAction.QUOTE_SIZE)).forEach(::test)
    }

    @Test fun testAvailableFileNamesForUpload() {
        fun test(file: String, expected: Int) {
            given().
                body("Hello World").
            `when`().
                put(FileWebServiceV1.NAMESPACE + file).
            then().
                statusCode(expected)
        }

        fun shouldFail(file: String) = test(file, 400)
        fun shouldSucceed(file: String) = test(file, 204)
        fun shouldNotFound(file: String) = test(file, 404)

        val FOLDER = "/folder/"

        listOf("/a", "/!", "/!/!", "/a/a", "/*f()l.d!e'r/*f!l.()e'", "/" + longString(MAX_PATH_LEN - 1),
                FOLDER + longString(MAX_PATH_LEN - FOLDER.length)).forEach(::shouldSucceed)

        listOf("", "/", "/fi&le", "/folder%/*!23", "/a//a", "/" + longString(MAX_PATH_LEN))
                .forEach(::shouldFail)

        listOf("!", "//", "//a", "//a/a").forEach(::shouldNotFound)
    }

    @Test fun testTrailingSlashOnUpload() {
        val BODY = "Hello World!"
        val PATH = FileWebServiceV1.NAMESPACE + "/config"
        val SLASHED_PATH = "$PATH/"

        given().
            body(BODY).
        `when`().
            put(SLASHED_PATH).
        then().
            statusCode(204)

        `when`().
            get(PATH).
        then().
            statusCode(200).
            body(BODY)

        `when`().
            get(SLASHED_PATH).
        then().
            statusCode(200)  // on question
    }

    @Test fun testUpdate() {
        fun test(path: String) {
            val prevEtag = given().
                body("original").
            `when`().
                put(path).
            then().
                statusCode(204).
                extract().header(Header.ETAG)

            val newEtag = given().
                body("updated").
            `when`().
                put(path).
            then().
                statusCode(204).
                extract().header(Header.ETAG)

            val getEtag = `when`().
                get(path).
            then().
                statusCode(200).
                body("updated").
                extract().header(Header.ETAG)

            assertNotEquals(prevEtag, newEtag)
            assertEquals(getEtag, newEtag)
        }

        listOf(TOP_LEVEL_FILE, SECOND_LEVEL_FILE).forEach(::test)
    }

    @Test fun testRemove() {
        fun test(path: String) {
            given().
                body("original").
            `when`().
                put(path).
            then().
                statusCode(204)

            `when`().
                delete(path).
            then().
                statusCode(204)

            `when`().
                get(path).
            then().
                statusCode(404)
        }

        listOf(TOP_LEVEL_FILE, SECOND_LEVEL_FILE).forEach(::test)
    }

    @Test fun testRemoveNonExistentFile() {
        `when`().delete(TOP_LEVEL_FILE).then().statusCode(204)
    }

    @Test fun testEmptyListings() {
        fun test(path: String) {
            `when`().
                options(path).
            then().
                statusCode(200).
                contentType(ContentType.JSON).
                body("[]")
        }

        listOf(ROOT_PATH, ROOT_PATH + "folder", ROOT_PATH + "folder/").forEach(::test)
    }

    @Test fun testSecondLevelListing() {
        `when`().options(ROOT_PATH + "folder/folder").then().statusCode(404)
        `when`().options(ROOT_PATH + "folder/folder/").then().statusCode(404)
    }

    @Test fun testListingHierarchy() {
        given().
            body("here is a top-level file").
        `when`().
            put(TOP_LEVEL_FILE).
        then().
            statusCode(204)

        given().
            body("here is a second-level file").
        `when`().
            put(SECOND_LEVEL_FILE).
        then().
            statusCode(204)

        given().
            body("here is a second (sic!) second-level file").
        `when`().
            put(SECOND_LEVEL_FILE2).
        then().
            statusCode(204)

        val topLevelListing = `when`().
            options(ROOT_PATH).
        then().
            statusCode(200).
            contentType(ContentType.JSON).
            body("""size()""", Matchers.equalTo(2))
            .extract().`as`(Set::class.java)

        val FOLDER = SECOND_LEVEL_FILE.substringBeforeLast("/").substringAfterLast("/") + "/"

        assertEquals(setOf(TOP_LEVEL_FILE.substringAfterLast("/"), FOLDER), topLevelListing)

        val folderListing = `when`().
            options(ROOT_PATH + FOLDER).
        then().
            statusCode(200).
            contentType(ContentType.JSON).
            body("""size()""", Matchers.equalTo(2))
            .extract().`as`(Set::class.java)

        assertEquals(setOf(
                SECOND_LEVEL_FILE.substringAfterLast("/"),
                SECOND_LEVEL_FILE2.substringAfterLast("/")
        ), folderListing)
    }

    @Test fun testQuoteViolation() {
        assert(StorageAction.QUOTE_SIZE % 2 == 0)

        val SIZE = StorageAction.QUOTE_SIZE / 2

        given().
            body(RandomCode.nextBytes(SIZE)).
        `when`().
            put(TOP_LEVEL_FILE).
        then().
            statusCode(204)

        given().
            body(RandomCode.nextBytes(SIZE)).
        `when`().
            put(SECOND_LEVEL_FILE).
        then().
            statusCode(204)

        given().
            body("a").
        `when`().
            put(SECOND_LEVEL_FILE2).
        then().
            statusCode(400).
            body(Matchers.containsString("Storage limit violation"))
    }

    @Test fun testQuoteViolationOnRewrite() {
        given().
            body(RandomCode.nextBytes(StorageAction.QUOTE_SIZE)).
        `when`().
            put(TOP_LEVEL_FILE).
        then().
            statusCode(204)

        given().
            body("a").
        `when`().
            put(TOP_LEVEL_FILE).
        then().
            statusCode(204)
    }

    @Test fun testMultipartUploadSingleFile() {
        val CONTENT = "Hello World!"
        val FILENAME = "file1.txt"
        val CONTROL_NAME = "control"

        fun test(path: String) {
            given().
                multiPart(CONTROL_NAME, FILENAME, CONTENT.toByteArray()).
            `when`().
                put(path).
            then().
                statusCode(200).
                hasProperties(1)

            `when`().
                get(path + CONTROL_NAME).
            then().
                statusCode(200).
                body(CONTENT)
        }

        listOf(ROOT_PATH, SECOND_LEVEL_FILE.substringBeforeLast("/") + "/").forEach(::test)
    }

    @Test fun testMultipartUploadSeveralFiles() {
        val filename1 = "file1.txt"
        val filename2 = "file2.txt"

        val content1 = "Hello World!"
        val content2 = "Hello World!!!"

        fun test(path: String) {
            given().
                multiPart(filename1, "dummy1", content1.toByteArray()).
                multiPart(filename2, "dummy2", content2.toByteArray()).
            `when`().
                put(path).
            then().
                statusCode(200).
                hasProperties(2)

            `when`().
                get(path + filename1).
            then().
                statusCode(200).
                body(content1)

            `when`().
                get(path + filename2).
            then().
                statusCode(200).
                body(content2)
        }

        listOf(ROOT_PATH, SECOND_LEVEL_FILE.substringBeforeLast("/") + "/").forEach(::test)
    }

    @Test fun testMultipartWithWrongContentType() {
        `when`().put(ROOT_PATH).then().statusCode(400)
    }

    @Test fun testMultipartContentCorrectness() {
        val filename = "file1.txt"

        fun test(content: ByteArray) {
            given().
                multiPart(filename, filename, content).
            `when`().
                put(ROOT_PATH).
            then().
                statusCode(200)

            assertTrue(Arrays.equals(
                content,

                `when`().
                    get(ROOT_PATH + filename).
                then().
                    statusCode(200).
                    extract().asByteArray()
            ))
        }

        test(ByteArray(0))
        test(RandomCode.nextBytes(StorageAction.QUOTE_SIZE))
    }

    @Test fun testMultipartWithDifferentLevelNames() {
        val filename1 = "file1.txt"
        val filename2 = "folder/file2.txt"

        val content1 = "Hello World!"
        val content2 = "Hello World!!!"

        val response = given().
            multiPart(filename1, "dummy1", content1.toByteArray()).
            multiPart(filename2, "dummy2", content2.toByteArray()).
        `when`().
            put(ROOT_PATH).
        then().
            statusCode(200).
            hasProperties(2).
            extract().`as`(Map::class.java)

        assertNotNull(response["/$filename1"])
        assertNotNull(response["/$filename2"])

        `when`().
            get(ROOT_PATH + filename1).
        then().
            statusCode(200).
            body(content1)

        `when`().
            get(ROOT_PATH + filename2).
        then().
            statusCode(200).
            body(content2)
    }

    @Test fun testMultipartUploadNameRestrictions() {
        fun test(path: String, name: String, expected: Int) {
            given().
                multiPart(name, name, "Hello World!").
            `when`().
                put(path).
            then().
                statusCode(expected)
        }

        fun shouldSucceed(path: String, name: String) = test(path, name, 200)
        fun shouldFailed(path: String, name: String) = test(path, name, 400)

        val FOLDER = SECOND_LEVEL_FILE.substringBeforeLast("/") + "/"

        shouldSucceed(ROOT_PATH, "a")
        shouldSucceed(ROOT_PATH, "!")
        shouldSucceed(ROOT_PATH, "file1.txt")
        shouldSucceed(ROOT_PATH, "folder/file1.txt")
        shouldSucceed(ROOT_PATH, "folder/!")
        shouldSucceed(ROOT_PATH, "!fil-e1()'.txt")
        shouldSucceed(ROOT_PATH, "folder/!fil-e1()'.txt")
        shouldSucceed(FOLDER, "!fil-e1()'.txt")
        shouldSucceed(ROOT_PATH, longString(MAX_PATH_LEN - 1))
        shouldSucceed(ROOT_PATH, "folder/" + longString(MAX_PATH_LEN - 8))

        shouldFailed(ROOT_PATH, "file&1.txt")
        shouldFailed(ROOT_PATH, "fold&er/file1.txt")
        shouldFailed(ROOT_PATH, "file1.txt/")
        shouldFailed(ROOT_PATH, "folder/file1.txt/")
        shouldFailed(ROOT_PATH, longString(MAX_PATH_LEN))
        shouldFailed(ROOT_PATH, "folder/" + longString(MAX_PATH_LEN - 7))
        shouldFailed(FOLDER, "file.txt/")
        shouldFailed(FOLDER, "file&.txt")
        shouldFailed(FOLDER, "folder/file.txt")
    }

    @Test fun testMultipartUploadQuoteRestrictions() {
        test(ROOT_PATH, listOf(
              File("file1.txt", RandomCode.nextBytes(StorageAction.QUOTE_SIZE)),
              File("file2.txt", ByteArray(0))
        ), 200)

        AmazonS3FileStorage.clear()

        assert(StorageAction.QUOTE_SIZE % 2 == 0)

        val halfQuote = StorageAction.QUOTE_SIZE / 2

        test(ROOT_PATH, listOf(
                File("file1.txt", RandomCode.nextBytes(halfQuote)),
                File("file2.txt", RandomCode.nextBytes(halfQuote))
        ), 200)

        AmazonS3FileStorage.clear()

        test(ROOT_PATH, listOf(
                File("file1.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file2.txt", RandomCode.nextBytes(halfQuote))
        ), 200)

        AmazonS3FileStorage.clear()

        test(ROOT_PATH, listOf(
                File("file1.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file2.txt", RandomCode.nextBytes(halfQuote + 1))
        ), 400)

        AmazonS3FileStorage.clear()

        test(ROOT_PATH, listOf(
                File("file1.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file2.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file3.txt", ByteArray(1))
        ), 400)
    }

    @Test fun testMultipartUpdateQuoteRestriction() {
        val halfQuote = StorageAction.QUOTE_SIZE / 2

        test(ROOT_PATH, listOf(
                File("file1.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file2.txt", RandomCode.nextBytes(10))
        ), 200)

        test(ROOT_PATH, listOf(
                File("folder/file2.txt", RandomCode.nextBytes(halfQuote))
        ), 200)
    }

    @Test fun testFullStorageOverwrite() {
        assert(StorageAction.QUOTE_SIZE % 2 == 0)

        val halfQuote = StorageAction.QUOTE_SIZE / 2

        (1..2).forEach {
            given().
                multiPart("file1.txt", "dummy1", RandomCode.nextBytes(halfQuote)).
                multiPart("folder/file2.txt", "dummy2", RandomCode.nextBytes(halfQuote)).
            `when`().
                put(ROOT_PATH).
            then().
                statusCode(200).
                hasProperties(2)
        }
    }

    @Test fun testMultipartTransactional() {
        assert(StorageAction.QUOTE_SIZE % 2 == 0)

        val halfQuote = StorageAction.QUOTE_SIZE / 2

        val files = listOf(
                File("file1.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file2.txt", RandomCode.nextBytes(halfQuote)),
                File("folder/file3.txt", ByteArray(1))
        )

        test(ROOT_PATH, files, 400)

        for (file in files) {
            `when`().
                get(ROOT_PATH + file.filename).
            then().
                statusCode(404)
        }
    }

    private class File(val filename: String, val content: ByteArray)

    private fun test(path: String, files: List<File>, expectedStatus: Int) {
        var request = given()

        for (file in files) {
            request = request.multiPart(file.filename, file.filename, file.content)
        }

        request.`when`().put(path).then().statusCode(expectedStatus)
    }
}