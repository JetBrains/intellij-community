package cloudconfig.file

import cloudconfig.User
import cloudconfig.http.ContentType
import javax.servlet.annotation.WebServlet
import javax.servlet.http.HttpServlet
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

object AuthServiceMock {

    val userList = mutableSetOf<User>()

    @WebServlet("/")
    class AuthServiceServlet : HttpServlet() {

        override fun doPost(request: HttpServletRequest, response: HttpServletResponse) = with(response) {

            when (val resolvedUser = request.getParameter("uid")?.let { uid -> userList.firstOrNull { it.uid == uid } }) {
                null -> sendError(HttpServletResponse.SC_UNAUTHORIZED, "Incorrect uid")
                else -> {
                    status = HttpServletResponse.SC_OK
                    contentType = ContentType.TEXT
                    writer.use {
                        it.print(resolvedUser.username)
                    }
                }
            }
        }
    }
}

