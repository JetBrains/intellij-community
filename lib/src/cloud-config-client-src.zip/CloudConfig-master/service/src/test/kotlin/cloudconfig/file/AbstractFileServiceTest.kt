package cloudconfig.file

import cloudconfig.AbstractServiceTest
import cloudconfig.storage.AmazonS3FileStorage
import org.testng.annotations.BeforeMethod
import cloudconfig.http.v1.FileWebService

abstract class AbstractFileServiceTest : AbstractServiceTest() {
    @BeforeMethod
    fun setUp() {
        AmazonS3FileStorage.clear()
    }

    companion object {
        const val ROOT_PATH = "${FileWebService.NAMESPACE}/"
        const val TOP_LEVEL_FILE = "${FileWebService.NAMESPACE}/compiler.xml"
        const val TOP_LEVEL_FILE2 = "${FileWebService.NAMESPACE}/vcs.xml"
        const val SECOND_LEVEL_FILE = "${FileWebService.NAMESPACE}/idea/compiler.xml"
        const val SECOND_LEVEL_FILE2 = "${FileWebService.NAMESPACE}/idea/encodings.xml"
        const val THIRD_LEVEL_FILE = "${FileWebService.NAMESPACE}/idea/core/compiler.xml"
    }
}