package cloudconfig

import cloudconfig.auth.AbstractAuthFilter
import cloudconfig.auth.JbaTokenAuthFilter
import cloudconfig.file.AuthServiceMock
import cloudconfig.storage.AmazonS3FileStorage
import io.restassured.RestAssured
import io.restassured.authentication.AuthenticationScheme
import io.restassured.internal.http.HTTPBuilder
import io.restassured.response.ValidatableResponse
import io.restassured.specification.RequestSpecification
import org.eclipse.jetty.server.Handler
import org.eclipse.jetty.server.Server
import org.eclipse.jetty.server.handler.ContextHandlerCollection
import org.eclipse.jetty.servlet.ServletContextHandler
import org.eclipse.jetty.servlet.ServletHolder
import org.eclipse.jetty.webapp.MetaInfConfiguration
import org.eclipse.jetty.webapp.WebAppContext
import org.eclipse.jetty.webapp.WebInfConfiguration
import org.eclipse.jetty.webapp.WebXmlConfiguration
import org.hamcrest.Matchers
import org.slf4j.LoggerFactory
import org.testng.AssertJUnit.assertEquals
import java.math.BigInteger
import java.net.ServerSocket
import java.security.SecureRandom
import java.util.*


abstract class AbstractServiceTest {

    object RandomCode {
        private val rnd = SecureRandom()
        private const val defaultLength: Int = 25

        /** It is highly recommended to use default 36 radix **/
        fun next(len: Int = defaultLength, radix: Int = 36): String {
            return BigInteger(128, rnd).toString(radix).takeLast(len)
        }

        fun nextBytes(len: Int): ByteArray = ByteArray(len).apply {
            rnd.nextBytes(this)
        }
    }

    protected fun ValidatableResponse.body(expected: String) = run {
        assertEquals(expected, extract().asString())
        this
    }

    protected fun RequestSpecification.jbaToken(uid: String): RequestSpecification = filter { req, res, ctx ->
        req.header(AbstractAuthFilter.AUTH_HEADER, JbaTokenAuthFilter.AUTH_SCHEME + " " + uid)
        ctx.next(req, res)
    }

    protected fun ValidatableResponse.hasProperties(n: Int): ValidatableResponse = body("keySet().size()", Matchers.equalTo(n))

    protected fun longString(len: Int) = String(ByteArray(len) { 97 })
}

data class User(val username: String) {
    val uid = UUID.randomUUID().toString()
}

class JbaTokenAuthScheme(private val user: User) : AuthenticationScheme {
    override fun authenticate(builder: HTTPBuilder) {
        val headers = HashMap(builder.headers)
        headers[AbstractAuthFilter.AUTH_HEADER] = JbaTokenAuthFilter.AUTH_SCHEME + " " + user.uid
        builder.headers = headers
    }
}

open class EnvironmentConfigurator() {
    private val log = LoggerFactory.getLogger(EnvironmentConfigurator::class.java)

    private var jetty: Server? = null

    val user01 = User(username = "test.user.01")
    val user02 = User(username = "test.user.02")

    open fun setupStorage() {
        // do nothing
    }

    open fun shutdownStorage() {
        // do nothing
    }

    private fun startApplication(vararg handlers: Handler, port: Int) {
        // bootstrap service itself
        jetty = Server(port).also { jettyServer ->
            jettyServer.handler = ContextHandlerCollection().also { hc ->
                hc.handlers = handlers
            }
            jettyServer.start()
        }

        log.info("Server has been started at port $port")
    }

    fun setupEnvironment() {
        // bootstrap storage
        setupStorage()

        val port = availablePort()

        // auth service mock
        val authServiceServlet = ServletContextHandler().apply {
            addServlet(
                    ServletHolder("auth-service", AuthServiceMock.AuthServiceServlet::class.java),
                    "/cloud-service-auth"
            )
        }
        AuthServiceMock.userList.addAll(listOf(user01, user02))

        // cloud-service app
        val cloudConfigPath = "/cloud-config"
        val serviceApp = WebAppContext().apply {
            configurations = arrayOf(
                    WebInfConfiguration(),
                    WebXmlConfiguration(),
                    MetaInfConfiguration())

            setInitParameter("kara.config", "src/test/resources/test-config.conf")
            setInitParameter("account-url", "http://localhost:$port")
            resourceBase = "src/main/webapp"
            contextPath = cloudConfigPath
        }

        startApplication(authServiceServlet, serviceApp, port = port)

        // configure RestAssured
        RestAssured.port = port
        RestAssured.basePath = cloudConfigPath
    }

    fun shutdownEnvironment() {
        fun <T : () -> Unit?> T.andThen(f: T): () -> Unit? = {
            try {
                this()
            } finally {
                f()
            }
        }

        {
            jetty?.stop()
            AuthServiceMock.userList.clear()
        }.andThen {
            shutdownStorage()
        }.andThen {
            AmazonS3FileStorage.reset()
        }.invoke()
    }

    private fun availablePort() = run {
        val socket = ServerSocket(0)
        socket.use { it.localPort }
    }
}