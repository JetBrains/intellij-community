package cloudconfig

import io.restassured.RestAssured.given
import org.testng.annotations.AfterClass
import org.testng.annotations.BeforeClass
import org.testng.annotations.Test

class AppStatusTest : AbstractServiceTest() {
    companion object : EnvironmentConfigurator()

    @BeforeClass fun setup() {
        setupEnvironment()
    }

    @AfterClass fun shutdown() {
        shutdownEnvironment()
    }

    @Test fun testStatus() {
        given().
            auth().none().
        `when`().
            get("/status").
        then().
            statusCode(200)
    }
}