package cloudconfig.file

import cloudconfig.EnvironmentConfigurator
import io.restassured.RestAssured.given
import org.testng.annotations.AfterClass
import org.testng.annotations.BeforeClass
import org.testng.annotations.Test

class AuthServiceTest : AbstractFileServiceTest() {
    companion object : EnvironmentConfigurator()

    @BeforeClass fun setup() {
        setupEnvironment()
    }

    @AfterClass fun shutdown() {
        shutdownEnvironment()
    }

    @Test fun testRequestWithoutAuth() {
        given().
            auth().none().
        `when`().
            get(TOP_LEVEL_FILE).
        then().
            statusCode(401)
    }

    @Test fun testRequestWithWrongCredentials() {
        given().
            jbaToken("wrong").
        `when`().
            get(TOP_LEVEL_FILE).
        then().
            statusCode(401)
    }

    @Test fun testRequestWithProperCredentials() {
        given().
            jbaToken(user01.uid).
        `when`().
            get(TOP_LEVEL_FILE).
        then().
            statusCode(404)
    }

    @Test fun testUserDataIsolation() {
        val BODY = "Hello World"

        fun test(file: String) {
            // put data as a Vasya Pupkin
            given().
                jbaToken(user01.uid).
                body(BODY).
            `when`().
                put(file).
            then().
                statusCode(204)

            // and read as another user
            given().
                auth().none().
                jbaToken(user02.uid).
            `when`().
                get(file).
            then().
                statusCode(404)
        }

        listOf(TOP_LEVEL_FILE, SECOND_LEVEL_FILE).forEach(::test)
    }
}