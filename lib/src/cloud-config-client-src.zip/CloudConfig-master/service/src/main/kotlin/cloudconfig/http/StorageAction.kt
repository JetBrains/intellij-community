package cloudconfig.http

import cloudconfig.AppConfig
import cloudconfig.MaxEntitySizeExceeded
import cloudconfig.storage.AmazonS3FileStorage
import com.amazonaws.AmazonClientException
import kara.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory

open class StorageAction(
    path: String,
    apiVersion: ApiVersion,
    action: ActionContext.(AmazonS3FileStorage, String) -> ActionResult
) : Action({
        try {
            val fullPath = fullPath(this, path, apiVersion)

            val route = resourceDescriptor.route.let { it.substring(0, it.indexOf('/', 1)) }
            logger.info("[${request.method}] - '$route' - '$fullPath'")

            action(STORAGE, fullPath)
        } catch (e: AmazonClientException) {
            throw if (e.cause is MaxEntitySizeExceeded)
                InvalidRequestException("Storage limit violation: only $QUOTE_SIZE bytes allowed to persist.")
            else
                e
        }
    }) {
    companion object {

        val logger: Logger = LoggerFactory.getLogger(StorageAction::class.java)

        private val PATH_REGEX = "(/[\\w!\\-.*'()]*)+".toRegex()

        val QUOTE_SIZE by lazy {
            try {
                AppConfig.param(AppConfig.QUOTE_SIZE_PARAM)?.toInt() ?: (512 * 1024)
            } catch (e: NumberFormatException) {
                throw RuntimeException("Invalid config value: ${AppConfig.QUOTE_SIZE_PARAM}")
            }
        }

        const val BUFFER_SIZE = 128 * 1024 + 1 // Amazon requirement

        val STORAGE = AmazonS3FileStorage

        fun userFolder(context: ActionContext, apiVersion: ApiVersion): String {
            val username = principal(context) ?: error("unauthorized request")
            return when (apiVersion) {
                ApiVersion.V1 -> "/$username/"
                ApiVersion.V2 -> "/v2/$username/"
            }
        }

        fun limit(context: ActionContext, apiVersion: ApiVersion, vararg exclude: String) =
            QUOTE_SIZE - STORAGE.sizeOf(userFolder(context, apiVersion), *exclude)

        fun fullPath(context: ActionContext, path: String, apiVersion: ApiVersion): String {
            require(!path.startsWith("/")) { "relative path required" }

            if (!"/$path".matches(PATH_REGEX) || path.contains("//"))
                throw InvalidRequestException("Invalid path: $path")

            val fullPath = "${userFolder(context, apiVersion)}$path"

            if ((STORAGE.prefix + fullPath).length > STORAGE.MAX_PATH_LEN) {
                val message = "Too long path: ${(STORAGE.prefix + fullPath)}"
                logger.error(message)
                throw InvalidRequestException("Too long path: $message")
            }

            return fullPath
        }
    }
}