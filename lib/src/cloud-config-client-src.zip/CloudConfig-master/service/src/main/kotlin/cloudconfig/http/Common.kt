package cloudconfig.http

import cloudconfig.MaxEntitySizeExceeded
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.KotlinModule
import kara.*
import java.io.FileNotFoundException
import java.io.InputStream
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

enum class ApiVersion(val getVersionFun: (HttpServletRequest) -> String?) {
    V1(getVersionFun = { null }),
    V2(getVersionFun = { it.getHeader(Header.VERSION_ID) })
}

object ContentType {
    const val JSON = "application/json"
    const val TEXT = "text/plain"
    const val OCTET_STREAM = "application/octet-stream"
    const val MULTIPART_FORM_DATA = "multipart/form-data"
}

object Header {
    const val IF_NONE_MATCH = "If-None-Match"
    const val CONTENT_LENGTH = "Content-Length"
    const val CACHE_CONTROL = "Cache-Control"
    const val ETAG = "ETag"
    const val VERSION_ID = "Version-Id"
}

open class Action(action: ActionContext.(username: String) -> ActionResult) : Request({
    val username = principal(this)

    if (username != null) try {
        action(username)
    } catch (e: InvalidRequestException) {
        ErrorResponse(HttpServletResponse.SC_BAD_REQUEST, e.message ?: "Invalid request parameters")
    } catch (e: FileNotFoundException) {
        ErrorResponse(HttpServletResponse.SC_NOT_FOUND, e.message ?: "File not found")
    } else
        ErrorResponse(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized")
}) {
    companion object {
        fun principal(context: ActionContext) =
            context.request.userPrincipal?.name ?: if (ActionContext.current().config.isDevelopment()) "test" else null
    }
}

class BoundedInputStream(val delegate: InputStream, val limit: Long) : InputStream() {
    private var counter = 0L

    override fun read(): Int {
        val result = delegate.read()

        if (result != -1)
            counter++

        checkLimitExceeded()

        return result
    }

    override fun read(b: ByteArray?, off: Int, len: Int): Int {
        val result = delegate.read(b, off, len)

        if (result != -1)
            counter += result

        checkLimitExceeded()

        return result
    }

    override fun skip(n: Long): Long {
        val result = delegate.skip(n)

        counter += result

        checkLimitExceeded()

        return result
    }

    override fun available() = delegate.available()

    override fun reset() = delegate.reset()

    override fun close() = delegate.close()

    override fun mark(readlimit: Int) = delegate.mark(readlimit)

    override fun markSupported() = delegate.markSupported()

    private fun checkLimitExceeded() {
        if (counter > limit)
            throw MaxEntitySizeExceeded("Entity cannot be greater than $limit")
    }
}

open class ErrorResponse(code: Int, message: String) : TextResult(message, code)

class JsonResponse(val data: Any?) : ActionResult {
    override fun writeResponse(context: ActionContext) {
        context.response.contentType = ContentType.JSON
        MAPPER.writeValue(context.response.outputStream, data)
    }

    companion object {
        val MAPPER = ObjectMapper().apply {
            registerModule(KotlinModule())
        }
    }
}

sealed class EmptyResponse(val status: Int) : ActionResult by kara.EmptyResponse(status) {
    object CREATED : EmptyResponse(HttpServletResponse.SC_CREATED)
    object ACCEPTED : EmptyResponse(HttpServletResponse.SC_ACCEPTED)
    object NO_CONTENT : EmptyResponse(HttpServletResponse.SC_NO_CONTENT)
    object NOT_MODIFIED : EmptyResponse(HttpServletResponse.SC_NOT_MODIFIED)
    object BAD_REQUEST : EmptyResponse(HttpServletResponse.SC_BAD_REQUEST)
    object EXPECTATION_FAILED: EmptyResponse(HttpServletResponse.SC_EXPECTATION_FAILED)
}

class S3ObjectContainer(val content: ByteArray, val contentLength: Long, val eTag: String?)

class StreamResult(private val container: S3ObjectContainer) : ActionResult {

    override fun writeResponse(context: ActionContext) = with(context.response) {
        status = HttpServletResponse.SC_OK
        contentType = ContentType.OCTET_STREAM

        setHeader(Header.CONTENT_LENGTH, container.contentLength.toString())
        setHeader(Header.CACHE_CONTROL, "no-store, must-revalidate")
        container.eTag?.let { setHeader(Header.ETAG, it) }

        outputStream.write(container.content)
        outputStream.flush()
    }
}

fun ActionResult.withHeader(name: String, value: String?) =
    if (value == null)
        this
    else
        object : ActionResult {
            override fun writeResponse(context: ActionContext) {
                context.response.setHeader(name, value)
                this@withHeader.writeResponse(context)
            }
        }

fun ActionResult.withCachingRestricted() =
    withHeader(Header.CACHE_CONTROL, "no-store, must-revalidate")

fun HttpServletRequest.isMultipart() =
    contentType != null && contentType.contains(ContentType.MULTIPART_FORM_DATA, ignoreCase = true)