package cloudconfig.http.v2

import cloudconfig.http.ApiVersion
import cloudconfig.http.EmptyResponse
import cloudconfig.http.JsonResponse
import cloudconfig.http.StorageAction
import cloudconfig.http.v2.VersionWebService.NAMESPACE
import kara.*

@Location(NAMESPACE)
object VersionWebService {
    // TODO: Consider using request params for versioned methods
    // TODO: Use common interfaces (constants, endpoints, etc.) both for sever and client (similar to marketplace)
    // TODO: Think about another pluggable persistence layer (Yandex storage or any other)
    const val NAMESPACE = "/versions-v2"
    private val apiVersion = ApiVersion.V2

    @Get("/:file")
    open class GetLatestVersion(file: String) : StorageAction(file, apiVersion, { storage, path ->
        when (val latestVersion = storage.getLatestFileVersion(path)) {
            null -> EmptyResponse.NO_CONTENT
            else -> JsonResponse(latestVersion)
        }
    })

    @Get("/:folder/:file")
    class GetNestedLatestVersion(folder: String, file: String) : GetLatestVersion("$folder/$file")

    @Route(HttpMethod.OPTIONS, "/:file", allowCrossOrigin = "*")
    open class GetVersions(file: String) : StorageAction(file, apiVersion, { storage, path ->
        JsonResponse(storage.listFileVersions(path))
    })

    @Route(HttpMethod.OPTIONS, "/:folder/:file", allowCrossOrigin = "*")
    class GetNestedVersions(folder: String, file: String) : GetVersions("$folder/$file")
}