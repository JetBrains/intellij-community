package cloudconfig

import kara.*

object AppConfig : ApplicationContextMonitor {
    const val QUOTE_SIZE_PARAM = "cloudconf.s3.quote"

    private var _config: ApplicationConfig? = null

    fun config() : ApplicationConfig = _config ?: error("Application was not initialized")

    operator fun get(name: String) =
            param(name) ?: throw RuntimeException("Missing config parameter: $name")

    fun param(name: String, default: String? = null) =
            (System.getProperty(name) ?: config()._config.tryGet(name) ?: default)?.takeIf { it.isNotBlank() }

    override fun created(context: ApplicationContext) {
        _config = context.config
    }

    override fun destroyed(context: ApplicationContext) {
        // do nothing
    }
}