package cloudconfig.http

import cloudconfig.storage.AmazonS3FileStorage
import kara.*
import org.slf4j.LoggerFactory
import java.util.*

@Suppress("unused")
object StatusController {

    private val logger = LoggerFactory.getLogger(javaClass)

    private val buildVersion: String by lazy {
        val buildVersionFileName = "build.version"
        val version = javaClass.getResourceAsStream("/$buildVersionFileName")?.reader()?.use { reader ->
            reader.readText()
        }
        when {
            version != null -> version
            else -> {
                logger.error("Can't resolve version from $buildVersionFileName")
                "N/A"
            }
        }
    }

    @Get("/status")
    object GetStatusAction : Request({
        val path = "/status_check/statusfile_${UUID.randomUUID()}.txt"

        val errMessage: String? = try {
            AmazonS3FileStorage.writeFile(path, buildVersion.byteInputStream(), buildVersion.length.toLong())
            AmazonS3FileStorage.readFile(path, Header.IF_NONE_MATCH, versionId = null)?.let { String(it.content, Charsets.UTF_8) }
            null
        } catch (e: Exception) {
            e.message
        }

        if (errMessage != null)
            ErrorResult(500, "Problem accessing to S3: $errMessage")
        else
            TextResult("Build: $buildVersion")
    })

    @Get("/crash-as-intended")
    object Crash : Request({
        error("This resource always crashes")
    })
}