package cloudconfig.storage

import com.amazonaws.AmazonClientException
import com.amazonaws.auth.*
import kara.*

object AmazonConfigParams {
    const val ACCESS_KEY = "aws.accessKey"
    const val SECRET_KEY = "aws.secretKey"
    const val REGION = "aws.region"
    const val S3_ENDPOINT = "aws.s3.endpoint"
}

class KaraConfigCredentialsProvider(private val config: ApplicationConfig) : AWSCredentialsProvider {
    override fun getCredentials(): AWSCredentials {
        val accessKey: String? = config._config.tryGet(AmazonConfigParams.ACCESS_KEY)
        val secretKey: String? = config._config.tryGet(AmazonConfigParams.SECRET_KEY)

        if (accessKey == null || secretKey == null) {
            throw AmazonClientException("Unable to load AWS credentials from Kara config file " +
                    "(${AmazonConfigParams.ACCESS_KEY} and ${AmazonConfigParams.SECRET_KEY})")
        }

        return BasicAWSCredentials(accessKey, secretKey)
    }

    override fun refresh() {
        // no-op
    }
}

class KaraAwsCredentialsProviderChain(config: ApplicationConfig) : AWSCredentialsProviderChain(
        EnvironmentVariableCredentialsProvider(),
        SystemPropertiesCredentialsProvider(),
        KaraConfigCredentialsProvider(config),
        EC2ContainerCredentialsProviderWrapper()
)