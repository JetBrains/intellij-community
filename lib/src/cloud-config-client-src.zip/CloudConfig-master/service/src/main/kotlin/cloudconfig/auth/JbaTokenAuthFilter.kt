package cloudconfig.auth

import javax.servlet.FilterChain
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class JbaTokenAuthFilter : AbstractAuthFilter() {
    companion object {
        val AUTH_SCHEME = "JBA-Token"
    }

    override fun doFilter(p0: ServletRequest?, p1: ServletResponse?, p2: FilterChain?) {
        val request = p0 as HttpServletRequest
        val response = p1 as HttpServletResponse

        val authHeader = request.getHeader(AUTH_HEADER)
        val authPrefix = "$AUTH_SCHEME "

        if (authHeader == null || !authHeader.startsWith(authPrefix)) {
            response.unauthorized()
            return
        }

        val uid = authHeader.substringAfter(authPrefix)

        val account = response.authenticate(uid, request.resolveIp())

        if (account != null)
            p2?.doFilter(WrappedRequest(request, account), response)
        else
            response.sendErrorFromStatus()
    }
}