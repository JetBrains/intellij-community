package cloudconfig.http

import cloudconfig.storage.AmazonS3FileStorage
import kara.*
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.Part

object CommonActions {
    open class RemoveFileAction(file: String, apiVersion: ApiVersion) :
        StorageAction(file, apiVersion, { storage, path ->
            storage.removeFile(path)
            EmptyResponse.NO_CONTENT
        })

    open class ListingAction(apiVersion: ApiVersion) : StorageAction("", apiVersion, { storage, path ->
        JsonResponse(storage.listFiles(path)).withCachingRestricted()
    })

    open class GetNestedListingAction(folder: String, apiVersion: ApiVersion) :
        StorageAction(folder, apiVersion, { storage, path ->
            JsonResponse(storage.listFiles(path))
        })

    /**
     *  Multipart upload is supported for api v1 only
     */
    open class MultiPutAction(folder: String, apiVersion: ApiVersion) :
        StorageAction(folder, apiVersion, { storage, _ ->
            if (!request.isMultipart())
                throw InvalidRequestException("Multipart request expected")

            val context = this

            fun Part.storagePath() = fullPath(context, (folder + "/" + this.name).trimStart('/'), apiVersion)

            val limit = limit(this, apiVersion, *request.parts.map { it.storagePath() }.toTypedArray())

            if (limit < request.parts.fold(0L) { acc, it -> acc + it.size })
                throw InvalidRequestException("Storage limit reached: $QUOTE_SIZE")

            val eTags = hashMapOf<String, String?>()

            val prefixToTrim = userFolder(this, apiVersion).trimEnd('/')

            request.parts.forEach { part ->
                val filePath = part.storagePath()

                when {
                    filePath.count { it == '/' } > 3 ->
                        throw InvalidRequestException("Maximum path depth exceeded: $filePath")
                    filePath.endsWith('/') ->
                        throw InvalidRequestException("File name must not have trailing slash: $filePath")
                    else -> {
                        val (eTag, _) = part.inputStream.use {
                            storage.writeFile(
                                filePath,
                                BoundedInputStream(it.buffered(BUFFER_SIZE), part.size),
                                part.size
                            )
                        }

                        eTags[filePath.substringAfter(prefixToTrim)] = eTag
                    }
                }
            }

            JsonResponse(eTags)
        })

    private fun isFileVersionMatch(
        apiVersion: ApiVersion,
        request: HttpServletRequest,
        storage: AmazonS3FileStorage,
        path: String
    ) = when (apiVersion) {
        ApiVersion.V1 -> true // no versioning
        else -> {
            val latestVersion = storage.getLatestFileVersion(path)?.versionId
            val expectedVersion = apiVersion.getVersionFun(request)
            when (latestVersion) {
                expectedVersion -> true
                else -> {
                    StorageAction.logger.warn("Version mismatch, expected '$expectedVersion', but was '$latestVersion'. Path: $path")
                    false
                }
            }
        }
    }

    open class PutFileAction(file: String, apiVersion: ApiVersion) :
        StorageAction(file, apiVersion, { storage, path ->
            when {
                apiVersion != ApiVersion.V1 && request.isMultipart() -> {
                    logger.warn("Multipart request is not supported for v2: $path")
                    EmptyResponse.BAD_REQUEST
                }
                request.isMultipart() -> MultiPutAction(file, apiVersion).handle(this)
                !isFileVersionMatch(apiVersion, request, storage, path) -> EmptyResponse.EXPECTATION_FAILED
                else -> {
                    val (eTag, versionId) = request.inputStream.use {
                        storage.writeFile(
                            path,
                            BoundedInputStream(it.buffered(BUFFER_SIZE), limit(this, apiVersion, path)),
                            request.contentLength.toLong()
                        )
                    }
                    EmptyResponse.NO_CONTENT
                        .withHeader(Header.ETAG, eTag)
                        .withHeader(Header.VERSION_ID, versionId)
                }
            }
        })

    open class GetFileAction(file: String, apiVersion: ApiVersion) :
        StorageAction(file, apiVersion, { storage, path ->
            val versionId = apiVersion.getVersionFun(request)
            when {
                apiVersion == ApiVersion.V2 && versionId == null -> {
                    logger.warn("No '${Header.VERSION_ID}' passed in request for $path")
                    EmptyResponse.BAD_REQUEST
                }
                else -> storage.readFile(
                    path = path,
                    tag = request.getHeader(Header.IF_NONE_MATCH),
                    versionId = versionId
                )?.let(::StreamResult) ?: EmptyResponse.NOT_MODIFIED
            }
        })
}