package cloudconfig.storage

import cloudconfig.AppConfig
import cloudconfig.http.S3ObjectContainer
import com.amazonaws.ClientConfiguration
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.S3ClientOptions
import com.amazonaws.services.s3.model.*
import kara.*
import org.slf4j.LoggerFactory
import java.io.FileNotFoundException
import java.io.InputStream
import java.util.*
import javax.servlet.http.HttpServletResponse
import kotlin.reflect.jvm.isAccessible

object AmazonS3FileStorage : ApplicationContextMonitor {
    private val logger = LoggerFactory.getLogger(javaClass)
    private const val CLOUDCONF_CONFIG_PREFIX = "cloudconf.s3."

    private const val BUCKET_PARAM_NAME = "${CLOUDCONF_CONFIG_PREFIX}bucket"
    private const val PREFIX_PARAM_NAME = "${CLOUDCONF_CONFIG_PREFIX}prefix"

    private const val DELIMITER = "/"

    const val MAX_PATH_LEN = 1024

    private val client by ResettableLazyField {
        val clientConfiguration = ClientConfiguration()
                .withGzip(true)
                .withMaxConnections(110)
                .withSocketTimeout(5_000)
                .withConnectionTimeout(5_000)
                .withClientExecutionTimeout(15_000)

        AmazonS3ClientBuilder.standard()
                .withCredentials(KaraAwsCredentialsProviderChain(AppConfig.config()))
                .withClientConfiguration(clientConfiguration)
                .also { builder -> AppConfig.param(AmazonConfigParams.REGION)?.let(builder::withRegion) }
                .build().apply {
                    AppConfig.param(AmazonConfigParams.S3_ENDPOINT)?.let {
                        setEndpoint(it)
                        setS3ClientOptions(S3ClientOptions.builder().setPathStyleAccess(true).build())
                    }
                }
    }

    private val bucket: String by lazy {
        AppConfig.param(BUCKET_PARAM_NAME) ?: error("Bucket name must be specified ($BUCKET_PARAM_NAME)")
    }

    val prefix: String by lazy {
        AppConfig.param(PREFIX_PARAM_NAME).orEmpty()
    }

    fun readFile(path: String, tag: String?, versionId: String?): S3ObjectContainer? = s3Action(path) { filePath ->
        try {
            val request = when {
                versionId != null -> GetObjectRequest(bucket, filePath, versionId)
                else -> GetObjectRequest(bucket, filePath)
            }.withNonmatchingETagConstraint(tag)

            client.getObject(request)?.use { s3Object ->
                S3ObjectContainer(
                        content = s3Object.objectContent.use { it.readBytes() },
                        contentLength = s3Object.objectMetadata.contentLength,
                        eTag = s3Object.objectMetadata.eTag
                )
            }
        } catch (e: AmazonS3Exception) {
            handleAmazonS3Exception(
                exception = e,
                notFoundMessage = "File $filePath cannot be found ${versionId?.let { ", version: $it" }.orEmpty()}"
            )
        }
    }

    private fun handleAmazonS3Exception(exception: AmazonS3Exception, notFoundMessage: String): Nothing {
        val statusCode = exception.statusCode
        throw when {
            statusCode == HttpServletResponse.SC_NOT_FOUND -> FileNotFoundException(notFoundMessage)
            statusCode == HttpServletResponse.SC_BAD_REQUEST && exception.message?.contains("Invalid version id") == true ->
                FileNotFoundException(notFoundMessage)
            else -> exception
        }
    }

    fun listFileVersions(path: String): List<FileVersion> = s3Action(path) { filePath ->
        try {
            client
                .listVersions(bucket, filePath)
                .versionSummaries
                .takeWhile { !it.isDeleteMarker }    // don't obtain removed versions
                .map {
                    FileVersion(
                        versionId = it.versionId,
                        lastModified = it.lastModified,
                        isLatest = it.isLatest
                    )
                }
        } catch (e: AmazonS3Exception) {
            handleAmazonS3Exception(e, notFoundMessage = "File $filePath cannot be found")
        }
    }

    fun getLatestFileVersion(path: String): FileVersion? = listFileVersions(path).singleOrNull { it.isLatest }

    /**
     * <p>
     * When using an {@link java.io.BufferedInputStream} as data source,
     * please remember to use a buffer of size no less than
     * {@link com.amazonaws.RequestClientOptions#DEFAULT_STREAM_BUFFER_SIZE}
     * while initializing the BufferedInputStream.
     * This is to ensure that the SDK can correctly mark and reset the stream with
     * enough memory buffer during signing and retries.
     * </p>
     */
    fun writeFile(path: String, content: InputStream, length: Long): Pair<String, String?> {
        if (path.endsWith(DELIMITER))
            throw IllegalArgumentException("Delimiter at the end of file is restricted")

        val putObjectResult = s3Action(path) { fullPath ->
            client.putObject(
                bucket,
                fullPath,
                content,
                ObjectMetadata().apply { if (length > -1) contentLength = length }
            )
        }

        return putObjectResult.eTag to putObjectResult.versionId
    }

    fun removeFile(path: String) =
            if (path.endsWith("/*"))
                removeContents(path.substringBefore('*'))
            else
                s3Action(path) { client.deleteObject(bucket, it) }


    private fun removeContents(path: String) {

        fun listFilesRecursively(key: String): List<String> {

            return listFiles(key).flatMapTo(mutableListOf()) { fileName ->
                val fullPath = key + fileName
                (if (fileName.endsWith(DELIMITER)) listFilesRecursively(fullPath) else emptyList()) + fullPath
            }
        }

        if (path.endsWith(DELIMITER)) {
            logger.warn("Removing contents: $path")
            listFilesRecursively(path).map { fullPath(it) }.run {
                if (isNotEmpty()) {
                    client.deleteObjects(DeleteObjectsRequest(bucket).withKeys(*toTypedArray()))
                }
            }
        }
    }

    fun listFiles(path: String): List<String> = s3Action(path) { prefix ->

        val result = arrayListOf<String>()

        tailrec fun list(continuationToken: String? = null) {

            val request = ListObjectsV2Request().also {
                it.bucketName = bucket
                it.prefix = if (prefix.endsWith(DELIMITER)) prefix else prefix + DELIMITER
                it.delimiter = DELIMITER
                it.continuationToken = continuationToken
            }

            val listObjects = client.listObjectsV2(request)

            fun String.trimPath() = this.substring(listObjects.prefix.length, this.length)

            result.addAll(
                    listObjects.objectSummaries.asSequence()
                            .filter { it.key != listObjects.prefix }
                            .map { it.key.trimPath() }
            )

            result.addAll(listObjects.commonPrefixes.map { it.trimPath() })

            if (listObjects.isTruncated) list(listObjects.nextContinuationToken)
        }

        list()

        result
    }

    /**
     * Implementation notes: uses path as a prefix for files. So files like '/path/file'
     * would be taken into account for path like '/path/fi'.
     */
    fun sizeOf(path: String, vararg exclude: String): Long = s3Action(path) { filePath ->
        val fullExcludes = exclude.map { fullPath(it) }

        if (fullExcludes.any { !it.startsWith(filePath) })
            throw IllegalArgumentException("Exclude paths must be start with path: $filePath")

        val objects = arrayListOf<S3ObjectSummary>()

        tailrec fun list(continuationToken: String? = null) {
            val request = ListObjectsV2Request().also {
                it.bucketName = bucket
                it.prefix = filePath
                it.continuationToken = continuationToken
            }
            val listObjects = client.listObjectsV2(request)

            objects.addAll(listObjects.objectSummaries.filter { obj -> fullExcludes.none { obj.key.startsWith(it) } })

            if (listObjects.isTruncated) list(listObjects.nextContinuationToken)
        }

        list()

        objects.fold(0L) { acc, s -> acc + s.size }
    }

    fun clear() = removeContents("/")

    // For test only
    fun reset() = (AmazonS3FileStorage::client
            .also { it.isAccessible = true }
            .getDelegate() as ResettableLazyField<*>)
            .reset()

    override fun created(context: ApplicationContext) {
        // do nothing
    }

    override fun destroyed(context: ApplicationContext) {
        client.shutdown()
    }

    private fun <T> s3Action(path: String, action: (String) -> T) = action(fullPath(path))

    private fun fullPath(path: String) = if (path.startsWith(DELIMITER))
        (prefix + path.substring(DELIMITER.length, path.length)).apply {
            if (this.toByteArray().size > MAX_PATH_LEN) {
                val message = "Too long path: $this"
                logger.error(message)
                throw IllegalArgumentException(message)
            }
        }
    else
        throw IllegalArgumentException("absolute path expected: $path")
}

data class FileVersion(val versionId: String, val lastModified: Date, val isLatest: Boolean)