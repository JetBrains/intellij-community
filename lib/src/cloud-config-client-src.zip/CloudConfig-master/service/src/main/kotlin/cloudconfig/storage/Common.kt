package cloudconfig.storage

import java.util.concurrent.atomic.AtomicReference
import kotlin.reflect.KProperty

class ResettableLazyField<T>(val factory: () -> T) {

    private val value = AtomicReference<T>()

    operator fun getValue(thisRef: Any?, property: KProperty<*>): T {
        return value.get() ?: synchronized(this) {
            value.get() ?: run {
                val value = factory()
                this.value.set(value)
                value
            }
        }
    }

    // Required for tests only
    @Synchronized
    fun reset() {
        value.set(null)
    }
}