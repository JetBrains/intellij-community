package cloudconfig.auth

import org.apache.commons.codec.binary.Base64
import javax.servlet.FilterChain
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class BasicHttpAuthFilter : AbstractAuthFilter() {
    override fun doFilter(p0: ServletRequest?, p1: ServletResponse?, p2: FilterChain?) {
        val request = p0 as HttpServletRequest
        val response = p1 as HttpServletResponse

        val authHeader = request.getHeader(AUTH_HEADER)
        val authPrefix = "Basic "

        if (authHeader == null || !authHeader.startsWith(authPrefix)) {
            response.unauthorized()
            return
        }

        val decoded = try {
            Base64.decodeBase64(authHeader.substringAfter(authPrefix)).toString(Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }

        if (decoded == null || !decoded.matches(".+:.+".toRegex())) {
            response.unauthorized()
            return
        }

        val (username, password) = run {
            val arr = decoded.split(":".toRegex(), 2)
            Pair(arr[0], arr[1])
        }

        val account = response.authenticate(username, password, request.resolveIp())

        if (account != null)
            p2?.doFilter(WrappedRequest(request, account), response)
        else
            response.sendErrorFromStatus()
    }
}
