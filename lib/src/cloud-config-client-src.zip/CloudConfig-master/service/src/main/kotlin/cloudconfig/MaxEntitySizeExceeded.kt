package cloudconfig

/**
 * Thrown when entity is too large.
 */
class MaxEntitySizeExceeded(msg: String) : Exception(msg)