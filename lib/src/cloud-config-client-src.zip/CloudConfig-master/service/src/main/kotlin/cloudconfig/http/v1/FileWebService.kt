package cloudconfig.http.v1

import cloudconfig.http.*
import cloudconfig.http.v1.FileWebService.NAMESPACE
import kara.*

@Location(NAMESPACE)
object FileWebService {
    const val NAMESPACE = "/files"
    private val apiVersion = ApiVersion.V1

    @Get("/:file")
    open class GetFile(file: String) : CommonActions.GetFileAction(file, apiVersion)

    @Get("/:folder/:file")
    class GetNestedFile(folder: String, file: String) : GetFile("$folder/$file")

    @Put("/", allowCrossOrigin = "*")
    class MultiPart(folder: String = "") : CommonActions.MultiPutAction(folder, apiVersion)

    @Put("/:file", allowCrossOrigin = "*")
    open class PutFile(file: String): CommonActions.PutFileAction(file, apiVersion)

    @Put("/:folder/:file", allowCrossOrigin = "*")
    class PutNestedFile(folder: String, file: String): PutFile("$folder/$file")

    @Delete("/:file", allowCrossOrigin = "*")
    open class RemoveFile(file: String) : CommonActions.RemoveFileAction(file, apiVersion)

    @Delete("/:folder/:file", allowCrossOrigin = "*")
    class RemoveNestedFile(folder: String, file: String) : RemoveFile("$folder/$file")

    @Route(HttpMethod.OPTIONS, "/", allowCrossOrigin = "*")
    class Listing : CommonActions.ListingAction(apiVersion)

    @Route(HttpMethod.OPTIONS, "/:folder", allowCrossOrigin = "*")
    class GetNestedListing(folder: String) : CommonActions.GetNestedListingAction(folder, apiVersion)
}
