package cloudconfig.auth

import org.apache.http.HttpStatus
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.HttpPost
import org.apache.http.config.SocketConfig
import org.apache.http.impl.client.HttpClients
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager
import org.apache.http.message.BasicNameValuePair
import org.apache.http.util.EntityUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.security.Principal
import javax.servlet.Filter
import javax.servlet.FilterConfig
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletRequestWrapper
import javax.servlet.http.HttpServletResponse
import kotlin.properties.Delegates

abstract class AbstractAuthFilter : Filter {
    companion object {
        const val AUTH_HEADER = "Authorization"
        const val ACCOUNT_URL_PARAM_NAME = "account-url"
        val logger: Logger = LoggerFactory.getLogger(AbstractAuthFilter::class.java)
        private const val DEFAULT_TIMEOUT = 30 * 1000

        private val httpClient by lazy {
            val connectionManager = PoolingHttpClientConnectionManager().also {
                it.maxTotal = 10
                it.defaultMaxPerRoute = 10
                it.defaultSocketConfig = SocketConfig.custom()
                        .setSoKeepAlive(true)
                        .setSoTimeout(DEFAULT_TIMEOUT)
                        .build()
            }

            val requestConfig = RequestConfig.custom()
                    .setConnectTimeout(DEFAULT_TIMEOUT)
                    .setConnectionRequestTimeout(DEFAULT_TIMEOUT)
                    .build()

            HttpClients.custom()
                    .setConnectionManager(connectionManager)
                    .setDefaultRequestConfig(requestConfig)
                    .build()
        }
    }

    private var authUrl: String by Delegates.notNull()

    override fun init(p0: FilterConfig) {
        val accountUrl = p0.servletContext?.getInitParameter(ACCOUNT_URL_PARAM_NAME)
                ?: error("Missing required ${javaClass.simpleName} parameter: $ACCOUNT_URL_PARAM_NAME")

        authUrl = "$accountUrl/cloud-service-auth"
    }

    override fun destroy() {
        // do nothing
    }

    protected fun HttpServletResponse.unauthorized() = sendError(HttpServletResponse.SC_UNAUTHORIZED)
    protected fun HttpServletResponse.sendErrorFromStatus() = sendError(status)

    protected class WrappedRequest(request: HttpServletRequest, val accountLogin: String) : HttpServletRequestWrapper(request) {
        override fun getUserPrincipal(): Principal? {
            return Principal { accountLogin }
        }

        override fun isUserInRole(role: String?): Boolean {
            throw UnsupportedOperationException("not implemented")
        }
    }

    protected fun HttpServletResponse.authenticate(username: String, password: String, ip: String): String? {
        return authenticate(mapOf("username" to username, "password" to password), ip)
    }

    protected fun HttpServletResponse.authenticate(uid: String, ip: String): String? {
        val params = mapOf("uid" to uid)
        return authenticate(params, ip)
    }

    protected fun HttpServletRequest.resolveIp() = getHeader("X-Forwarded-For") ?: remoteAddr ?: "N/A"

    private fun HttpServletResponse.authenticate(authParams: Map<String, String>, ip: String): String? {
        val httpPost = HttpPost(authUrl).apply {
            entity = UrlEncodedFormEntity(authParams.map { BasicNameValuePair(it.key, it.value) })
        }

        val response = httpClient.execute(httpPost)

        val account: String? = response.use {
            val status = it.statusLine.statusCode
            if (status != HttpStatus.SC_OK) {
                it.entity?.let { EntityUtils.consume(it) }
                if (status == HttpStatus.SC_FORBIDDEN) {
                    logger.info("User $authParams has no invitation yet, ip: $ip. Response status: $status")
                } else {
                    logger.warn("Can't authorize user $authParams, ip: $ip. Response status: $status")
                }
                this.status = status
                null
            } else {
                EntityUtils.toString(it.entity, Charsets.UTF_8)
            }
        }

        return account
    }
}