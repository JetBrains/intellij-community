package com.michaelbaranov.microba.calendar;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.michaelbaranov.microba.Microba;
import com.michaelbaranov.microba.calendar.ui.DatePickerUI;

/**
 * A concrete implementation of JComponent. Capable of displaying and selecting
 * dates, much like an editable combo-box with a calendar dropdown.
 * 
 * @author Michael Baranov
 */
public class DatePicker extends CalendarPane {

	/**
	 * The name of a "dateFormat" property.
	 */
	public static final String PROPERTY_NAME_DATE_FORMAT = "dateFormat";

	/**
	 * The name of a "fieldEditable" property.
	 */
	public static final String PROPERTY_NAME_FIELD_EDITABLE = "fieldEditable";

	/**
	 * The name of a "keepTime" property.
	 */
	public static final String PROPERTY_NAME_KEEP_TIME = "keepTime";

	private static final String uiClassID = "microba.DatePickerUI";

	private DateFormat dateFormat;

	private boolean fieldEditable;

	private boolean keepTime;

	static {
		Microba.init();
	}

	/**
	 * Constructor.
	 */
	public DatePicker() {
		this(new Date(), DateFormat.MEDIUM, Locale.getDefault(), TimeZone
				.getDefault());
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate) {
		this(initialDate, DateFormat.MEDIUM, Locale.getDefault(), TimeZone
				.getDefault());
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate, int dateStyle) {
		this(initialDate, dateStyle, Locale.getDefault(), TimeZone.getDefault());
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate, DateFormat dateFormat) {
		this(initialDate, dateFormat, Locale.getDefault(), TimeZone
				.getDefault());
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate, int dateStyle, Locale locale) {
		this(initialDate, dateStyle, locale, TimeZone.getDefault());
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate, DateFormat dateFormat, Locale locale) {
		this(initialDate, dateFormat, locale, TimeZone.getDefault());
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate, int dateStyle, Locale locale,
			TimeZone zone) {
		super(initialDate, CalendarPane.STYLE_CLASSIC, locale, zone);
		checkDateStyle(dateStyle);
		this.dateFormat = dateFormatFromStyle(dateStyle);
		this.fieldEditable = true;
		this.keepTime = true;
		this.setStripTime(false);
		updateUI();
	}

	/**
	 * Constructor.
	 */
	public DatePicker(Date initialDate, DateFormat dateFormat, Locale locale,
			TimeZone zone) {
		super(initialDate, CalendarPane.STYLE_CLASSIC, locale, zone);
		checkDateFormat(dateFormat);
		this.dateFormat = dateFormat;
		this.fieldEditable = true;
		this.keepTime = true;
		this.setStripTime(false);
		updateUI();
	}

	public String getUIClassID() {
		return uiClassID;
	}

	/**
	 * Returns the date format.
	 * <p>
	 * 
	 * @return current date format
	 * @see #setDateFormat(DateFormat)
	 */
	public DateFormat getDateFormat() {
		return dateFormat;
	}

	/**
	 * Sets the date format constant defined by {@link DateFormat} and updates
	 * the control to reflect new date style.
	 * <p>
	 * 
	 * @param dateFormat
	 *            the date format constant to set
	 * @see #getDateFormat()
	 * @see DateFormat
	 */
	public void setDateFormat(DateFormat dateFormat) {
		checkDateFormat(dateFormat);
		Object oldValue = this.dateFormat;
		this.dateFormat = dateFormat;
		firePropertyChange(PROPERTY_NAME_DATE_FORMAT, oldValue, dateFormat);
	}

	/**
	 * Is the edit field of the control editable by the user?
	 * <p>
	 * If not editable, the user can not type in the date and can only use
	 * calendar drop-down to select dates.
	 * 
	 * @return <code>true</code> if the edit field is editable,
	 *         <code>false</code> otherwise
	 * 
	 * @see #setFieldEditable(boolean)
	 */
	public boolean isFieldEditable() {
		return fieldEditable;
	}

	/**
	 * Enables or disables editing of the edit field by the user.
	 * <p>
	 * If not editable, the user can not type in the date and can only use
	 * calendar drop-down to select dates.
	 * 
	 * @param fieldEditable
	 *            the editable value to set
	 * 
	 * @see #isFieldEditable()
	 */
	public void setFieldEditable(boolean fieldEditable) {
		boolean old = this.fieldEditable;
		this.fieldEditable = fieldEditable;
		firePropertyChange(PROPERTY_NAME_FIELD_EDITABLE, old, fieldEditable);
	}

	/**
	 * Does UI try to preserve time components entered in the edit field?
	 * <p>
	 * If <code>true</code> and if the date format has some time fields
	 * (hours, minutes, seconds, fraction of second), the UI tries to respect
	 * the time fields' values entered by user as much as possible.
	 * <p>
	 * Note: to be able to receive time portion of the date, make sure
	 * {@link #isStripTime()} is <code>false</code> (the dafualt).
	 * 
	 * @return <code>true</code> if the UI respects time fields,
	 *         <code>false</code> otherwise
	 * @see #setKeepTime(boolean)
	 * @see #setStripTime(boolean)
	 * @see #isStripTime()
	 * 
	 */
	public boolean isKeepTime() {
		return keepTime;
	}

	/**
	 * Determines if the UI should try to preserve time components entered in
	 * the edit field.
	 * <p>
	 * If <code>true</code> and if the date format has some time fields
	 * (hours, minutes, seconds, fraction of second), the UI tries to respect
	 * the time fields' values entered by user as much as possible.
	 * <p>
	 * Note: to be able to receive time portion of the date, make sure
	 * {@link #isStripTime()} is <code>false</code> (the dafualt).
	 * 
	 * @param keepTime
	 *            <code>true</code> to make the UI respects time fields,
	 *            <code>false</code> otherwise
	 * @see #isKeepTime()
	 * @see #setStripTime(boolean)
	 * @see #isStripTime()
	 */
	public void setKeepTime(boolean keepTime) {
		boolean old = this.keepTime;
		this.keepTime = keepTime;
		firePropertyChange(PROPERTY_NAME_KEEP_TIME, old, keepTime);
	}

	/**
	 * Displays the calendar dropdown.
	 */
	public void showPopup() {
		((DatePickerUI) getUI()).showPopup(true);
	}

	/**
	 * Hides the calendar dropdown without selecting a date.
	 */
	public void hidePopup() {
		((DatePickerUI) getUI()).showPopup(false);
	}

	public boolean commitEdit() {
		try {
			((DatePickerUI) getUI()).commit();
			fireCommitEvent(true);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void revertEdit() {
		((DatePickerUI) getUI()).revert();
		fireCommitEvent(false);
	}

	private void checkDateStyle(int style) {
		if (style != DateFormat.SHORT && style != DateFormat.MEDIUM
				&& style != DateFormat.LONG)
			throw new IllegalArgumentException("dateStyle: unrecognized style");
	}

	private void checkDateFormat(DateFormat dateFormat) {
		if (dateFormat == null)
			throw new IllegalArgumentException("dateFormat: null value");
	}

	private DateFormat dateFormatFromStyle(int dateStyle) {
		DateFormat df = DateFormat.getDateInstance(dateStyle, this.getLocale());
		df.setTimeZone(this.getZone());
		return df;
	}

}
