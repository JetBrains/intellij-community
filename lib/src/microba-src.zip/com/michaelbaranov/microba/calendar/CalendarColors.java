package com.michaelbaranov.microba.calendar;

import java.awt.Color;

public interface CalendarColors {

	public static final String COLOR_BACKGROUND = "background";

	public static final String COLOR_GRID_BACKGROUND = "grid.background";

	public static final String COLOR_HEADER = "header";

	public static final String COLOR_SELECTION_BACKGROUND = "selection.background";

	public static final String COLOR_SELECTION_TEXT = "selection.text";

	public static final String COLOR_VETO = "veto";

	public Color getColor(String key);
}
