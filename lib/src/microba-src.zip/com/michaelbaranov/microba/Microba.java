package com.michaelbaranov.microba;

import java.applet.Applet;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.LookAndFeel;
import javax.swing.UIManager;

/**
 * This class is used to initialize Microba library.
 * 
 * @author Michael Baranov
 * 
 */
public class Microba {

	private static UIChangeListener changeListener = new UIChangeListener();

	/**
	 * Initializes the library: installs L&F properties, sets up a L&F change
	 * listener.
	 * <p>
	 * No need to call this method explicitly for desktop applications. You
	 * should only call it in {@link Applet#init()}. This will handle browser
	 * refresh button correctly.
	 * 
	 */
	public static synchronized void init() {
		setLookAndFeelProperties(UIManager.getLookAndFeel());

		UIManager.removePropertyChangeListener(changeListener);
		UIManager.addPropertyChangeListener(changeListener);
	}

	private static synchronized void setLookAndFeelProperties(
			LookAndFeel lookAndFeel) {
		if (lookAndFeel == null)
			return;

		String packagePrefix = "com.michaelbaranov.microba.";

		// all L&F
		UIManager.put("microba.CalendarPaneUI", packagePrefix
				+ "calendar.ui.basic.BasicCalendarPaneUI");
		UIManager.put("microba.DatePickerUI", packagePrefix
				+ "calendar.ui.basic.BasicDatePickerUI");
		UIManager.put("microba.GradientUI", packagePrefix
				+ "gradient.ui.basic.BasicGradientUI");
		UIManager.put("microba.GradientEditorUI", packagePrefix
				+ "gradienteditor.ui.basic.BasicGradientEditorUI");
		UIManager.put("microba.MarkerBarUI", packagePrefix
				+ "marker.ui.basic.BasicMarkerBarUI");

		// particular L&F
		if (lookAndFeel.getID().equals("Windows")) {
			UIManager.put("microba.MarkerBarUI", packagePrefix
					+ "marker.ui.windows.WindowsMarkerBarUI");
		} else if (lookAndFeel.getID().equals("Metal")) {
			UIManager.put("microba.MarkerBarUI", packagePrefix
					+ "marker.ui.metal.MetalMarkerBarUI");
		} else if (lookAndFeel.getID().equals("Motif")) {
			UIManager.put("microba.MarkerBarUI", packagePrefix
					+ "marker.ui.motif.MotifMarkerBarUI");
		}

	}

	private static final class UIChangeListener implements
			PropertyChangeListener {
		public void propertyChange(PropertyChangeEvent event) {
			if ("lookAndFeel".equals(event.getPropertyName())) {
				setLookAndFeelProperties((LookAndFeel) event.getNewValue());
			}
		}
	}

}
