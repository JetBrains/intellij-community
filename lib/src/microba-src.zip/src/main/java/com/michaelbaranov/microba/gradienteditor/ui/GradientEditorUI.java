package com.michaelbaranov.microba.gradienteditor.ui;

import javax.swing.plaf.ComponentUI;

public class GradientEditorUI extends ComponentUI{

}
