package org.picocontainer.doc.introduction;

// START SNIPPET: class

public interface Peelable {
    void peel();
}

// END SNIPPET: class
