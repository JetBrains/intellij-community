package org.picocontainer.doc.hotswapping;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1279 $
 */
// START SNIPPET: class
public interface Man {
    int getEndurance();
}

// END SNIPPET: class
