package org.picocontainer.doc.hotswapping;


/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1279 $
 */
// START SNIPPET: class
public interface Woman {
    Man getMan();
}

// END SNIPPET: class
