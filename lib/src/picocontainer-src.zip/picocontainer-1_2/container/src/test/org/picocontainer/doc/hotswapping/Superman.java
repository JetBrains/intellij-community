package org.picocontainer.doc.hotswapping;

/**
 * @author Aslak Helles&oslash;y
 * @version $Revision: 1279 $
 */
// START SNIPPET: class
public class Superman implements Man {
    public int getEndurance() {
        return 1000;
    }
}

// START SNIPPET: class
