package org.picocontainer.doc.introduction;

// START SNIPPET: class

public class Apple implements Peelable {
    public void peel() {
    }
}

// END SNIPPET: class
