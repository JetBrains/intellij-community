package org.picocontainer.doc.tutorial.interfaces;

// START SNIPPET: kissable

public interface Kissable {
    void kiss(Object kisser);
}

// END SNIPPET: kissable
