package org.picocontainer.doc.tutorial.simple;

// START SNIPPET: boy

public class Boy {
    public void kiss(Object kisser) {
        System.out.println("I was kissed by " + kisser);
    }
}

// END SNIPPET: boy
