package zoo.fish

class Trout extends zoo.Fish {

  String saySomething(String something) {
    return "Trout says " + something + "...blubb�!"
  }

}
