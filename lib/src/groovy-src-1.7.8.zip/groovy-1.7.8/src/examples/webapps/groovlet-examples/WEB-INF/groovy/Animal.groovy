interface Animal {

  String saySomething(String something);

}
