package org.jetbrains.jps.server;

import org.jetbrains.jps.incremental.MessageHandler;
import org.jetbrains.jps.incremental.messages.BuildMessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * @author Eugene Zhuravlev
 *         Date: 9/29/11
 */
public class SimpleProjectBuilder {

  public static void main(String[] args) throws Throwable {
    final HashMap<String, String> pathVars = new HashMap<String, String>();
    pathVars.put("MAVEN_REPOSITORY", "C:\\Users\\jeka\\.m2\\repository");

    final List<GlobalLibrary> libs = new ArrayList<GlobalLibrary>();
    final BuildParameters params = new BuildParameters(BuildType.MAKE);
    final String jdk6Home = "C:/java/jdk160_27";
    libs.add(new SdkLibrary("1.6", jdk6Home, Arrays.<String>asList(
      jdk6Home + "/jre/lib/plugin.jar",
      jdk6Home + "/jre/lib/charsets.jar",
      jdk6Home + "/jre/lib/jce.jar",
      jdk6Home + "/jre/lib/rt.jar",
      jdk6Home + "/jre/lib/management-agent.jar",
      jdk6Home + "/jre/lib/resources.jar",
      jdk6Home + "/jre/lib/deploy.jar",
      jdk6Home + "/jre/lib/jsse.jar",
      jdk6Home + "/jre/lib/javaws.jar",
      jdk6Home + "/jre/lib/alt-rt.jar",
      jdk6Home + "/jre/lib/ext/sunpkcs11.jar",
      jdk6Home + "/jre/lib/ext/dnsns.jar",
      jdk6Home + "/jre/lib/ext/localedata.jar",
      jdk6Home + "/jre/lib/ext/sunjce_provider.jar",
      jdk6Home + "/lib/tools.jar"
    )));
    final String jdk5Home = "C:/java/jdk150_22";
    libs.add(new SdkLibrary("1.5", jdk5Home, Arrays.<String>asList(
      jdk5Home + "/jre/lib/plugin.jar",
      jdk5Home + "/jre/lib/charsets.jar",
      jdk5Home + "/jre/lib/jce.jar",
      jdk5Home + "/jre/lib/rt.jar",
      jdk5Home + "/jre/lib/management-agent.jar",
      jdk5Home + "/jre/lib/resources.jar",
      jdk5Home + "/jre/lib/deploy.jar",
      jdk5Home + "/jre/lib/jsse.jar",
      jdk5Home + "/jre/lib/javaws.jar",
      jdk5Home + "/jre/lib/alt-rt.jar",
      jdk5Home + "/jre/lib/ext/sunpkcs11.jar",
      jdk5Home + "/jre/lib/ext/dnsns.jar",
      jdk5Home + "/jre/lib/ext/localedata.jar",
      jdk5Home + "/jre/lib/ext/sunjce_provider.jar",
      jdk5Home + "/lib/tools.jar"
    )));

    final Facade facade = Facade.getInstance();
    facade.setGlobals(libs, pathVars);

    facade.startBuild("C:/tmp/CpBuildSample", null, params, new MessageHandler() {
      public void processMessage(BuildMessage msg) {
        System.out.println(msg);
      }
    });
    System.exit(0);
  }

}
