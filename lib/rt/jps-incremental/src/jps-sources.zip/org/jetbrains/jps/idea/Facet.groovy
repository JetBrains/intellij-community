package org.jetbrains.jps.idea

/**
 * @author nik
 */
class Facet {
  String name;
}
