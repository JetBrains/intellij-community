package org.jetbrains.jps.server;

/**
* @author Eugene Zhuravlev
*         Date: 9/10/11
*/
public enum BuildType {
  REBUILD, MAKE, CLEAN
}
