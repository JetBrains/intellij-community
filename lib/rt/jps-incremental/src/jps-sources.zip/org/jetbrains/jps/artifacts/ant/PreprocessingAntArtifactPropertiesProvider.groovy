package org.jetbrains.jps.artifacts.ant

/**
 * @author nik
 */
class PreprocessingAntArtifactPropertiesProvider extends AntArtifactPropertiesProvider {
  public static final String ID = "ant-preprocessing"

  PreprocessingAntArtifactPropertiesProvider() {
    super(ID)
  }
}
