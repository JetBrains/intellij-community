package com.intellij.ui;

/**
 * @author oleg
 */
public interface CheckBoxListListener {
  void checkBoxSelectionChanged(int index, boolean value);
}
