/*
 * @(#)Enum.java	1.3 03/08/11
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package java.lang;

import java.util.List;
import java.util.Iterator;
import java.io.ObjectStreamException;
import java.io.InvalidObjectException;
import java.io.Serializable;

/**
 * This is the common base class of all Java language enumeration types.
 *
 * @author  Neal Gafter
 * @version 1.3, 08/11/03
 * @since   1.5
 */
public class Enum<E extends Enum<E>> implements Comparable<E>, Serializable {

    /**
     * The name of this enum constant, as declared in the enum declaration.
     * Most programmers should use the {@link #toString} method rather than
     * accessing this field.
     */
    public final String name;

    /**
     * The ordinal of this enumeration constant (its position
     * in the enum declaration, where the initial constant is assigned
     * an ordinal of zero).
     * 
     * Most programmers will have no use for this field.  It is designed
     * for use by sophisticated enum-based data structures, such as
     * {@link java.util.EnumSet} and {@link java.util.EnumMap}.
     */
    public transient final int ordinal;

    /**
     * Sole constructor.  Programmers cannot invoke this constructor.
     * It is for use by code emitted by the compiler in response to
     * enum class declarations.
     *
     * @param name - The name of this enum constant, which is the identifier
     *               used to declare it.
     * @param ordinal - The ordinal of this enumeration constant (its position
     *         in the enum declaration, where the initial constant is assigned
     *         an ordinal of zero).
     */
    protected Enum(String name, int ordinal) {
	this.name = name;
	this.ordinal = ordinal;
    }

    /**
     * Returns the name of this enum constant, as contained in the
     * declaration.  This method may be overridden, though it typically
     * isn't necessary or desirable.  An enum class should override this
     * method when a more "programmer-friendly" string form exists.
     *
     * @return the name of this enum constant
     */
    public String toString() {
	return name;
    }

    /**
     * Returns true if the specified object is equal to this
     * enum constant.
     *
     * @param other the object to be compared for equality with this object.
     * @return  true if the specified object is equal to this
     *          enum constant.
     */
    final public boolean equals(Object other) { 
        return this==other;
    }

    /**
     * Returns a hash code for this enum constant.
     *
     * @return a hash code for this enum constant.
     */
    final public int hashCode() {
        return System.identityHashCode(this);
    }

    /**
     * Throws CloneNotSupportedException.  This guarantees that enums
     * are never cloned, which is necessary to preserve their "singleton"
     * status.
     *
     * @return (never returns)
     */
    final protected Object clone() throws CloneNotSupportedException {
	throw new CloneNotSupportedException();
    }

    /**
     * Compares this enum with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * 
     * Enum constants are only comparable to other enum constants of the
     * same enum class.  The natural order implemented by this
     * method is the order in which the constants are declared.
     */
    public int compareTo(E o) {
	Enum other = (Enum)o;
	Enum self = this;
	if (self.family() != other.family()) throw new ClassCastException();
        return self.ordinal - other.ordinal;
    }

    /**
     * Returns an immutable list of all the enum constants in this
     * enum constant's enum class.  This should be abstract, but isn't
     * due to a bug in the generic compiler.
     *
     * @return an immutable list of all of the enum constants in this
     *         enum constant's enum class.
     */
    public List<E> family() { throw new AssertionError(); }

    /**
     * This helper function exists in the prototype only; it will not
     * appear in the final implementation.  It is a shortcut to help
     * implement Enumtype.valueOf(String).
     */
    protected static <E extends Enum<E>> E valueOf(List<E> family, String name) {
	for (Iterator<E> i = family.iterator(); i.hasNext(); ) {
	    E e = i.next();
	    if (e.name.equals(name)) return e;
	}
	throw new IllegalArgumentException(name);
    }

    /**
     * This method ensures proper deserialization of enum constants.
     * 
     * @return the canonical form of this desesrialized enum const.
     */
    protected final Object readResolve() throws ObjectStreamException {
        // prototype implementation; known to be slow
        for (Iterator<E> i = this.family().iterator(); i.hasNext(); ) {
            E e = i.next();
            if (e.name.equals(name))
                return e;
        }
        throw new InvalidObjectException("Enum const " + name +
					 " no longer exists in " + getClass().getName());
    }
}
