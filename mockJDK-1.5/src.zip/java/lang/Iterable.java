/*
 * @(#)Iterable.java	1.1 03/05/20
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package java.lang;

/** Implementing this interface allows an object to be the object of
 *  the foreach statement. */
public interface Iterable<T> {
    /**
     * Returns an iterator over a set of elements of type T.
     * 
     * @return a SimpleIterator.
     */
    SimpleIterator<T> iterator();
}
