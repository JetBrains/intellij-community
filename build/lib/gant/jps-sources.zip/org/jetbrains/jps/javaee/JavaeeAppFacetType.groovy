package org.jetbrains.jps.javaee

/**
 * @author nik
 */
public class JavaeeAppFacetType extends JavaeeFacetTypeBase {
  JavaeeAppFacetType() {
    super("javaeeApplication")
  }
}
