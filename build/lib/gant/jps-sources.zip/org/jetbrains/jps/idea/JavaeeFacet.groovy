package org.jetbrains.jps.idea

/**
 * @author nik
 */
class JavaeeFacet extends Facet {
  final List<Map<String, String>> descriptors = []
  final List<Map<String, String>> webRoots = []
}
