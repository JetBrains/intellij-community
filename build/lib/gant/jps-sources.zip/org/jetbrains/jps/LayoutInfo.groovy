package org.jetbrains.jps

/**
 * @author nik
 */
class LayoutInfo {
  Set<String> usedModules = [] as Set
}
