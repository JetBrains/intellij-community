package lib.named;

public class C {
}
