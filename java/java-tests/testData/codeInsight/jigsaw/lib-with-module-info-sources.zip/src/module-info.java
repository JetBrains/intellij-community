module lib.with.module.info {
    exports lib.named;
}