package ppp;

/**
 * Created by IntelliJ IDEA.
 * User: JEKA
 * Date: Sep 11, 2008
 * Time: 4:01:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class BadClass {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
