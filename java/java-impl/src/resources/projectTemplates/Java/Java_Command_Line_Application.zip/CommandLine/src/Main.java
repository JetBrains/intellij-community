public class Main {

    public static int main(String[] args) {
	// write your code here
    }
}
