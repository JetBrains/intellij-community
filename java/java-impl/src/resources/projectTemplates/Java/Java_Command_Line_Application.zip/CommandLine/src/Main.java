/**
 * This is the entry point for Java console application
 */
public class Main {

    public static int main(String[] args) {
        return
    }
}
