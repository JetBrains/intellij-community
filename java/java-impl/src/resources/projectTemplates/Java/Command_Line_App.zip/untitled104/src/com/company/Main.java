#if ("$!IJ_BASE_PACKAGE" != "")
package ${IJ_BASE_PACKAGE};

#end
public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
